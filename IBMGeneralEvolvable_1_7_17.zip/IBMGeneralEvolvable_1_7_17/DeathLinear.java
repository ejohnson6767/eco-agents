import java.io.Serializable;
import java.util.ArrayList;

public class DeathLinear implements IDeathProcess, Serializable
{
	private Community com;
	private ISpecies speciesOwner;
	private double deathRate;
	private int speciesValue;

	public DeathLinear(double deathRate)
	{
		//this.com = com;
		this.deathRate = deathRate;
	}
	
	public double getDeathRate(Location loc)
	{
		/*double realizedDeathRate = 0;
		ArrayList<ISpecies> speciesList = this.com.getSpeciesList();
		for (int i = 0; i < speciesList.size(); i++)
		{
			LocalLV localLV = speciesList.get(i).getLocalLV();
			if (localLV != null)
			{
				// LVEffect[] lVEffect = this.com.getLVEffects((i+1), this.speciesValue);

				LVEffectsOnOneHetero[] lVEffectsOnAllHeteros = localLV.getLVEffectsOnAllHeteros();

				LVEffectsOnOneHetero lVEffectsOnOneHetero = lVEffectsOnAllHeteros[this.speciesValue - 1];
				if (lVEffectsOnOneHetero != null)
				{
					LVEffect[] lVEffects = lVEffectsOnOneHetero.getLVEffects();

					for (int j = 0; j < lVEffects.length; j++)
					{
						realizedDeathRate += this.deathRate * lVEffects[j].getEffect(loc);
					}
				}

			}
		}
		return realizedDeathRate;*/
		double realizedDeathRate = 0;
		ArrayList<IEffect> lvEffects= this.speciesOwner.getAffectingLVEffects();
		
		
		for(int i = 0; i < lvEffects.size(); i++)
		{
			
		realizedDeathRate += this.deathRate * lvEffects.get(i).getEffect(loc);
		}

		return realizedDeathRate;
	}
	
	
	
	public void scaleByDt(double dt)
	{
		this.deathRate *= dt;
		
	}
	
	public void setSpeciesOwner(ISpecies species)
	{
		this.speciesOwner = species;
		
	}
	
	public void setupAfterCommunityIsCreated(Community com)
	{
		this.com = com;
		this.speciesValue = this.speciesOwner.getGridProxy();
	}
}
