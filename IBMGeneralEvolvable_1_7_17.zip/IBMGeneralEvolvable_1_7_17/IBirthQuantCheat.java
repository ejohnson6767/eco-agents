
public interface IBirthQuantCheat
{

	void setQ(IQuantCheatQ quantCheatQIB, int indicator);


	IQuantCheatQ getQ(int indicator);

}
