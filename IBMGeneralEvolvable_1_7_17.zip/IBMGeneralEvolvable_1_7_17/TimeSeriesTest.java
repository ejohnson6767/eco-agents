import java.util.ArrayList;

public class TimeSeriesTest
{
	// community constructor params //int envLength, int numSpecies, int radius, double fractionToFill, int initAbund)
	// varying area lots little
	// length radius 20 19 18 17 16 15 14 13 12 11 10 9 8 7 6 5 4 3 2 1
	// width radius 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39

	// varying perim lots
	// length radius 20 17 15 14 13 12 11 10 9 8 7 6 5 4
	// width radius 20 24 27 28 31 33 36 40 44 49 56 66 80 100

	// varying perim lots
	// length radius 50 30 21 16 13 11 8
	// width radius 1 2 3 4 5 6 8
	private static int timeStepCounter; // will give you an idea of how many time steps the simulation has been running for
	// private static Community community;
	private static Community community;

	// how long should the donut be?
	private static int gridLength = 200;
	private static float[] pixels = new float[gridLength * gridLength * 3];

	// construct species and put them in an array list. The format for species is given below:

	// Species(int speciesName, int initialAbundance, double cmax, double d, int dispersalRadius,
	// boolean makesAA1, boolean makesAA2, boolean makesAA3,
	// int AA1K, int AA2K, int AA3K)
	private static double dt = 1.0;

	private static boolean neverInoculate = false;

	private static double propToStart = 0.80;
	private static double initProp = 0.1;
	private static double r1 = 0.90;
	private static double r2 = 0.90;
	private static double a11 = 0.0;
	private static double a12 = 0.0;
	private static double a21 = 0.0;
	private static double a22 = 0.0;

	private static double n1Death = 0.2;
	private static double n2Death = 0.2;

	private static double d11 = 0.0;
	private static double d12 = 0.0;
	private static double d21 = 0.0;
	private static double d22 = 0.0;

	private static int n1InitAbund = 100;
	private static int n2InitAbund = 100;

	private static boolean n1MultiplyB = false;
	private static boolean n1MultiplyD = false;
	private static boolean n1TrueLV = false;
	private static int n1DispersalRadius = 40;
	private static int n1Inoculation = 0;
	private static int n1EvolveStart = 500;
	private static int startTradeOff = 2000000;

	private static boolean n2MultiplyB = false;
	private static boolean n2MultiplyD = false;
	private static boolean n2TrueLV = false;
	private static int n2DispersalRadius = 1;
	private static int n2Inoculation = 0;
	private static int n2EvolveStart = 500;

	private static int invaderValue = 1;
	private static int invasionStart = 500000;
	private static double initialDensity = 0.005;
	private static double tooLow = 0.001;
	private static double tooHigh = 0.05;
	private static int regulateInvadersThisOften = 1;
	private static int archiveOldTraitsThisOften = 10;
	private static boolean overwrite = false;

	private static boolean useAltApproach = true;
	private static boolean hasRecruitmentGrid = false;

	// private static double cmaxSynmakesAA3 = 0.60;

	private static int stepsUntilInoculateCheater = 0;
	private static int stepsUntilInoculateGeneralist = 200;
	private static int scatterHowOften = 100000;

	// how far can species dispersal in any direction
	private static int interactionRadius = 1;

	// how many amino acids does each critter produce?

	private static boolean pause = false;
	private static boolean inoculateCheater = false;

	private static ArrayList<ISpecies> speciesList = new ArrayList<ISpecies>();

	private static int numberOfSpecies;

	private static int numSteps = 100;
	private static int measureHowOften = 1;

	public static void main(String[] args) throws Exception
	{
		speciesList = new ArrayList<ISpecies>();

		speciesList.add(new Species(r1, n1Death, n1DispersalRadius));
		speciesList.add(new Species(r2, n2Death, n2DispersalRadius));

		IEffect lv1 = new Effect(8, 1);
		IEffect lv2 = new Effect(8, 2);

		// speciesList.get(0).setLocalLVEffect(2, lv1);
		// speciesList.get(1).setLocalLVEffect(1, lv2);

		IBirthProcess bl = new BirthLinear(r2);
		IDeathProcess d1 = new DeathLinear(n1Death);

		// IBirthProcess bl = new BirthAdditive(r2);
		// IDeathProcess d1 = new DeathAdditive(n1Death);

		// speciesList.get(0).setDeathProcess(d1);
		// speciesList.get(1).setBirthProcess(bl);

		IMutationFunction mfDifn1 = new MutationFunctionDiscreteBoundedByZero(0.1, 1);
		Evolvable diffusionEvolven1 = new DiffusionIB(mfDifn1, 2, 1, lv1);

		IMutationFunction mfDifn2 = new MutationFunctionDiscreteBoundedByZero(0.1, 1);
		Evolvable diffusionEvolven2 = new DiffusionIB(mfDifn2, 1, 1, lv2);

		IMutationFunction mfEff = new MutationFunctionContinuous(0.00, 0.05);
		Evolvable effectValueEvolve = new EffectValueIB(mfEff, 2, 1, lv1);

		IMutationFunction mfDisp = new MutationFunctionDiscreteBoundedByOne(0.05, 1);
		Evolvable dispEvolven1 = new DispersalIB(mfDisp);

		IMutationFunction mfDispn2 = new MutationFunctionDiscreteBoundedByOne(0.005, 1);
		Evolvable dispEvolven2 = new DispersalIB(mfDispn2);

		IMutationFunction mfEvolveProb = new MutationFunctionContinuousBoundedByZero(0.05, 0.03);
		Evolvable evolveProbEvolve = new EvolveProbIB(mfEvolveProb, mfDisp);

		IMutationFunction mfmm = new MutationFunctionContinuousBoundedByZero(0.05, 0.5);
		Evolvable mmEvolve = new MutationMagnitudeIB(mfmm, mfDisp);

		// speciesList.get(0).setHomeGridValue(1);
		// speciesList.get(1).setHomeGridValue(2);

		// speciesList.get(0).setEnvGridValuesThatAffectRecruitment(new int[] { 1, 2 });
		// speciesList.get(1).setEnvGridValuesThatAffectRecruitment(new int[] { 2 });

		// ContinuousTrait trait1 = new ContinuousTrait(gridLength, 0.10, 3);
		// DispersalDistance trait2 = new DispersalDistance(gridLength, 0.05, 1);
		// BaselineBirthRate trait2 = new BaselineBirthRate(gridLength, 0.05, 0.05);

		// ArrayList<Evolvable> tradeOffTraits = new ArrayList<Evolvable>();
		// tradeOffTraits.add(trait2);

		// TradeOff tradeOff = new DispersalBirthRateTradeOff(trait1, tradeOffTraits);
		// ArrayList<TradeOff> tradeOffList = new ArrayList<TradeOff>();
		// tradeOffList.add(tradeOff);

		ArrayList<Evolvable> traitList = new ArrayList<Evolvable>();
		// traitList.add(trait1);
		// traitList.add(diffusionEvolve);
		traitList.add(effectValueEvolve);

		// TraitList traitListList = new TraitList(traitList, tradeOffList);
		TraitList traitListList = new TraitList(traitList);
		// traitListList.setTimeBetweenOldTraitUpdates(0);
		// traitListList.setUseAltApproach(useAltApproach);

		// speciesList.get(0).setTraitList(traitListList);
		// speciesList.get(0).addTrait(effectValueEvolve);
		//speciesList.get(0).addTrait(dispEvolven1);
		// speciesList.get(1).addTrait(dispEvolven2);
		// speciesList.get(0).addTrait(diffusionEvolven1);
		// speciesList.get(1).addTrait(diffusionEvolven2);

		// speciesList.get(0).addTrait(evolveProbEvolve);
		// speciesList.get(0).addTrait(mmEvolve);

		// speciesList.get(1).addEvolvableTrait(trait1);
		double[][][] pcGoal = new double[][][] {{{0.8, 0.3},{0.8, 0.3}},{{0.2, 0.7},{0.2, 0.7}}};
		MakeGrids mg = new MakeGrids(gridLength);
		mg.makePairCorrelationGridFromScratch(new int[] {12000}, pcGoal, 10000000, 0.000000001, 10000);
		
		GenericDemographyGrid grid = new GenericDemographyGrid(gridLength);
		grid.setGenericDemographyGrid(mg.getGrid());
		// grid.makePatchyGrid(speciesList.size(), 30, 20, 0.3, 300);
		/*grid.setSeed(20);
		grid.makePercolationGrid(new double[] { 0.80 });

		 grid.makeCheckerboardGrid(gridLength/40, 40, true);*/
		 speciesList.get(0).setRecruitmentGrid(grid, new double[] { 0, 1 });
		 //speciesList.get(1).setRecruitmentGrid(grid, new double[] { 0, 1 });

		// RegionallySimilarSpecies rss = new RegionallySimilarSpecies( grid, speciesList, true);

		// rss.makeSpeciesRateByLocationMatrix(0.8, 0.4, 0, 0.1);
		// rss.applyToSpeciesBirth();

		numberOfSpecies = speciesList.size();

		// Community(int envLength, ArrayList<Species> speciesList)
		// community = new Community(gridLength, dt, interactionRadius, speciesList);
		community = new Community(gridLength, dt, speciesList);

		AddCritters ac = new AddCritters(community, 1, false);
		//ac.setReferenceLocation(100, 100); 
		//ac.setDispersalLength(10); 
		ac.addCrittersRandomly(n1InitAbund);
		
		
		ac = new AddCritters(community, 2, false);
		//ac.setReferenceLocation(100, 100); 
		//ac.setDispersalLength(10); 
		ac.addCrittersRandomly(n2InitAbund);
		
	/*	long start = System.nanoTime();
		for (int j = 0; j < 10; j++)
		{
			community = new Community(gridLength, dt, speciesList);
			for (int i = 0; i < 500; i++)
			{
				community.step();
			}
		}
		
		long end = System.nanoTime();
		long nanoTime = end - start;
		System.out.println("prg fill new " + nanoTime / (double) 1000000000 + " seconds");*/
			 
		
		//int numTests = 2000;
		
		/*
		long start = System.nanoTime();
		for (int i = 0; i < numTests; i++)
		{
			PRG prg = new PRG(community);
			prg.fillGridMovingWindowAllSpeciesNoTraits();
		}
		long end = System.nanoTime();
		long nanoTime = end - start;
		System.out.println("prg fill new " + nanoTime / (double) 1000000000 + " seconds");
		
		long start2 = System.nanoTime();
		for (int i = 0; i < numTests; i++)
		{
			PRG prg2 = new PRG(community);
			prg2.fillGridMovingWindowAllSpeciesNoTraits();
		}
		long end2 = System.nanoTime();
		long nanoTime2 = end2 - start2;
		System.out.println("prg fill old " + nanoTime2 / (double) 1000000000 + " seconds");
		
	*/
		speciesList.get(0).addTrait(dispEvolven1);
		
		community.step(100);
		dispEvolven1.startEvolution();
		
		
		
		
		TimeSeries ts = new TimeSeries(community,2,1, false);
		ArrayList<ITimeSeriesQuantity> tsq = new ArrayList<ITimeSeriesQuantity>();
		//tsq.add(new LambdaTilda(community, 1));
		//tsq.add(new LambdaBar(community, 1));
		//tsq.add(new LambdaDensityCovariance(community, 1));

		//tsq.add(new TimeSeriesPairCorrelation( community, 5, new int[][] {{1, 1, 1},{1,1,2},{1,1,3}} ));
		tsq.add(new TimeSeriesAbundAllSpecies(community, false));
		tsq.add(new TimeSeriesAbundSpeciesSubset(community, false, new int[] {1}));

		TerminateIfSpeciesDiesOrGrowsTooLarge tc = new TerminateIfSpeciesDiesOrGrowsTooLarge(community, 1, .9);
		System.out.println();
		
		//double[][] tsAbund = ts.timeSeries(tsq);
		//double[][] tsAbund = ts.timeSeries(false, tc);
		//double[][] tsAbund = ts.timeSeries(false);
		int[][][] gridTS = ts.gridTimeSeries();
		double[] dub = ArrayFlattener.flatten(gridTS);
		for (int i = 0; i < dub.length; i++)
		{
			System.out.println(dub[i]);
		}
		/*for (int i = 0; i < tsAbund.length; i++)
		{
			for (int j = 0; j < tsAbund[0].length; j++)
			{
				System.out.print(tsAbund[i][j] + "   ");
			}
			System.out.println();

		}*/
	}
}
