import java.util.ArrayList;

public class UpdateAbundances
{
	private Community com;
	
	public UpdateAbundances(Community com)
	{
		this.com = com;
		
	}
	
	public void update()
	{
		int numberOfSpecies = com.getNumberOfSpecies();
		int gridLength = com.getEnvironment().getGridLength();
		Environment env = com.getEnvironment();
		ArrayList<ISpecies> speciesList = com.getSpeciesList();
		//fecundityGrid = new double[gridLength][gridLength][numberOfSpecies];
		int[] critterCounter = new int[numberOfSpecies]; 
	
		// this second main determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius
	
		for (int i = 0; i < env.getHeight(); i++)
		{
		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				int critterValue = env.getGridValue(row, col, i);
				// if it's occupied, pull a random number to see if it dies
				if (critterValue != 0)
				{
					critterCounter[critterValue - 1]++;
				}
			}
		}
		}
		
		//com.setCritterCounter(critterCounter);
		for (int k = 0; k < numberOfSpecies; k++)
		{
			speciesList.get(k).setAbundance(critterCounter[k]);	
		}
	}
}
