 
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class QuantCheatQIB extends ContinuousTrait implements IQuantCheatQ, IEffectValue, Evolvable, Serializable
{
	// private Community com;
	// Environment env;
	private double baselineTrait;
	private int indicator;
	// private int speciesValue;
	// private boolean useAltApproach;
	// private int speciesIndex;
	// private int envGridIndex;
	// private int possibleNeighbors;

	// private double effectPerSite;=
	// private double[][] lVEffectGrid;

	public QuantCheatQIB(IMutationFunction mf, int indicator)
	{
		super(mf);
		this.indicator = indicator;
		// this.com = com;
	}
/*
	public double getEffectPerSite()
	{
		return this.effectPerSite;
	}

	public LVEffectIB(IMutationFunction mf, int affectedSpeciesValue, int affectedSpeciesLVEffectValue) { super(mf); this.lvEffect = null; this.useAltApproach = false; this.affectedSpeciesValue = affectedSpeciesValue; this.affectedSpeciesLVEffectValue = affectedSpeciesLVEffectValue; // this.com = com; }
*/
	public void initializeSpatialDistributionTracker()
	{
		IQuantCheatQ q = ((IBirthQuantCheat) this.species.getBirthProcess()).getQ(this.indicator);
		//System.out.println(q);
		this.baselineTrait = q.getQ(new Location(0, 0));
		this.spatialDistributionTracker = q.getSpatialDistributionTracker();

		((IBirthQuantCheat) this.species.getBirthProcess()).setQ(this, this.indicator);
/*
		System.out.println("STARTING SHIT");
		IQuantCheatQ q = ((IBirthQuantCheat) this.species.getBirthProcess()).getQ(this.indicator);
		System.out.println(q);
		this.spatialDistributionTracker = ((IBirthQuantCheat) this.species.getBirthProcess()).getQ(this.indicator).getSpatialDistributionTracker();

		((IBirthQuantCheat) this.species.getBirthProcess()).setQ(this, this.indicator);*/

		LocalLV locLv = this.species.getLocalLV();
		if (locLv != null)
		{
			// System.out.println("species has local lv");
			LVEffectsOnOneHetero[] h = locLv.getLVEffectsOnAllHeteros();
			if (h != null)
			{
				for (int i = 0; i < h.length; i++)
				{
					LVEffectsOnOneHetero e = h[i];
					if (e != null)
					{
						// System.out.println("species has a heter object for species " + (i + 1));
						IEffect[] es = e.getLVEffects();
						for (int j = 0; j < es.length; j++)
						{
							IEffect cur = es[j];
							if (cur.getIndicator() == this.indicator)
							{

								es[j].setEffectValue(this);
							}
						}
					}
				}
			}
		}
	}

	public void startEvolution()
	{
		this.isEvolving = true;
		this.isIndividualBased = true;
		// setUpAfterCommunityIsCreated(com, this.species.getGridProxy());
		initializeSpatialDistributionTracker();

		
		CommunityUtilsStep.stepPrimer(com);
		//LocalLVAllSpecies lvAll = new LocalLVAllSpecies(com);
		//lvAll.resetAffectingLVEffectsAllSpecies();

		//System.out.println("made species " + species.getGridProxy() + " individual-based and evolvable");
		// System.out.println("is individual based " + this.isIndividualBased);
	}

	public void startBeingIndividualBased()
	{
		this.isIndividualBased = true;
		// setUpAfterCommunityIsCreated(com, this.species.getGridProxy());
		initializeSpatialDistributionTracker();

		CommunityUtilsStep.stepPrimer(com);

		//LocalLVAllSpecies lvAll = new LocalLVAllSpecies(com);
		//lvAll.resetAffectingLVEffectsAllSpecies();

		// System.out.println("made species " + species.getGridProxy() + " individual-based ");
	}

	public boolean isIndividualBased()
	{
		return this.isIndividualBased;
	}

	public double getBaselineTrait()
	{
		// System.out.println("Getting baseline TRAIT: " + com.getAbundances()[this.speciesIndex] );
		if (com.getAbundances()[this.speciesIndex] != 0)
		{
			//System.out.println("species abundances is not zero. Baseline trait is trait average");
			return getTraitAverage();
		}
		else
		{
			// System.out.println(this.baselineTrait);
			return this.baselineTrait;
		}
	}

	public void setSpeciesOwner(ISpecies species)
	{
		// this.species = species;
		// this.lvEffect.setSpeciesOwner(this.species);
	}

	public void setupAfterCommunityIsCreated(Community com)
	{
		// this.com = com;
		// this.gridLength = this.com.getEnvironment().getGridLength();
		// this.baselineTrait = (int) getTraitAverage();
		// IDiffusion dif =this.lvEffect.getDiffusion();
		// this.lvEffect.getDiffusion().setupAfterCommunityIsCreated(com);
		// this.spatialDistributionTracker = new double[gridLength][gridLength];
	}

	public double[][] getSpatialDistributionTracker()
	{
		return this.spatialDistributionTracker;
	}

	@Override
	public double getQ(Location loc)
	{
		return this.spatialDistributionTracker[loc.row()][loc.col()];
	}

	@Override
	public double getEffectValue(int row, int col)
	{
		return this.spatialDistributionTracker[row][col];
	}

	@Override
	public double getEffectValue()
	{
		return -69;
	}

}
