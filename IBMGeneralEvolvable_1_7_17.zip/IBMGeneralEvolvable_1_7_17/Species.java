import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

/**
 * @author Evan
 *
 */
public class Species implements Serializable, ISpecies
{

	/**
	 * 
	 */

	private boolean isInvader;
	private String speciesName;
	private int initialAbundance;
	private double b;
	private double d;
	// private int dispersalRadius;

	private int gridProxy;
	private int inoculateWhen;
	private boolean inoculateOverwrite;

	private DemographyGridKit recruitment;
	private DemographyGridKit birth;
	private DemographyGridKit death;
	private boolean variableRecruitment;
	private boolean variableBirth;
	private boolean variableDeath;
	private TraitList traitList;
	private boolean hasBeenInculated;
	private boolean useMovingWindowForPropaguleRain;
	private int homeGridIndex;
	private int[] envGridIndexesThatAffectRecruitment;

	private IDispersalTrait dispersalStrategy;
	private LocalLV localLV;
	private IBirthProcess birthProcess;
	private IDeathProcess deathProcess;
	private ArrayList<IEffect> affectingLVEffects;
	private Community com;
	private int abundance;
	private ArrayList<ArrayList<IEffect>> affectingLVEffectsByIndicator;
	private DummyTrait dummyTraitForIBFitness;

	/**
	 * A species object ontains information that lets the simulation methods know how to treat individuals.
	 * Importantly, a species object knows nothing about the location or number of individuals.
	 */

	public Species(double b, double d, int dispersalAbility /* int dispersalRadius, */)
	{
		this.speciesName = null;

		// this.dispersalRadius = dispersalRadius;

		this.initialAbundance = 0;
		this.gridProxy = 0;
		this.inoculateWhen = 0;
		this.inoculateOverwrite = true;
		this.variableRecruitment = false;
		this.variableBirth = false;
		this.variableDeath = false;
		this.isInvader = false;
		this.traitList = null;
		this.hasBeenInculated = false;
		this.useMovingWindowForPropaguleRain = false;
		/*
		 * if (this.dispersalAbility > 1) { this.useMovingWindowForPropaguleRain = true; }
		 */
		this.envGridIndexesThatAffectRecruitment = new int[] { 0 };
		this.homeGridIndex = 0;
		this.dispersalStrategy = new DispersalStrategyStandard(dispersalAbility, this);
		this.localLV = null;
		this.affectingLVEffects = new ArrayList<IEffect>();
		this.affectingLVEffectsByIndicator = new ArrayList<ArrayList<IEffect>>();
		this.birthProcess = new BirthStandard(b);
		this.deathProcess = new DeathStandard(d);
		this.com = null;
		this.recruitment = null;
		this.birth = null;
		this.death = null;
		this.abundance = 0;

	}

	public Species(String speciesName1, double b, double d, int dispersalAbility /* int dispersalRadius, */)
	{
		this.speciesName = speciesName1;

		// this.dispersalRadius = dispersalRadius;

		this.initialAbundance = 0;
		this.gridProxy = 0;
		this.inoculateWhen = 0;
		this.inoculateOverwrite = true;
		this.variableRecruitment = false;
		this.variableBirth = false;
		this.variableDeath = false;
		this.isInvader = false;
		this.traitList = null;
		this.hasBeenInculated = false;
		this.useMovingWindowForPropaguleRain = false;
		/*
		 * if (this.dispersalAbility > 1) { this.useMovingWindowForPropaguleRain = true; }
		 */
		this.envGridIndexesThatAffectRecruitment = new int[] { 0 };
		this.homeGridIndex = 0;
		this.dispersalStrategy = new DispersalStrategyStandard(dispersalAbility, this);
		this.localLV = null;
		this.affectingLVEffects = new ArrayList<IEffect>();
		this.affectingLVEffectsByIndicator = new ArrayList<ArrayList<IEffect>>();
		this.birthProcess = new BirthStandard(b);
		this.deathProcess = new DeathStandard(d);
		this.com = null;
		this.abundance = 0;

	}

	public Species(double b, double d, int dispersalAbility, int initialAbundance, int inoculateWhen, boolean inoculateOverwrite /* int dispersalRadius, */)
	{
		this.speciesName = null;
		// this.dispersalRadius = dispersalRadius;
		this.initialAbundance = initialAbundance;
		this.gridProxy = 0;
		this.inoculateWhen = inoculateWhen;
		this.inoculateOverwrite = inoculateOverwrite;
		this.variableRecruitment = false;
		this.variableBirth = false;
		this.variableDeath = false;
		this.isInvader = false;
		this.traitList = null;
		this.hasBeenInculated = false;
		this.useMovingWindowForPropaguleRain = false;
		/*
		 * if (this.dispersalAbility > 1) { this.useMovingWindowForPropaguleRain = true; }
		 */
		this.envGridIndexesThatAffectRecruitment = new int[] { 0 };
		this.homeGridIndex = 0;
		this.dispersalStrategy = new DispersalStrategyStandard(dispersalAbility, this);
		this.localLV = null;
		this.affectingLVEffects = new ArrayList<IEffect>();
		this.affectingLVEffectsByIndicator = new ArrayList<ArrayList<IEffect>>();
		this.birthProcess = new BirthStandard(b);
		this.deathProcess = new DeathStandard(d);
		this.com = null;
		this.abundance = 0;

	}

	public Species(String speciesName1, double b, double d, int dispersalAbility, int initialAbundance, int inoculateWhen, boolean inoculateOverwrite /* int dispersalRadius, */)
	{
		this.speciesName = speciesName1;

		// this.dispersalRadius = dispersalRadius;

		this.initialAbundance = initialAbundance;
		this.gridProxy = 0;
		this.inoculateWhen = inoculateWhen;
		this.inoculateOverwrite = inoculateOverwrite;
		this.variableRecruitment = false;
		this.variableBirth = false;
		this.variableDeath = false;
		this.isInvader = false;
		this.traitList = null;
		this.hasBeenInculated = false;
		this.useMovingWindowForPropaguleRain = false;
		/*
		 * if (this.dispersalAbility > 1) { this.useMovingWindowForPropaguleRain = true; }
		 */
		this.envGridIndexesThatAffectRecruitment = new int[] { 0 };
		this.homeGridIndex = 0;
		this.dispersalStrategy = new DispersalStrategyStandard(dispersalAbility, this);
		this.localLV = null;
		this.affectingLVEffects = new ArrayList<IEffect>();
		this.affectingLVEffectsByIndicator = new ArrayList<ArrayList<IEffect>>();
		this.birthProcess = new BirthStandard(b);
		this.deathProcess = new DeathStandard(d);
		this.com = null;
		this.abundance = 0;
	}

	// this is a very important method. Certain aspect of a species (the dispersal process, birth process, local lv effects diffusion process) may need to communicate with parts of the community (the environment, the species).
	public void setupSpeciesAfterCommunityIsCreated(Community com)
	{
		this.com = com;
		this.dispersalStrategy.setupAfterCommunityIsCreated(this.com);
		if (this.traitList != null)
		{
			this.traitList.setupAfterCommunityisCreated(this.com);
		}
		if (this.localLV != null)
		{
			this.localLV.setSpeciesOwner(this);
			this.localLV.setupAfterCommunityIsCreated(this.com);
		}
		this.birthProcess.setSpeciesOwner(this);
		this.birthProcess.setupAfterCommunityIsCreated(this.com);

		this.deathProcess.setSpeciesOwner(this);
		this.deathProcess.setupAfterCommunityIsCreated(this.com);

	}

	public LocalLV getLocalLV()
	{
		return this.localLV;
	}

	public int[] getEnvGridsThatAffectRecruitment()
	{
		return this.envGridIndexesThatAffectRecruitment;
	}

	public void setEnvGridIndexesThatAffectRecruitment(int[] envGridIndexesThatAffectRecruitment)
	{
		// this.envGridIndexesThatAffectRecruitment = new int[envGridIndexesThatAffectRecruitment.length];
		this.envGridIndexesThatAffectRecruitment = envGridIndexesThatAffectRecruitment;
	}

	public void setEnvGridValuesThatAffectRecruitment(int[] envGridValuesThatAffectRecruitment)
	{
		this.envGridIndexesThatAffectRecruitment = new int[envGridValuesThatAffectRecruitment.length];
		for (int i = 0; i < envGridValuesThatAffectRecruitment.length; i++)
		{
			this.envGridIndexesThatAffectRecruitment[i] = envGridValuesThatAffectRecruitment[i] - 1;
		}

	}

	public int getHomeGridIndex()
	{
		return this.homeGridIndex;
	}

	public void setHomeGridValue(int homeGridValue)
	{
		this.homeGridIndex = homeGridValue - 1;
	}

	public boolean isOnGrid()
	{
		return this.abundance > 0;
	}

	public boolean hasBeenInoculated()
	{
		return this.hasBeenInculated;
	}

	public void setHasBeenInoculated(boolean inoculated)
	{
		this.hasBeenInculated = inoculated;
	}

	public void setTraitList(TraitList traitList)
	{

		this.traitList = traitList;
		this.traitList.setSpeciesOwner(this);
		/*
		 * if (this.com != null) { this.traitList.setupAfterCommunityisCreated(this.com); }
		 */
	}

	public void addTrait(Evolvable trait)
	{
		if (this.traitList == null)
		{
			this.traitList = new TraitList(new ArrayList<Evolvable>(Arrays.asList(trait)));
			this.traitList.setSpeciesOwner(this);

		}
		else
		{
			this.traitList.getList().add(trait);
			this.traitList.setSpeciesOwner(this);

		}

		if (this.com != null)
		{
			this.traitList.setupAfterCommunityisCreated(this.com);
		}

		if (this.com != null)
		{
			this.traitList.setRandomGenerator(this.com.getEnvironment().getGenerator(this.homeGridIndex));
		}
	}

	public DummyTrait getDummyTrait()
	{
		return this.dummyTraitForIBFitness;
	}

	public void addDummyTrait(DummyTrait trait)
	{
		if (this.traitList == null)
		{
			this.traitList = new TraitList(new ArrayList<Evolvable>(Arrays.asList(trait)));
			this.traitList.setSpeciesOwner(this);
			this.dummyTraitForIBFitness = trait;

		}
		else
		{
			this.traitList.getList().add(trait);
			this.traitList.setSpeciesOwner(this);
			this.dummyTraitForIBFitness = trait;

		}

		if (this.com != null)
		{
			this.traitList.setupAfterCommunityisCreated(this.com);
		}

		if (this.com != null)
		{
			this.traitList.setRandomGenerator(this.com.getEnvironment().getGenerator(this.homeGridIndex));
		}
	}

	public TraitList getTraitList()
	{
		return this.traitList;
	}

	public void speciesGridLengthConcordanceWithEnvironentGridLength(Environment env)
	{
		if (this.variableBirth)
		{
			GenericDemographyGrid gdg = this.birth.getGenericDemographyGrid();
			if (gdg != null)
			{
				if (gdg.getGrid().length != env.getGridLength())
				{
					throw new IllegalStateException("species birth grid is a different size from the shared environment grid");
				}
			}
		}
		if (this.variableDeath)
		{
			if (this.death.getGenericDemographyGrid().getGrid().length != env.getGridLength())
			{
				throw new IllegalStateException("species death grid is a different size from the shared environment grid");
			}
		}
		if (this.variableRecruitment)
		{
			// this.recruitment.getGenericDemographyGrid().getGrid();
			System.out.println(this.recruitment.getGenericDemographyGrid().getGrid().length);
			System.out.println(env.getGridLength());
			if (this.recruitment.getGenericDemographyGrid().getGrid().length != env.getGridLength())
			{
				throw new IllegalStateException("species recruitment grid is a different size from the shared environment grid");
			}
		}
	}

	public void setRecruitmentGrid(GenericDemographyGrid grid, double[] rates) throws Exception
	{
		this.recruitment = new DemographyGridKit(grid, rates);
		this.variableRecruitment = true;

	}

	public double[][] getRecruitmentGrid()
	{
		DemographyGridKit r = this.recruitment;
		if (r != null)
		{
			return r.getSpecificDemographyGrid();
		}
		else
		{
			int gridLength = this.com.getEnvironment().getGridLength();
			double[][] recGrid = new double[gridLength][gridLength];
			for (int i = 0; i < recGrid.length; i++)
			{
				Arrays.fill(recGrid[i], 1.0);
			}
			return recGrid;
		}
	}

	public void setBirthGrid(GenericDemographyGrid grid, double[] rates) throws Exception
	{
		this.birth = new DemographyGridKit(grid, rates);
		this.variableBirth = true;
	}

	public void setBirthGrid(double[][] specificDemographyGrid)
	{
		this.birth = new DemographyGridKit(specificDemographyGrid);
		this.variableBirth = true;
	}

	public DemographyGridKit getBirthGrid()
	{
		return this.birth;
	}

	public void setDeathGrid(GenericDemographyGrid grid, double[] rates) throws Exception
	{
		this.death = new DemographyGridKit(grid, rates);
		this.variableDeath = true;
	}

	public void setIsInvader(boolean isInvader)
	{
		this.isInvader = isInvader;
	}

	public boolean isInvader()
	{
		return isInvader;
	}

	/*
	 * public int getBaselineDispersalAbility() { return this.dispersalAbility; }
	 */

	/*
	 * public int getDispersalAbility(Location loc) { int dispersalAbility = this.dispersalAbility; if (this.traitList != null) { ArrayList<Evolvable> traits = this.traitList.getList();
	 * 
	 * for (int i = 0; i < traits.size(); i++) { if (traits.get(i).isDispersal()) { if (traits.get(i).isIndividualBased()) { dispersalAbility = (int) traits.get(i).getTrait(loc); } } } } return dispersalAbility;
	 * 
	 * }
	 */

	/*
	 * public void setDispersalAbility(int dispersalAbility) { this.dispersalAbility = dispersalAbility; }
	 */

	/**
	 * If true, then heterospecific individuals can be overwritten during the inoculation period.
	 */
	public boolean getInoculateOverwrite()
	{
		return this.inoculateOverwrite;
	}

	/**
	 * Sets whether heterospecific individuals can be overwritten during the inoculation period. 
	 */
	public void setInoculateOverwrite(boolean inoculateOverwrite)
	{
		this.inoculateOverwrite = inoculateOverwrite;
	}

	/**
	 * Gets the time at which the species is inoculated.
	 */
	public int getInoculateWhen()
	{
		return this.inoculateWhen;
	}

	/**
	 * Sets the time at which the species is inoculated.
	 */
	public void setInoculateWhen(int inoculateWhen)
	{
		this.inoculateWhen = inoculateWhen;
	}

	/**
	 * Sets the integer proxy that will denote the species' locations on the environment grid. In the community constructor, this is set up so the gridProxy is the index of the species in the specieslist, plus one (because one is empty space).
	 */
	public void setGridProxy(int gridProxy)
	{
		this.gridProxy = gridProxy;
	}

	/**
	 * Gets the integer proxy that will denote the species' locations on the environment grid. In the community constructor, this is set up so the gridProxy is the index of the species in the specieslist, plus one (because one is empty space).
	 */
	public int getGridProxy()
	{
		return this.gridProxy;
	}

	/**
	 * Gets the name of the species. If the user did not construct the species list from scratch, but instead used the MakeSpeciesList class or the Community constructor, then the species name will indicate what amino acids the species produces (e.g. 0 is the cheater; 123 is the generalist).
	 */
	public String getSpeciesName()
	{
		System.out.println(this.speciesName);
		return this.speciesName;
	}

	/**
	 * Gets the name of the species. If the user did not construct the species list from scratch, but instead used the MakeSpeciesList class or the Community constructor, then the species name will indicate what amino acids the species produces (e.g. 0 is the cheater; 123 is the generalist).
	 */
	public void setSpeciesName(String speciesName)
	{
		this.speciesName = speciesName;
	}

	/**
	 * Gets the species abundance when it is inoculated.
	 */
	public int getInitialAbundance()
	{
		return this.initialAbundance;
	}

	/**
	 * Sets the species abundance when it is inoculated.
	 */
	public void setInitialAbundance(int initialAbundance)
	{
		this.initialAbundance = initialAbundance;
	}

	public double getBirthRate(Location loc)
	{

		return this.birthProcess.getBirthRate(loc);
	}

	public double getDeathRate(Location loc)
	{
		return this.deathProcess.getDeathRate(loc);
	}

	public boolean canRecruitAtEmptySite(Community com, Location loc)
	{

		boolean canRecruit = true;
		if (this.variableRecruitment)
		{
			Random generator = com.getEnvironment().getGenerator(this.homeGridIndex);
			double rand = generator.nextDouble();
			if (rand > this.recruitment.getRate(loc))
			{
				canRecruit = false;
			}
		}
		return canRecruit;
	}

	public boolean canRecruit(Community com, Location loc)
	{

		int row = loc.row();
		int col = loc.col();
		for (int i = 0; i < this.envGridIndexesThatAffectRecruitment.length; i++)
		{
			int height = this.envGridIndexesThatAffectRecruitment[i];

			int gridValue = com.getEnvironment().getGridValue(row, col, height);
			if (gridValue != 0)
			{
				return false;
			}
		}

		if (this.variableRecruitment)
		{
			Random generator = com.getEnvironment().getGenerator(this.homeGridIndex);

			double rand = generator.nextDouble();
			if (rand > this.recruitment.getRate(loc))
			{
				return false;
			}
		}

		return true;

	}

	public boolean canRecruitIfCritterCanOverwriteHeterospecifics(Community com, Location loc)
	{

		int row = loc.row();
		int col = loc.col();
		for (int i = 0; i < this.envGridIndexesThatAffectRecruitment.length; i++)
		{
			int height = this.envGridIndexesThatAffectRecruitment[i];
			int gridValue = com.getEnvironment().getGridValue(row, col, height);

			if (height != this.homeGridIndex)
			{
				if (gridValue != 0)
				{
					return false;
				}
			}
			else
			{
				if (gridValue != 0)
				{
					if (gridValue == this.gridProxy)
					{
						return false;
					}
				}
			}
		}

		// System.out.println("trying to recruit on someone else or empty space - sure!");
		if (this.variableRecruitment)
		{
			Random generator = com.getEnvironment().getGenerator(this.homeGridIndex);

			double rand = generator.nextDouble();
			if (rand > this.recruitment.getRate(loc))
			{
				return false;
			}
		}
		return true;
	}

	public double getAverageRecruitment(Community com, Location loc)
	{

		int dispersalRadius = this.dispersalStrategy.getDispersalRadius(loc);
		Environment env = com.getEnvironment();
		int gridLength = env.getGridLength();

		int row = loc.row();
		int col = loc.col();
		double total = 0;
		int counter = 0;
		for (int row2 = row - dispersalRadius; row2 <= row + dispersalRadius; row2++)
		{
			for (int col2 = col - dispersalRadius; col2 <= col + dispersalRadius; col2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				total += this.recruitment.getRate(realRow, realCol);
				counter++;
			}
		}

		// correct for the focal space
		total -= this.recruitment.getRate(row, col);
		counter--;

		return total / (double) counter;

	}

	public double getProportionOfViablePropagules(Location loc)
	{
		int dispersalRadius = this.dispersalStrategy.getDispersalRadius(loc);
		Environment env = com.getEnvironment();
		int gridLength = env.getGridLength();

		int row = loc.row();
		int col = loc.col();
		double total = 0;
		int counter = 0;
		for (int row2 = row - dispersalRadius; row2 <= row + dispersalRadius; row2++)
		{
			for (int col2 = col - dispersalRadius; col2 <= col + dispersalRadius; col2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);

				boolean siteMatters = true;
				for (int i = 0; i < this.envGridIndexesThatAffectRecruitment.length; i++)
				{
					if (env.getGridValue(realRow, realCol, this.envGridIndexesThatAffectRecruitment[i]) != 0)
					{
						siteMatters = false;
						break;
					}
				}
				if (siteMatters)
				{
					total += this.recruitment.getRate(realRow, realCol);
				}
				counter++;

			}
		}

		boolean siteMatters = true;
		for (int i = 0; i < this.envGridIndexesThatAffectRecruitment.length; i++)
		{
			if (env.getGridValue(row, col, this.envGridIndexesThatAffectRecruitment[i]) != 0)
			{
				siteMatters = false;
				break;
			}
		}
		if (siteMatters)
		{
			total -= this.recruitment.getRate(row, col);
		}
		counter--;

		return total / (double) counter;

	}

	public double getProportionOfEmptySites(Location loc)
	{

		int dispersalRadius = this.dispersalStrategy.getDispersalRadius(loc);
		//// System.out.println("dispersal radius is" + dispersalRadius);
		Environment env = com.getEnvironment();
		int gridLength = env.getGridLength();

		int row = loc.row();
		int col = loc.col();
		int total = 0;
		int counter = 0;
		for (int row2 = row - dispersalRadius; row2 <= row + dispersalRadius; row2++)
		{
			for (int col2 = col - dispersalRadius; col2 <= col + dispersalRadius; col2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				total++;
				for (int i = 0; i < this.envGridIndexesThatAffectRecruitment.length; i++)
				{
					if (env.getGridValue(realRow, realCol, this.envGridIndexesThatAffectRecruitment[i]) != 0)
					{
						total--;
						break;

					}
				}

				counter++;
			}
		}

		boolean middleWasIncluded = true;
		for (int i = 0; i < this.envGridIndexesThatAffectRecruitment.length; i++)
		{
			if (env.getGridValue(row, col, this.envGridIndexesThatAffectRecruitment[i]) != 0)
			{
				middleWasIncluded = false;
				break;
			}
		}

		if (middleWasIncluded)
		{
			total--;
		}
		counter--;

		return total / (double) counter;

	}

	public boolean hasVariableRecruitment()
	{
		return this.variableRecruitment;
	}

	public double getFitness(Location loc)
	{

		double birth = getBirthRate(loc);
		if (this.variableRecruitment)
		{
			birth *= getProportionOfViablePropagules(loc);
		}
		else
		{
			birth *= getProportionOfEmptySites(loc);
			//// System.out.println("birth rate for fit is now " + birth );
		}

		double death = getDeathRate(loc);
		double lambda = 1 + birth - death;

		return lambda;
	}

	public boolean useMovingWindowForPropaguleRain()
	{

		return this.useMovingWindowForPropaguleRain;

	}

	public ArrayList<Evolvable> getEvolvableTraits()
	{
		ArrayList<Evolvable> list = new ArrayList<Evolvable>();
		if (this.traitList != null)
		{
			list = this.traitList.getList();
		}
		return list;
	}

	public IDispersalTrait getDispersalStrategy()
	{
		return this.dispersalStrategy;
	}

	public void setDispersalStrategy(IDispersalTrait newDispersalTrait)
	{
		this.dispersalStrategy = newDispersalTrait;
	}

	@Override
	public IBirthProcess getBirthProcess()
	{
		return this.birthProcess;

	}

	public void setBirthProcess(IBirthProcess bp)
	{
		this.birthProcess = bp;
		if (this.com != null)
		{
			this.birthProcess.setupAfterCommunityIsCreated(com);
		}

	}

	public void setDeathProcess(IDeathProcess dp)
	{
		this.deathProcess = dp;
		this.deathProcess.setSpeciesOwner(this);
		if (this.com != null)
		{
			this.deathProcess.setupAfterCommunityIsCreated(com);
		}

	}

	@Override
	public IDeathProcess getDeathProcess()
	{
		return this.deathProcess;
	}

	public void setLocalEffects(LocalLV localLV)
	{
		this.localLV = localLV;
		this.localLV.setSpeciesOwner(this);
		if (this.com != null)
		{
			this.localLV.setupAfterCommunityIsCreated(com);
		}

	}

	public void setLocalEffect(int affectedSpeciesValue, double effectValue, int diffusionRadius)
	{
		if (this.localLV != null)
		{
			if (this.localLV.getLVEffectsOnAllHeteros().length >= affectedSpeciesValue)
			{
				LVEffectsOnOneHetero lVEffectsOnOneHetero = this.localLV.getLVEffectsOnAllHeteros()[affectedSpeciesValue - 1];
				if (lVEffectsOnOneHetero != null)
				{
					lVEffectsOnOneHetero.addLVEffect(effectValue, diffusionRadius);
				}
				else
				{
					lVEffectsOnOneHetero = new LVEffectsOnOneHetero(new double[] { effectValue }, new int[] { diffusionRadius });
				}

				this.localLV.setSpeciesOwner(this);
				if (this.com != null)
				{
					this.localLV.setupAfterCommunityIsCreated(com);
				}
			}
			else
			{
				this.localLV.extendHeteroArray(affectedSpeciesValue);
				LVEffectsOnOneHetero lVEffectsOnOneHetero = this.localLV.getLVEffectsOnAllHeteros()[affectedSpeciesValue - 1];
				if (lVEffectsOnOneHetero != null)
				{
					lVEffectsOnOneHetero.addLVEffect(effectValue, diffusionRadius);
				}
				else
				{
					lVEffectsOnOneHetero = new LVEffectsOnOneHetero(new double[] { effectValue }, new int[] { diffusionRadius });
				}
			}

			this.localLV.setSpeciesOwner(this);
			if (this.com != null)
			{
				this.localLV.setupAfterCommunityIsCreated(com);
			}
		}
		else
		{
			this.localLV = new LocalLV(new double[][] { {} }, new int[][] { {} });
			this.localLV.extendHeteroArray(affectedSpeciesValue);
			LVEffectsOnOneHetero[] lVEffectsOnOneHetero = this.localLV.getLVEffectsOnAllHeteros();// [affectedSpeciesValue - 1];
			lVEffectsOnOneHetero[affectedSpeciesValue - 1] = new LVEffectsOnOneHetero(new double[] { effectValue }, new int[] { diffusionRadius });

			this.localLV.setSpeciesOwner(this);
			if (this.com != null)
			{
				this.localLV.setupAfterCommunityIsCreated(com);
			}

		}

	}

	public void setLocalEffect(int affectedSpeciesValue, double effectValue, int diffusionRadius, int indicator)
	{
		if (this.localLV != null)
		{
			if (this.localLV.getLVEffectsOnAllHeteros().length >= affectedSpeciesValue)
			{
				LVEffectsOnOneHetero lVEffectsOnOneHetero = this.localLV.getLVEffectsOnAllHeteros()[affectedSpeciesValue - 1];
				if (lVEffectsOnOneHetero != null)
				{
					lVEffectsOnOneHetero.addLVEffect(effectValue, diffusionRadius, indicator);
				}
				else
				{
					lVEffectsOnOneHetero = new LVEffectsOnOneHetero(new double[] { effectValue }, new int[] { diffusionRadius }, new int[] { indicator });
				}

				this.localLV.setSpeciesOwner(this);
				if (this.com != null)
				{
					this.localLV.setupAfterCommunityIsCreated(com);
				}
			}
			else
			{
				this.localLV.extendHeteroArray(affectedSpeciesValue);
				LVEffectsOnOneHetero lVEffectsOnOneHetero = this.localLV.getLVEffectsOnAllHeteros()[affectedSpeciesValue - 1];
				if (lVEffectsOnOneHetero != null)
				{
					lVEffectsOnOneHetero.addLVEffect(effectValue, diffusionRadius, indicator);
				}
				else
				{
					lVEffectsOnOneHetero = new LVEffectsOnOneHetero(new double[] { effectValue }, new int[] { diffusionRadius }, new int[] { indicator });
				}
			}

			this.localLV.setSpeciesOwner(this);
			if (this.com != null)
			{
				this.localLV.setupAfterCommunityIsCreated(com);
			}
		}
		else
		{
			this.localLV = new LocalLV(new double[][] { {} }, new int[][] { {} });
			this.localLV.extendHeteroArray(affectedSpeciesValue);
			LVEffectsOnOneHetero[] lVEffectsOnOneHetero = this.localLV.getLVEffectsOnAllHeteros();// [affectedSpeciesValue - 1];
			lVEffectsOnOneHetero[affectedSpeciesValue - 1] = new LVEffectsOnOneHetero(new double[] { effectValue }, new int[] { diffusionRadius }, new int[] { indicator });

			this.localLV.setSpeciesOwner(this);
			if (this.com != null)
			{
				this.localLV.setupAfterCommunityIsCreated(com);
			}
		}
	}

	public void setLocalEffect(int affectedSpeciesValue, IEffect lvEffect01) throws Exception
	{
		IEffect lvEffect = (IEffect) DeepCopy.deepCopy(lvEffect01);
		// System.out.println("SETTING LOCAL LV");
		if (this.localLV != null)
		{
			// System.out.println("cur local lv hetero length is " + this.localLV.getLVEffectsOnAllHeteros().length);
			// System.out.println("affect species value is " + affectedSpeciesValue);
			if (this.localLV.getLVEffectsOnAllHeteros().length >= affectedSpeciesValue)
			{
				// System.out.println("stick it in ");
				LVEffectsOnOneHetero lVEffectsOnOneHetero = this.localLV.getLVEffectsOnAllHeteros()[affectedSpeciesValue - 1];
				if (lVEffectsOnOneHetero != null)
				{
					lVEffectsOnOneHetero.addLVEffect(lvEffect);
				}
				else
				{
					lVEffectsOnOneHetero = new LVEffectsOnOneHetero(new IEffect[] { lvEffect });
				}

				this.localLV.setSpeciesOwner(this);
				if (this.com != null)
				{
					this.localLV.setupAfterCommunityIsCreated(com);
				}
			}
			else
			{
				// System.out.println("extend array ");

				this.localLV.extendHeteroArray(affectedSpeciesValue);
				LVEffectsOnOneHetero lVEffectsOnOneHetero = this.localLV.getLVEffectsOnAllHeteros()[affectedSpeciesValue - 1];
				if (lVEffectsOnOneHetero != null)
				{
					// System.out.println("adding lv effect to hetero");
					lVEffectsOnOneHetero.addLVEffect(lvEffect);
				}
				else
				{
					// System.out.println("first lveffect for hetero");
					this.localLV.getLVEffectsOnAllHeteros()[affectedSpeciesValue - 1] = new LVEffectsOnOneHetero(new IEffect[] { lvEffect });
				}
				// System.out.println("length of affected species " + this.localLV.getLVEffectsOnAllHeteros().length);
			}

			// this.localLV.setSpeciesOwner(this);
			if (this.com != null)
			{
				this.localLV.setupAfterCommunityIsCreated(com);
			}
		}
		else
		{

			this.localLV = new LocalLV(new double[][] {}, new int[][] {});
			// System.out.println("before extending " + this.localLV.getLVEffectsOnAllHeteros().length);

			this.localLV.extendHeteroArray(affectedSpeciesValue);
			LVEffectsOnOneHetero[] lVEffectsOnAllHetero = this.localLV.getLVEffectsOnAllHeteros();
			lVEffectsOnAllHetero[affectedSpeciesValue - 1] = new LVEffectsOnOneHetero(new IEffect[] { lvEffect });
			// System.out.println("after extending " + this.localLV.getLVEffectsOnAllHeteros().length);
			// System.out.println("length I need is " + (affectedSpeciesValue));
			// .addLVEffect(lvEffect);

			this.localLV.setSpeciesOwner(this);
			if (this.com != null)
			{
				this.localLV.setupAfterCommunityIsCreated(com);
			}

		}

		test();
		System.out.println();
	}

	public void test()
	{
		/*
		 * System.out.println("TEST"); if (this.localLV != null) { System.out.println("species has local lv"); LVEffectsOnOneHetero[] h = this.localLV.getLVEffectsOnAllHeteros(); if (h != null) { System.out.println("species has array for heteros. length " + h.length); } for (int i = 0; i < h.length; i++) { LVEffectsOnOneHetero e = h[i]; if (e != null) { System.out.println("species has a heter object for species " + (i + 1)); IEffect[] es = e.getLVEffects(); for (int j = 0; j < es.length; j++) { System.out.println("lv effect " + (j + 1) + " is " + es[j].getEffectValue()); } } } }
		 */
	}

	public void addAffectingLVEffect(IEffect lvEffect)
	{
		this.affectingLVEffects.add(lvEffect);
	}

	public void addAffectingLVEffectByIndicator(IEffect lvEffect)
	{
		// System.out.println("ADDING LV EFFECT BY INDICATOR");
		int indicator = lvEffect.getIndicator();
		// System.out.println("indicator is " + indicator);
		// System.out.println("size of arraylist of arraylists of lv effects is " + this.affectingLVEffectsByIndicator.size());
		if (this.affectingLVEffectsByIndicator.size() < indicator + 1)
		{
			// System.out.println("extending the indicator");
			extendAffectingLVEffectsByIndicator(indicator);
		}
		// System.out.println("after extending the object, size of arraylist of arraylists of lv effects is " + this.affectingLVEffectsByIndicator.size());

		this.affectingLVEffectsByIndicator.get(indicator);
		this.affectingLVEffectsByIndicator.get(indicator).add(lvEffect);

	}

	private void extendAffectingLVEffectsByIndicator(int indicator)
	{
		ArrayList<ArrayList<IEffect>> temp = new ArrayList<ArrayList<IEffect>>();
		for (int i = 0; i < this.affectingLVEffectsByIndicator.size(); i++)
		{
			// System.out.println("re adding old lv effect");
			temp.add(this.affectingLVEffectsByIndicator.get(i));
		}

		for (int i = this.affectingLVEffectsByIndicator.size(); i < indicator + 1; i++)
		{
			// System.out.println("adding new lv effect");
			temp.add(new ArrayList<IEffect>());
		}
		this.affectingLVEffectsByIndicator = temp;
	}

	public void resetAffectingLVEffects()
	{
		this.affectingLVEffects = new ArrayList<IEffect>();
	}

	public void resetAffectingLVEffectsByIndicator()
	{
		this.affectingLVEffectsByIndicator = new ArrayList<ArrayList<IEffect>>();
	}

	@Override
	public ArrayList<IEffect> getAffectingLVEffects()
	{

		return this.affectingLVEffects;
	}

	@Override
	public void setAbundance(int i)
	{
		this.abundance = i;
	}

	public int getAbundance()
	{
		return this.abundance;
	}

	@Override
	public ArrayList<ArrayList<IEffect>> getAffectingLVEffectsByIndicator()
	{
		return this.affectingLVEffectsByIndicator;
	}

	/*
	 * @Override public double getRecruitment(Location emptySiteLoc) { // TODO Auto-generated method stub return 0; }
	 * 
	 * @Override public double getEStar(Community com, Location location) { // TODO Auto-generated method stub return 0; }
	 * 
	 * public double getCurlyC(Community com, Location loc, double[] EBars) {
	 * 
	 * }
	 */

	/*
	 * public double getE(Community com, Location loc) {
	 * 
	 * 
	 * 
	 * }
	 */

}