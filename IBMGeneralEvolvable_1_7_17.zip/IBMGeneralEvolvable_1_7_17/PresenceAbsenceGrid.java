
public class PresenceAbsenceGrid
{
	private Community com;
	private Environment env;
	private int gridLength;
	private int speciesValue;

	public PresenceAbsenceGrid(Community com, int speciesValue)
	{
		this.speciesValue = speciesValue;
		this.com = com;
		this.env = this.com.getEnvironment();
		this.gridLength = this.env.getGridLength();
	}

	public double[][] getGrid()
	{
		double[][] paGrid = new double[this.gridLength][this.gridLength];

		ISpecies aSpecies = this.com.getSpeciesList().get(speciesValue - 1);
		int envGridIndex = aSpecies.getHomeGridIndex();
		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				int gridValue = env.getGridValue(row, col, envGridIndex);
				if (gridValue == speciesValue)
				{
					paGrid[row][col] = 1;
				}
			}
		}
		return paGrid;
	}
}
