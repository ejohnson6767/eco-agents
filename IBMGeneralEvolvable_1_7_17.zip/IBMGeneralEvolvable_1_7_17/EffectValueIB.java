import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class EffectValueIB extends ContinuousTrait implements IEffectValue, Evolvable, Serializable
{
	// private Community com;
	// Environment env;
	private double baselineTrait;
	// private int speciesValue;
	// private boolean useAltApproach;
	// private int speciesIndex;
	// private int envGridIndex;
	// private int possibleNeighbors;
	private int affectedSpeciesValue;
	private int affectedSpeciesLVEffectValue;
	private IEffect lvEffect;
	// private double effectPerSite;
	// private double[][] lVEffectGrid;

	public EffectValueIB(IMutationFunction mf, int affectedSpeciesValue, int affectedSpeciesLVEffectValue, IEffect lvEffectToOverwrite)
	{
		super(mf);
		this.lvEffect = lvEffectToOverwrite;
		this.affectedSpeciesValue = affectedSpeciesValue;
		this.affectedSpeciesLVEffectValue = affectedSpeciesLVEffectValue;
	}

	public double[][] getLVEffectGrid()
	{
		return this.lvEffect.getLVEffectGrid();
	}

	/*
	 * public double getEffectPerSite() { return this.effectPerSite; }
	 */

	/*
	 * public LVEffectIB(IMutationFunction mf, int affectedSpeciesValue, int affectedSpeciesLVEffectValue) { super(mf); this.lvEffect = null; this.useAltApproach = false; this.affectedSpeciesValue = affectedSpeciesValue; this.affectedSpeciesLVEffectValue = affectedSpeciesLVEffectValue; // this.com = com; }
	 */

	public void initializeSpatialDistributionTracker() throws Exception
	{

		LocalLV localLV = this.species.getLocalLV();
		if (localLV == null)
		{
			this.species.setLocalEffect(this.affectedSpeciesValue, this.lvEffect);
			this.spatialDistributionTracker = this.lvEffect.getEffectValue().getSpatialDistributionTracker();
			this.baselineTrait = this.lvEffect.getEffectValue().getEffectValue();

			this.lvEffect.setEffectValue(this);

		}
		else
		{
			LVEffectsOnOneHetero[] allHeteros = localLV.getLVEffectsOnAllHeteros();
			if (allHeteros.length < this.affectedSpeciesValue)
			{
				this.species.setLocalEffect(this.affectedSpeciesValue, this.lvEffect);
				this.spatialDistributionTracker = this.lvEffect.getEffectValue().getSpatialDistributionTracker();
				this.baselineTrait = this.lvEffect.getEffectValue().getEffectValue();

				this.lvEffect.setEffectValue(this);

			}
			else
			{
				LVEffectsOnOneHetero LVEffects = allHeteros[this.affectedSpeciesValue - 1];
				IEffect[] lvEffects = LVEffects.getLVEffects();
				if (lvEffects.length < this.affectedSpeciesLVEffectValue)
				{
					this.species.setLocalEffect(this.affectedSpeciesValue, this.lvEffect);
					this.spatialDistributionTracker = this.lvEffect.getEffectValue().getSpatialDistributionTracker();
					this.baselineTrait = this.lvEffect.getEffectValue().getEffectValue();

					this.lvEffect.setEffectValue(this);

				}
				else
				{
					IEffect lvEffectToOverwrite = lvEffects[this.affectedSpeciesLVEffectValue - 1];
					// lvEffectToOverwrite = snew LVEffect(((LVEffect) lvEffectToOverwrite).getEffectValue(), ((LVEffect) lvEffectToOverwrite).getDiffusionRadius() );
					this.lvEffect = lvEffectToOverwrite;
					this.spatialDistributionTracker = this.lvEffect.getEffectValue().getSpatialDistributionTracker();

					IEffectValue eff = this.lvEffect.getEffectValue();
					if (eff.isIndividualBased())
					{
						this.baselineTrait = ((EffectValueIB) eff).getTraitAverage();
					}
					else
					{
						// System.out.println("not individual based");
						this.baselineTrait = eff.getEffectValue();
					}

					this.lvEffect.setEffectValue(this);

					this.species.getLocalLV().setupAfterCommunityIsCreated(this.com);

				}
			}

		}
	}

	public void startEvolution() throws Exception
	{
		this.isEvolving = true;
		this.isIndividualBased = true;
		// setUpAfterCommunityIsCreated(com, this.species.getGridProxy());
		initializeSpatialDistributionTracker();

		LocalLVAllSpecies lvAll = new LocalLVAllSpecies(com);
		lvAll.resetAffectingLVEffectsAllSpecies();

		System.out.println("made species " + species.getGridProxy() + " individual-based and evolvable");
		// System.out.println("is individual based " + this.isIndividualBased);
	}

	public void startBeingIndividualBased() throws Exception
	{
		this.isIndividualBased = true;
		// setUpAfterCommunityIsCreated(com, this.species.getGridProxy());
		initializeSpatialDistributionTracker();
		// this.lvEffect.setupAfterCommunityIsCreated(this.com);

		LocalLVAllSpecies lvAll = new LocalLVAllSpecies(com);
		lvAll.resetAffectingLVEffectsAllSpecies();

		System.out.println("made species " + species.getGridProxy() + " individual-based ");
	}

	public boolean isIndividualBased()
	{
		return this.isIndividualBased;
	}

	public double getBaselineTrait()
	{
		// System.out.println("Getting baseline TRAIT: " + com.getAbundances()[this.speciesIndex] );
		if (com.getAbundances()[this.speciesIndex] != 0)
		{
			// System.out.println("not zero. Getting trait average");
			return getTraitAverage();
		}
		else
		{
			// System.out.println(this.baselineTrait);
			return this.baselineTrait;
		}
	}

	public void setSpeciesOwner(ISpecies species)
	{
		// this.species = species;
		this.lvEffect.setSpeciesOwner(this.species);
	}

	public void setupAfterCommunityIsCreated(Community com)
	{
		// this.com = com;

		// this.gridLength = this.com.getEnvironment().getGridLength();
		// this.baselineTrait = (int) getTraitAverage();
		// IDiffusion dif =this.lvEffect.getDiffusion();
		// this.lvEffect.getDiffusion().setupAfterCommunityIsCreated(com);
		// this.spatialDistributionTracker = new double[gridLength][gridLength];

	}

	public double[][] getSpatialDistributionTracker()
	{
		return this.spatialDistributionTracker;
	}

	public double getEffectValue()
	{
		return getTraitAverage();
	}

	public double getEffect(Location loc)
	{
		return this.lvEffect.getEffect(loc);
	}

	public int getDiffusion()
	{
		return (int) Math.round(getTraitAverage());
	}

	public int getDiffusion(int row, int col)
	{
		return (int) this.spatialDistributionTracker[row][col];
	}

	@Override
	public double getEffectValue(int row, int col)
	{
		return this.spatialDistributionTracker[row][col];
	}

}
