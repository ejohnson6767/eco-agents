
public interface Chessonable
{
	Object get();
}
