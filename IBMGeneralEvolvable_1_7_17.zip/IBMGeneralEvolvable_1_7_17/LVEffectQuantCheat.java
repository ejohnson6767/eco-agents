
public class LVEffectQuantCheat extends Effect
{

	public LVEffectQuantCheat(double K, double q, int diffusion)
	{
		super(q, diffusion);
		this.effectValue = new EffectValueQuantCheat(K, q);
	}

	public LVEffectQuantCheat(double k, double q, int diffusion, int indicator)
	{
		this(k, q, diffusion);
		this.indicator = indicator;
	}
	
	

}
