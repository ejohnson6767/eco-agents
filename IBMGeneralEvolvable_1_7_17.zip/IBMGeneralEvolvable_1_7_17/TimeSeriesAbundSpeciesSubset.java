import java.io.Serializable;

public class TimeSeriesAbundSpeciesSubset implements ITimeSeriesQuantity, Serializable
{

	private Community com;
	private boolean reportDensity;
	private int[] subsetValues;
	private int returnLength;

	public TimeSeriesAbundSpeciesSubset(Community com, boolean reportDensity, int[] subsetValues)
	{
		this.com = com;
		this.reportDensity = reportDensity;
		this.subsetValues = subsetValues;
		this.returnLength = this.subsetValues.length;
	}
	
	public int getReturnLength()
	{
		return this.returnLength; 
	}
	
	public double[] get()
	{
		double[] abundsSub = new double[this.subsetValues.length];
		double[] abunds = this.com.getAbundances(this.reportDensity);
		int counter = 0;
		for (int i = 0; i < this.subsetValues.length; i++)
		{
			
				abundsSub[counter] = abunds[this.subsetValues[i]-1];
			
		}
		return abundsSub;
	}

}