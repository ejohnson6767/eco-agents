import java.io.Serializable;

public class TimeSeriesAbundAllSpecies implements ITimeSeriesQuantity, Serializable
{

	private Community com;
	private boolean reportDensity;
	private int returnLength;

	public TimeSeriesAbundAllSpecies(Community com, boolean reportDensity)
	{
		this.com = com;
		this.reportDensity = reportDensity;
		this.returnLength = this.com.numberOfSpecies;

	}
	

	public double[] get()
	{
		return this.com.getAbundances(this.reportDensity);
	}

	public int getReturnLength()
	{
		return this.returnLength; 
	}
	
}
