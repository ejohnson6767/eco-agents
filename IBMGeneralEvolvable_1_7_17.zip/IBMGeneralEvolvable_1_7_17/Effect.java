import java.io.Serializable;
import java.text.DecimalFormat;

public class Effect implements IEffect, Serializable
{

	protected Community com;
	protected ISpecies speciesOwner;
	// private double effectPerSite;
	// private int possibleNeighbors;
	protected Environment env;
	protected int gridLength;
	protected int speciesValue;
	// private int speciesIndex;
	protected int envGridIndex;
	// private int diffusion;
	protected double[][] lVEffectGrid;
	// private double effectValue;
	protected int indicator;
	protected IDiffusion diffusion;
	protected IEffectValue effectValue;

	public Effect(double effectVal, int diffusion)
	{
		this.diffusion = new Diffusion(diffusion);
		this.effectValue = new EffectValue(effectVal);

		// this.possibleNeighbors = (int) Math.pow(diffusion * 2 + 1, 2) - 1;
		// this.effectPerSite = this.effectValue / (double) possibleNeighbors;
		this.indicator = 1;

	}

	public Effect(double effectVal, int diffusion, int indicator)
	{
		this(effectVal, diffusion);
		this.indicator = indicator;
	}

	public double[][] getLVEffectGrid()
	{
		return this.lVEffectGrid;
	}

	public void setSpeciesOwner(ISpecies species)
	{
		this.speciesOwner = species;
		this.diffusion.setSpeciesOwner(species);
		this.effectValue.setSpeciesOwner(species);
	}

	public int getIndicator()
	{
		return this.indicator;
	}

	public boolean isIndividualBased()
	{
		if (this.diffusion.isIndividualBased() || this.effectValue.isIndividualBased())
		{
			return true;

		}
		else
		{
			return false;
		}
	}

	public void fillLV()
	{

		// will use the alternate approach (moving window for each dispersal value in the empirical distribution) if dispersal is the individual based trait.
		// the logic for this is contained in the prg class, method fillGrid, and it modifies the useAltApproach field in the trait list class
		/*
		 * if (this.species.getTraitList().useAltApproach()) { fillGridMovingWindowAllDispersal(); } else {
		 * 
		 * fillGridBlandSingleSpeciesWithTraitsAndIndividualBasedDispersal(); }
		 */
		this.lVEffectGrid = new double[this.gridLength][this.gridLength];

		if (isIndividualBased())
		{
			if (this.effectValue.isIndividualBased())
			{
				//System.out.println("fillGridBland because effect value is individual based");
				fillGridBland();
			}
			else
			{
				////System.out.println("moving window when effect value is not individual based but diffusion is");
				//fillGridBland();

				fillGridMovingWindowAllDispersal();
			}
		}
		else
		{
			////System.out.println("moving window. diffusion and effect is not IBs");
			fillGridNotIB();
		}
		////test();

	}

	public void test()
	{

		if (com.getStepCallCounter() % 50 == 0 && com.getStepCallCounter() / 50 != 0)
		{
			for (int row = 0; row < 6; row++)
			{
				for (int col = 0; col < 6; col++)
				{
					double val = getEffect(new Location(row, col));
					if (val == 0)
					{
						val = 0.0;
					}
					DecimalFormat df = new DecimalFormat("#.#");
					System.out.print(df.format(val) + " ");

				}
				System.out.println();
			}
			System.out.println();
			System.out.println();
			System.out.println();
			System.out.println();
			System.out.println();
			System.out.println();
			for (int row = 0; row < 6; row++)
			{
				for (int col = 0; col < 6; col++)
				{
					int gridValue = this.com.getEnvironment().getGridValue(row, col, this.envGridIndex);
					if (gridValue == this.speciesValue)
					{
						System.out.print(1 + "  ");
					}
					else
					{
						System.out.print(0 + "  ");

					}
				}
				System.out.println();
			}
		}
	}

	public void fillLVTest() throws Exception
	{
		this.lVEffectGrid = new double[this.gridLength][this.gridLength];
		fillGridBland();
		double[][] blandIB = (double[][]) DeepCopy.deepCopy(this.lVEffectGrid);

		this.lVEffectGrid = new double[this.gridLength][this.gridLength];
		fillGridMovingWindowAllDispersal();
		double[][] mwIB = (double[][]) DeepCopy.deepCopy(this.lVEffectGrid);

		this.lVEffectGrid = new double[this.gridLength][this.gridLength];
		fillGridNotIB();
		System.out.println("DISP AVG IS " + this.getDiffusion().getDiffusion());
		double[][] mw = (double[][]) DeepCopy.deepCopy(this.lVEffectGrid);

		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				System.out.println("blandIB is " + blandIB[row][col]);
				System.out.println("mwIB is " + mwIB[row][col]);
				System.out.println("mwreg is " + mw[row][col]);
				System.out.println();
			}

		}

	}

	public void fillGridNotIB()
	{
		// ////System.out.println("the species value is " + this.speciesValue);

		/// ////System.out.println("disp is " + dispersalRadius);

		// ////System.out.println("possible neighbors " + possibleNeighbors);

		double[][] posPropagule = new double[gridLength][3];
		int diffusion = this.diffusion.getDiffusion();
		double possibleNeighbors = Math.pow(diffusion * 2 + 1, 2) - 1;
		double effect = this.effectValue.getEffectValue();
		double effectPerSite = effect / possibleNeighbors;
		//// System.out.println("effect is " + effect);
		//// System.out.println("possible neighbors is " + possibleNeighbors);
		//// System.out.println("effect per site is " + effectPerSite);

		// this second main loop determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius

		// this algorithm scans right across the grid, goes down one line, scans again, and so on (just like reading). It's time complexity is O(n) (where n is the number of microsites) compared to O(n^2) of a trivial moving window algorithm.
		// It works by summing all of the
		// cumulative birth rates in the topmost row, the bottommost row, and everything in between. This is where the last dimension on pos array comes in:
		// 0 is TOP, 1 is MID, and 2 is BOT. when you to the next gid locationCommunity com,, your cumulative growth rate is TOPnew + MIDnew + BOTnew. MIDnew is simply MIDnorth + BOTnorth - TOPnew.
		// (where north indicates the position above you). TOPnew can be written TOPwest - TOPwest.leftMost + TOPnew.rightmost. BOTnew can be written BOTwest - BOTwest.leftMost + BOTnew.rightmost.
		// the TOP, MID, and BOT are all recorded.
		int row = 0;
		int col = 0;

		// pos = new double[numberOfSpecies][gridLength][3];
		int row2 = row - diffusion;
		for (int col2 = col - diffusion; col2 <= col + diffusion; col2++)
		{
			int realRow = WrapAround.wrapAround(row2, gridLength);
			int realCol = WrapAround.wrapAround(col2, gridLength);
			int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
			if (gridValue == speciesValue)
			{

				posPropagule[col][0] += effectPerSite;

			}
		}
		// ////System.out.println("col == " + col + " first is " + first[1]);

		for (int col2 = col - diffusion; col2 <= col + diffusion; col2++)
		{
			for (row2 = row - diffusion + 1; row2 <= row + diffusion - 1; row2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{

					posPropagule[col][1] += effectPerSite;

				}
			}
		}
		// ////System.out.println("col == 0 middle is " + middle[1]);

		row2 = row + diffusion;
		for (int col2 = col - diffusion; col2 <= col + diffusion; col2++)
		{
			int realRow = WrapAround.wrapAround(row2, gridLength);
			int realCol = WrapAround.wrapAround(col2, gridLength);
			int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
			if (gridValue == speciesValue)
			{

				posPropagule[col][2] += effectPerSite;

			}
		}

		// ACTUALLY ADD TO PROPAGULE RAIN GRID
		lVEffectGrid[row][col] = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2]);

		for (col = 1; col < gridLength; col++)
		{

			// generate new top
			int NWRow = WrapAround.wrapAround(row - diffusion, gridLength);
			int NWCol = WrapAround.wrapAround(col - 1 - diffusion, gridLength);
			int NERow = WrapAround.wrapAround(row - diffusion, gridLength);
			int NECol = WrapAround.wrapAround(col + diffusion, gridLength);

			int SWRow = WrapAround.wrapAround(row + diffusion, gridLength);
			int SWCol = WrapAround.wrapAround(col - 1 - diffusion, gridLength);
			int SERow = WrapAround.wrapAround(row + diffusion, gridLength);
			int SECol = WrapAround.wrapAround(col + diffusion, gridLength);

			posPropagule[col][0] = posPropagule[col - 1][0];
			if (env.getGridValue(NWRow, NWCol, envGridIndex) == speciesValue)
			{
				posPropagule[col][0] -= effectPerSite;
			}

			if (env.getGridValue(NERow, NECol, envGridIndex) == speciesValue)
			{
				posPropagule[col][0] += effectPerSite;
			}

			double leftSideOfOldMid = 0;
			int col2 = col - diffusion - 1;
			for (row2 = row - diffusion + 1; row2 <= row + diffusion - 1; row2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{

					leftSideOfOldMid += effectPerSite;

				}
			}

			double rightSideOfNewMid = 0;
			col2 = col + diffusion;
			for (row2 = row - diffusion + 1; row2 <= row + diffusion - 1; row2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{

					rightSideOfNewMid += effectPerSite;

				}
			}

			posPropagule[col][1] = posPropagule[col - 1][1] - leftSideOfOldMid + rightSideOfNewMid;

			posPropagule[col][2] = posPropagule[col - 1][2];
			if (env.getGridValue(SWRow, SWCol, envGridIndex) == speciesValue)
			{
				posPropagule[col][2] -= effectPerSite;
			}

			if (env.getGridValue(SERow, SECol, envGridIndex) == speciesValue)
			{
				posPropagule[col][2] += effectPerSite;
			}
			// ACTUALLY ADD TO PROPAGULE RAIN GRID
			lVEffectGrid[row][col] = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2]);
		}

		for (row = 1; row < gridLength; row++)
		{
			col = 0;

			posPropagule[col][0] = 0;

			row2 = row - diffusion;
			for (int col2 = col - diffusion; col2 <= col + diffusion; col2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{

					posPropagule[col][0] += effectPerSite;

				}
			}

			posPropagule[col][1] += posPropagule[col][2] - posPropagule[col][0];

			posPropagule[col][2] = 0;

			row2 = row + diffusion;
			for (int col2 = col - diffusion; col2 <= col + diffusion; col2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{

					posPropagule[col][2] += effectPerSite;

				}
			}

			// ACTUALLY ADD TO PROPAGULE RAIN GRID
			lVEffectGrid[row][col] = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2]);

			for (col = 1; col < gridLength; col++)
			{

				// generate new top
				int NWRow = WrapAround.wrapAround(row - diffusion, gridLength);
				int NWCol = WrapAround.wrapAround(col - 1 - diffusion, gridLength);
				int NERow = WrapAround.wrapAround(row - diffusion, gridLength);
				int NECol = WrapAround.wrapAround(col + diffusion, gridLength);

				int SWRow = WrapAround.wrapAround(row + diffusion, gridLength);
				int SWCol = WrapAround.wrapAround(col - 1 - diffusion, gridLength);
				int SERow = WrapAround.wrapAround(row + diffusion, gridLength);
				int SECol = WrapAround.wrapAround(col + diffusion, gridLength);

				posPropagule[col][0] = posPropagule[col - 1][0];
				if (env.getGridValue(NWRow, NWCol, envGridIndex) == speciesValue)
				{
					posPropagule[col][0] -= effectPerSite;
				}

				if (env.getGridValue(NERow, NECol, envGridIndex) == speciesValue)
				{
					posPropagule[col][0] += effectPerSite;
				}

				posPropagule[col][1] += posPropagule[col][2] - posPropagule[col][0];

				posPropagule[col][2] = posPropagule[col - 1][2];
				if (env.getGridValue(SWRow, SWCol, envGridIndex) == speciesValue)
				{
					posPropagule[col][2] -= effectPerSite;
				}

				if (env.getGridValue(SERow, SECol, envGridIndex) == speciesValue)
				{
					posPropagule[col][2] += effectPerSite;
				}

				// ACTUALLY ADD TO PROPAGULE RAIN GRID
				lVEffectGrid[row][col] = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2]);

			}
		}

		// ////System.out.println(propaguleRainGrid[row][col][speciesIndex]);

	}

	public void fillGridBland()
	{
		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				if (this.env.getGridValue(row, col, this.envGridIndex) == speciesValue)
				{
					fillGridBlandSingleSite(row, col);
				}
			}
		}
	}

	public void fillGridBlandSingleSite(int row, int col)
	{

		int diffusion = this.diffusion.getDiffusion(row, col);
		double possibleNeighbors = Math.pow(diffusion * 2 + 1, 2) - 1;

		
		double effectValue = this.effectValue.getEffectValue(row, col);
		////// System.out.println("fill grid bland single site");
		
		double effectValuePerSite = effectValue / possibleNeighbors;
		
		
		/*System.out.println(effectValue);
		System.out.println(possibleNeighbors);

		System.out.println( effectValuePerSite);*/
		for (int row2 = row - diffusion; row2 < row + 1 + diffusion; row2++)
		{
			for (int col2 = col - diffusion; col2 < col + 1 + diffusion; col2++)
			{
				int realRow = WrapAround.wrapAround(row2, this.gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);

				
				this.lVEffectGrid[realRow][realCol] += effectValuePerSite;

			}
		}

	}

	public void fillGridMovingWindowAllDispersal()
	{
		// TraitList tl = this.species.getTraitList();

		DiscreteTrait disTrait = ((DiscreteTrait) this.diffusion);
		disTrait.fillDiscreteHistogram();
		int[] discreteHistogram = disTrait.getDiscreteHistogram();
		for (int i = 1; i < discreteHistogram.length; i++)
		{
			if (discreteHistogram[i] != 0)
			{
				// System.out.println();
				// System.out.println("discrete histogram bin " + i + " is " + discreteHistogram[i]);

				fillLVMovingWindowSingleDiffusion(i);
			}
		}
		// System.out.println();

	}

	public void fillLVMovingWindowSingleDiffusion(int diffusion)
	{

		// ////System.out.println("the species value is " + this.speciesValue);

		/// ////System.out.println("disp is " + dispersalRadius);

		// ////System.out.println("possible neighbors " + possibleNeighbors);

		double[][] posPropagule = new double[gridLength][3];

		//// System.out.println("single diffusion moving window. diffusion is " + diffusion);

		double possibleNeighbors = Math.pow(diffusion * 2 + 1, 2) - 1;
		double effect = this.effectValue.getEffectValue();
		double effectPerSite = effect / possibleNeighbors;
		//// System.out.println("effect is " + effect);
		//// System.out.println("possible neighbors is " + possibleNeighbors);
		//// System.out.println("effect per site is " + effectPerSite);

		// this second main loop determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius

		// this algorithm scans right across the grid, goes down one line, scans again, and so on (just like reading). It's time complexity is O(n) (where n is the number of microsites) compared to O(n^2) of a trivial moving window algorithm.
		// It works by summing all of the
		// cumulative birth rates in the topmost row, the bottommost row, and everything in between. This is where the last dimension on pos array comes in:
		// 0 is TOP, 1 is MID, and 2 is BOT. when you to the next gid locationCommunity com,, your cumulative growth rate is TOPnew + MIDnew + BOTnew. MIDnew is simply MIDnorth + BOTnorth - TOPnew.
		// (where north indicates the position above you). TOPnew can be written TOPwest - TOPwest.leftMost + TOPnew.rightmost. BOTnew can be written BOTwest - BOTwest.leftMost + BOTnew.rightmost.
		// the TOP, MID, and BOT are all recorded.
		int row = 0;
		int col = 0;

		// pos = new double[numberOfSpecies][gridLength][3];
		int row2 = row - diffusion;
		for (int col2 = col - diffusion; col2 <= col + diffusion; col2++)
		{
			int realRow = WrapAround.wrapAround(row2, gridLength);
			int realCol = WrapAround.wrapAround(col2, gridLength);
			int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
			if (gridValue == speciesValue)
			{

				posPropagule[col][0] += effectPerSite;

			}
		}
		// ////System.out.println("col == " + col + " first is " + first[1]);

		for (int col2 = col - diffusion; col2 <= col + diffusion; col2++)
		{
			for (row2 = row - diffusion + 1; row2 <= row + diffusion - 1; row2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{

					posPropagule[col][1] += effectPerSite;

				}
			}
		}
		// ////System.out.println("col == 0 middle is " + middle[1]);

		row2 = row + diffusion;
		for (int col2 = col - diffusion; col2 <= col + diffusion; col2++)
		{
			int realRow = WrapAround.wrapAround(row2, gridLength);
			int realCol = WrapAround.wrapAround(col2, gridLength);
			int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
			if (gridValue == speciesValue)
			{

				posPropagule[col][2] += effectPerSite;

			}
		}

		// ACTUALLY ADD TO PROPAGULE RAIN GRID
		lVEffectGrid[row][col] = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2]);

		for (col = 1; col < gridLength; col++)
		{

			// generate new top
			int NWRow = WrapAround.wrapAround(row - diffusion, gridLength);
			int NWCol = WrapAround.wrapAround(col - 1 - diffusion, gridLength);
			int NERow = WrapAround.wrapAround(row - diffusion, gridLength);
			int NECol = WrapAround.wrapAround(col + diffusion, gridLength);

			int SWRow = WrapAround.wrapAround(row + diffusion, gridLength);
			int SWCol = WrapAround.wrapAround(col - 1 - diffusion, gridLength);
			int SERow = WrapAround.wrapAround(row + diffusion, gridLength);
			int SECol = WrapAround.wrapAround(col + diffusion, gridLength);

			posPropagule[col][0] = posPropagule[col - 1][0];
			if (env.getGridValue(NWRow, NWCol, envGridIndex) == speciesValue)
			{
				posPropagule[col][0] -= effectPerSite;
			}

			if (env.getGridValue(NERow, NECol, envGridIndex) == speciesValue)
			{
				posPropagule[col][0] += effectPerSite;
			}

			double leftSideOfOldMid = 0;
			int col2 = col - diffusion - 1;
			for (row2 = row - diffusion + 1; row2 <= row + diffusion - 1; row2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{

					leftSideOfOldMid += effectPerSite;

				}
			}

			double rightSideOfNewMid = 0;
			col2 = col + diffusion;
			for (row2 = row - diffusion + 1; row2 <= row + diffusion - 1; row2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{

					rightSideOfNewMid += effectPerSite;

				}
			}

			posPropagule[col][1] = posPropagule[col - 1][1] - leftSideOfOldMid + rightSideOfNewMid;

			posPropagule[col][2] = posPropagule[col - 1][2];
			if (env.getGridValue(SWRow, SWCol, envGridIndex) == speciesValue)
			{
				posPropagule[col][2] -= effectPerSite;
			}

			if (env.getGridValue(SERow, SECol, envGridIndex) == speciesValue)
			{
				posPropagule[col][2] += effectPerSite;
			}
			// ACTUALLY ADD TO PROPAGULE RAIN GRID
			lVEffectGrid[row][col] = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2]);
		}

		for (row = 1; row < gridLength; row++)
		{
			col = 0;

			posPropagule[col][0] = 0;

			row2 = row - diffusion;
			for (int col2 = col - diffusion; col2 <= col + diffusion; col2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{

					posPropagule[col][0] += effectPerSite;

				}
			}

			posPropagule[col][1] += posPropagule[col][2] - posPropagule[col][0];

			posPropagule[col][2] = 0;

			row2 = row + diffusion;
			for (int col2 = col - diffusion; col2 <= col + diffusion; col2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{

					posPropagule[col][2] += effectPerSite;

				}
			}

			// ACTUALLY ADD TO PROPAGULE RAIN GRID
			lVEffectGrid[row][col] = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2]);

			for (col = 1; col < gridLength; col++)
			{

				// generate new top
				int NWRow = WrapAround.wrapAround(row - diffusion, gridLength);
				int NWCol = WrapAround.wrapAround(col - 1 - diffusion, gridLength);
				int NERow = WrapAround.wrapAround(row - diffusion, gridLength);
				int NECol = WrapAround.wrapAround(col + diffusion, gridLength);

				int SWRow = WrapAround.wrapAround(row + diffusion, gridLength);
				int SWCol = WrapAround.wrapAround(col - 1 - diffusion, gridLength);
				int SERow = WrapAround.wrapAround(row + diffusion, gridLength);
				int SECol = WrapAround.wrapAround(col + diffusion, gridLength);

				posPropagule[col][0] = posPropagule[col - 1][0];
				if (env.getGridValue(NWRow, NWCol, envGridIndex) == speciesValue)
				{
					posPropagule[col][0] -= effectPerSite;
				}

				if (env.getGridValue(NERow, NECol, envGridIndex) == speciesValue)
				{
					posPropagule[col][0] += effectPerSite;
				}

				posPropagule[col][1] += posPropagule[col][2] - posPropagule[col][0];

				posPropagule[col][2] = posPropagule[col - 1][2];
				if (env.getGridValue(SWRow, SWCol, envGridIndex) == speciesValue)
				{
					posPropagule[col][2] -= effectPerSite;
				}

				if (env.getGridValue(SERow, SECol, envGridIndex) == speciesValue)
				{
					posPropagule[col][2] += effectPerSite;
				}

				// ACTUALLY ADD TO PROPAGULE RAIN GRID
				lVEffectGrid[row][col] = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2]);

			}
		}
	}

	public void setupAfterCommunityIsCreated(Community com)
	{
		this.com = com;
		this.diffusion.setupAfterCommunityIsCreated(com);
		this.effectValue.setupAfterCommunityIsCreated(com);
		this.env = this.com.getEnvironment();
		this.gridLength = this.env.getGridLength();
		this.speciesValue = this.speciesOwner.getGridProxy();
		this.envGridIndex = this.speciesOwner.getHomeGridIndex();
		this.lVEffectGrid = new double[this.gridLength][this.gridLength];

	}

	public void setLVEffectGrid(int[][] totalGrid)
	{
		this.lVEffectGrid = new double[this.gridLength][this.gridLength];
		int diffusion = this.diffusion.getDiffusion();
		double possibleNeighbors = Math.pow(diffusion * 2 + 1, 2) - 1;
		double effect = this.effectValue.getEffectValue();
		double effectPerSite = effect / possibleNeighbors;
		//// System.out.println("USING METHOD SET LV EFFECT GRID");
		//// System.out.println("effect is " + effect);
		//// System.out.println("possible neighbors is " + possibleNeighbors);
		//// System.out.println("effect per site is " + effectPerSite);
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				this.lVEffectGrid[row][col] = totalGrid[row][col] * effectPerSite;
			}
		}

	}

	public double getEffect(Location loc)
	{
		return this.lVEffectGrid[loc.row()][loc.col()];
	}

	/*
	 * @Override public double[][] getSpatialDistributionTracker() { ////System.out.println("initialize spatial tracker"); double[][] tempGrid = new double[gridLength][gridLength]; //int counter = 0; for (int row = 0; row < gridLength; row++) { for (int col = 0; col < gridLength; col++) { int gridValue = env.getGridValue(row, col, envGridIndex); if (gridValue == speciesValue) { // ////System.out.println("row " + row + " col " +col + " is " + dispersalRadius); tempGrid[row][col] = this.diffusion; //counter++; } } } return tempGrid;
	 * 
	 * }
	 */

	public IEffectValue getEffectValue()
	{
		return this.effectValue;
	}

	public void setEffectValue(IEffectValue e)
	{
		this.effectValue = e;
	}

	public IDiffusion getDiffusion()
	{

		return this.diffusion;
	}

	public void setDiffusion(IDiffusion d)
	{
		this.diffusion = d;
	}

	public int getSpeciesValue()
	{
		return this.speciesValue;
	}

}
