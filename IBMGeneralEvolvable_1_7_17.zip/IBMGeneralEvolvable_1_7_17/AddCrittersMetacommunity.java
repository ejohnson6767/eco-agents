import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

public class AddCrittersMetacommunity extends AddCritters implements Serializable
{
	private ArrayList<Location> bestPatchLocations;
	private ArrayList<ArrayList<Location>> bestPatchLocationsByPatch;
	private int numberOfBestMicrosites;
	private int numberOfBestMicrositesInOnePatch;
	private int patchesPerSpecies;
	private RegionallySimilarSpecies rss;

	public AddCrittersMetacommunity(Community com, RegionallySimilarSpecies rss, int speciesValue, boolean overwrite)
	{
		super(com, speciesValue, overwrite);
		this.rss = rss;

	}
	

	public void getBestPatchLocations()
	{
		this.bestPatchLocations = new ArrayList<Location>();

		ArrayList<ArrayList<Patch>> patches = this.rss.getGenericDemographyGrid().getPatchList();
		ArrayList<Patch> bestPatches = patches.get(this.curSpeciesValue - 1);
		for (int i = 0; i < bestPatches.size(); i++)
		{
			Patch curPatch = bestPatches.get(i);

			int rowLength = curPatch.getRowLength();
			int colLength = curPatch.getColLength();
			int startRow = curPatch.getRow();
			int startCol = curPatch.getCol();
			for (int r = 0; r < rowLength; r++)
			{
				for (int c = 0; c < colLength; c++)
				{

					int newRow = WrapAround.wrapAround(startRow + r, gridLength);
					int newCol = WrapAround.wrapAround(startCol + c, gridLength);
					bestPatchLocations.add(new Location(newRow, newCol));
				}

			}
		}
		this.numberOfBestMicrosites = this.bestPatchLocations.size();
	}

	public void getBestPatchLocationsByPatch()
	{
		this.bestPatchLocationsByPatch = new ArrayList<ArrayList<Location>>();

		ArrayList<ArrayList<Patch>> patches = this.rss.getGenericDemographyGrid().getPatchList();
		ArrayList<Patch> bestPatches = patches.get(this.curSpeciesValue - 1);
		for (int i = 0; i < bestPatches.size(); i++)
		{
			Patch curPatch = bestPatches.get(i);
			this.bestPatchLocationsByPatch.add(new ArrayList<Location>());

			int rowLength = curPatch.getRowLength();
			int colLength = curPatch.getColLength();
			int startRow = curPatch.getRow();
			int startCol = curPatch.getCol();
			for (int r = 0; r < rowLength; r++)
			{
				for (int c = 0; c < colLength; c++)
				{
					int newRow = WrapAround.wrapAround(startRow + r, gridLength);
					int newCol = WrapAround.wrapAround(startCol + c, gridLength);
					this.bestPatchLocationsByPatch.get(i).add(new Location(newRow, newCol));
				}

			}
		}
		this.numberOfBestMicrositesInOnePatch = this.bestPatchLocationsByPatch.get(0).size();
		this.patchesPerSpecies = this.bestPatchLocationsByPatch.size();
	}

	public void addCrittersRandomlyToBestPatches(int invadersToAdd)
	{
		TraitList curSpeciesTraits = this.curSpecies.getTraitList();
		for (int i = 0; i < invadersToAdd; i++)
		{
			addCritterRandomlyToBestPatches(curSpeciesTraits);
		}

		UpdateAbundances ua = new UpdateAbundances(com);
		ua.update();
		CommunityUtilsStep.stepPrimer(this.com);
	}

	public void addCritterRandomlyToBestPatches(TraitList curSpeciesTraits)
	{
		int k = 0;
		while (true)
		{
			Location randLoc = this.bestPatchLocations.get(this.generator.nextInt(this.numberOfBestMicrosites));
			int randRow = randLoc.row();
			int randCol = randLoc.col();

			Location newLoc = new Location(randRow, randCol);
			Location3D newLoc3D = new Location3D(randRow, randCol, this.curSpeciesHomeIndex);
			boolean added = false;

			if (k < 100)
			{
				added = tryToAddCritter(curSpeciesTraits, newLoc3D, newLoc, null, false);
			}
			else
			{
				added = tryToAddCritterOverwritingAlwaysPermitted(curSpeciesTraits, newLoc3D, newLoc, null, false);
			}

			if (added)
			{
				break;
			}

			k++;
		}
	}

	public void addCrittersRandomlyToBestPatchesByPatch(int invadersToAdd)
	{
		int invadersPerPatch = invadersToAdd / this.patchesPerSpecies;
		int remainder = invadersToAdd % this.patchesPerSpecies;
		boolean[] extraDude = new boolean[this.patchesPerSpecies];
		Arrays.fill(extraDude, false);
		for (int i = 0; i < remainder; i++)
		{
			extraDude[i] = true;
		}

		TraitList curSpeciesTraits = this.curSpecies.getTraitList();

		for (int j = 0; j < this.patchesPerSpecies; j++)
		{
			int invadersToAddInThisPatch = invadersPerPatch;
			if(extraDude[j])
			{
				invadersToAddInThisPatch++;
			}
			
			for (int i = 0; i < invadersToAddInThisPatch; i++)
			{				
				addCritterRandomlyToBestPatchesByPatch(j, curSpeciesTraits);
			}
		}

		UpdateAbundances ua = new UpdateAbundances(com);
		ua.update();
		CommunityUtilsStep.stepPrimer(this.com);
	}

	public void addCritterRandomlyToBestPatchesByPatch(int patchIndex, TraitList curSpeciesTraits)
	{
		int k = 0;
		ArrayList<Location> singlePatchLocations = this.bestPatchLocationsByPatch.get(patchIndex);
		while (true)
		{
			Location randLoc = singlePatchLocations.get(this.generator.nextInt(this.numberOfBestMicrositesInOnePatch));
			int randRow = randLoc.row();
			int randCol = randLoc.col();

			Location newLoc = new Location(randRow, randCol);
			Location3D newLoc3D = new Location3D(randRow, randCol, this.curSpeciesHomeIndex);
			boolean added = false;

			if (k < 100)
			{
				added = tryToAddCritter(curSpeciesTraits, newLoc3D, newLoc, null, false);
			}
			else
			{
				added = tryToAddCritterOverwritingAlwaysPermitted(curSpeciesTraits, newLoc3D, newLoc, null, false);
			}

			if (added)
			{
				break;
			}

			k++;
		}
	}

	public boolean tryToAddCritter(TraitList curSpeciesTraits, Location3D newLoc3D, Location newLoc, Location oldLoc, boolean useOldLoc)
	{
		boolean added = false;
		if (overwrite)
		{

			if (this.curSpecies.canRecruitIfCritterCanOverwriteHeterospecifics(this.com, newLoc))
			{
				addCritter(curSpeciesTraits, newLoc3D, newLoc, oldLoc, useOldLoc);
				added = true;
			}

		}
		else
		{
			if (this.curSpecies.canRecruit(this.com, newLoc))
			{
				addCritter(curSpeciesTraits, newLoc3D, newLoc, oldLoc, useOldLoc);
				added = true;
			}
		}

		return added;
	}

	public boolean tryToAddCritterOverwritingAlwaysPermitted(TraitList curSpeciesTraits, Location3D newLoc3D, Location newLoc, Location oldLoc, boolean useOldLoc)
	{
		boolean added = false;

		if (this.curSpecies.canRecruitIfCritterCanOverwriteHeterospecifics(this.com, newLoc))
		{
			addCritter(curSpeciesTraits, newLoc3D, newLoc, oldLoc, useOldLoc);
			added = true;
		}
		return added;
	}

	public void addCritter(TraitList tl, Location3D newLoc3D, Location newLoc, Location oldLoc, boolean useOldLoc)
	{

		int deadSpeciesVal = this.env.getGridValue(newLoc3D);
		this.env.add(newLoc3D, this.curSpeciesValue);
		if (tl != null)
		{
			if (useOldLoc)
			{
				tl.addToAllSpatialDistributionTrackers(newLoc, oldLoc);
			}
			else
			{
				if (tl.hasOldTraitArchive())
				{
					tl.addToAllSpatialDistributionTrackersRandomOldTraits(newLoc);
				}
				else
				{
					tl.addToAllSpatialDistributionTrackersBaselineTraits(newLoc);
				}
			}

		}

		if (deadSpeciesVal != 0)
		{
			TraitList deadSpeciesTL = this.com.getSpeciesList().get(deadSpeciesVal - 1).getTraitList();
			if (deadSpeciesTL != null)
			{
				deadSpeciesTL.removeFromAllSpatialDistributionTrackers(newLoc);
			}
		}
	}

}
