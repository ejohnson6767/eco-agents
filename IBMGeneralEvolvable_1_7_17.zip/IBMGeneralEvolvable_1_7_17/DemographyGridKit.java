import java.io.Serializable;

public class DemographyGridKit implements Serializable
{

	private GenericDemographyGrid genericDemographyGrid;
	private double[] rates;
	private double[][] specificDemographyGrid;
	
	public DemographyGridKit(GenericDemographyGrid genericDemographyGrid, double[] rates) throws Exception
	{
		this.genericDemographyGrid = (GenericDemographyGrid) DeepCopy.deepCopy(genericDemographyGrid);
		this.rates = rates;
		if(this.genericDemographyGrid.getNumberOfPatchTypes() != this.rates.length)
		{
			throw new IllegalArgumentException();
		}
		this.specificDemographyGrid = makeSpecificDemographyGrid(this.genericDemographyGrid);
	}
	
	public DemographyGridKit(double[][] specificDemographyGrid)
	{
		this.specificDemographyGrid = specificDemographyGrid;
	}
	
	public double[][] makeSpecificDemographyGrid(GenericDemographyGrid genericDemographyGrid)
	{
		int gridLength = genericDemographyGrid.getGridLength();
		double[][] newGrid = new double[gridLength][gridLength];
		int[][] grid = genericDemographyGrid.getGrid();
		
		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				
				newGrid[row][col] = rates[grid[row][col]];
			}
		}
		return newGrid;
	}
	
	public double[] getRates()
	{
		return this.rates;
	}
	
	public GenericDemographyGrid getGenericDemographyGrid()
	{
		return this.genericDemographyGrid;
	}
	
	public double[][] getSpecificDemographyGrid()
	{
		return this.specificDemographyGrid;
	}
	
	public double getRate(Location loc)
	{
		return this.specificDemographyGrid[loc.row()][loc.col()];
	}
	public double getRate(int row, int col)
	{
		return this.specificDemographyGrid[row][col];
	}
	
	
	
	
	
	
}
