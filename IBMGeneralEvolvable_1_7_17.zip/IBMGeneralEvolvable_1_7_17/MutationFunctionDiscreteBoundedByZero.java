import java.io.Serializable;
import java.util.Random;

public class MutationFunctionDiscreteBoundedByZero extends MutationFunctionStandard implements IMutationFunction, Serializable
{
	

	public MutationFunctionDiscreteBoundedByZero(double evolveProb, double mutationMagnitude)
	{
		super(evolveProb, mutationMagnitude);		
	}
	

	
	public double mutate(double traitValue)
	{
		
			// System.out.println("current br is " + curTrait);
			if (generator.nextDouble() < evolveProb.getEvolveProb())
			{
				int addTo = (int) Math.round(generator.nextGaussian() * mutationMagnitude.getMutationMagnitude());
				

				if (generator.nextInt(2) == 1)
				{
					addTo *= -1;

				}

				traitValue += addTo;

				if (traitValue < 0)
				{
					traitValue = 0;
				}

			}
			// System.out.println("modified br is " + curTrait);
			// System.out.println();

			return traitValue;
		}
	
	public double mutate(double traitValue, Location parentLoc)
	{
		
			// System.out.println("current br is " + curTrait);
			if (generator.nextDouble() < evolveProb.getEvolveProb(parentLoc))
			{
				int addTo = (int) Math.round(generator.nextGaussian() * mutationMagnitude.getMutationMagnitude(parentLoc));
				

				if (generator.nextInt(2) == 1)
				{
					addTo *= -1;

				}

				traitValue += addTo;

				if (traitValue < 0)
				{
					traitValue = 0;
				}

			}
			// System.out.println("modified br is " + curTrait);
			// System.out.println();

			return traitValue;
		}

	
}
