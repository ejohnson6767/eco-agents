import java.io.Serializable;

public interface IDeathProcess extends Serializable
{
	double getDeathRate(Location loc);
	void scaleByDt(double dt);
	void setSpeciesOwner(ISpecies species);
	void setupAfterCommunityIsCreated(Community com);

}
