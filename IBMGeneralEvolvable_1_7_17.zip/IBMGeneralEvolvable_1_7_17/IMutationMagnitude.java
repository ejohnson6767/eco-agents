import java.io.Serializable;

public interface IMutationMagnitude extends Serializable
{
	double getMutationMagnitude();
	void setMutationMagnitude(double newMutationMagnitude);
	double getMutationMagnitude(Location parentLoc);
	double[][] getSpatialDistributionTracker();
	void setupAfterCommunityIsCreated(Community com);
	void setSpeciesOwner(ISpecies species);
	boolean isIndividualBased();

	
}
