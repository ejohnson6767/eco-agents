import java.awt.BorderLayout;
import java.util.LinkedList;
import java.util.ListIterator;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.DisplayMode;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.io.File;
import java.io.IOException;
import java.lang.Math;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.LinkedList;
import java.util.ListIterator;

import com.jogamp.opengl.GL2;
import com.jogamp.opengl.GLAutoDrawable;
import com.jogamp.opengl.GLCapabilities;
import com.jogamp.opengl.GLEventListener;
import com.jogamp.opengl.GLProfile;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.glu.GLU;
import com.jogamp.opengl.util.FPSAnimator;
import com.jogamp.opengl.util.texture.Texture;
import com.jogamp.opengl.util.texture.TextureIO;

import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.KeyStroke;

public class QuantCheatVisualDonut implements GLEventListener
{

	// community constructor params //int envLength, int numSpecies, int radius, double fractionToFill, int initAbund)
	// varying area lots little
	// length radius 20 19 18 17 16 15 14 13 12 11 10 9 8 7 6 5 4 3 2 1
	// width radius 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39

	// varying perim lots
	// length radius 20 17 15 14 13 12 11 10 9 8 7 6 5 4
	// width radius 20 24 27 28 31 33 36 40 44 49 56 66 80 100

	// varying perim lots
	// length radius 50 30 21 16 13 11 8
	// width radius 1 2 3 4 5 6 8
	private static int timeStepCounter; // will give you an idea of how many time steps the simulation has been running for
	// private static Community community;
	private static Community community;

	// how long should the donut be?
	private static int gridLength = 50;
	private static float[] pixels = new float[gridLength * gridLength * 3];

	// construct species and put them in an array list. The format for species is given below:

	// Species(int speciesName, int initialAbundance, double cmax, double d, int dispersalRadius,
	// boolean makesAA1, boolean makesAA2, boolean makesAA3,
	// int AA1K, int AA2K, int AA3K)
	private static double dt = 0.2;

	private static boolean neverInoculate = false;

	private static double propToStart = 0.80;
	private static double initProp = 0.1;
	private static double r1 = 1;
	private static double r2 = 1;
	private static double r3 = 1;


	private static double n1Death = 0.1;
	private static double n2Death = 0.1;
	private static double n3Death = 0.1;


	private static int n1InitAbund = 1000;
	private static int n2InitAbund = 1000;
	private static int n3InitAbund = 0;

	private static int n1DispersalRadius = 5;
	private static int n1Inoculation = 0;
	private static int n1EvolveStart = 200;

	private static int n2DispersalRadius = 5;
	private static int n2Inoculation = 0;
	private static int n2EvolveStart = 200;
	
	private static int n3DispersalRadius = 1;
	private static int n3Inoculation = 1000000;
	private static int n3EvolveStart = 1000000;


	
	private static int invaderValue = 1;
	private static int invasionStart = 500000;
	private static double initialDensity = 0.005;
	private static double tooLow = 0.001;
	private static double tooHigh = 0.05;
	private static int regulateInvadersThisOften = 1;
	private static int archiveOldTraitsThisOften = 10;
	private static boolean overwrite = false;

	private static boolean useAltApproach = true;
	private static boolean hasRecruitmentGrid = false;

	// private static double cmaxSynmakesAA3 = 0.60;

	private static int stepsUntilInoculateCheater = 0;
	private static int stepsUntilInoculateGeneralist = 200;
	private static int scatterHowOften = 100000;

	// how far can species dispersal in any direction
	private static int interactionRadius = 1;

	// how many amino acids does each critter produce?

	private static boolean pause = false;
	private static boolean inoculateCheater = false;

	private static ArrayList<ISpecies> speciesList = new ArrayList<ISpecies>();

	private static int numberOfSpecies;

	private static GraphicsEnvironment graphicsEnviorment;
	private static boolean isFullScreen = false;
	public static DisplayMode dm, dm_old;
	private static Dimension xgraphic;
	private static Point point = new Point(0, 0);

	private GLU glu = new GLU();

	private static float xRot, yRot, zRot;
	private static float xRotSpeed, yRotSpeed, zRotSpeed;

	private int texture;
	private float[] lightAmbient = { 1f, 1f, 1f, 1.0f };
	private float[] lightDiffuse = { 0f, 0f, 0f, 0f };
	private float[] lightPosition = { 0.0f, 0.0f, 0.0f, 0.0f };
	private static boolean light = false;

	// angle of rotation for the camera direction
	float angle = 0.0f;
	// actual vector representing the camera's direction
	float lx = 0.0f, ly = 0.0f, lz = -1.0f;
	// XZ position of the camera
	float x = 0.0f, y = 1.0f, z = 5.0f;

	private static int FPS = 1000;

	public float[] getColor(int speciesValue)
	{
		float[] update = new float[3];

		if (speciesValue == 0)
		{
			update[0] = 1.0f;
			update[1] = 1.0f;
			update[2] = 1.0f;
		}
		else if (speciesValue == 1)
		{
			update[0] = 0.0f;
			update[1] = 1.0f;
			update[2] = 0.0f;

		}
		else if (speciesValue == 2)
		{
			update[0] = 1.0f;
			update[1] = 0.0f;
			update[2] = 0.0f;
		}
		else if (speciesValue == 3)
		{
			update[0] = 0.0f;
			update[1] = 0.0f;
			update[2] = 1.0f;
		}
		else if (speciesValue == 4)
		{
			update[0] = 1.0f;
			update[1] = 1.0f;
			update[2] = 0.0f;
		}
		else if (speciesValue == 5)
		{
			update[0] = 0.0f;
			update[1] = 1.0f;
			update[2] = 1.0f;
		}
		else if (speciesValue == 6)
		{
			update[0] = 1.0f;
			update[1] = 0.0f;
			update[2] = 1.0f;
		}
		else if (speciesValue == 7)
		{
			update[0] = 0.5f;
			update[1] = 1.0f;
			update[2] = 0.0f;
		}
		else if (speciesValue == 8)
		{
			update[0] = 0.0f;
			update[1] = 0.5f;
			update[2] = 1.0f;
		}
		else if (speciesValue == 69)
		{
			update[0] = 1.0f;
			update[1] = 1.0f;
			update[2] = 1.0f;
		}
		else
		{
			update[0] = 0.5f;
			update[1] = 0.0f;
			update[2] = 1.0f;
		}

		return update;
	}

	public void updateOnePixel(int row, int col, int speciesValue)
	{
		int start = ((col * gridLength) + row) * 3;
		float[] update = getColor(speciesValue);
		pixels[start] = update[0];
		pixels[start + 1] = update[1];
		pixels[start + 2] = update[2];

	}

	public void updatePixels() throws Exception
	{

		if (timeStepCounter == n1EvolveStart)
		{

			TraitList tl = speciesList.get(0).getTraitList();
			if (tl != null)
			{
				ArrayList<Evolvable> list = tl.getList();
				for (Evolvable e : list)
				{
					e.startEvolution();
				}
			}
		}
		if (timeStepCounter == n2EvolveStart)
		{
			TraitList tl = speciesList.get(1).getTraitList();
			if (tl != null)
			{
				ArrayList<Evolvable> list = tl.getList();
				for (Evolvable e : list)
				{
					e.startEvolution();
				}
			}
		}
		if (timeStepCounter == n3EvolveStart)
		{

			TraitList tl = speciesList.get(2).getTraitList();
			if (tl != null)
			{
				ArrayList<Evolvable> list = tl.getList();
				for (Evolvable e : list)
				{
					e.startEvolution();
				}
			}
		}
		/*if(timeStepCounter == 600)
		{
			TraitList tl = speciesList.get(0).getTraitList();
			if (tl != null)
			{
				ArrayList<Evolvable> list = tl.getList();
				for (Evolvable e : list)
				{
					e.stopEvolution();
				}
			}
		}*/

		pixels = new float[gridLength * gridLength * 3];
		pixels = new float[gridLength * gridLength * 3];
		if (!pause)
		{
			// community.evolutionHousekeeping();
			// CommunityUtilsStep.stepLVMovingWindowPropaguleRainMovingWindow(community);
			// CommunityUtilsStep.stepLVMovingWindowPropaguleRainBland(community);
			// CommunityUtilsStep.stepLVUpdatePropaguleRainMovingWindow(community);
			// CommunityUtilsStep.stepLVUpdatePropaguleRainBland(community);

			community.step();
			//community.step();

			
			// System.out.println("prop rain - using alt approach");
			// long start = System.nanoTime();
			// community.step();
			// long end = System.nanoTime();
			// long nanoTime = end - start;
			// System.out.println("whole step " + timeStepCounter + " took " + nanoTime / (double) 1000000 + " milliseconds");
			// System.out.println();

			timeStepCounter++;
		}

		if (timeStepCounter / 500 != 0 && timeStepCounter % 500 == 0)
		{
			/*
			 * double[] abunds = community.getAbundances(false); for (int i = 0; i < 3; i++) { System.out.println("the abundance of species " + i + " is " + abunds[i]); } for (int i = 0; i < 3; i++) { System.out.println(); }
			 */

		}

		if (inoculateCheater)
		{
			CommunityUtilsInoculate.inoculateSpecies(community, 0, true);
			inoculateCheater = false;
		}
		/*
		 * if (community.getTimeStep() == 100) { ArrayList<Species> SL = community.getSpeciesList(); for (int s = 0; s < this.numberOfSpecies; s++) { Species tempSpecies = SL.get(s); System.out.println("species " + s + " has a birth rate of " + tempSpecies.getCmax()); System.out.println("species " + s + " has a death rate of " + tempSpecies.getD()); System.out.println(""); } }
		 */
		/*
		 * if(timeStepCounter > 500) { community.invaderCheck(speciesList.get(0), tooLow, tooHigh);
		 * 
		 * }
		 */
		// community.scatter2();

		int[][][] grid = community.getGrid();

		double[][] dGrid = new double[gridLength][gridLength];
		for (int i = 0; i < dGrid.length; i++)
		{
			Arrays.fill(dGrid[i], 1);
		}

		if (hasRecruitmentGrid)
		{
			dGrid = community.getSpeciesList().get(0).getRecruitmentGrid();
		}
		for (int i = 0; i < grid.length; i++)
		{

			for (int row = 0; row < gridLength; row++)
			{
				for (int col = 0; col < gridLength; col++)
				{
					if (hasRecruitmentGrid)
					{
						if (dGrid[row][col] == 0)
						{
							updateOnePixel(row, col, 69);
						}
					}

					int gridValue = grid[i][row][col];

					if (gridValue == 0)
					{
						continue;
					}

					int currentName = speciesList.get(gridValue - 1).getGridProxy();
					// System.out.println("current name is " + currentName);

					updateOnePixel(row, col, currentName);

					/*
					 * if (currentName == 1) { updateOnePixel(row, col, 1);
					 * 
					 * if ((community.getTimeStep()-1) / 500 != 0 && (community.getTimeStep()-1) % 500 == 0) { double[][][] AAGrid = community.getAAGrid(); System.out.println("Amino acid 1 at syn one's site is " + row + " " + col + " at time step " + (community.getTimeStep()-1) + " is " + AAGrid[row][col][0]); System.out.println("Amino acid 2 at syn two's site is " + row + " " + col + " at time step " + (community.getTimeStep()-1) + " is " + AAGrid[row][col][1]); System.out.println("");
					 * 
					 * }
					 * 
					 * } else if (currentName == 2) { updateOnePixel(row, col, 2);
					 * 
					 * } else if (currentName == 3) {
					 * 
					 * updateOnePixel(row, col, 4); } else if (currentName == 12) {
					 * 
					 * updateOnePixel(row, col, 3); } else { updateOnePixel(row, col, 0); }
					 */
				}
			}
		}

		if (timeStepCounter / 50 != 0 && timeStepCounter % 50 == 0)
		{
			System.out.println("Time Step: " + timeStepCounter);

			double[] abunds = community.getAbundances(true);
			for (int i = 0; i < abunds.length; i++)
			{
				System.out.println("species " + i + " abund is " + abunds[i]);
			}
			ArrayList<Evolvable> traits = speciesList.get(0).getEvolvableTraits();
			for (int i = 0; i < traits.size(); i++)
			{
				System.out.println("trait average is " + traits.get(i).getTraitAverage());
			}

			traits = speciesList.get(1).getEvolvableTraits();
			for (int i = 0; i < traits.size(); i++)
			{
				System.out.println("trait average is " + traits.get(i).getTraitAverage());
			}
			
			traits = speciesList.get(2).getEvolvableTraits();
			for (int i = 0; i < traits.size(); i++)
			{
				System.out.println("trait average is " + traits.get(i).getTraitAverage());
			}

			/*
			 * double[] d = getDispersal.getDispersalDistribution(community, 1); for (int i = 0; i < 10; i++) { System.out.println("disp " + (i+1) + " is " + d[i]); }
			 */
			// System.out.println("species 1 is individual based: " + speciesList.get(0).getEvolvableTraits().get(0).isIndividualBased());
			// System.out.println("species 2 is individual based: " + speciesList.get(1).getEvolvableTraits().get(0).isIndividualBased());

		}

	

		if (timeStepCounter == stepsUntilInoculateCheater)
		{
			System.out.println("INOCULATING QUANTITATIVE CHEATER");
		}

	}

	/*
	 * public void drawTorus(GL2 gl, float r, float R, int nsides, int rings) {
	 * 
	 * float ringDelta = 2.0f * (float) Math.PI / rings; float sideDelta = 2.0f * (float) Math.PI / nsides; float theta = 0.0f, cosTheta = 1.0f, sinTheta = 0.0f;
	 * 
	 * gl.glFrontFace(GL2.GL_CW);
	 * 
	 * gl.glBindTexture(GL2.GL_TEXTURE_2D, this.texture); gl.glTexEnvf(GL2.GL_TEXTURE_ENV, GL2.GL_TEXTURE_ENV_MODE, GL2.GL_MODULATE);
	 * 
	 * for (int i = rings - 1; i >= 0; i--) { float theta1 = theta + ringDelta; float cosTheta1 = (float) Math.cos(theta1); float sinTheta1 = (float) Math.sin(theta1); gl.glBegin(GL2.GL_QUAD_STRIP); float phi = 0.0f; for (int j = nsides; j >= 0; j--) { phi += sideDelta; float cosPhi = (float) Math.cos(phi); float sinPhi = (float) Math.sin(phi); float dist = R + r * cosPhi; gl.glNormal3f(cosTheta1 * cosPhi, -sinTheta1 * cosPhi, sinPhi); gl.glVertex3f(cosTheta1 * dist, -sinTheta1 * dist, r * sinPhi); gl.glNormal3f(cosTheta * cosPhi, -sinTheta * cosPhi, sinPhi); gl.glVertex3f(cosTheta * dist, -sinTheta * dist, r * sinPhi); } gl.glEnd(); theta = theta1; cosTheta = cosTheta1; sinTheta = sinTheta1; } gl.glFrontFace(GL2.GL_CCW);
	 * 
	 * }
	 */
	// public void drawTorus(GL2 gl, double r, double c, int rSeg, int cSeg/*, int texture*/)

	/* void drawTorus( */

	/*
	 * { r = 0.07; c = 0.15; rSeg = 16; cSeg = 8; //texture = 0; gl.glFrontFace(GL2.GL_CW);
	 * 
	 * gl.glBindTexture(GL2.GL_TEXTURE_2D, this.texture); gl.glTexEnvf(GL2.GL_TEXTURE_ENV, GL2.GL_TEXTURE_ENV_MODE, GL2.GL_MODULATE);
	 * 
	 * double PI = 3.1415926535897932384626433832795; double TAU = 2 * PI;
	 * 
	 * for (int i = 0; i < rSeg; i++) { gl.glBegin(GL2.GL_QUAD_STRIP); for (int j = 0; j <= cSeg; j++) { for (int k = 0; k <= 1; k++) { double s = (i + k) % rSeg + 0.5; double t = j % (cSeg + 1);
	 * 
	 * double x = (c + r * Math.cos(s * TAU / rSeg)) * Math.cos(t * TAU / cSeg); double y = (c + r * Math.cos(s * TAU / rSeg)) * Math.sin(t * TAU / cSeg); double z = r * Math.sin(s * TAU / rSeg);
	 * 
	 * double u = (i + k) / (float) rSeg; double v = t / (float) cSeg;
	 * 
	 * gl.glTexCoord2d(u, v); //gl.glNormal3f(2 * x, 2 * y, 2 * z); gl.glVertex3d(2 * x, 2 * y, 2 * z); } } gl.glEnd(); }
	 * 
	 * //gl.glFrontFace(GL2.GL_CCW); }
	 */

	private void getSpeciesList()
	{
		// TODO Auto-generated method stub

	}

	void drawTorus(GL2 gl, double R, double r, int rSeg, int cSeg)
	{

		// this.texture = 0;

		gl.glFrontFace(GL2.GL_CW);

		gl.glBindTexture(GL2.GL_TEXTURE_2D, this.texture);
		gl.glTexEnvf(GL2.GL_TEXTURE_ENV, GL2.GL_TEXTURE_ENV_MODE, GL2.GL_MODULATE);

		double PI = Math.PI;
		double TAU = 2 * PI;

		for (int i = 0; i < rSeg; i++)
		{
			gl.glBegin(GL2.GL_QUAD_STRIP);
			for (int j = 0; j <= cSeg; j++)
			{
				for (int k = 0; k <= 1; k++)
				{
					double s = (i + k) % rSeg + 0.5;
					double t = j % (cSeg + 1);

					double x = (R + r * Math.cos(s * TAU / rSeg)) * Math.cos(t * TAU / cSeg);
					double y = (R + r * Math.cos(s * TAU / rSeg)) * Math.sin(t * TAU / cSeg);
					double z = r * Math.sin(s * TAU / rSeg);

					double u = (i + k) / (float) rSeg;
					double v = t / (float) cSeg;

					gl.glTexCoord2d(u, v);
					gl.glNormal3d(2 * x, 2 * y, 2 * z);
					gl.glVertex3d(2 * x, 2 * y, 2 * z);

					/*
					 * System.out.println("x is " + x); System.out.println("y is " + y);
					 * 
					 * System.out.println("z is " + z); System.out.println("");
					 */
				}
			}
			gl.glEnd();
		}

		gl.glFrontFace(GL2.GL_CCW);
	}

	public void drawSquare(GL2 gl, int row, int col)
	{

		// gl.glBegin(GL2.GL_QUADS);

		gl.glVertex3f((float) (row + .50), (float) (col + .50), 0.0f);
		gl.glVertex3f((float) (row + .50), (float) (col - .50), 0.0f);
		gl.glVertex3f((float) (row - .50), (float) (col - .50), 0.0f);
		gl.glVertex3f((float) (row - .50), (float) (col + .50), 0.0f);

		// gl.glEnd();

	}

	public void display(GLAutoDrawable drawable)
	{

		/*
		 * if(timeStepCounter % 30 == 0 && timeStepCounter / 30 != 0) { System.out.println("adding and removing critters"); community.addAndRemoveCritters(new double[] {1000,5000}); int[] abunds = community.getAbundances(); for (int i = 0; i < abunds.length; i++) { System.out.println(abunds[i]); } }
		 */
		final GL2 gl = drawable.getGL().getGL2();

		gl.glClearColor(0.4f, 0.5f, 1.0f, 1f);
		try
		{
			updatePixels();
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		ByteBuffer byteBuf = ByteBuffer.allocateDirect(pixels.length * Float.BYTES); // 4 bytes per float
		byteBuf.order(ByteOrder.nativeOrder());
		FloatBuffer buffer = byteBuf.asFloatBuffer();
		buffer.put(pixels);
		buffer.position(0);

		gl.glTexImage2D(GL2.GL_TEXTURE_2D, 0, GL2.GL_RGB, gridLength, gridLength, 0, GL2.GL_RGB, GL2.GL_FLOAT, buffer);

		gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_MAG_FILTER, GL2.GL_NEAREST);

		gl.glClear(GL2.GL_COLOR_BUFFER_BIT | GL2.GL_DEPTH_BUFFER_BIT); // Clear The Screen And The Depth Buffer
		gl.glLoadIdentity();
		// Reset The View
		/*
		 * glu.gluLookAt(x, y, z, x + lx, y + ly, z + lz, 0.0f, 1.0f, 0.0f); gl.glTranslatef(-5.0f, 1.0f, -10.0f); // Move Left 1.5 Units And Into The Screen 6.0
		 * 
		 * gl.glRotatef(xRot, 1.0f, 0.0f, 0.0f); gl.glRotatef(yRot, 0.0f, 1.0f, 0.0f); gl.glRotatef(zRot, 0.0f, 0.0f, 1.0f);
		 * 
		 * gl.glFrontFace(GL2.GL_CW);
		 * 
		 * gl.glBindTexture(GL2.GL_TEXTURE_2D, this.texture); gl.glTexEnvf(GL2.GL_TEXTURE_ENV, GL2.GL_TEXTURE_ENV_MODE, GL2.GL_MODULATE);
		 * 
		 * 
		 * // Drawing Using Triangl.gles
		 * 
		 * gl.glTranslatef(0f, 0f, -5.0f); gl.glRotatef(xrot, 1.0f, 0.0f, 0.0f); gl.glRotatef(yrot, 0.0f, 1.0f, 0.0f); gl.glRotatef(zrot, 0.0f, 0.0f, 1.0f); gl.glBindTexture(GL2.GL_TEXTURE_2D, texture); gl.glBegin(GL2.GL_QUADS); // Front Face gl.glTexCoord2f(0.0f, 0.0f); gl.glVertex3f(-1.0f, -1.0f, 1.0f); gl.glTexCoord2f(1.0f, 0.0f); gl.glVertex3f(1.0f, -1.0f, 1.0f); gl.glTexCoord2f(1.0f, 1.0f); gl.glVertex3f(1.0f, 1.0f, 1.0f); gl.glTexCoord2f(0.0f, 1.0f); gl.glVertex3f(-1.0f, 1.0f, 1.0f); // Back Face gl.glTexCoord2f(1.0f, 0.0f); gl.glVertex3f(-1.0f, -1.0f, -1.0f); gl.glTexCoord2f(1.0f, 1.0f); gl.glVertex3f(-1.0f, 1.0f, -1.0f); gl.glTexCoord2f(0.0f, 1.0f); gl.glVertex3f(1.0f, 1.0f, -1.0f); gl.glTexCoord2f(0.0f, 0.0f); gl.glVertex3f(1.0f, -1.0f, -1.0f); // Top Face gl.glTexCoord2f(0.0f, 1.0f); gl.glVertex3f(-1.0f, 1.0f, -1.0f); gl.glTexCoord2f(0.0f, 0.0f); gl.glVertex3f(-1.0f, 1.0f, 1.0f); gl.glTexCoord2f(1.0f, 0.0f); gl.glVertex3f(1.0f, 1.0f, 1.0f); gl.glTexCoord2f(1.0f, 1.0f);
		 * gl.glVertex3f(1.0f, 1.0f, -1.0f); // Bottom Face gl.glTexCoord2f(1.0f, 1.0f); gl.glVertex3f(-1.0f, -1.0f, -1.0f); gl.glTexCoord2f(0.0f, 1.0f); gl.glVertex3f(1.0f, -1.0f, -1.0f); gl.glTexCoord2f(0.0f, 0.0f); gl.glVertex3f(1.0f, -1.0f, 1.0f); gl.glTexCoord2f(1.0f, 0.0f); gl.glVertex3f(-1.0f, -1.0f, 1.0f); // Right face gl.glTexCoord2f(1.0f, 0.0f); gl.glVertex3f(1.0f, -1.0f, -1.0f); gl.glTexCoord2f(1.0f, 1.0f); gl.glVertex3f(1.0f, 1.0f, -1.0f); gl.glTexCoord2f(0.0f, 1.0f); gl.glVertex3f(1.0f, 1.0f, 1.0f); gl.glTexCoord2f(0.0f, 0.0f); gl.glVertex3f(1.0f, -1.0f, 1.0f); // Left Face gl.glTexCoord2f(0.0f, 0.0f); gl.glVertex3f(-1.0f, -1.0f, -1.0f); gl.glTexCoord2f(1.0f, 0.0f); gl.glVertex3f(-1.0f, -1.0f, 1.0f); gl.glTexCoord2f(1.0f, 1.0f); gl.glVertex3f(-1.0f, 1.0f, 1.0f); gl.glTexCoord2f(0.0f, 1.0f); gl.glVertex3f(-1.0f, 1.0f, -1.0f); gl.glEnd(); gl.glFlush(); xrot += .3f; yrot += .2f; zrot += .4;
		 * 
		 * double R = 1.5; double r = 1; int rSeg = 50; int cSeg = 50;
		 * 
		 * drawTorus(gl, R, r, rSeg, cSeg);
		 * 
		 * xRot += xRotSpeed; yRot += yRotSpeed; zRot += zRotSpeed;
		 * 
		 * gl.glLightfv(GL2.GL_LIGHT1, GL2.GL_AMBIENT, this.lightAmbient, 0); gl.glLightfv(GL2.GL_LIGHT1, GL2.GL_DIFFUSE, this.lightDiffuse, 0); gl.glLightfv(GL2.GL_LIGHT1, GL2.GL_POSITION, this.lightPosition, 0);
		 * 
		 * if (light) { gl.glEnable(GL2.GL_LIGHT1); gl.glEnable(GL2.GL_LIGHTING); } // System.out.println(xRotSpeed);
		 */gl.glLoadIdentity(); // Reset The View
		glu.gluLookAt(x, y, z, x + lx, y + ly, z + lz, 0.0f, 1.0f, 0.0f);
		// gl.glTranslatef(5.0f, 1.0f, -10.0f); // Move Left 1.5 Units And Into The Screen 6.0
		gl.glTranslatef(0.0f, 1.0f, -8.0f); // Move Left 1.5 Units And Into The Screen 6.0

		gl.glBegin(GL2.GL_QUADS);

		gl.glTexCoord2d(0, 1);
		gl.glVertex3d(-4, 4, 0.5);

		gl.glTexCoord2d(1, 1);
		gl.glVertex3d(4, 4, .5);

		gl.glTexCoord2d(1, 0);
		gl.glVertex3d(4, -4, .5);

		gl.glTexCoord2d(0, 0);
		gl.glVertex3d(-4, -4, .5);

		gl.glEnd();

		gl.glFlush();

		/*
		 * //final GL2 gl2 = drawable.getGL().getGL2();
		 * 
		 * //gl2.glClear(GL2.GL_COLOR_BUFFER_BIT | GL2.GL_DEPTH_BUFFER_BIT); // Clear The Screen And The Depth Buffer //gl2.glLoadIdentity(); // Reset The View gl.glLoadIdentity(); // Reset The View
		 * 
		 * glu.gluLookAt( x, y, z, x+lx, y+ly, z+lz, 0.0f, 1.0f, 0.0f);
		 * 
		 * 
		 * gl.glTranslatef(1.0f, 0.0f, -15.0f); // Move Left 1.5 Units And Into The Screen 6.0 makeFlatGrid(gl);
		 * 
		 * 
		 * gl.glFlush();
		 */

	}

	public void dispose(GLAutoDrawable drawable)
	{
		// TODO Auto-generated method stub

	}

	public void init(GLAutoDrawable drawable)
	{

		final GL2 gl = drawable.getGL().getGL2();
		gl.glShadeModel(GL2.GL_SMOOTH);
		gl.glClearColor(0f, 0f, 0f, 0f);
		gl.glClearDepth(1.0f);
		gl.glEnable(GL2.GL_DEPTH_TEST);
		gl.glDepthFunc(GL2.GL_LEQUAL);
		gl.glHint(GL2.GL_PERSPECTIVE_CORRECTION_HINT, GL2.GL_NICEST);

		gl.glEnable(GL2.GL_TEXTURE_2D);
		try
		{
			File im = new File("IBM.png");
			System.out.println("found the data");
			Texture t = TextureIO.newTexture(im, true);
			this.texture = t.getTextureObject(gl);
		} catch (IOException e)
		{
			System.out.println("can't find the png");
			e.printStackTrace();

		}
	}

	public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height)
	{
		// TODO Auto-generated method stub
		final GL2 gl = drawable.getGL().getGL2();

		if (height <= 0)
			height = 1;
		final float h = (float) width / (float) height;
		gl.glViewport(0, 0, width, height);
		gl.glMatrixMode(GL2.GL_PROJECTION);
		gl.glLoadIdentity();
		glu.gluPerspective(45.0f, h, 1.0, 20.0);
		gl.glMatrixMode(GL2.GL_MODELVIEW);
		gl.glLoadIdentity();
	}

	/**
	 * @param args
	 */
	/*
	 * public static void main(String[] args) { // TODO Auto-generated method stub // setUp open GL version 2 final GLProfile profile = GLProfile.get(GLProfile.GL2); GLCapabilities capabilities = new GLCapabilities(profile);
	 * 
	 * // The canvas final GLCanvas glcanvas = new GLCanvas(capabilities); Render r = new Render(); glcanvas.addGLEventListener(r); glcanvas.setSize(400, 400);
	 * 
	 * final FPSAnimator animator = new FPSAnimator(glcanvas, 300, true);
	 * 
	 * final JFrame frame = new JFrame("nehe: Lesson 6");
	 * 
	 * frame.getContentPane().add(glcanvas);
	 * 
	 * // Shutdown frame.addWindowListener(new WindowAdapter() { public void windowClosing(WindowEvent e) { if (animator.isStarted()) animator.stop(); System.exit(0); } });
	 * 
	 * frame.setSize(frame.getContentPane().getPreferredSize());
	 *//**
		* Centers the screen on start up
		* 
		*/

	/*
	 * graphicsEnviorment = GraphicsEnvironment.getLocalGraphicsEnvironment();
	 * 
	 * GraphicsDevice[] devices = graphicsEnviorment.getScreenDevices();
	 * 
	 * dm_old = devices[0].getDisplayMode(); dm = dm_old; Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	 * 
	 * int windowX = Math.max(0, (screenSize.width - frame.getWidth()) / 2); int windowY = Math.max(0, (screenSize.height - frame.getHeight()) / 2);
	 * 
	 * frame.setLocation(windowX, windowY);
	 *//**
		* @throws Exception 
			 * 
			 */
	/*
	 * frame.setVisible(true);
	 * 
	 * Time to add Button Control
	 * 
	 * JPanel p = new JPanel(); p.setPreferredSize(new Dimension(0, 0)); frame.add(p, BorderLayout.SOUTH);
	 * 
	 * keyBindings(p, frame, r); animator.start(); }
	 */
	public static void main(String[] args) throws Exception
	{
		


		// bmin, gain, K, q, theta
		double death = 0.1;
		
		double bmin1 = 1;
		double bmin2 = 1;
		double gain1 = 0.08;
		double gain2 = 0.08;
		double K = 2.5;
		double q1 = 0.6;
		double q2 = 0.6;
		double theta1 = 5;
		double theta2 = 5;
		n1DispersalRadius = 10;
		n2DispersalRadius = 10;
		int diffusion1 = 10;
		int diffusion2 = 10;
		
		double bmin3 = 0.6;
		double gain31 = 0.01;
		double gain32 = 0.01;
		double q31 = 0.8;
		double q32 = 0.8;
		double theta31 = 5;
		double theta32 = 5;
		int diffusion31 = 3;
		int diffusion32 = 3;
		
		
		
		speciesList = new ArrayList<ISpecies>();

		/*
		 * // Species(int speciesName1, int initialAbundance, double cmax, double d, boolean makesAA1, boolean makesAA2, boolean makesAA3, double AA1K, double AA2K, double AA3K)
		 * 
		 * speciesList.add(new Species(0, quantCheatInitAbund, cmaxQuantCheat, death, 0, false, new boolean[] { false, false, false, false, false, false, false, false }, new double[] { 1, 1, 1, 1, 1, 1, 1, 1 })); speciesList.add(new Species(1, synInitAbund, cmaxSynGen, death, 0, false, new boolean[] { true, false, false, false, false, false, false, false }, new double[] { 0, 1, 1, 1, 1, 1, 1, 1 })); speciesList.add(new Species(2, synInitAbund, cmaxSynGen, death, 0, false, new boolean[] { false, true, false, false, false, false, false, false }, new double[] { 1, 0, 1, 1, 1, 1, 1, 1 })); speciesList.add(new Species(12, synInitAbund, cmaxGeneralist, death, 0, false, new boolean[] { true, true, false, false, false, false, false, false }, new double[] { 0, 0, 1, 1, 1, 1, 1, 1 }));
		 */
		speciesList.add(new Species(r2, n2Death, n2DispersalRadius));
		speciesList.add(new Species(r1, n1Death, n1DispersalRadius));
		speciesList.add(new Species(r3, n3Death, n3DispersalRadius));
		
		
		

		IBirthProcess bpQCn1 = new BirthQuantCheat(bmin1, gain1, K, q1, theta1);
		IBirthProcess bpQCn2 = new BirthQuantCheat(bmin2, gain2, K, q2, theta2);
		IBirthProcess bpQCn3 = new BirthQuantCheatGen(bmin3, new double[] { gain31, gain32 }, K, new double[] { q31, q32 }, new double[] { theta31, theta32 });
		
		speciesList.get(0).setBirthProcess(bpQCn1);
		speciesList.get(1).setBirthProcess(bpQCn2);
		speciesList.get(2).setBirthProcess(bpQCn3);
		
		speciesList.get(0).setDeathProcess(new DeathStandard(death));
		speciesList.get(1).setDeathProcess(new DeathStandard(death));
		speciesList.get(2).setDeathProcess(new DeathStandard(death));

		
		// q, diffusion radius
		IEffect lv1 = new Effect(q1, diffusion1, 1);
		// ILVEffect lv1 = new Effect(q1, diffusion1, 1);
		// ILVEffect lv1On3 = new Effect(0.8, 3, 1);

		IEffect lv2 = new Effect(q2, diffusion2, 2);
		// ILVEffect lv2On2 = new Effect(q2, diffusion2, 2);
		// ILVEffect lv2On3 = new Effect(0.8, 3, 2);
		IEffect lv31 = new Effect(q31, diffusion31, 1);
		IEffect lv32 = new Effect(q32, diffusion32, 2);
		IEffect lv3On2 = new Effect(0.8, 3, 1);
		IEffect lv3On3 = new Effect(0.8, 3, 1);
		IEffect lv3On12 = new Effect(0.8, 3, 2);
		IEffect lv3On22 = new Effect(0.8, 3, 2);
		IEffect lv3On32 = new Effect(0.8, 3, 2);

		speciesList.get(0).setLocalEffect(1, lv1);
		speciesList.get(0).setLocalEffect(2, lv1);
		// speciesList.get(0).setLocalEffect(3, lv1On3);

		speciesList.get(1).setLocalEffect(1, lv2);
		speciesList.get(1).setLocalEffect(2, lv2);
		
		speciesList.get(2).setLocalEffect(1, lv31);
		speciesList.get(2).setLocalEffect(2, lv31);
		speciesList.get(2).setLocalEffect(3, lv31);
		speciesList.get(2).setLocalEffect(1, lv32);
		speciesList.get(2).setLocalEffect(2, lv32);
		speciesList.get(2).setLocalEffect(3, lv32);
		


		
		
	/*	// predatorPrey stuff
		IEffect preyEffect = new Effect(1, 2, 1);
		IEffect predEffect = new Effect(1, 2, 1);
		
		speciesList.get(0).setLocalEffect(2, preyEffect);
		speciesList.get(1).setLocalEffect(1, predEffect);

		IBirthProcess bPred = new BirthLinear(1);
		IDeathProcess dPred = new DeathStandard(0.1);

		IBirthProcess bPrey = new BirthStandard(0.1);
		IDeathProcess dPrey = new DeathLinear(1);
	
		speciesList.get(0).setBirthProcess(bPrey);
		speciesList.get(0).setDeathProcess(dPrey);
		speciesList.get(1).setBirthProcess(bPred);
		speciesList.get(1).setDeathProcess(dPred);*/
		
		
		
		/*
		 * ILVEffect lv11 = new Effect(8, 1); ILVEffect lv21 = new Effect(8, 5);
		 */

		// LVEffectQuantCheat lv1 = new LVEffectQuantCheat(16, 0.5, 1);
		// LVEffectQuantCheat lv2 = new LVEffectQuantCheat(16, 0.5, 5);

		// speciesList.get(0).setLocalLVEffect(2, lv1);
		// speciesList.get(1).setLocalLVEffect(1, lv2);

		// IBirthProcess bl = new BirthLinear(r2);
		// IDeathProcess d1 = new DeathLinear(n1Death);

		// IBirthProcess bl = new BirthAdditive(r2);
		// IDeathProcess d1 = new DeathAdditive(n1Death);

		// speciesList.get(0).setDeathProcess(d1);
		// speciesList.get(1).setBirthProcess(bl);
		/*IMutationFunction mfDifn1 = new MutationFunctionDiscreteBoundedByZero(0.05, 1);
		Evolvable diffusionEvolven1 = new DiffusionIB(mfDifn1, 2, 1, preyEffect);

		IMutationFunction mfDifn2 = new MutationFunctionDiscreteBoundedByZero(0.05, 1);
		Evolvable diffusionEvolven2 = new DiffusionIB(mfDifn2, 1, 1, predEffect);*/

		/*IMutationFunction mfEff = new MutationFunctionContinuous(0.00, 0.05);
		Evolvable effectValueEvolve = new EffectValueIB(mfEff, 2, 1, lv1);*/

		IMutationFunction mfDisp = new MutationFunctionDiscreteBoundedByOne(0.1, 1);
		Evolvable dispEvolven1 = new DispersalIB(mfDisp);

		IMutationFunction mfDispn2 = new MutationFunctionDiscreteBoundedByOne(0.005, 1);
		Evolvable dispEvolven2 = new DispersalIB(mfDispn2);

		IMutationFunction mfEvolveProb = new MutationFunctionContinuousBoundedByZero(0.05, 0.03);
		Evolvable evolveProbEvolve = new EvolveProbIB(mfEvolveProb, mfDisp);

		IMutationFunction mfmm = new MutationFunctionContinuousBoundedByZero(0.05, 0.5);
		Evolvable mmEvolve = new MutationMagnitudeIB(mfmm, mfDisp);

		IMutationFunction mfQn1 = new MutationFunctionContinuousBoundedBetweenZeroAndOne(0.2, 0.05);
		Evolvable evolveQn1 = new QuantCheatQIB(mfQn1, 1);
		
		IMutationFunction mfQn2 = new MutationFunctionContinuousBoundedBetweenZeroAndOne(0.2, 0.05);
		Evolvable evolveQn2 = new QuantCheatQIB(mfQn2, 2);
		
		IMutationFunction mfQ31 = new MutationFunctionContinuousBoundedBetweenZeroAndOne(0.9, 0.05);
		Evolvable evolveQ31 = new QuantCheatQIB(mfQ31, 1);
		IMutationFunction mfQ32 = new MutationFunctionContinuousBoundedBetweenZeroAndOne(0.9, 0.05);
		Evolvable evolveQ32 = new QuantCheatQIB(mfQ32, 2);


		//speciesList.get(0).setHomeGridValue(1);
		//speciesList.get(1).setHomeGridValue(2);

		//speciesList.get(0).setEnvGridValuesThatAffectRecruitment(new int[] {1});
		//speciesList.get(1).setEnvGridValuesThatAffectRecruitment(new int[] {2});

		// ContinuousTrait trait1 = new ContinuousTrait(gridLength, 0.10, 3);
		// DispersalDistance trait2 = new DispersalDistance(gridLength, 0.05, 1);
		// BaselineBirthRate trait2 = new BaselineBirthRate(gridLength, 0.05, 0.05);

		// ArrayList<Evolvable> tradeOffTraits = new ArrayList<Evolvable>();
		// tradeOffTraits.add(trait2);

		// TradeOff tradeOff = new DispersalBirthRateTradeOff(trait1, tradeOffTraits);
		// ArrayList<TradeOff> tradeOffList = new ArrayList<TradeOff>();
		// tradeOffList.add(tradeOff);

		// ArrayList<Evolvable> traitList = new ArrayList<Evolvable>();
		// traitList.add(trait1);
		// traitList.add(diffusionEvolve);
		// traitList.add(effectValueEvolve);

		// TraitList traitListList = new TraitList(traitList, tradeOffList);
		// TraitList traitListList = new TraitList(traitList);
		// traitListList.setTimeBetweenOldTraitUpdates(0);
		// traitListList.setUseAltApproach(useAltApproach);

		// speciesList.get(0).setTraitList(traitListList);
		// speciesList.get(0).addTrait(effectValueEvolve);
		
		 
		//speciesList.get(0).addTrait(dispEvolven1);
		//speciesList.get(0).addTrait(diffusionEvolven1);
		//speciesList.get(1).addTrait(diffusionEvolven2);

		// speciesList.get(0).addTrait(evolveProbEvolve);
		// speciesList.get(0).addTrait(mmEvolve);

		speciesList.get(0).addTrait(evolveQn1);
		speciesList.get(1).addTrait(evolveQn2);

		//speciesList.get(2).addTrait(evolveQ31);
		//speciesList.get(2).addTrait(evolveQ32);

		
		// speciesList.get(1).addTrait(evolveQn2);

		// speciesList.get(1).addEvolvableTrait(trait1);

		GenericDemographyGrid grid = new GenericDemographyGrid(gridLength);
		// grid.makePatchyGrid(speciesList.size(), 30, 20, 0.3, 300);
		grid.setSeed(20);
		// grid.makePercolationGrid(new double[] { 0.80 });

		// grid.makeCheckerboardGrid(gridLength/40, 40, true);
		// speciesList.get(0).setRecruitmentGrid(grid, new double[] { 0, 1 });
		// speciesList.get(1).setRecruitmentGrid(grid, new double[] { 0, 1 });

		// RegionallySimilarSpecies rss = new RegionallySimilarSpecies( grid, speciesList, true);

		// rss.makeSpeciesRateByLocationMatrix(0.8, 0.4, 0, 0.1);
		// rss.applyToSpeciesBirth();


		community = new Community(gridLength, dt, speciesList);

		
		//dispEvolven1.startEvolution();
		
		AddCritters ac = new AddCritters(community, 1, false);
		ac.addCrittersRandomly(n1InitAbund);
		ac = new AddCritters(community, 2, false);
		ac.addCrittersRandomly(n2InitAbund);
		ac = new AddCritters(community, 3, false);
		ac.addCrittersRandomly(n3InitAbund);
		numberOfSpecies = speciesList.size();
		
		/*speciesList.get(0).addTrait(dispEvolven1);
		dispEvolven1.startEvolution();
		
		speciesList.get(0).addTrait(evolveProbEvolve);
		evolveProbEvolve.startEvolution();*/
	
	
	/*	System.out.println("SIZE is " + speciesList.get(0).getTraitList().getList().size());
		ArrayList<Evolvable> l = speciesList.get(0).getTraitList().getList();
		for(Evolvable trait:l)
		{
			System.out.println("is evolving " + trait.isIndividualBased());
		}*/
		//speciesList.get(0).addTrait(evolveProbEvolve);
		//evolveProbEvolve.startEvolution();

		// Community(int envLength, ArrayList<Species> speciesList)
		// community = new Community(gridLength, dt, interactionRadius, speciesList);
		
		// ac = new AddCritters(community, 3, false);
		// ac.setReferenceLocation(100, 100);
		// ac.setDispersalLength(10);
		// ac.addCrittersRandomly(n2InitAbund);

		
		// community.setFancyInvasionParameters(invaderValue, invasionStart, tooLow, tooHigh, overwrite, regulateInvadersThisOften, archiveOldTraitsThisOften);
		// community.setBlandInvasionParameters(invaderValue, invasionStart, initialDensity, overwrite);
		// community.setUseMovingWindowForPropaguleRain(true);
		// community.setOptimizeThisOften(0);

		// Community com = (Community) DeepCopy.deepCopy(community);
		// community = com;
		// System.out.println("done with deep copy");
		// community.getEnvironment().setSeedAtOneLevel(2, 20);

		// CommunityUtilsInoculate.inoculateSpeciesUniformly(community, 0, true);

		/*ArrayList<ISpecies> speciesList = community.getSpeciesList();
		ISpecies curSpecies = speciesList.get(0);
		int init = curSpecies.getInitialAbundance();*/
		// AddCritters ac = new AddCritters(community, (0 + 1), false);
		// ac.setReferenceLocation(100, 100);
		// ac.setDispersalLength(10);
		// ac.addCrittersUniformly(init);

		// System.out.println("abund after addcritters is " + community.getAbundances()[0]);
		/*
		 * System.out.println(community.getAbundances()[0]);
		 * 
		 * community.step(50); System.out.println(community.getAbundances()[0]);
		 * 
		 * speciesList.get(0).getTraitList().getList().get(0).startEvolution(community); for (int i = 0; i < 300; i++) { community.step(); } System.out.println(community.getAbundances()[0]); DispersalIB dss = (DispersalIB) community.getSpeciesList().get(0).getDispersalStrategy();
		 * 
		 * long start = System.nanoTime(); for (int i = 0; i < 1000; i++) { dss.fillGridMovingWindowAllDispersal(); } long end = System.nanoTime(); long nanoTime = end - start; System.out.println("regular approach took " + nanoTime / (double) 1000000 + " milliseconds");
		 * 
		 * start = System.nanoTime(); for (int i = 0; i < 1000; i++) { dss.fillGridMovingWindowAllDispersalNew(); } end = System.nanoTime(); nanoTime = end - start; System.out.println("new approach took " + nanoTime / (double) 1000000 + " milliseconds");
		 */

		// community.getEnvironment().getGenerator(1).setSeed(20);

		/*
		 * community.step(); speciesList.get(1).startEvolution(community); community.anySpeciesEvolving();
		 */
		// System.out.println("optimizing");p
		// community.optimizeEfficiency(10);
		/*
		 * community.inoculateInMiddle(false, true, true); community.neverInoculate();
		 */
		// community = community.deepCopy(community);
		// community.getPercolationCommunity(new int[] {1000,1000});
		// community.inoculateInMiddle(100);

		/*
		 * community = new Community(0,0, 0,0 , stepsUntilInoculateCheater, 1000, dt, gridLength, interactionRadius, dispersalRadius, KAAProduced, death, cmaxQuantCheat, 0, cmaxSynmakesAA1, cmaxSynmakesAA2, useStep2, 0.10, 1,1, 0,1, 1,0);
		 * 
		 * speciesList = community.getSpeciesList();
		 */

		System.out.println();
		// setUp open GL version 2
		final GLProfile profile = GLProfile.get(GLProfile.GL2);
		GLCapabilities capabilities = new GLCapabilities(profile);

		// The canvas
		final GLCanvas glcanvas = new GLCanvas(capabilities);
		QuantCheatVisualDonut r = new QuantCheatVisualDonut();
		glcanvas.addGLEventListener(r);
		glcanvas.setSize(900, 400);

		final FPSAnimator animator = new FPSAnimator(glcanvas, FPS, true);

		final JFrame frame = new JFrame("donut model");

		frame.getContentPane().add(glcanvas);

		// Shutdown
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e)
			{
				if (animator.isStarted())
					animator.stop();
				System.exit(0);
			}
		});

		frame.setSize(frame.getContentPane().getPreferredSize());
		/**
		 * Centers the screen on start up
		 * 
		 */
		graphicsEnviorment = GraphicsEnvironment.getLocalGraphicsEnvironment();

		GraphicsDevice[] devices = graphicsEnviorment.getScreenDevices();

		dm_old = devices[0].getDisplayMode();
		dm = dm_old;
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

		int windowX = Math.max(0, (screenSize.width - frame.getWidth()) / 2);
		int windowY = Math.max(0, (screenSize.height - frame.getHeight()) / 2);

		frame.setLocation(windowX, windowY);
		/**
				 * 
				 */
		frame.setVisible(true);
		/*
		 * Time to add Button Control
		 */
		JPanel p = new JPanel();
		p.setPreferredSize(new Dimension(0, 0));
		frame.add(p, BorderLayout.SOUTH);

		keyBindings(p, frame, r);
		animator.start();
	}

	public static void keyBindings(JPanel p, final JFrame frame, final QuantCheatVisualDonut r)
	{

		ActionMap actionMap = p.getActionMap();
		InputMap inputMap = p.getInputMap();

		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0), "F1");
		actionMap.put("F1", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				fullScreen(frame);
			}
		});
		/**
		 * 
		 */
		/*
		 * 
		 */
		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_UP, 0), "UP");
		actionMap.put("UP", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				if (xRotSpeed > -8)
				{
					xRotSpeed -= 0.1f;
				}
			}
		});
		/**
		 * 
		 */
		/*
		 * 
		 */
		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_P, 0), "P");
		actionMap.put("P", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				if (pause)
				{
					pause = false;
				}
				else
				{
					pause = true;
				}
			}
		});
		/**
		 * 
		 */
		/*
		 * 
		 */

		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_I, 0), "I");
		actionMap.put("I", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				inoculateCheater = true;
			}
		});
		/**
		 * 
		 */
		/*
		 * 
		 */
		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_K, 0), "K");
		actionMap.put("K", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				int[][][] grid = community.getGrid();

				for (int i = 0; i < grid.length; i++)
				{

					for (int row = 0; row < gridLength; row++)
					{
						for (int col = 0; col < gridLength; col++)
						{
							if (grid[i][row][col] == 1)
							{
								grid[i][row][col] = 0;
							}
						}
					}
				}
			}
		});
		/**
		 * 
		 */
		/*
		 * 
		 */
		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_C, 0), "C");
		actionMap.put("C", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				int[][][] grid = community.getGrid();
				int mid = (int) Math.round(gridLength / (double) 2);

				for (int i = 0; i < grid.length; i++)
				{
					for (int row = mid - 80; row < mid + 80; row++)
					{
						for (int col = mid - 80; col < mid + 80; col++)
						{

							grid[i][row][col] = 0;

						}
					}
				}
			}
		});
		/**
		 * 
		 */
		/*
		 * 
		 */
		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, 0), "DOWN");
		actionMap.put("DOWN", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				if (xRotSpeed < 8)
				{
					xRotSpeed += 0.1f;
				}
			}
		});
		/** 
		 * 
		 */
		/*
		 * 
		 */
		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0), "LEFT");
		actionMap.put("LEFT", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				if (yRotSpeed < 8)
				{
					yRotSpeed += 0.1f;
				}
			}
		});
		/**
		 * 
		 */
		/*
		 * 
		 */
		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0), "RIGHT");
		actionMap.put("RIGHT", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				if (yRotSpeed > -8)
				{
					yRotSpeed -= 0.1f;
				}
			}
		});
		/**
		 * 
		 */
		/*
		 * 
		 */

		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_S, 0), "S");
		actionMap.put("S", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				float fraction = 0.1f;
				r.x -= r.lx * fraction;
				r.z -= r.lz * fraction;
			}
		});

		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_W, 0), "W");
		actionMap.put("W", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				float fraction = 0.1f;
				r.x += r.lx * fraction;
				r.z += r.lz * fraction;
			}
		});

		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_D, 0), "D");
		actionMap.put("D", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				float fraction = 0.1f;
				r.x += fraction;
			}
		});

		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_A, 0), "A");
		actionMap.put("A", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				float fraction = 0.1f;
				r.x -= fraction;
			}
		});

	}

	protected static void fullScreen(JFrame f)
	{
		// TODO Auto-generated method stub
		if (!isFullScreen)
		{
			f.dispose();
			f.setUndecorated(true);
			f.setVisible(true);
			f.setResizable(false);
			xgraphic = f.getSize();
			point = f.getLocation();
			f.setLocation(0, 0);
			Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
			f.setSize((int) screenSize.getWidth(), (int) screenSize.getHeight());
			isFullScreen = true;
		}
		else
		{
			f.dispose();
			f.setUndecorated(false);
			f.setResizable(true);
			f.setLocation(point);
			f.setSize(xgraphic);
			f.setVisible(true);

			isFullScreen = false;
		}

	}

}