import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

public class ScrambleMultipleSpecies extends AddCritters implements Serializable
{

	private int[] speciesValueMultipleSpecies;
	private boolean[] overwriteMultipleSpecies;
	private boolean[] isIB;
	private ArrayList<ArrayList<double[]>> allTraitsAllSpecies;
	private ArrayList<int[]> indexes;
	private int[] abundanceCounter;
	private int speciesIndexToAdd;

	public ScrambleMultipleSpecies(Community com, int[] speciesValues)
	{
		// the second two parameters are meaningless. The only method in the class will change these when it is needed
		super(com, 1, false);
		this.speciesValueMultipleSpecies = speciesValues;
		this.overwriteMultipleSpecies = new boolean[speciesValues.length];
		for (int i = 0; i < speciesValues.length; i++)
		{
			this.overwriteMultipleSpecies[i] = false;
		}

	}

	private int[] shuffleIndexArray(int speciesValue, int length)
	{
		int[] array = new int[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = i;
		}

		int index;
		this.generator = com.getEnvironment().getGenerator(this.curSpeciesHomeIndex);
		for (int i = array.length - 1; i > 0; i--)
		{
			index = generator.nextInt(i + 1);
			if (index != i)
			{
				array[index] ^= array[i];
				array[i] ^= array[index];
				array[index] ^= array[i];
			}
		}
		return array;
	}

	public void setupFieldsNStuff()
	{

	}

	public void scrambleCrittersMultipleSpecies()
	{
		int numSpecies = this.speciesValueMultipleSpecies.length;

		this.allTraitsAllSpecies = new ArrayList<ArrayList<double[]>>();
		this.indexes = new ArrayList<int[]>();

		this.isIB = new boolean[numSpecies];
		ArrayList<ISpecies> speciesList = this.com.getSpeciesList();

		int[] abundances = new int[numSpecies];
		int[] curAbunds = this.com.getAbundances();
		for (int i = 0; i < com.getNumberOfSpecies(); i++)
		{
			if ((i + 1) == this.speciesValueMultipleSpecies[i])
			{
				abundances[i] = curAbunds[i];
				ISpecies curSpecies = speciesList.get(i);
				if (SpeciesTraitQuestions.isIndividualBased(curSpecies))
				{
					isIB[i] = true;
					TraitList tl = curSpecies.getTraitList();
					allTraitsAllSpecies.add(tl.getTraits());
					indexes.add(shuffleIndexArray((i + 1), abundances[i]));
					tl.resetAllSpatialDistributionTrackers();
				}
				else
				{
					isIB[i] = false;
					allTraitsAllSpecies.add(null);
					indexes.add(null);
				}
				RemoveCritters rc = new RemoveCritters(this.com, this.speciesValueMultipleSpecies[i]);
				rc.removeCritters(abundances[this.speciesValueMultipleSpecies[i] - 1]);
			}
		}
		// System.out.println("starting makePercolationGrid");

		this.abundanceCounter = new int[numSpecies];
		double[] placeCritterProbs = new double[numSpecies];
		double[] placeCritterProbsCum = new double[numSpecies];
		// whether the number of added critters (totalAbundanceCounter) equals the number that need to be added will be determine when the algorithm is finished
		int totalAbundanceCounter = 0;
		int total = 0;
		for (int i = 0; i < numSpecies; i++)
		{
			total += abundances[i];
		}

		// the relative proportions of species will determine their probability of being picked to be added. Critters are added in this random way to give fully random spatial distributions
		if (total == 0)
		{
			for (int i = 0; i < numSpecies; i++)
			{
				placeCritterProbs[i] = 0;
				// System.out.println("placeCriterProbs " + i + " is " + placeCritterProbs[i]) ;
			}
		}
		else
		{
			for (int i = 0; i < numSpecies; i++)
			{
				placeCritterProbs[i] = abundances[i] / (double) total;
				// System.out.println("placeCriterProbs " + i + " is " + placeCritterProbs[i]);
			}
		}

		for (int i = 0; i < numSpecies; i++)
		{
			if (i == 0)
			{
				placeCritterProbsCum[i] = placeCritterProbs[i];
			}
			else
			{
				placeCritterProbsCum[i] = placeCritterProbs[i] + placeCritterProbsCum[i - 1];
			}
			// System.out.println("placeCriterProbsCum " + i + " is " + placeCritterProbsCum[i]);

		}

		// main loop. only breaks once all species are added
		while (true)
		{
			// System.out.println("in the loop");
			// get a random number to decide which species is going to be added...
			double rand = generator.nextDouble();
			for (int i = 0; i < numSpecies; i++)
			{
				// System.out.println("rand is " + rand + ". place critter probs cum is " + placeCritterProbsCum[i]);

				if (rand <= placeCritterProbsCum[i])
				{
					this.speciesIndexToAdd = i;
					// System.out.println("species Index to add is " + this.speciesIndexToAdd);
					break;
				}

			}

			/*
			 * System.out.println(""); System.out.println("totalAbundanceCounter is " + totalAbundanceCounter); System.out.println("abundanceGoal is " + total);
			 */

			// ... if all the critters of the chosen species has been added, continue the loop and try again for a different species...

			// otherwise, search for an empty site and place the critter there
			if (this.abundanceCounter[this.speciesIndexToAdd] != abundances[this.speciesIndexToAdd])
			{
				this.overwrite = this.overwriteMultipleSpecies[speciesIndexToAdd];
				this.curSpeciesValue = this.speciesValueMultipleSpecies[speciesIndexToAdd];
				this.curSpecies = com.getSpeciesList().get(this.curSpeciesValue - 1);
				this.curSpeciesHomeIndex = this.curSpecies.getHomeGridIndex();
				this.generator = com.getEnvironment().getGenerator(this.curSpeciesHomeIndex);

				addCrittersRandomlyWithLimitations(1, this.speciesValueMultipleSpecies);

				this.abundanceCounter[this.speciesIndexToAdd]++;
				//System.out.println("abundance for species " + this.speciesValueMultipleSpecies[this.speciesIndexToAdd] + " is " + this.abundanceCounter[this.speciesIndexToAdd]);
				totalAbundanceCounter++;
			}
			else
			{
				if (totalAbundanceCounter == total)
				{
					break;
				}
			}
			/*
			 * System.out.println(""); System.out.println("totalAbundanceCounter is " + totalAbundanceCounter); System.out.println("abundanceGoal is " + total);
			 */
		}
		UpdateAbundances ua = new UpdateAbundances(this.com);
		ua.update();
	}

	public void addCritter(TraitList tl, Location3D newLoc3D, Location newLoc)
	{

		if (this.isIB[this.speciesIndexToAdd])
		{
			int randIndex = this.indexes.get(this.speciesIndexToAdd)[this.abundanceCounter[this.speciesIndexToAdd]];
			double[] traitValues = this.allTraitsAllSpecies.get(this.speciesIndexToAdd).get(randIndex);

			this.env.add(newLoc3D, this.curSpeciesValue);
			ArrayList<Evolvable> traits = tl.getList();
			for (int i = 0; i < traitValues.length; i++)
			{
				traits.get(i).addToSpatialDistributionTrackerForScrambling(newLoc, traitValues[i]);
			}

		}
		else
		{
			this.env.add(newLoc3D, this.curSpeciesValue);
		}

	}

}
