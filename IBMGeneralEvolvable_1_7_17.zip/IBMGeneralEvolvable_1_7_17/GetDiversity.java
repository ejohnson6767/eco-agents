import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

public class GetDiversity implements Serializable
{
	private Community com;
	private Environment env;
	private int gridLength;
	private RegionallySimilarSpecies rss;
	private boolean[] regionalSpeciesEncountered;
	private double[][] patchTypeByIndexDivMatrix;

	public GetDiversity(Community com, RegionallySimilarSpecies rss)
	{
		this.com = com;
		this.env = this.com.getEnvironment();
		this.gridLength = this.env.getGridLength();
		this.rss = rss;
		this.regionalSpeciesEncountered = new boolean[this.com.getNumberOfSpecies() + 1];
		Arrays.fill(this.regionalSpeciesEncountered, false);
		this.regionalSpeciesEncountered[0] = true;
		
	}
	
	public double getRegionalRichness()
	{
		int totalEncountered = -1;
		for (int i = 0; i < this.regionalSpeciesEncountered.length; i++)
		{
			if(this.regionalSpeciesEncountered[i])
			{
				totalEncountered ++;
			}
		}
		return totalEncountered;
	}
	
	public double[][] getLocalRichnessMatrix()
	{
		return this.patchTypeByIndexDivMatrix;
	}
	
	
	public void collectData()
	{
		ArrayList<ArrayList<Patch>> patches = this.rss.getGenericDemographyGrid().getPatchList();
		GenericDemographyGrid gdg = this.rss.getGenericDemographyGrid();
		int patchesPerSpecies = gdg.getPatchesPerSpecies();
		int numPatchTypes = gdg.getNumberOfNonZeroPatchTypes();

		this.patchTypeByIndexDivMatrix = new double[numPatchTypes][patchesPerSpecies]; 
		for (int i = 0; i < numPatchTypes; i++)
		{
			ArrayList<Patch> patchesForASingleType = patches.get(i);
			for (int j = 0; j < patchesPerSpecies; j++)
			{
				Patch curPatch = patchesForASingleType.get(j);
				patchTypeByIndexDivMatrix[i][j] = getLocalDiv(curPatch);
			}
		}
	}
	
	
	private int getLocalDiv(Patch curPatch)
	{
		boolean[] speciesEncountered = new boolean[com.getNumberOfSpecies() + 1]; 
		Arrays.fill(speciesEncountered, false);
		speciesEncountered[0] = true;
		
		int rowLength = curPatch.getRowLength();
		int colLength = curPatch.getColLength();
		int startRow = curPatch.getRow();
		int startCol = curPatch.getCol();
		for (int r = 0; r < rowLength; r++)
		{
			for (int c = 0; c < colLength; c++)
			{
				int newRow = WrapAround.wrapAround(startRow + r, gridLength);
				int newCol = WrapAround.wrapAround(startCol + c, gridLength);
				int gridValue = this.env.getGridValue(newRow, newCol, 0);
				speciesEncountered[gridValue] = true;
				this.regionalSpeciesEncountered[gridValue] = true;
			}
		}
		
		int totalEncountered = -1;
		for (int i = 0; i < speciesEncountered.length; i++)
		{
			if(speciesEncountered[i])
			{
				totalEncountered ++;
			}
		}
		
		return totalEncountered;
	}
}
