import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

// TODO: Auto-generated Javadoc
/**
 * The Class Environment.
 */
public class Environment implements Serializable
{

	/** The generator of random numbers */
	private Random[] generators;

	/** The grid on which critters and spatial information of patches */
	protected int[][][] grid;

	protected int totalSites;
	/** The grid length. */
	protected int gridLength;

	protected int height;

	/**
	 * Instantiates a new environment, which is composed of the gridlength and a two dimensional array.  
	 *
	 * @param gridLength the grid length
	 */
	public Environment(int gridLength)
	{
		this.grid = new int[0][gridLength][gridLength];
		this.gridLength = gridLength;
		this.totalSites = this.gridLength * this.gridLength;
		this.height = 1;
		this.generators = new Random[] { new Random() };
		// this.AAGrid = new double[gridLength][gridLength][3];
	}

	public Environment(int[][] grid)
	{
		this.grid[0] = grid;
		this.gridLength = grid.length;
		this.totalSites = this.gridLength * this.gridLength;
		this.height = 1;
	}

	public Environment(int gridLength, int thisManyGrids)
	{
		this.grid = new int[thisManyGrids][gridLength][gridLength];
		this.gridLength = gridLength;
		this.totalSites = this.gridLength * this.gridLength;
		this.height = thisManyGrids;

		this.generators = new Random[this.height];
		for (int i = 0; i < height; i++)
		{
			this.generators[i] = new Random();
		}
	}

	public void setSeedAtOneLevel(int generatorValue, int ss)
	{
		this.generators[generatorValue - 1].setSeed(ss);
	}

	public Random[] getGenerators()
	{
		return this.generators;
	}

	public Random getGenerator(int generatorIndex)
	{
		return this.generators[generatorIndex];
	}

	public int getHeight()
	{
		return this.height;
	}

	/**
	 * Replaces the current grid configuration with a new grid.
	 * @param grid a environment grid
	 */
	public void setGrid(int[][] grid)
	{
		
			for (int i = 0; i < this.gridLength; i++)
			{
				for (int j = 0; j < this.gridLength; j++)
				{
					this.grid[0][i][j] = grid[i][j];
				}
			}

		
	}

	public void setGrid(int[][][] grid)
	{

		for (int k = 0; k < this.height; k++)
		{
			for (int i = 0; i < this.gridLength; i++)
			{
				for (int j = 0; j < this.gridLength; j++)
				{
					this.grid[k][i][j] = grid[k][i][j];
				}
			}
		}
		
	}

	/**
	 * Gets the grid.
	 *
	 * @return the grid
	 */
	public int[][][] getGrid()
	{
		int[][][] toReturn = new int[this.height][this.gridLength][this.gridLength];
		for (int k = 0; k < this.height; k++)
		{
			for (int i = 0; i < this.gridLength; i++)
			{
				for (int j = 0; j < this.gridLength; j++)
				{
					toReturn[k][i][j] = this.grid[k][i][j];
				}
			}
		}
		return toReturn;
	}
	
	

	/**
	 * Gets the value of a site. 0 denotes empty space; anything else is a critter. 
	 * 
	 * @param row the row of the location
	 * @param col the col of the locaton
	 * 
	 * @return theGridValue
	 */
	/*
	 * public int getGridValue(int row, int col) { return this.grid[0][row][col]; }
	 */

	public int getGridValue(int row, int col, int height)
	{	
		if(row == -1 || col == -1)
		{
			return 0;
		} else
		{
			return this.grid[height][row][col];
		}
	}

	/*
	 * int getGridValue(Location loc) { return this.grid[0][loc.row()][loc.col()]; }
	 */

	int getGridValue(Location3D loc)
	{
		return this.grid[loc.height()][loc.row()][loc.col()];
	}

	/**
	 * Gets the grid length.
	 *
	 * @return the grid length
	 */
	public int getGridLength()
	{
		return this.gridLength;
	}

	/**
	 * Checks if a particular location is occupied by a critter.
	 *
	 * @param location the location
	 * @return true, if the location is occupied
	 */
	/*
	 * public boolean isOccupied(Location location) { return this.grid[0][location.row()][location.col()] != 0; }
	 */

	public boolean isOccupied(Location3D location)
	{
		return this.grid[location.height()][location.row()][location.col()] != 0;
	}

	/**
	 * Checks if a particular location is occupied by a critter.
	 *
	 * @param row the row of the location
	 * @param col the col of the locaton
	 * @return true, if the location is occupied
	 */
	/*
	 * public boolean isOccupied(int row, int col) { return this.grid[0][row][col] != 0; }
	 */

	public boolean isOccupied(int row, int col, int height)
	{
		return this.grid[height][row][col] != 0;
	}

	/**
	 * Checks if a location on a grid does NOT have a critter
	 *
	 * @param location the location
	 * @return true, if it is empty
	 */
	/*
	 * public boolean isEmpty(Location location) { return this.grid[0][location.row()][location.col()] == 0; }
	 */

	public boolean isEmpty(Location3D location)
	{
		return this.grid[location.height()][location.row()][location.col()] == 0;
	}

	/**
	 *  Checks if a location on a grid does NOT have a critter.
	 *
	 * @param row the row of the location
	 * @param col the col of the locaton
	 * @return true, if it is empty
	 */
	/*
	 * public boolean isEmpty(int row, int col) { return this.grid[0][row][col] == 0; }
	 */

	public boolean isEmpty(int row, int col, int height)
	{
		return this.grid[height][row][col] == 0;
	}

	/**
	 * Adds a unique species identifier on a grid location.
	 *
	 * @param location the location
	 * @param speciesValue the critter value
	 */
	/*
	 * public void add(Location location, int speciesValue) { this.grid[0][location.row()][location.col()] = speciesValue; }
	 */

	public void add(Location3D location, int speciesValue)
	{
		this.grid[location.height()][location.row()][location.col()] = speciesValue;
	}

	/**
	 * Adds a unique species identifier on a grid location.
	 *
	 * @param row the row of the location
	 * @param col the col of the locaton
	 * @param speciesValue the critter value
	 */
	/*
	 * public void add(int row, int col, int speciesValue) { this.grid[0][row][col] = speciesValue;
	 * 
	 * }
	 */

	public void add(int row, int col, int height, int speciesValue)
	{
		this.grid[height][row][col] = speciesValue;

	}

	/**
	 * Removes any species identifier from a particular grid location.
	 *
	 * @param location the location
	 */
	/*
	 * public void remove(Location location) { this.grid[0][location.row()][location.col()] = 0;
	 * 
	 * }
	 */

	public void remove(Location3D location)
	{
		this.grid[location.height()][location.row()][location.col()] = 0;

	}

	/**
	 * Removes any species identifier from a particular grid location.
	 * 
	 * @param row the row of the location
	 * @param col the col of the locaton
	 */
	/*
	 * public void remove(int row, int col) { this.grid[0][row][col] = 0;
	 * 
	 * }
	 */

	public void remove(int row, int col, int height)
	{
		this.grid[height][row][col] = 0;

	}

	/**
	 * Clears the environment grid of all critters.
	 */
	/*
	 * public void clearEnvOfCritters() { for (int j = 0; j <= this.gridLength - 1; j++) { for (int i = 0; i <= this.gridLength - 1; i++) { this.grid[0][i][j] = 0; } } }
	 */

	public void clearEnvOfCritters()
	{
		for (int k = 0; k < this.grid.length; k++)
		{
			for (int j = 0; j <= this.gridLength - 1; j++)
			{
				for (int i = 0; i <= this.gridLength - 1; i++)
				{
					this.grid[k][i][j] = 0;
				}
			}
		}
	}

	public int getTotalSites()
	{
		return this.totalSites;
	}

}
