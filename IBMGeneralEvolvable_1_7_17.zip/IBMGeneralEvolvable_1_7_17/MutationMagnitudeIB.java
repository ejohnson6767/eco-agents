import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class MutationMagnitudeIB extends ContinuousTrait implements IMutationMagnitude, Evolvable, Serializable
{
	// private Community com;
	// Environment env;
	private double baselineTrait;
	// private int speciesValue;
	// private boolean useAltApproach;
	// private int speciesIndex;
	// private int envGridIndex;
	// private int possibleNeighbors;

	private IMutationFunction mfToOverwrite;
	// private double effectPerSite;
	// private double[][] lVEffectGrid;

	public MutationMagnitudeIB(IMutationFunction mf, IMutationFunction mfToOverwrite)
	{
		super(mf);
		this.mfToOverwrite = mfToOverwrite;

		// this.com = com;
	}

	/*
	 * public double getEffectPerSite() { return this.effectPerSite; }
	 */

	/*
	 * public LVEffectIB(IMutationFunction mf, int affectedSpeciesValue, int affectedSpeciesLVEffectValue) { super(mf); this.lvEffect = null; this.useAltApproach = false; this.affectedSpeciesValue = affectedSpeciesValue; this.affectedSpeciesLVEffectValue = affectedSpeciesLVEffectValue; // this.com = com; }
	 */

	public void initializeSpatialDistributionTracker()
	{
		this.spatialDistributionTracker = this.mfToOverwrite.getMutationMagnitude().getSpatialDistributionTracker();

	}

	public void startEvolution()
	{
		this.isEvolving = true;
		this.isIndividualBased = true;
		// setUpAfterCommunityIsCreated(com, this.species.getGridProxy());
		initializeSpatialDistributionTracker();
		IMutationMagnitude mm = this.mfToOverwrite.getMutationMagnitude();
		if(mm.isIndividualBased())
		{
			this.baselineTrait = ((MutationMagnitudeIB) mm).getTraitAverage();
		} else
		{
			//System.out.println("not individual based");
			this.baselineTrait = mm.getMutationMagnitude();
		}
		
		
		this.mfToOverwrite.setMutationMagnitude(this);

		System.out.println("made species " + species.getGridProxy() + " individual-based and evolvable");
		// System.out.println("is individual based " + this.isIndividualBased);
	}

	public void startBeingIndividualBased()
	{
		this.isIndividualBased = true;
		// setUpAfterCommunityIsCreated(com, this.species.getGridProxy());
		initializeSpatialDistributionTracker();
		
		IMutationMagnitude mm = this.mfToOverwrite.getMutationMagnitude();
		if(mm.isIndividualBased())
		{
			this.baselineTrait = ((MutationMagnitudeIB) mm).getTraitAverage();
		} else
		{
			//System.out.println("not individual based");
			this.baselineTrait = mm.getMutationMagnitude();
		}
		this.mfToOverwrite.setMutationMagnitude(this);

		System.out.println("made species " + species.getGridProxy() + " individual-based ");
	}

	public boolean isIndividualBased()
	{
		return this.isIndividualBased;
	}

	public double getBaselineTrait()
	{
		// System.out.println("Getting baseline TRAIT: " + com.getAbundances()[this.speciesIndex] );
		if (com.getAbundances()[this.speciesIndex] != 0)
		{
			// System.out.println("not zero. Getting trait average");
			return getTraitAverage();
		}
		else
		{
			// System.out.println(this.baselineTrait);
			return this.baselineTrait;
		}
	}

	public void setSpeciesOwner(ISpecies species)
	{
		// nothing needs to be done. species owner was already set in continuous trait
	}

	public void setupAfterCommunityIsCreated(Community com)
	{
		// this.com = com;

		// this.gridLength = this.com.getEnvironment().getGridLength();
		//this.baselineTrait = (int) getTraitAverage();
		// IDiffusion dif =this.lvEffect.getDiffusion();
		// this.lvEffect.getDiffusion().setupAfterCommunityIsCreated(com);
		// this.spatialDistributionTracker = new double[gridLength][gridLength];

	}

	public double[][] getSpatialDistributionTracker()
	{
		return this.spatialDistributionTracker;
	}

	@Override
	public double getMutationMagnitude()
	{
		throw new IllegalArgumentException("this method should never be called in this class");
	}

	@Override
	public void setMutationMagnitude(double evolveProb)
	{
		throw new IllegalArgumentException("this method should never be called in this class");

	}

	@Override
	public double getMutationMagnitude(Location parentLoc)
	{
		// System.out.println("evolve prob is " + this.spatialDistributionTracker[parentLoc.row()][parentLoc.col()]);

		return this.spatialDistributionTracker[parentLoc.row()][parentLoc.col()];
	}

}
