import java.io.IOException;
import java.util.ArrayList;
//import java.util.LinkedList;
//import java.util.ListIterator;
//import java.util.List;
import java.util.Random;
//import java.lang.Math;
// puts it all together. Initializes a patchy environment (is-an envrionment) and species (hasa critter hasa location). These classes are interdependent 
////(i.e. critters don't just go on the grid - critters have locations which indicate their position, and the envrionment is aware of critter locations at each time step)

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedList;
//import java.util.ListIterator;
//import java.util.List;
import java.lang.Math;

/**
 * @author Evan
 * This is where simulations are exacted and data is extracted. A Community has three main things: 1) An environment with information about what type of critters are where.
 * 2) a species list with species-specific parameters (e.g. maximum birth rate) 3) instance variables that are called in the time step function
 * 
 * 
 * @date 1/25/207
 */
/**
 * @author Evan
 *
 */

public class Community implements Serializable
{

	// instance variables

	/**
	 * contains species objects, which contain species specific parameters
	 */
	protected ArrayList<ISpecies> speciesList;
	/**
	 * holds the lattice and the length of the lattice
	 */
	protected Environment env;
	/**
	 * the total number of possible species in the system
	 */
	protected int numberOfSpecies;
	/**
	 * the length of one side of the lattice. We assume that the lattice is square, so that the total number of site/cells is gridlength^2
	 */
	int gridLength;
	/**
	 * the amount of time that one call to the time-step method comprises. 
	 */
	protected double dt;
	
	/**
	 * counts how many calls haves been made to the step method
	 */
	protected int timeStep;
	
	/**
	 * if true, then the simulation code won't check to see if species still need to be inoculated. Gives marginal speed-ups
	 */
	protected boolean neverInoculate;

	/**
	 * 	 keeps track of how which species have been added to the community. Once all species have been added, the time-stepping method will stop looking to see if species need to be inoculated, giving a small speed-up
	 */
	protected ArrayList<Integer> inoculatedSpeciesIndexesTracker;

	/**
	 * 	the grid of the fecundity of individuals. Levels are row, column, species index
	 */
	protected double[][][] fecundityGrid;
	/**
	 * 	 the total number of cells on the lattice
	 */
	protected int totalSites;
	/**
	 * a grid that tracks the number of propagules (from each species) that land on sites. Levels are row, column, species index
	 */
	protected double[][][][] propaguleRainGrid;
	/**
	 *  tells you if all of the species have the same dispersal distance. If dispersal is the same, you can use one pass of a moving window algorithm to determine the propagule rain for each species.
	 */
	// protected int maxDALength = 5;
	// protected int[][][] DA

	protected boolean anySpeciesHasIndividualBasedTrait;

	// protected ArrayList<Integer> evolvingDispersalSpeciesIndexTracker;

	// protected int numberOfEvolvingDispersalSpecies;

	protected int optimizeThisOften;
	protected int optimizeTestSteps;
	
	

	/**
	 * Sets up a community. Simulation and data grabbing methods will do work on the community
	 * 
	 * @param gridLength the length of one dimension of the square landscape
	 * @param dt the length of time that one call to the step method represents
	 * @param alphaDiffusionRadius the "radius" of the square (Moore) neighborhood over which lotka voltera effects diffuse
	 * @param speciesList a list of species objects wih species specific information (e.g. maximum birth rate)
	 * @throws Exception 
	 */
	public Community(int gridLength, double dt, ArrayList<ISpecies> speciesList) throws Exception
	{
		// makes sure that the community matrix (assembled from columns of
		this.speciesList = speciesList;
		

		int maxEnvDepth = 1 + getMaxIndexOfSpeciesHomeGrids();
		//System.out.println(maxEnvDepth);
		// assign instance variables
		this.dt = dt;
		this.timeStep = 0;
		this.env = new Environment(gridLength, maxEnvDepth);
		for (int s = 0; s < this.speciesList.size() - 1; s++)
		{
			// throw an exception if the environment grid has different dimensions than any spatially variable grids for basline birth rates/death rates/recruitment rates that any species may have
			this.speciesList.get(s).speciesGridLengthConcordanceWithEnvironentGridLength(this.env);
		}
		
		giveRandomGeneratorsToTraits();
		this.gridLength = gridLength;
		this.totalSites = this.env.getTotalSites();
		this.numberOfSpecies = speciesList.size();
		this.neverInoculate = false;
		

	

		// intialize these "background" grids
		this.fecundityGrid = new double[maxEnvDepth][this.gridLength][this.gridLength];
		this.propaguleRainGrid = new double[maxEnvDepth][this.gridLength][this.gridLength][this.numberOfSpecies];
	

		
		
		
		// sets up the numbers that appear on the grid
		for (int i = 0; i < this.numberOfSpecies; i++)
		{
			this.speciesList.get(i).setGridProxy(i + 1);
		}

		/*this.anyIndividualBasedEvolution = false;

		this.allSameDispersal = true;
		int firstDispersalAbility = this.speciesList.get(0).getBaselineDispersalAbility();

		for (int i = 1; i < this.numberOfSpecies; i++)
		{
			if (this.speciesList.get(i).getBaselineDispersalAbility() != firstDispersalAbility)
			{
				this.allSameDispersal = false;
				break;
			}
		}*/

	/*	// if all of the species dispersal radius are the same, then initialize some helpful instance variables
		if (this.allSameDispersal)
		{
			this.dispersalRadius = this.speciesList.get(0).getBaselineDispersalAbility();
			int dispersalLength = 1 + this.dispersalRadius * 2;
			this.possibleNeighbors = dispersalLength * dispersalLength - 1;

		}*/

		// initialize the inoculated species tracker
		this.inoculatedSpeciesIndexesTracker = new ArrayList<Integer>();

		this.optimizeThisOften = 0;
		this.optimizeTestSteps = 5;

		this.anySpeciesHasIndividualBasedTrait = false;
		
		for (int i = 0; i < this.speciesList.size(); i++)
		{
			
			this.speciesList.get(i).setupSpeciesAfterCommunityIsCreated(this);
		}
		// CommunityUtilsOptimize.optimizeEfficiencyEvolutionStrict(this, this.optimizeTestSteps);
		scaleByDt();

	}
	
	
	public void makeBoundaryPeriodic()
	{
		WrapAround.periodic();
	}
	
	public void makeBoundaryReflect()
	{
		WrapAround.reflect();
	}
	
	public void makeBoundaryFallOff()
	{
		WrapAround.fallOff();
	}
	
/*	public void setUpLVEffects()
	{
		for
	}*/
	
	public void giveRandomGeneratorsToTraits()
	{
		for (int i = 0; i < this.speciesList.size(); i++)
		{
			TraitList tl = this.speciesList.get(i).getTraitList();
			if(tl != null)
			{
				tl.setRandomGenerator(this.env.getGenerator(this.speciesList.get(i).getHomeGridIndex()));
			}
		}
	}

	public int getMaxIndexOfSpeciesHomeGrids()
	{
		int max = 0;
		for (int i = 0; i < this.speciesList.size(); i++)
		{
			int temp = this.speciesList.get(i).getHomeGridIndex();
			if (temp > max)
			{
				max = temp;
			}
		}
		return max;
	}

	public void setOptimizeTestSteps(int testSteps)
	{
		this.optimizeTestSteps = testSteps;
	}

	public void setOptimizeThisOften(int optimizeThisOften)
	{
		this.optimizeThisOften = optimizeThisOften;
	}

	/**
	 * gets the average species densities that result from relicates of time-evolution.
	 * 
	 * @param numSpecies the current number of species in the system
	 * @param numReps number of replicates to average the end densities over
	 * @param numSteps number of time steps
	 * @return the replicate-averaged vector of species densities
	 * @throws Exception
	 */
	public double[] getFlowAverage(int numSpecies, int numReps, int numSteps) throws Exception
	{
		double[][] reps = new double[numReps][numSpecies];
		for (int i = 0; i < numReps; i++)
		{
			// System.out.println("community - stepping for flow average");
			Community tempCom = Community.deepCopy(this);
			tempCom.step(numSteps);
			reps[i] = tempCom.getAbundances(true);
		}
		double[] toReturn = new double[numSpecies];
		for (int i = 0; i < numSpecies; i++)
		{
			toReturn[i] = MeanAndSD.meanAcrossRows(reps, i);
		}

		return toReturn;
	}

	/** 
	 * gets the number of possible species in the system (i.e. the number of species in the species list).
	 * @return
	 */
	public int getNumberOfSpecies()
	{
		return this.numberOfSpecies;
	}

	/**
	 * @param oldObj a Community object
	 * @return a deep clone of the Community object; modifications to the clone will not change the state of the old object
	 * @throws Exception
	 */
	public static Community deepCopy(Object oldObj) throws Exception
	{
		ObjectOutputStream oos = null;
		ObjectInputStream ois = null;
		try
		{
			ByteArrayOutputStream bos = new ByteArrayOutputStream(); // A
			oos = new ObjectOutputStream(bos); // B
			// serialize and pass the object
			oos.writeObject(oldObj); // C
			oos.flush(); // D
			ByteArrayInputStream bin = new ByteArrayInputStream(bos.toByteArray()); // E
			ois = new ObjectInputStream(bin); // F
			// return the new object
			return (Community) ois.readObject(); // G
		} catch (Exception e)
		{
			System.out.println("Exception in ObjectCloner = " + e);
			throw (e);
		} finally
		{
			oos.close();
			ois.close();
		}
	}

	/**
	 * gets the list of species objects, which contain species-specific simulation parameters
	 * @param list
	 */
	public void setSpeciesList(ArrayList<ISpecies> list)
	{
		this.speciesList = list;
	}

	/**
	 * Takes a proportion of microsites and turns it into an number of microsites. This is a helper method for inoculation methods.
	 * @param prop the proportion of microsites
	 * @return abundace a integer of individuals
	 * @see inoculateInMiddle, inoculateSpecies
	 */
	public int abundFromProp(double prop)
	{
		return (int) Math.round(prop * (double) Math.pow(this.gridLength, 2));
	}

	/**
	 * gets the abundance for each species.
	 * 
	 * @param reportDensity if true, then return an array of densities
	 * @return abundances an array of abundances. Exception: the first index of the array is the time step.
	 */
	public double[] getAbundances(boolean reportDensity)
	{
		double[] abundances = new double[this.numberOfSpecies];
		if(reportDensity)
		{
			for (int j = 0; j < this.numberOfSpecies; j++)
			{
				ISpecies curSpecies = this.speciesList.get(j);
				abundances[j] = curSpecies.getAbundance() / (double) this.totalSites;
			}
		} else
		{
		for (int j = 0; j < this.numberOfSpecies; j++)
		{
			ISpecies curSpecies = this.speciesList.get(j);
			abundances[j] = curSpecies.getAbundance();
		}
		}
		return abundances;
			
		/*int[] abundances = new int[this.numberOfSpecies + 1];

		for (int i = 0; i < this.env.getHeight(); i++)
		{

			for (int row = 0; row < this.gridLength; row++)
			{
				for (int col = 0; col < this.gridLength; col++)
				{
					abundances[this.env.getGridValue(row, col, i)]++;
				}
			}
		}

		double[] realAbundances = new double[this.numberOfSpecies];
		if (reportDensity)
		{
			for (int s = 0; s < this.numberOfSpecies; s++)
			{
				realAbundances[s] = abundances[s + 1] / (double) this.totalSites;
			}
		}
		else
		{
			for (int s = 0; s < this.numberOfSpecies; s++)
			{
				realAbundances[s] = abundances[s + 1];
			}
		}
		return realAbundances;
*/
	}


	/**
	 * gets the abundance for each species.
	 * 
	 * @param reportDensity if true, then return an array of densities
	 * @return abundances an array of abundances. Exception: the first index of the array is the time step.
	 */
	public int[] getAbundances()
	{
		
		int[] abundances = new int[this.numberOfSpecies];
		
		for (int j = 0; j < this.numberOfSpecies; j++)
		{
			ISpecies curSpecies = this.speciesList.get(j);
			abundances[j] = curSpecies.getAbundance();
		}
		return abundances;
		
		/*int[] abundances = new int[this.numberOfSpecies + 1];
		for (int i = 0; i < this.env.getHeight(); i++)
		{
			for (int row = 0; row < this.gridLength; row++)
			{
				for (int col = 0; col < this.gridLength; col++)
				{
					abundances[this.env.getGridValue(row, col, i)]++;
				}
			}
		}

		int[] realAbundances = new int[this.numberOfSpecies];

		for (int s = 0; s < this.numberOfSpecies; s++)
		{
			realAbundances[s] = abundances[s + 1];
		}

		return realAbundances;*/

	}

	/**
	 * gets the delta t, i.e. the length of a time-step method
	 * @return
	 */
	public double getDt()
	{
		return this.dt;
	}

	/**
	 * Gets the environment, which consists of a grid and that grid's length.
	 * @return Environment 
	 */
	public Environment getEnvironment()
	{
		return this.env;
	}

	/**
	 * @return speciesList an arrayList of species. This method is exclusivelty for Jlink use (mathematica - java interface), since JLink was have a hard time accessing fields directly.
	 */
	public ArrayList<ISpecies> getSpeciesList()
	{
		return this.speciesList;
	}

	/**
	 * gets the number of time step calls that have occurred. Please note - the time step is not necessarily the number of time units that have elapsed (only if dt == 1) ; it is simply the number of time-stepper method calls
	 * @return
	 */
	public int getStepCallCounter()
	{
		return this.timeStep;
	}
	
	public double getTime()
	{
		return this.timeStep * this.dt;
	}

	/** sets the time step parameter
	 * @param timeStep
	 */
	public void setTimeStep(int timeStep)
	{
		this.timeStep = timeStep;
	}

	/**
	 *returns the environment grid; the lattice
	 * @return
	 */
	public int[][][] getGrid()
	{
		return this.env.getGrid();
	}
	
	
/*	public int[][] getGrid()
	{
		return this.env.getGrid()[0];
	}
	*/




	/**
	 * scales species birth and death rates by dt, as well as the number of time-stepper calls until species are inoculated. The lower the dt, the more simulation steps are in a single time unit; called by the community constructor.
	 * 
	 */
	public void scaleByDt()
	{
		for (int s = 0; s < this.numberOfSpecies; s++)
		{
			ISpecies tempSpecies = this.speciesList.get(s);
			tempSpecies.getBirthProcess().scaleByDt(this.dt);
			tempSpecies.getDeathProcess().scaleByDt(this.dt);
			tempSpecies.setInoculateWhen((int) Math.round(tempSpecies.getInoculateWhen() / this.dt));
		}

	}

	
	

	/**
	 * gives the simulation a new dt (time scaling factor) and changes the birth and death rates accordingly.
	 * @param newDt
	 */
	public void setDt(double newDt)
	{
		this.dt = newDt;
		scaleByDt();
	}


	

	public void updateTimeStepCounter()
	{
		this.timeStep++;
	}

/*	public void optimizeIfTimeIsRight() throws Exception
	{
		if (this.optimizeThisOften != 0)
		{
			if (this.timeStep % this.optimizeThisOften == 0 && this.timeStep / this.optimizeThisOften != 0)
			{
				System.out.println("TIME IS RIGHT FOR OPTIMIZATION");
				CommunityUtilsOptimize.optimizeEfficiencyStrict(this, this.optimizeTestSteps);
			}
		}
	}*/

	public void individualBasedHousekeeping()
	{
		this.anySpeciesHasIndividualBasedTrait = false;
		// System.out.println("");
		for (int i = 0; i < this.numberOfSpecies; i++)
		{
			ISpecies curSpecies = this.speciesList.get(i);
			if (curSpecies.isOnGrid())
			{

				ArrayList<Evolvable> traits = curSpecies.getEvolvableTraits();
				for (int j = 0; j < traits.size(); j++)

				{
					if (traits.get(j).isIndividualBased())
					{
						//System.out.println("a species is evolving");
						this.anySpeciesHasIndividualBasedTrait = true;
						break;
					}
				}
			}

		}
	}
	
	
	public void step() throws Exception
	{
		if (this.anySpeciesHasIndividualBasedTrait)
		{
			CommunityUtilsStep.stepWithIndividualBasedTraits(this);
		}
		else
		{
			CommunityUtilsStep.stepWithoutIndividualBasedTraits(this);
		}
		CommunityUtilsStep.stepPrimer(this);
	}
	

	public void step(int numSteps) throws Exception
	{
		for (int i = 0; i < numSteps; i++)
		{
			//individualBasedHousekeeping();
			if (this.anySpeciesHasIndividualBasedTrait)
			{
				CommunityUtilsStep.stepWithIndividualBasedTraits(this);
			}
			else
			{
				CommunityUtilsStep.stepWithoutIndividualBasedTraits(this);
			}
			CommunityUtilsStep.stepPrimer(this);
		}
	}
	
	public void stepThroughTime(int time) throws Exception
	{
		int numSteps = (int) Math.round(time/this.getDt());
		for (int i = 0; i < numSteps; i++)
		{
			if (this.anySpeciesHasIndividualBasedTrait)
			{
				CommunityUtilsStep.stepWithIndividualBasedTraits(this);
			}
			else
			{
				CommunityUtilsStep.stepWithoutIndividualBasedTraits(this);
			}
			CommunityUtilsStep.stepPrimer(this);
		}
	}
	
	public void stepAndScrambleThroughTime(int time) throws Exception
	{
		
		int numSteps = (int) Math.round(time/this.getDt());
		for (int i = 0; i < numSteps; i++)
		{
			//individualBasedHousekeeping();
			if (this.anySpeciesHasIndividualBasedTrait)
			{
				CommunityUtilsStep.stepWithIndividualBasedTraits(this);
			}
			else
			{
				CommunityUtilsStep.stepWithoutIndividualBasedTraits(this);
			}
			UpdateAbundances ua = new UpdateAbundances(this);
			ua.update();
			Scramble s = new Scramble(this);
			s.scramble();
			CommunityUtilsStep.stepPrimer(this);
		}
	}

	public void scramble()
	{
		UpdateAbundances ua = new UpdateAbundances(this);
		ua.update();
		Scramble s = new Scramble(this);
		s.scramble();
		CommunityUtilsStep.stepPrimer(this);
	}
	
	public void stepAndScramble() throws Exception
	{
		//individualBasedHousekeeping();
		if (this.anySpeciesHasIndividualBasedTrait)
		{
			CommunityUtilsStep.stepWithIndividualBasedTraits(this);
			
		}
		else
		{
			CommunityUtilsStep.stepWithoutIndividualBasedTraits(this);
		}
		UpdateAbundances ua = new UpdateAbundances(this);
		ua.update();
		Scramble s = new Scramble(this);
		s.scramble();
		CommunityUtilsStep.stepPrimer(this);
	}

	public void stepAndScramble( int numSteps) throws Exception
	{
		for (int i = 0; i < numSteps; i++)
		{
			//individualBasedHousekeeping();
			if (this.anySpeciesHasIndividualBasedTrait)
			{
				CommunityUtilsStep.stepWithIndividualBasedTraits(this);
				
			}
			else
			{
				CommunityUtilsStep.stepWithoutIndividualBasedTraits(this);
				
			}
			UpdateAbundances ua = new UpdateAbundances(this);
			ua.update();
			Scramble s = new Scramble(this);
			s.scramble();
			CommunityUtilsStep.stepPrimer(this);


		}
	}

	public void stepAndMaybeTerminate(int numSteps, int checkHowOften, boolean scramble, ITerminateCondition condition) throws Exception
	{
		for (int i = 0; i < numSteps; i++)
		{

			step();
			if(scramble)
			{
				UpdateAbundances ua = new UpdateAbundances(this);
				ua.update();
				Scramble s = new Scramble(this);
				s.scramble();
			}
			CommunityUtilsStep.stepPrimer(this);
			
			int timeStep = this.getStepCallCounter();
			if (timeStep / checkHowOften != 0 && timeStep % checkHowOften == 0)
			{
				if (condition.shouldTerminate())
				{
					break;
				}

			}
		}
	}
	
	
	public void stepAndMaybeTerminateThroughTime(int time, int checkHowOftenTime, boolean scramble, ITerminateCondition condition) throws Exception
	{
		int numSteps = (int) Math.round(time/getDt());
		int checkHowOften = (int) Math.round(checkHowOftenTime/getDt());
		for (int i = 0; i < numSteps; i++)
		{

			step();
			if(scramble)
			{
				UpdateAbundances ua = new UpdateAbundances(this);
				ua.update();
				Scramble s = new Scramble(this);
				s.scramble();
			}
			CommunityUtilsStep.stepPrimer(this);

			int timeStep = getStepCallCounter();
			if (timeStep / checkHowOften != 0 && timeStep % checkHowOften == 0)
			{
				if (condition.shouldTerminate())
				{
					break;
				}

			}
		}
	}

	

	public double[][][] getFecundityGrid()
	{
		return this.fecundityGrid;
	}

	public int getPossibleNeighbors(int dispersalRadius)
	{
		return (int) Math.pow(dispersalRadius * 2 + 1, 2) - 1;
	}

	public static int proportionToAbundance(double prop, int totalSites)
	{
		return (int) Math.round(prop * totalSites);
	}

	public boolean getNeverInoculate()
	{
		return this.neverInoculate;
	}

	public void setNeverInoculate(boolean neverInoculate)
	{
		this.neverInoculate = neverInoculate;

	}

	public ArrayList<Integer> getInoculatedSpeciesIndexesTracker()
	{
		return this.inoculatedSpeciesIndexesTracker;
	}

	

	public double[][][][] getPropaguleRainGrid()
	{
		////System.out.println("GETTING PRG");
		int counter = 0; 
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if(this.propaguleRainGrid[0][row][col][0] != 0)
				{
					
					////System.out.println("value of nonzero cell is " + this.propaguleRainGrid[0][row][col][0]);
					////System.out.println("row is " + row);
					////System.out.println("col is " + col);

					counter++;
				}
			}
		}
		////System.out.println("NUM OF NONZERO PROP RAIN GRID IS " + counter);
		return this.propaguleRainGrid;
	}
	
	public void setPropaguleRainGrid(double[][][][] prg)
	{
		////System.out.println("SETTING PRG");
		this.propaguleRainGrid = prg;
		int counter = 0; 
		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				if(propaguleRainGrid[0][row][col][0] != 0)
				{
					////System.out.println("value of nonzero cell is " + propaguleRainGrid[0][row][col][0]);
					counter++;
				}
			}
		}
		////System.out.println("NUM OF NONZERO PROP RAIN GRID IS " + counter);
		
	}

	public boolean doesAnySpeciesHaveAnIndividualBasedTrait()
	{
		return this.anySpeciesHasIndividualBasedTrait;
	}

	



	public void resetPropaguleRainGrid()
	{
		for (int p = 0; p < this.propaguleRainGrid.length; p++)
		{
			for (int i = 0; i < this.gridLength; i++)
			{
				for (int j = 0; j < this.gridLength; j++)
				{
					for (int k = 0; k < this.numberOfSpecies; k++)
					{
						this.propaguleRainGrid[p][i][j][k] = 0;
					}
				}
			}
		}
	}

	public void resetFecundityGrid()
	{
		for (int p = 0; p < env.getHeight(); p++)
		{
		for (int i = 0; i < gridLength; i++)
		{
			for (int j = 0; j < gridLength; j++)
			{
				
					fecundityGrid[p][i][j] = 0;
				
			}
		}
		}
		
	}

	/*public LVEffect[] getLVEffects(int affectingSpeciesValue, int affectedSpeciesValue)
	{
		return speciesList.get(affectingSpeciesValue-1).getLocalLV().getLVEffectsOnAllHeteros()[affectedSpeciesValue-1].getLVEffects();
	}
*/
	
	
}