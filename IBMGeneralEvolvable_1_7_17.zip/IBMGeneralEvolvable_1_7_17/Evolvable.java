import java.io.Serializable;
import java.util.Random;

public interface Evolvable extends Serializable
{

	boolean isEvolving();

	void resetSpatialDistributionTracker();

	

	boolean isIndividualBased();
	void removeFromSpatialDistributionTracker(Location loc);

	void setSpeciesOwner(ISpecies species);

	void startEvolution() throws Exception;

	double getTrait(Location location);


	
	void initializeSpatialDistributionTracker() throws Exception;

	double getTraitAverage();

	void setTrait(Location loc, double tradeOffVal);

	void startBeingIndividualBased() throws Exception;

	ISpecies getSpeciesOwner();

	//void startTradeOff(Community com);

	//TradeOff getTradeOff();
	double[][] getSpatialDistributionTracker();
	void addToSpatialDistributionTracker(Location loc, Location parentLoc);
	double getBaselineTrait();
	void addToSpatialDistributionTracker(Location loc, double disp);
	void setRandomGenerator(Random generator);

	int getGridLength();

	void setupAfterCommunityIsCreated(Community com);

	void setupContinuousTraitAfterCommunityIsCreated(Community com);

	void setContinuousTraitSpeciesOwner(ISpecies species);

	boolean isContinuous();

	boolean isDiscrete();

	void addToSpatialDistributionTrackerForScrambling(Location newLoc, double d);

	void stopEvolution();




}
