
public class FlatTest
{

	public static void main(String[] args)
	{
		double[][][] arr = new double[][][] {{{},{2, 5, 8}, {4, 5.7}}, {{5},{},{}, {7, 9.2, 49}}};
		double[] res = ArrayFlattener.flatten(arr);
		for (int i = 0; i < res.length; i++)
		{
			System.out.println(res[i]);
		}
	}

}
