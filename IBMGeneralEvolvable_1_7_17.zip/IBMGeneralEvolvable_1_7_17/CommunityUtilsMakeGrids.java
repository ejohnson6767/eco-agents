import java.io.Serializable;

public class CommunityUtilsMakeGrids implements Serializable
{
	/**
	 * makes a new landscape with the individuals randomly distributed
	 * 
	 * @param com the community object to modify
	 * @param abunds the abundances of the species
	 */
	public static void getPercolationCommunity(Community com, int[] abunds)
	{
		int gridLength = com.getEnvironment().getGridLength();
		MakeGrids mg = new MakeGrids(gridLength, abunds);
		com.getEnvironment().setGrid(mg.getGrid());
	}

	/**
	 * makes a community that satisfies the specified abundances vector and tries to satisfy the specified pair correlation function
	 * 
	 * @param com the community object to modify
	 * @param abundances a vector of species abundances
	 * @param PCGoal the pair correlation goal
	 * @param lambda controls probability of accepting a bad iteration of the pair correlation algorithm. If lambda is high, then the probability of accepting a bad iteration is low. Decent rule of thumb is 100000
	 * @param epsilon stopping criterion. when the cumulative difference between the normalized components of the current pair correlation function and PCGoal is smaller than epsilon
	 * @param maxTries stop the algorithm automatically after this many iterations (cell-state-swaps)
	 */
	public static void getPairCorrelationCommunity(Community com, int[] abundances, double[][][] PCGoal, double lambda, double epsilon, int maxTries)
	{
		Environment env = com.getEnvironment();
		int gridLength = env.getGridLength();
		MakeGrids mg = new MakeGrids(gridLength, abundances);
		mg.makePairCorrelationGrid(abundances, PCGoal, lambda, epsilon, maxTries);
		env.setGrid(mg.getGrid());
	}

	/**
	 * makes a community with a random spatial distribution of the specified species densities
	 * @param com the community object to modify
	 * @param abunds a vector of species densities
	 */
	public static void getPercolationCommunity(Community com, double[] abunds)
	{
		Environment env = com.getEnvironment();
		int gridLength = env.getGridLength();
		int totalSites = env.getTotalSites();
		int[] abundsInt = new int[abunds.length];
		for (int i = 0; i < abundsInt.length; i++)
		{
			abundsInt[i] = (int) Math.round(abunds[i] * totalSites);
		}
		MakeGrids mg = new MakeGrids(gridLength, abundsInt);
		env.setGrid(mg.getGrid());
	}

	/**
	 * makes a community that satisfies the specified abundances vector and tries to satisfy the specified pair correlation function
	 * 
	 * @param com the community object to modify
	 * @param abundances a vector of species densities
	 * @param PCGoal the pair correlation goal
	 * @param lambda controls probability of accepting a bad iteration of the pair correlation algorithm. If lambda is high, then the probability of accepting a bad iteration is low. Decent rule of thumb is 100000
	 * @param epsilon stopping criterion. when the cumulative difference between the normalized components of the current pair correlation function and PCGoal is smaller than epsilon
	 * @param maxTries stop the algorithm automatically after this many iterations (cell-state-swaps)
	 */
	public static void getPairCorrelationCommunity(Community com, double[] abundances, double[][][] PCGoal, double lambda, double epsilon, int maxTries)
	{
		Environment env = com.getEnvironment();
		int gridLength = env.getGridLength();
		int[] abundsInt = new int[abundances.length];
		for (int i = 0; i < abundsInt.length; i++)
		{
			abundsInt[i] = (int) Math.round(abundances[i]);
		}
		MakeGrids mg = new MakeGrids(gridLength, abundsInt);
		mg.makePairCorrelationGrid(abundsInt, PCGoal, lambda, epsilon, maxTries);
		env.setGrid(mg.getGrid());
	}

}
