import java.io.Serializable;

public class LVEffectsOnOneHetero implements Serializable
{
	IEffect[] lVEffects;
	private Community com;
	private ISpecies speciesOwner;
	private Environment env;
	private int gridLength;
	private int speciesValue;
	private int speciesIndex;
	private int envGridIndex;
	private boolean allSameDiffusion;
	
	public LVEffectsOnOneHetero(double[] effectValuesOneHetero, int[] diffusionOneHetero)
	{
		this.lVEffects = new IEffect[effectValuesOneHetero.length];
		for (int i = 0; i < effectValuesOneHetero.length; i++)
		{
			/*System.out.println(i);
			System.out.println(effectValuesOneHetero[i]);
			System.out.println(diffusionOneHetero[i]);
			System.out.println( this.speciesOwner);*/
			lVEffects[i] = new Effect(effectValuesOneHetero[i], diffusionOneHetero[i]);
		}
		this.allSameDiffusion = false;
	}
	
	public LVEffectsOnOneHetero(double[] effectValuesOneHetero, int[] diffusionOneHetero, int[] indicators)
	{
		this.lVEffects = new IEffect[effectValuesOneHetero.length];
		for (int i = 0; i < effectValuesOneHetero.length; i++)
		{
		/*	System.out.println(i);
			System.out.println(effectValuesOneHetero[i]);
			System.out.println(diffusionOneHetero[i]);
			System.out.println( this.speciesOwner);*/
			lVEffects[i] = new Effect(effectValuesOneHetero[i], diffusionOneHetero[i], indicators[i]);
		}
		this.allSameDiffusion = false;

	}
	
	public LVEffectsOnOneHetero(IEffect[] lvEffects)
	{
		this.lVEffects = new IEffect[lvEffects.length];
		for (int i = 0; i < lvEffects.length; i++)
		{
		/*	System.out.println(i);
			System.out.println(effectValuesOneHetero[i]);
			System.out.println(diffusionOneHetero[i]);
			System.out.println( this.speciesOwner);*/
			this.lVEffects[i] = lvEffects[i];
		}
		this.allSameDiffusion = false;

	}
	
	public void addLVEffect(double effectVal, int diffusion)
	{
		IEffect[] temp = new Effect[this.lVEffects.length+1];
		for (int i = 0; i < this.lVEffects.length; i++)
		{
			temp[i] = this.lVEffects[i];
		}
		temp[this.lVEffects.length] = new Effect(effectVal, diffusion);
		this.lVEffects = temp;
	}
	
	public void addLVEffect(double effectVal, int diffusion, int indicator)
	{
		IEffect[] temp = new Effect[this.lVEffects.length+1];
		for (int i = 0; i < this.lVEffects.length; i++)
		{
			temp[i] = this.lVEffects[i];
		}
		temp[this.lVEffects.length] = new Effect(effectVal, diffusion, indicator);
		this.lVEffects = temp;
	}
	
	public void addLVEffect(IEffect lvEffect)
	{
		IEffect[] temp = new Effect[this.lVEffects.length+1];
		for (int i = 0; i < this.lVEffects.length; i++)
		{
			temp[i] = this.lVEffects[i];
		}
		temp[this.lVEffects.length] = lvEffect;
		this.lVEffects = temp;
	}

	public void setupAfterCommunityIsCreated(Community com)
	{
		this.com = com;
		for (int i = 0; i < lVEffects.length; i++)
		{
			lVEffects[i].setupAfterCommunityIsCreated(com);
		}
		this.env = this.com.getEnvironment();
		this.gridLength = this.env.getGridLength();
		this.speciesValue = this.speciesOwner.getGridProxy();
		this.speciesIndex = this.speciesValue - 1;getClass();
		this.envGridIndex = this.speciesOwner.getHomeGridIndex();
	}

	public void fillLVSameDiffusionForOneHetero()
	{
	
		// System.out.println("the species value is " + this.speciesValue);

		/// System.out.println("disp is " + dispersalRadius);

		// System.out.println("possible neighbors " + possibleNeighbors);

		int diffusion = this.lVEffects[0].getDiffusion().getDiffusion();
	
		int[][] totalGrid = new int[this.gridLength][this.gridLength];
		
		
		int[][] posPropagule = new int[gridLength][3];

		// this second main loop determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius

		// this algorithm scans right across the grid, goes down one line, scans again, and so on (just like reading). It's time complexity is O(n) (where n is the number of microsites) compared to O(n^2) of a trivial moving window algorithm.
		// It works by summing all of the
		// cumulative birth rates in the topmost row, the bottommost row, and everything in between. This is where the last dimension on pos array comes in:
		// 0 is TOP, 1 is MID, and 2 is BOT. when you to the next gid locationCommunity com,, your cumulative growth rate is TOPnew + MIDnew + BOTnew. MIDnew is simply MIDnorth + BOTnorth - TOPnew.
		// (where north indicates the position above you). TOPnew can be written TOPwest - TOPwest.leftMost + TOPnew.rightmost. BOTnew can be written BOTwest - BOTwest.leftMost + BOTnew.rightmost.
		// the TOP, MID, and BOT are all recorded.
		int row = 0;
		int col = 0;
		

		// pos = new double[numberOfSpecies][gridLength][3];
		int row2 = row - diffusion;
		for (int col2 = col - diffusion; col2 <= col + diffusion; col2++)
		{
			int realRow = WrapAround.wrapAround(row2, gridLength);
			int realCol = WrapAround.wrapAround(col2, gridLength);
			int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
			if (gridValue == speciesValue)
			{
				
				posPropagule[col][0] ++;

			}
		}
		// System.out.println("col == " + col + " first is " + first[1]);

		for (int col2 = col - diffusion; col2 <= col + diffusion; col2++)
		{
			for (row2 = row - diffusion + 1; row2 <= row + diffusion - 1; row2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{

					posPropagule[col][1] ++;

				}
			}
		}
		// System.out.println("col == 0 middle is " + middle[1]);

		row2 = row + diffusion;
		for (int col2 = col - diffusion; col2 <= col + diffusion; col2++)
		{
			int realRow = WrapAround.wrapAround(row2, gridLength);
			int realCol = WrapAround.wrapAround(col2, gridLength);
			int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
			if (gridValue == speciesValue)
			{

				posPropagule[col][2] ++;

			}
		}

		//ACTUALLY ADD TO PROPAGULE RAIN GRID
		int correctForMiddle = 0;
		if(env.getGridValue(row, col, envGridIndex) == speciesValue)
		{
			correctForMiddle--;
		}
		
		totalGrid[row][col] = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2] + correctForMiddle);
		
		
		
		for (col = 1; col < gridLength; col++)
		{

			// generate new top
			int NWRow = WrapAround.wrapAround(row - diffusion, gridLength);
			int NWCol = WrapAround.wrapAround(col - 1 - diffusion, gridLength);
			int NERow = WrapAround.wrapAround(row - diffusion, gridLength);
			int NECol = WrapAround.wrapAround(col + diffusion, gridLength);

			int SWRow = WrapAround.wrapAround(row + diffusion, gridLength);
			int SWCol = WrapAround.wrapAround(col - 1 - diffusion, gridLength);
			int SERow = WrapAround.wrapAround(row + diffusion, gridLength);
			int SECol = WrapAround.wrapAround(col + diffusion, gridLength);

			
			posPropagule[col][0] = posPropagule[col - 1][0];
			if(env.getGridValue(NWRow, NWCol, envGridIndex) == speciesValue)
			{
				posPropagule[col][0] --;
			}
			
			if(env.getGridValue(NERow, NECol, envGridIndex) == speciesValue)
			{
				posPropagule[col][0] ++;
			}
			
			

			int leftSideOfOldMid = 0;
			int col2 = col - diffusion - 1;
			for (row2 = row - diffusion + 1; row2 <= row + diffusion - 1; row2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{

					leftSideOfOldMid ++;

				}
			}

			int rightSideOfNewMid = 0;
			col2 = col + diffusion;
			for (row2 = row - diffusion + 1; row2 <= row + diffusion - 1; row2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{

					rightSideOfNewMid ++;

				}
			}

			posPropagule[col][1] = posPropagule[col - 1][1] - leftSideOfOldMid + rightSideOfNewMid;

			posPropagule[col][2] = posPropagule[col - 1][2];
			if(env.getGridValue(SWRow, SWCol, envGridIndex) == speciesValue)
			{
				posPropagule[col][2] --;
			}
			
			if(env.getGridValue(SERow, SECol, envGridIndex) == speciesValue)
			{
				posPropagule[col][2] ++;
			}
			//ACTUALLY ADD TO PROPAGULE RAIN GRID
			correctForMiddle = 0;
			if(env.getGridValue(row, col, envGridIndex) == speciesValue)
			{
				correctForMiddle--;
			}
			
			totalGrid[row][col] = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2] + correctForMiddle);
		}

		for (row = 1; row < gridLength; row++)
		{
			col = 0;

			posPropagule[col][0] = 0;

			row2 = row - diffusion;
			for (int col2 = col - diffusion; col2 <= col + diffusion; col2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{

					posPropagule[col][0] ++;

				}
			}

			posPropagule[col][1] += posPropagule[col][2] - posPropagule[col][0];

			posPropagule[col][2] = 0;

			row2 = row + diffusion;
			for (int col2 = col - diffusion; col2 <= col + diffusion; col2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{

					posPropagule[col][2] ++;

				}
			}
			
			//ACTUALLY ADD TO PROPAGULE RAIN GRID
			correctForMiddle = 0;
			if(env.getGridValue(row, col, envGridIndex) == speciesValue)
			{
				correctForMiddle--;
			}
			
			totalGrid[row][col] = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2] + correctForMiddle);

			for (col = 1; col < gridLength; col++)
			{

				// generate new top
				int NWRow = WrapAround.wrapAround(row - diffusion, gridLength);
				int NWCol = WrapAround.wrapAround(col - 1 - diffusion, gridLength);
				int NERow = WrapAround.wrapAround(row - diffusion, gridLength);
				int NECol = WrapAround.wrapAround(col + diffusion, gridLength);

				int SWRow = WrapAround.wrapAround(row + diffusion, gridLength);
				int SWCol = WrapAround.wrapAround(col - 1 - diffusion, gridLength);
				int SERow = WrapAround.wrapAround(row + diffusion, gridLength);
				int SECol = WrapAround.wrapAround(col + diffusion, gridLength);

				posPropagule[col][0] = posPropagule[col - 1][0];
				if(env.getGridValue(NWRow, NWCol, envGridIndex) == speciesValue)
				{
					posPropagule[col][0] --;
				}
				
				if(env.getGridValue(NERow, NECol, envGridIndex) == speciesValue)
				{
					posPropagule[col][0] ++;
				}
				
				

				posPropagule[col][1] += posPropagule[col][2] - posPropagule[col][0];

				
				
				
				posPropagule[col][2] = posPropagule[col - 1][2];
				if(env.getGridValue(SWRow, SWCol, envGridIndex) == speciesValue)
				{
					posPropagule[col][2] --;
				}
				
				if(env.getGridValue(SERow, SECol, envGridIndex) == speciesValue)
				{
					posPropagule[col][2] ++;
				}

				//ACTUALLY ADD TO PROPAGULE RAIN GRID
				correctForMiddle = 0;
				if(env.getGridValue(row, col, envGridIndex) == speciesValue)
				{
					correctForMiddle--;
				}
				
				totalGrid[row][col] = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2] + correctForMiddle);

				
			}
		}

		
		for (int i = 0; i < this.lVEffects.length; i++)
		{
			this.lVEffects[i].setLVEffectGrid(totalGrid);
		}

	}

	public IEffect[] getLVEffects()
	{
		return this.lVEffects;
	}

	/*public boolean sameDiffusionForOneHetero()
	{
		boolean toReturn = true;
		int referenceDiffusion = lVEffects[0].getDiffusionRadius();
		for (int i = 1; i < lVEffects.length; i++)
		{
			if(lVEffects[i].getDiffusionRadius() != referenceDiffusion)
			{
				toReturn = false;
				break;
			}
		}
		return toReturn;
	}*/

	public void markDiffusionNotAllSameWithinHetero()
	{
		this.allSameDiffusion = false;
		
	}

	public void markDiffusionAllSameWithinHetero()
	{
		this.allSameDiffusion = true;
		
	}

	public boolean diffusionAllSameWithinHetero()
	{
		return this.allSameDiffusion;
	}

	public void setSpeciesOwner(ISpecies speciesOwner)
	{
		this.speciesOwner = speciesOwner;
	
		for (int i = 0; i < lVEffects.length; i++)
		{
			this.lVEffects[i].setSpeciesOwner(this.speciesOwner);
		}
		
	}
			
}
