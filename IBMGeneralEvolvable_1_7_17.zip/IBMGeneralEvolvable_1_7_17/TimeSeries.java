import java.util.ArrayList;

public class TimeSeries
{
	private Community com;
	private int numSteps;
	private int measureHowOften;
	private boolean useScramble;
	private boolean throughTime;

	public TimeSeries(Community com, int numSteps, int measureHowOften)
	{
		this.com = com;

		this.numSteps = numSteps;
		this.measureHowOften = measureHowOften;

		this.useScramble = false;
		this.throughTime = false;
	}

	public TimeSeries(Community com, int numSteps, int measureHowOften, boolean throughTime)
	{
		this.com = com;
		this.throughTime = throughTime;
		if (this.throughTime)
		{
			this.numSteps = (int) Math.round(numSteps / this.com.getDt());
			this.measureHowOften = (int) Math.round(measureHowOften / this.com.getDt());
		}
		else
		{
			this.numSteps = numSteps;
			this.measureHowOften = measureHowOften;
		}
		this.useScramble = false;
		this.throughTime = throughTime;
	}

	public TimeSeries(Community com, int numSteps, int measureHowOften, boolean throughTime, boolean useScramble)
	{
		this(com, numSteps, measureHowOften, throughTime);
		this.useScramble = useScramble;
	}

	/**
	 * Generates time series data over a specified number of time steps, at a specified resolution.
	 * 
	 * @param numSteps the time series is recorded over this many time steps
	 * @param measureHowOften abundances are recorded once every this time steps
	 * @param reportDensity  if true, density be reported. Otherwise, raw counts are reported
	 * @param scatter if true, then the bacteria are scattered after each time step. Approximates a well-mixed system while keeping the feature of local interactions
	 * @return an two dimensional [species][time] array of abundances
	 * @throws Exception 
	 */
	public double[] pairCorrelationFunctionTimeSeries(int focalState, int pairedState, int radius) throws Exception
	{

		double[] abundanceArray = new double[(numSteps / measureHowOften) + 1];
		int counter = 0;

		// get abudances at time zero

		abundanceArray[counter] = MakeGrids.getPCFunction(com.getEnvironment().getGrid()[0], radius)[radius - 1][focalState][pairedState];

		counter++;

		for (int s = 1; s < numSteps + 1; s++)
		{

			com.step();
			if (useScramble)
			{
				com.scramble();
			}

			// get abundances every so often
			if ((s % measureHowOften == 0) && (s / measureHowOften != 0))
			{

				abundanceArray[counter] = MakeGrids.getPCFunction(com.getEnvironment().getGrid()[0], radius)[radius - 1][focalState][pairedState];

				counter++;
			}
		}
		return abundanceArray;
	}

	public double[][] timeSeries(boolean reportDensity) throws Exception
	{

		int numberOfSpecies = com.getNumberOfSpecies();
		double[][] abundanceArray = new double[(numSteps / measureHowOften) + 1][numberOfSpecies];
		int counter = 0;

		// get abudances at time zero
		double[] currentAbundances = com.getAbundances(reportDensity);
		for (int i = 0; i < currentAbundances.length; i++)
		{
			abundanceArray[counter][i] = currentAbundances[i];
		}
		counter++;

		for (int s = 1; s < numSteps + 1; s++)
		{

			com.step();
			if (useScramble)
			{
				com.scramble();
			}

			// get abundances every so often
			if ((s % measureHowOften == 0) && (s / measureHowOften != 0))
			{
				currentAbundances = com.getAbundances(reportDensity);

				for (int i = 0; i < currentAbundances.length; i++)
				{
					abundanceArray[counter][i] = currentAbundances[i];
				}
				counter++;
			}
		}
		return abundanceArray;
	}

	public double[][] timeSeries(boolean reportDensity, ITerminateCondition tc) throws Exception
	{
		// System.out.println("doing TIME SERIES ABUND/Density");
		boolean didTerminate = false;
		int numberOfSpecies = com.getNumberOfSpecies();
		double[][] abundanceArray = new double[(numSteps / measureHowOften) + 1][numberOfSpecies];
		int counter = 0;

		if (!tc.shouldTerminate())
		{

			// get abudances at time zero
			double[] currentAbundances = com.getAbundances(reportDensity);
			for (int i = 0; i < currentAbundances.length; i++)
			{
				abundanceArray[counter][i] = currentAbundances[i];
			}
			counter++;

			for (int s = 1; s < numSteps + 1; s++)
			{

				com.step();
				if (useScramble)
				{
					com.scramble();
				}

				if (!tc.shouldTerminate())
				{

					// get abundances every so often
					if ((s % measureHowOften == 0) && (s / measureHowOften != 0))
					{
						currentAbundances = com.getAbundances(reportDensity);

						for (int i = 0; i < currentAbundances.length; i++)
						{
							abundanceArray[counter][i] = currentAbundances[i];
						}
						counter++;
					}
				}
				else
				{
					didTerminate = true;
					break;
				}
			}
		}
		else
		{
			System.out.println("terminate off the bat");
			didTerminate = true;
		}

		if (didTerminate)
		{
			double[][] abundanceArrayTerm = new double[counter][numberOfSpecies];
			for (int i = 0; i < counter; i++)
			{
				for (int j = 0; j < numberOfSpecies; j++)
				{
					abundanceArrayTerm[i][j] = abundanceArray[i][j];

				}
			}
			return abundanceArrayTerm;

		}
		else
		{
			return abundanceArray;

		}
	}

	public double[][] timeSeries(ArrayList<ITimeSeriesQuantity> whatToMeasure, ITerminateCondition tc) throws Exception
	{
		boolean didTerminate = false;

		int lengthCounter = 0;
		int[] tSQLengths = new int[whatToMeasure.size()];
		for (int i = 0; i < whatToMeasure.size(); i++)
		{
			int len = whatToMeasure.get(i).getReturnLength();
			lengthCounter += len;
			tSQLengths[i] = len;
		}

		double[][] tsArray = new double[(numSteps / measureHowOften) + 1][lengthCounter];
		int counter = 0;

		if (!tc.shouldTerminate())
		{
			tsArray[counter] = getTSQuantities(lengthCounter, tSQLengths, whatToMeasure);

			counter++;

			for (int s = 1; s < numSteps + 1; s++)
			{

				com.step();
				if (useScramble)
				{
					com.scramble();
				}

				if (!tc.shouldTerminate())
				{

					// get abundances every so often
					if ((s % measureHowOften == 0) && (s / measureHowOften != 0))
					{
						tsArray[counter] = getTSQuantities(lengthCounter, tSQLengths, whatToMeasure);

						counter++;
					}
				}
				else
				{
					didTerminate = true;
					break;
				}
			}
		}
		else
		{
			didTerminate = true;
		}

		if (didTerminate)
		{

			double[][] tsArrayTerm = new double[counter][lengthCounter];
			for (int i = 0; i < counter; i++)
			{
				for (int j = 0; j < lengthCounter; j++)
				{
					tsArrayTerm[i][j] = tsArray[i][j];

				}
			}
			return tsArrayTerm;

		}
		else
		{
			return tsArray;

		}

	}

	public static double[] getTSQuantities(int lengthCounter, int[] tSQLengths, ArrayList<ITimeSeriesQuantity> whatToMeasure)
	{
		double[] toReturn = new double[lengthCounter];
		int counter = 0;
		for (int i = 0; i < whatToMeasure.size(); i++)
		{
			ITimeSeriesQuantity tsq = whatToMeasure.get(i);
			double[] toAppend = new double[tSQLengths[i]];
			Object quantity = tsq.get();
			if (quantity instanceof Double)
			{
				toAppend[0] = (double) quantity;
			}
			else if (quantity instanceof double[])
			{
				double[] quantity2 = (double[]) quantity;
				for (int j = 0; j < toAppend.length; j++)
				{
					toAppend[j] = quantity2[j];
				}
			}
			else if (quantity instanceof Integer)
			{
				toAppend[0] = (double) quantity;
			}
			else if (quantity instanceof int[])
			{
				double[] quantity2 = (double[]) quantity;
				for (int j = 0; j < toAppend.length; j++)
				{
					toAppend[j] = quantity2[j];
				}
			}
			for (int j = 0; j < toAppend.length; j++)
			{
				toReturn[counter + j] = toAppend[j];
			}
			counter += tSQLengths[i];
		}
		return toReturn;
	}

	public double[][] timeSeries(ArrayList<ITimeSeriesQuantity> whatToMeasure) throws Exception
	{
		int lengthCounter = 0;
		int[] tSQLengths = new int[whatToMeasure.size()];
		for (int i = 0; i < whatToMeasure.size(); i++)
		{
			int len = whatToMeasure.get(i).getReturnLength();
			System.out.println("length is  " + len);
			lengthCounter += len;
			tSQLengths[i] = len;
		}
		System.out.println();

		double[][] tsArray = new double[(numSteps / measureHowOften) + 1][lengthCounter];
		int counter = 0;

		tsArray[counter] = getTSQuantities(lengthCounter, tSQLengths, whatToMeasure);

		counter++;

		for (int s = 1; s < numSteps + 1; s++)
		{

			com.step();
			if (useScramble)
			{
				com.scramble();
			}

			// get abundances every so often
			if ((s % measureHowOften == 0) && (s / measureHowOften != 0))
			{
				tsArray[counter] = getTSQuantities(lengthCounter, tSQLengths, whatToMeasure);

				counter++;
			}
		}
		return tsArray;
	}

	public int[][][] gridTimeSeries(ITerminateCondition tc) throws Exception
	{
		boolean didTerminate = false;

		Environment env = this.com.getEnvironment();
		int gridLength = env.getGridLength();

		// get abudances at time zero

		int[][][] gridArray = new int[(numSteps / measureHowOften) + 1][gridLength][gridLength];
		int counter = 0;

		if (!tc.shouldTerminate())
		{
			gridArray[counter] = env.getGrid()[0];
			counter++;

			for (int s = 1; s < numSteps + 1; s++)
			{

				com.step();
				if (useScramble)
				{
					com.scramble();
				}

				if (!tc.shouldTerminate())
				{

					// get abundances every so often
					if ((s % measureHowOften == 0) && (s / measureHowOften != 0))
					{
						gridArray[counter] = env.getGrid()[0];
						counter++;
					}
				}
				else
				{
					didTerminate = true;
					break;
				}
			}
		}
		else
		{
			didTerminate = true;
		}

		if (didTerminate)
		{

			int[][][] gridArrayTerm = new int[(numSteps / measureHowOften) + 1][gridLength][gridLength];
			for (int i = 0; i < counter; i++)
			{
				for (int j = 0; j < gridLength; j++)
				{
					for (int k = 0; k < gridLength; k++)
					{
						gridArrayTerm[i][j][k] = gridArray[i][j][k];

					}
				}
			}
			return gridArrayTerm;

		}
		else
		{
			return gridArray;

		}

	}
	

	public int[][][] gridTimeSeries() throws Exception
	{
		Environment env = this.com.getEnvironment();
		int gridLength = env.getGridLength();
		int[][][] gridArray = new int[(numSteps / measureHowOften) + 1][gridLength][gridLength];
		int counter = 0;

		// get abudances at time zero

		gridArray[counter] = env.getGrid()[0];
		counter++;

		for (int s = 1; s < numSteps + 1; s++)
		{

			com.step();
			if (useScramble)
			{
				com.scramble();
			}

			// get abundances every so often
			if ((s % measureHowOften == 0) && (s / measureHowOften != 0))
			{
				gridArray[counter] = env.getGrid()[0];
				counter++;
			}
		}
		return gridArray;
	}

	public int[][][] gridTimeSeriesBackwards() throws Exception
	{
		Environment env = this.com.getEnvironment();
		int gridLength = env.getGridLength();
		int[][][] gridArray = new int[gridLength][gridLength][(numSteps / measureHowOften) + 1];
		int counter = 0;

		// get abudances at time zero

		int[][] curGrid = env.getGrid()[0];
		for(int row = 0; row < gridLength; row++)
		{
			for(int col = 0; col < gridLength; col++)
			{
				gridArray[row][col][counter] = curGrid[row][col];
			}
		}
		counter++;

		for (int s = 1; s < numSteps + 1; s++)
		{

			com.step();
			if (useScramble)
			{
				com.scramble();
			}

			// get abundances every so often
			if ((s % measureHowOften == 0) && (s / measureHowOften != 0))
			{
				curGrid = env.getGrid()[0];
				for(int row = 0; row < gridLength; row++)
				{
					for(int col = 0; col < gridLength; col++)
					{
						gridArray[row][col][counter] = curGrid[row][col];
					}
				}
				counter++;
			}
		}
		return gridArray;
	}


	public int[][][] gridTimeSeriesBackwards(ITerminateCondition tc) throws Exception
	{
		boolean didTerminate = false;

		Environment env = this.com.getEnvironment();
		int gridLength = env.getGridLength();

		// get abudances at time zero

		int[][][] gridArray = new int[gridLength][gridLength][(numSteps / measureHowOften) + 1];
		int counter = 0;

		if (!tc.shouldTerminate())
		{
			int[][] curGrid = env.getGrid()[0];
			for(int row = 0; row < gridLength; row++)
			{
				for(int col = 0; col < gridLength; col++)
				{
					gridArray[row][col][counter] = curGrid[row][col];
				}
			}
			counter++;

			for (int s = 1; s < numSteps + 1; s++)
			{

				com.step();
				if (useScramble)
				{
					com.scramble();
				}

				if (!tc.shouldTerminate())
				{

					// get abundances every so often
					if ((s % measureHowOften == 0) && (s / measureHowOften != 0))
					{
						curGrid = env.getGrid()[0];
						for(int row = 0; row < gridLength; row++)
						{
							for(int col = 0; col < gridLength; col++)
							{
								gridArray[row][col][counter] = curGrid[row][col];
							}
						}
						counter++;
					}
				}
				else
				{
					didTerminate = true;
					break;
				}
			}
		}
		else
		{
			didTerminate = true;
		}

		if (didTerminate)
		{

			int[][][] gridArrayTerm = new int[gridLength][gridLength][(numSteps / measureHowOften) + 1];
			for (int i = 0; i < counter; i++)
			{
				for (int j = 0; j < gridLength; j++)
				{
					for (int k = 0; k < gridLength; k++)
					{
						gridArrayTerm[j][k][i] = gridArray[j][k][i];

					}
				}
			}
			return gridArrayTerm;

		}
		else
		{
			return gridArray;

		}

	}


	
	public static int[][] DMDTimeSeries(Community com, int numSteps, int measureHowOften, int gridHeightIndex) throws Exception
	{

		int gridLength = com.getEnvironment().getGridLength();
		int totalSites = com.getEnvironment().getTotalSites();

		int[][] abundanceArray = new int[totalSites][(numSteps / measureHowOften) + 1];
		int counter = 0;

		int[][] tempGrid = com.getEnvironment().getGrid()[gridHeightIndex];
		for (int col = 0; col < gridLength; col++)
		{
			for (int row = 0; row < gridLength; row++)
			{

				abundanceArray[gridLength * col + row][counter] = tempGrid[row][col];
			}
		}
		counter++;

		for (int s = 1; s <= numSteps; s++)
		{
			com.step();
			if ((s % measureHowOften == 0) && (s / measureHowOften != 0))
			{
				tempGrid = com.getEnvironment().getGrid()[gridHeightIndex];
				for (int col = 0; col < gridLength; col++)
				{
					for (int row = 0; row < gridLength; row++)
					{

						abundanceArray[gridLength * col + row][counter] = tempGrid[row][col];
					}
				}
			}
			counter++;
		}

		return abundanceArray;
	}

}
