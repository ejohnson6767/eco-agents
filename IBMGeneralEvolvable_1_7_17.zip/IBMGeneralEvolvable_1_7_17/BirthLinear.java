import java.io.Serializable;
import java.util.ArrayList;

public class BirthLinear implements IBirthProcess, Serializable
{
	private Community com;
	private ISpecies speciesOwner;
	private double birthRate;
	private int speciesValue;

	public BirthLinear(double birthRate)
	{
		// this.com = com;
		this.birthRate = birthRate;
	}

	public double getBirthRate(Location loc)
	{
	
		double realizedBirthRate = 0;
		ArrayList<IEffect> lvEffects= this.speciesOwner.getAffectingLVEffects();
		
		for(int i = 0; i < lvEffects.size(); i++)
		{
			
			realizedBirthRate += this.birthRate * lvEffects.get(i).getEffect(loc);
			////System.out.println("getting lv ...  " +lvEffects.get(i).getEffect(loc));
			////System.out.println("realized birth rate is " + realizedBirthRate);

		}
		
		////System.out.println();
		return realizedBirthRate;
	}

	
	
	public void scaleByDt(double dt)
	{
		this.birthRate *= dt;

	}

	public void setSpeciesOwner(ISpecies species)
	{
		this.speciesOwner = species;

	}

	public void setupAfterCommunityIsCreated(Community com)
	{
		this.com = com;
		this.speciesValue = this.speciesOwner.getGridProxy();
	}

}
