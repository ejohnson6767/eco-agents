import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

public class CommunityUtilsInoculate implements Serializable
{

	/*
	 * goes through the list of species and checks if it's time for that species to be inoculated. If it's time, then the species is inoculated.
	 */
	public static void checkForInoculations(Community com)
	{

		if (!com.getNeverInoculate())
		{
			ArrayList<ISpecies> speciesList = com.getSpeciesList();
			int numberOfSpecies = com.getNumberOfSpecies();
			ArrayList<Integer> speciesIndexesToInoculate = new ArrayList<Integer>();
			// System.out.println("stepping");
			for (int sp = 0; sp < numberOfSpecies; sp++)
			{
				// System.out.println(" time step : " + timeStep);
				if (com.getStepCallCounter() == speciesList.get(sp).getInoculateWhen())
				{
					speciesIndexesToInoculate.add(sp);
				}
			}

			if (speciesIndexesToInoculate.size() != 0)
			{
				if (speciesIndexesToInoculate.size() > 1)
				{
					int[] speciesValues = new int[speciesIndexesToInoculate.size()];
					for (int i = 0; i < speciesValues.length; i++)
					{
						speciesValues[i] = speciesIndexesToInoculate.get(i) + 1;
						com.getInoculatedSpeciesIndexesTracker().add((speciesValues[i] - 1));
					}

					//System.out.println("about to inoculate muliple species");
					CommunityUtilsInoculate.inoculateMultipleSpecies(com, speciesValues);
					//System.out.println("done inoculating muliple species");

					if (com.getInoculatedSpeciesIndexesTracker().size() == numberOfSpecies)
					{
						com.setNeverInoculate(true);
					}

				}
				else
				{
					int sp = speciesIndexesToInoculate.get(0);
					CommunityUtilsInoculate.inoculateSpecies(com, sp, speciesList.get(sp).getInoculateOverwrite());
					com.getInoculatedSpeciesIndexesTracker().add(sp);
					if (com.getInoculatedSpeciesIndexesTracker().size() == numberOfSpecies)
					{
						com.setNeverInoculate(true);
					}
				}

				/*
				 * if (com.getAnyCMEffects()) { CommunityUtilsLVEffects.fillCMGridMovingWindow(com); } if (com.getAnyDMEffects()) { CommunityUtilsLVEffects.fillDMGridMovingWindow(com); }
				 */
			}
		}
	}

	// /**
	// *
	// * Randomly places a population on the environment grid.
	// *
	// * @param speciesListIndex the speciesList index of the species that is to be inoculated
	// * @param overrideOtherCritters if true, overwrite heterospecifics upon inocuation. If false, try to find an empty microsite 500 times. If that doesn't work, go ahead and overwrite heterospecifics
	// */
	// public static void inoculateSpecies(Community com, int speciesListIndex, boolean overrideOtherCritters)
	// {
	// ArrayList<ISpecies> speciesList = com.getSpeciesList();
	// ISpecies curSpecies = speciesList.get(speciesListIndex);
	// int envGridIndex = curSpecies.getHomeGridIndex();
	// Environment env = com.getEnvironment();
	// Random generator = env.getGenerator(envGridIndex);
	// boolean useMovingWindowForAlpha = com.getUseMovingWindowForAlpha();
	// int val = curSpecies.getGridProxy();
	//
	// int init = curSpecies.getInitialAbundance();
	// int i = 0;
	// // if we don't plan to overwrite other critters
	// if (!overrideOtherCritters)
	//
	// // do the following for each individual
	// while (i < init)
	// {
	// int k = 0;
	// // try to find an empty site 500 times
	// while (k < 500)
	// {
	// int row = generator.nextInt(env.getGridLength());
	// int col = generator.nextInt(env.getGridLength());
	// if (env.isEmpty(row, col, envGridIndex))
	// {
	// env.add(row, col, envGridIndex, val);
	//
	// if (!useMovingWindowForAlpha)
	// {
	//
	// CommunityUtilsLVEffects.addCMEffects(com, row, col, curSpecies);
	// CommunityUtilsLVEffects.addDMEffects(com, row, col, curSpecies);
	//
	// }
	//
	// break;
	// }
	// k++;
	// }
	//
	// // if that doesn't work, keep trying to establish until you find an empty site or a heterospecific
	// if (k == 500)
	// {
	// while (true)
	// {
	// int row = generator.nextInt(env.getGridLength());
	// int col = generator.nextInt(env.getGridLength());
	// int gridValue = env.getGridValue(row, col, envGridIndex);
	// if (gridValue != val)
	// {
	// if (gridValue == 0)
	// {
	// // take over that spot
	// env.add(row, col, envGridIndex, val);
	// if (!useMovingWindowForAlpha)
	// {
	//
	// CommunityUtilsLVEffects.addCMEffects(com, row, col, curSpecies);
	// CommunityUtilsLVEffects.addDMEffects(com, row, col, curSpecies);
	//
	// }
	// }
	// else
	// {
	// // take over that spot
	// env.add(row, col, envGridIndex, val);
	// if (!useMovingWindowForAlpha)
	// {
	//
	// CommunityUtilsLVEffects.addCMEffects(com, row, col, curSpecies);
	// CommunityUtilsLVEffects.addDMEffects(com, row, col, curSpecies);
	// CommunityUtilsLVEffects.subtractCMEffects(com, row, col, speciesList.get(gridValue - 1));
	// CommunityUtilsLVEffects.subtractDMEffects(com, row, col, speciesList.get(gridValue - 1));
	//
	// }
	// }
	//
	// break;
	// }
	// }
	// }
	//
	// i++;
	//
	// }
	// // if we don't have a problem with overwriting heterospecifics
	// else
	// {
	// // do the following for each individual
	// while (i < init)
	// {
	// // search for an empty site or a site with a heterospecific
	// while (true)
	// {
	// int row = generator.nextInt(env.getGridLength());
	// int col = generator.nextInt(env.getGridLength());
	// int gridValue = env.getGridValue(row, col, envGridIndex);
	// if (gridValue != val)
	// {
	// if (gridValue == 0)
	// {
	// // take over that spot
	// env.add(row, col, envGridIndex, val);
	// if (!useMovingWindowForAlpha)
	// {
	//
	// CommunityUtilsLVEffects.addCMEffects(com, row, col, curSpecies);
	// CommunityUtilsLVEffects.addDMEffects(com, row, col, curSpecies);
	//
	// }
	// }
	// else
	// {
	// // take over that spot
	// env.add(row, col, envGridIndex, val);
	// if (!useMovingWindowForAlpha)
	// {
	//
	// CommunityUtilsLVEffects.addCMEffects(com, row, col, curSpecies);
	// CommunityUtilsLVEffects.addDMEffects(com, row, col, curSpecies);
	// CommunityUtilsLVEffects.subtractCMEffects(com, row, col, speciesList.get(gridValue - 1));
	// CommunityUtilsLVEffects.subtractDMEffects(com, row, col, speciesList.get(gridValue - 1));
	//
	// }
	// }
	//
	// break;
	// }
	// }
	// i++;
	// }
	// }
	//
	// }

	/**
	 * 
	 * Randomly places a population on the environment grid.
	 * 
	 * @param speciesListIndex the speciesList index of the species that is to be inoculated
	 * @param overrideOtherCritters if true, overwrite heterospecifics upon inocuation. If false, try to find an empty microsite 500 times. If that doesn't work, go ahead and overwrite heterospecifics
	 */
	public static void inoculateSpecies(Community com, int speciesListIndex, boolean overrideOtherCritters)
	{
		ArrayList<ISpecies> speciesList = com.getSpeciesList();
		ISpecies curSpecies = speciesList.get(speciesListIndex);
		int init = curSpecies.getInitialAbundance();
		//System.out.println("init in inoculate is " + init);
		AddCritters ac = new AddCritters(com, (speciesListIndex + 1), overrideOtherCritters);
		ac.addCrittersRandomly(init);
		
		//System.out.println("afterwards, abund is " + com.getAbundances()[speciesListIndex]);
		
		LocalLVAllSpecies lv = new LocalLVAllSpecies(com);
		lv.setBooleans();
		lv.doLocalLVStuff();
	}

	public static void inoculateMultipleSpecies(Community com, int[] speciesValues)
	{
		ArrayList<ISpecies> speciesList = com.getSpeciesList();

		int[] init = new int[speciesValues.length];
		boolean[] overwrite = new boolean[speciesValues.length];

		for (int i = 0; i < init.length; i++)
		{
			ISpecies curSpecies = speciesList.get(speciesValues[i] - 1);
			init[i] = curSpecies.getInitialAbundance();
			overwrite[i] = curSpecies.getInoculateOverwrite();
		}

		// here, the last two parameters (1, and false) don't matter.
		AddCrittersMultipleSpecies ac = new AddCrittersMultipleSpecies(com, speciesValues, overwrite);
		ac.addCrittersRandomlyMultipleSpecies(init);

		LocalLVAllSpecies lv = new LocalLVAllSpecies(com);
		lv.setBooleans();
		lv.doLocalLVStuff();
	}

	/**
	 * 
	 * Randomly places a population on the environment grid.
	 * 
	 * @param speciesListIndex the speciesList index of the species that is to be inoculated
	 * @param overrideOtherCritters if true, overwrite heterospecifics upon inocuation. If false, try to find an empty microsite 500 times. If that doesn't work, go ahead and overwrite heterospecifics
	 */
	public static void inoculateSpeciesUniformly(Community com, int speciesListIndex, boolean overrideOtherCritters)
	{
		ArrayList<ISpecies> speciesList = com.getSpeciesList();
		ISpecies curSpecies = speciesList.get(speciesListIndex);
		int init = curSpecies.getInitialAbundance();
		AddCritters ac = new AddCritters(com, (speciesListIndex + 1), overrideOtherCritters);
		ac.addCrittersUniformly(init);

		LocalLVAllSpecies lv = new LocalLVAllSpecies(com);
		lv.setBooleans();
		lv.doLocalLVStuff();
	}

	/**
	 * Makes sure that no species can be added to the environmment after this method is called.
	 */
	public static void neverInoculate(Community com)
	{
		com.setNeverInoculate(true);

	}
}
