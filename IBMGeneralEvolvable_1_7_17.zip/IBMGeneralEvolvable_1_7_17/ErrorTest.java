import java.util.ArrayList;

public class ErrorTest
{

	public static void main(String[] args) throws Exception
	{
		// regular params
		int gridLength = 100;
		double dt = 1;
		// int n1InitAbund = 2000;
		// int n2InitAbund = 2000;
		double r1 = 0.46;
		double r2 = 0.46;
		double d1 = 0.2;
		double d2 = 0.2;
		int disp1 = 1;
		int disp2 = 1;

		// inoculation params
		int n1InitAbund = 1000; // number of individuals to be inoculate
		int n1InoculationTime = 0; // what time does inoculation happen? automatically scaled my
		boolean n1Overwrite = true; // can you overwrite heterospecifics during inoculation. Meaningless if this is the first species to be inoculated
		int n2InitAbund = 1000;
		int n2InoculationTime = 10;
		boolean n2Overwrite = true;

		// put species objects in a list
		ArrayList<ISpecies> list = new ArrayList<ISpecies>();

		// add the first species
		list.add(new Species(r1, d1, disp1));
		list.add(new Species(r2, d2, disp2));

		Community com = new Community(gridLength, dt, list);

		AddCritters ac1 = new AddCritters(com, 1, false);
		ac1.addCrittersRandomly(100);

		AddCritters ac2 = new AddCritters(com, 2, false);
		ac2.addCrittersRandomly(100);

		com.step(100);
		com.getAbundances();

		// first make the mutation function
		double mutationMagnitude = 1;
		double evolveProb = 0.01;

		IMutationFunction mfDispn1 = new MutationFunctionDiscreteBoundedByOne(evolveProb, mutationMagnitude);

		DispersalIB dispIB = new DispersalIB(mfDispn1);

		// dispIB = .jcast(dispIB, "IDispersalStrategy")
		// give the evolvable trait to the first species
		com.getSpeciesList().get(0).addTrait(dispIB);
		TimeSeries ts = new TimeSeries(com, 1000, 5);
		ts.timeSeries(true);

		dispIB.startEvolution();
		// com.getSpeciesList().get(as.integer(0)).getEvolvableTraits().get(as.integer(0)).startEvolution()

		TimeSeries ts2 = new TimeSeries(com, 1000, 5);
		ts.timeSeries(true);

		// abundsOverTime = .jevalArray(ts1.timeSeries(TRUE), simplify = TRUE)

	}

}
