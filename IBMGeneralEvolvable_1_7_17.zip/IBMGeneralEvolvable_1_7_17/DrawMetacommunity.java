import java.util.ArrayList;

public class DrawMetacommunity
{

	public static int[][] drawPatchPerimeters(int gridLength, ArrayList<ArrayList<Patch>> patchList)
	{
		int[][] patchPerimGrid = new int[gridLength][gridLength];
		// gl.glLoadIdentity(); // Reset The View
		int theRow;
		int theCol;
		int newRow;
		int newCol;

		for (int j = 0; j < patchList.size(); j++)
		{
			// System.out.println("getting subpatchlist " + (j+1));
			ArrayList<Patch> patchSubList = patchList.get(j);
			/*
			 * if (j == 0) { gl.glColor4f(1.0f, 0.0f, 0.0f, 0.2f); } else if (j == 1) { gl.glColor4f(0.0f, 1.0f, 0.0f, 0.2f); } else if (j == 2) { gl.glColor4f(0.0f, 0.0f, 1.0f, 0.2f); } else if (j == 3) { gl.glColor4f(1.0f, 1.0f, 0.0f, 0.2f); } else { gl.glColor4f(0.0f, 1.0f, 1.0f, .2f); }
			 */
			for (int i = 0; i < patchSubList.size(); i++)
			{
				// System.out.println("getting patch " + (i+1));
				Patch loc = patchSubList.get(i);
				int rowLength = loc.getRowLength();
				int colLength = loc.getColLength();
				theRow = loc.getRow();
				theCol = loc.getCol();
				for (int r = 0; r < rowLength; r++)
				{
					for (int c = 0; c < colLength; c++)
					{
						if ((r == 0 || r == rowLength - 1) || ((r != 0 || r != rowLength - 1) && (c == 0 || c == colLength - 1)))
						{

							newRow = WrapAround.wrapAround(theRow + r, gridLength);
							newCol = WrapAround.wrapAround(theCol + c, gridLength);

							patchPerimGrid[newRow][newCol] = 1;
						}
					}

				}
			}
		}
		
		return patchPerimGrid;
	}

	public static int[][] drawPatches(int gridLength, ArrayList<ArrayList<Patch>> patchList)
	{
		int[][] patchGrid = new int[gridLength][gridLength];
		// gl.glLoadIdentity(); // Reset The View
		int theRow;
		int theCol;
		int newRow;
		int newCol;

		for (int j = 0; j < patchList.size(); j++)
		{
			// System.out.println("getting subpatchlist " + (j+1));
			ArrayList<Patch> patchSubList = patchList.get(j);
			/*
			 * if (j == 0) { gl.glColor4f(1.0f, 0.0f, 0.0f, 0.2f); } else if (j == 1) { gl.glColor4f(0.0f, 1.0f, 0.0f, 0.2f); } else if (j == 2) { gl.glColor4f(0.0f, 0.0f, 1.0f, 0.2f); } else if (j == 3) { gl.glColor4f(1.0f, 1.0f, 0.0f, 0.2f); } else { gl.glColor4f(0.0f, 1.0f, 1.0f, .2f); }
			 */
			for (int i = 0; i < patchSubList.size(); i++)
			{
				// System.out.println("getting patch " + (i+1));
				Patch loc = patchSubList.get(i);
				int rowLength = loc.getRowLength();
				int colLength = loc.getColLength();
				theRow = loc.getRow();
				theCol = loc.getCol();
				for (int r = 0; r < rowLength; r++)
				{
					for (int c = 0; c < colLength; c++)
					{

						newRow = WrapAround.wrapAround(theRow + r, gridLength);
						newCol = WrapAround.wrapAround(theCol + c, gridLength);

						patchGrid[newRow][newCol] = 1;

					}

				}
			}
		}
		return patchGrid;
	}

}
