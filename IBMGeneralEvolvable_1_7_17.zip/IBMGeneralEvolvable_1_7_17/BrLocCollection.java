import java.io.Serializable;

public class BrLocCollection implements Serializable
{
	private double br;
	private Location loc;
	public BrLocCollection(double br, Location loc)
	{
		this.br = br;
		this.loc = loc;

	}
	
	public double getBr()
	{
		return this.br;
	}
	public Location getLoc()
	{
		return this.loc;
	}
}
