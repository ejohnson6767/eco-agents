import java.io.Serializable;

public class ExpectedFitness implements Serializable
{
	private int speciesValue;
	private Community com;
	private int returnLength;

	public ExpectedFitness(Community com, int speciesValue)
	{
		this.speciesValue = speciesValue;
		this.com = com; 
		this.returnLength = 1;

	}

	public int getReturnLength()
	{
		return this.returnLength;
	}

	public double[][] getFitnessGrid()
	{
		ISpecies aSpecies = com.getSpeciesList().get(this.speciesValue - 1);
		IDispersalTrait dt = aSpecies.getDispersalStrategy();
		double dTime = this.com.getDt();
		Environment env = com.getEnvironment();
		int gridLength = env.getGridLength();
		int envGridIndex = aSpecies.getHomeGridIndex();

		double[][] lambdaGrid = new double[gridLength][gridLength];

		if (dt.isIndividualBased())
		{
			for (int row = 0; row < gridLength; row++)
			{
				for (int col = 0; col < gridLength; col++)
				{
					int gridValue = env.getGridValue(row, col, envGridIndex);
					if (gridValue == speciesValue)
					{
						lambdaGrid[row][col] = aSpecies.getFitness(new Location(row, col));
					}
					else
					{
						lambdaGrid[row][col] = 0 / (double) 0;
					}
				}
			}
			return lambdaGrid;
		}
		else
		{
			GetEGrid geg = new GetEGrid(this.com, this.speciesValue);
			double[][] EGrid = geg.getGrid(dt.getDispersalRadius());
			for (int row = 0; row < gridLength; row++)
			{
				for (int col = 0; col < gridLength; col++)
				{
					int gridValue = env.getGridValue(row, col, envGridIndex);
					if (gridValue == speciesValue)
					{
						Location loc = new Location(row, col);
						double lambda = 1 + (aSpecies.getBirthRate(loc) * EGrid[row][col]) - aSpecies.getDeathRate(loc);
						lambdaGrid[row][col] = CorrectLambdaWithDt.correct(lambda, dTime);
					}
					else
					{
						lambdaGrid[row][col] = 0 / (double) 0;
					}

				}
			}

			return lambdaGrid;
		}

	}

	public double[][] getFitnessGrid(double[][] EGrid)
	{
		ISpecies aSpecies = com.getSpeciesList().get(this.speciesValue - 1);
		int envGridIndex = aSpecies.getHomeGridIndex();
		double dTime = this.com.getDt();
		Environment env = com.getEnvironment();
		int gridLength = env.getGridLength();
		double[][] lambdaGrid = new double[gridLength][gridLength];

		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				int gridValue = env.getGridValue(row, col, envGridIndex);
				if (gridValue == speciesValue)
				{
					Location loc = new Location(row, col);
					double lambda = 1 + (aSpecies.getBirthRate(loc) * EGrid[row][col]) - aSpecies.getDeathRate(loc);
					lambdaGrid[row][col] = CorrectLambdaWithDt.correct(lambda, dTime);
				}
				else
				{
					lambdaGrid[row][col] = 0 / (double) 0;
				}
			}
		}
		return lambdaGrid;
	}

	public double getFitnessAverage()
	{
		Environment env = com.getEnvironment();
		int gridLength = env.getGridLength();
		double[][] fitGrid = getFitnessGrid();
		double total = 0;
		int counter = 0;

		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				if (!Double.isNaN(fitGrid[row][col]))
				{
					total += fitGrid[row][col];
					counter++;
				}
			}
		}
		return total / (double) counter;
	}



	
}