import java.io.Serializable;
import java.util.ArrayList;

public class BirthQuantCheatGen implements IBirthQuantCheat, IBirthProcess, Serializable
{

	// private Community com;
	private double[] gain;
	private IQuantCheatQ[] q;
	private double bMin;
	private ISpecies speciesOwner;
	private double[] theta;
	private double K;

	public BirthQuantCheatGen(double bMin, double[] gain, double K, double[] q, double[] theta)
	{
		this.bMin = bMin;
		
		this.gain = gain;
	
		this.q = new IQuantCheatQ[q.length];
		for (int i = 0; i < q.length; i++)
		{
			this.q[i] = new QuantCheatQ(q[i]);
		}
		
			this.theta = theta;
		
		this.K = K;
	}

	public double getBirthRateBaseline(Location loc)
	{
		double total = 0;
		for (int i = 0; i < gain.length; i++)
		{
			total += this.gain[i] * (1 - this.q[i].getQ(loc));
		}
		
		return this.bMin * (1 + total);
	}

	public double getResourceLimitation(Location loc)
	{
		double min = 1;
		ArrayList<ArrayList<IEffect>> lvEffects = this.speciesOwner.getAffectingLVEffectsByIndicator();
		// System.out.println("size of lv effects is " + lvEffects.size());
		for (int i = 1; i < lvEffects.size(); i++)
		{
			ArrayList<IEffect> oneIndicator = lvEffects.get(i);
			if (oneIndicator.size() != 0)
			{

				double localEffect = 0;
				for (int j = 0; j < oneIndicator.size(); j++)
				{
					/*if(oneIndicator.get(j).getEffectValue().isIndividualBased())
					{
						System.out.println("resource " + i + " from species " + oneIndicator.get(j).getSpeciesValue() + " is individual based");
					}*/
					
					localEffect += oneIndicator.get(j).getEffect(loc);
				}
				//System.out.println("local effect is "+ localEffect );
				
					// System.out.println("lv Effect raw is " + (this.K * lv.getEffect(loc)));
					// System.out.println("lv Effect bonus is " + (this.K * (Math.pow(this.q.getQ(loc) , this.theta))));
					double val = this.K * (localEffect + Math.pow(this.q[i-1].getQ(loc), this.theta[i-1]));
					//System.out.println("val is " + val);

					if (val < min)
					{
						min = val;
					}
				
			}

			 //System.out.println("min is " + min);
		}
		//System.out.println("");
		return min;

	}

	public void setQ(IQuantCheatQ q, int indicator)
	{
		/*System.out.println("indicator is " + indicator);
		System.out.println("q is " + q);
		System.out.println("this.q is " + this.q);
		System.out.println("length of q array is " + this.q.length);*/

		this.q[indicator-1] = ((IQuantCheatQ) q);
	}

	public double getBirthRate(Location loc)
	{
		return getBirthRateBaseline(loc) * getResourceLimitation(loc);
	}

	public void scaleByDt(double dt)
	{
		this.bMin *= dt;

	}

	@Override
	public void setSpeciesOwner(ISpecies species)
	{
		this.speciesOwner = species;
		for (int i = 0; i < q.length; i++)
		{
			this.q[i].setSpeciesOwner(species);
		}
		

	}

	@Override
	public void setupAfterCommunityIsCreated(Community com)
	{
		for (int i = 0; i < q.length; i++)
		{
			this.q[i].setupAfterCommunityIsCreated(com);
		}
		

	}

	public IQuantCheatQ getQ(int indicator)
	{
		return this.q[indicator - 1];
	}

	

	
}
