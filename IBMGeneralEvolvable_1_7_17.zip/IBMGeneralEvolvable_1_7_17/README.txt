
PROJECT TITLE:  Metacommunity simulator
The metacommunity simulation is a stoichastic spatial model that explores
community patterns in a source-sink metacommunity. The landscape is a grid
that wraps around to create a donut. The communities are square patches within
the landscape. Each species is the best competitor (operationalized as birth rate)
in one type of community, the second best in another community, and so on. In other
words, while there are local disparities in competitive abilities, species are 
regionally equivalent. There is an option to add birth rate probability density 
unevely so that there is a regionally best competitor. This option of deviation from
the strict similarity case represents contingencies that would be expected in nature,
such as a novel mutation or the stoichasticity of genetic drift. However, it 
constrains the regionally best competitor from being so good that it has a higher
birth rate than the best local competitor. Individuals (critters) are sessile, so
populations can only move through space through reproduction (dispersion, though 
named "dispersal" in the program). If the por


VERSION or DATE:  3 March 2016

HOW TO START THIS PROJECT: copy the entire zipped file to an eclipse workspace. In 
the eclipse IDE, create a new package which has the same name as the workspace folder.
Right-click on the newly created package in the file viewer, and select configure build 
path. 

AUTHORS: Evan Johnson

USER INSTRUCTIONS:
Go to the Visual class, specify parameter values (static fields), and click run. 

