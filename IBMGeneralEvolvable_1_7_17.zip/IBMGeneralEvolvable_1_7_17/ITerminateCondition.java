import java.io.Serializable;

public interface ITerminateCondition extends Serializable
{
	boolean shouldTerminate();
}
