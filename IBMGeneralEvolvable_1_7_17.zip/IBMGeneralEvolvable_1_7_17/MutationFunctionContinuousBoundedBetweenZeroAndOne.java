import java.io.Serializable;
import java.util.Random;

public class MutationFunctionContinuousBoundedBetweenZeroAndOne extends MutationFunctionStandard implements IMutationFunction, Serializable
{

	public MutationFunctionContinuousBoundedBetweenZeroAndOne(double evolveProb, double mutationMagnitude)
	{
		super(evolveProb, mutationMagnitude);
	}

	public void setGenerator(Random generator)
	{
		this.generator = generator;
	}

	public double mutate(double traitValue)
	{

		if (generator.nextDouble() < evolveProb.getEvolveProb())
		{
			double addTo = generator.nextGaussian() * mutationMagnitude.getMutationMagnitude();

			if (generator.nextInt(2) == 1)
			{
				addTo *= -1;
			}

			traitValue += addTo;

			if (traitValue < 0)
			{
				traitValue = 0;
			}
			else if (traitValue > 1)
			{
				traitValue = 1;
			}

		}

		return traitValue;
	}

	public double mutate(double traitValue, Location parentLoc)
	{
		if (generator.nextDouble() < evolveProb.getEvolveProb(parentLoc))
		{
			double addTo = generator.nextGaussian() * mutationMagnitude.getMutationMagnitude(parentLoc);

			if (generator.nextInt(2) == 1)
			{
				addTo *= -1;
			}

			traitValue += addTo;

			if (traitValue < 0)
			{
				traitValue = 0;
			} else if (traitValue > 1)
			{
				traitValue = 1;
			}

		}

		return traitValue;
	}

}
