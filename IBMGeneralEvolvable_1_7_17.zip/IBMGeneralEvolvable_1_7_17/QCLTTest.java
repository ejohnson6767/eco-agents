import java.util.ArrayList;

public class QCLTTest
{

	public static void main(String[] args) throws Exception
	{

		int initAbund1 = 1600;
		int initAbund2 = 1600;

		// The number of steps the simulation is run for.
		int numSteps = 100;

		// gridLength is the length and width of the community it sites. Thus, if it is 200, then the community will be a 200x200 square (and thus 40,000 sites).
		int gridLength = 70;

		// dt is Delta T in the paper (i.e., the number of time steps per unit time). I found that 0.1 was generally small enough that it didn't cause problems.
		double dt = 1;

		// These parameters are directly in the model:
		double thebmin = 1; // The cheater's birth rate, b_0.
		double thegain = .2; // The birth rate of each cross-feeder, b_1 and b_2.
		double death = .1; // The death rate of each speices, delta.
		double K = 2; // The amont of compounds leaked.

		// q1val is the vector of q_1's we consider.
		double[] q1val = new double[] { 0.7 }; // seq(.35,.9,0.05);//seq(.7,.76,0.02);
		double q2val = .7;// seq(0,1,0.1);
		int qqq = 0;
		// TOTALRUN is the number of communities we will need to generate (needed for parallell computing).
		int TOTALRUN = 1;

		int r_mic = 2;
		int r_res = 2;

		//////////////////////////////////////////////////
		// Run the community simulations
		//////////////////////////////////////////////////

		// make the arrayList
		ArrayList<ISpecies> list = new ArrayList<ISpecies>();

		// add the first species
		list.add(new Species(.42, death, r_mic, initAbund1, 0, true));

		// add the second species
		list.add(new Species(.42, death, r_mic, initAbund2, 0, true));

		////////////////////////////

		//// first, let's create the different birth processes...
		IBirthProcess bpQCn1 = new BirthQuantCheat(thebmin, thegain, K, q1val[qqq], 0);
		IBirthProcess bpQCn2 = new BirthQuantCheat(thebmin, thegain, K, q2val, 0);
		// ... then give them to our basleine species
		//// note that since indexing in java is zero-based, the species 1 is retrieved with get(0)
		list.get(0).setBirthProcess(bpQCn1);
		list.get(1).setBirthProcess(bpQCn2);

		// the last argument [1], is the type of resource the species is making. species 1 makes type 1. Species 2 makes type 2.
		IEffect eff1 = new Effect(q1val[qqq], r_res, 1);
		IEffect eff2 = new Effect(q2val, r_res, 2);

		// now we have to give the species their resource excrement responsibilities, and make sure the other species can "see" the resources
		// the following line reads... species 1 [speciesList.get(0)] affects species 1 [setLocalEffect(1...,)] with resource 1 (...eff1)
		list.get(0).setLocalEffect(1, eff1);
		// it also affects species 2
		list.get(0).setLocalEffect(2, eff1);

		list.get(1).setLocalEffect(1, eff2);
		list.get(1).setLocalEffect(2, eff2);

		Community com = new Community(gridLength, dt, list);

		com.getEnvironment().setSeedAtOneLevel(1, 20);

		//com.step(1000);

		int[][] grid = com.getEnvironment().getGrid()[0];
		for (int i = 0; i < 12; i++)
		{
			System.out.println(grid[0][i]);
		}

		///////////////////////////////////////////////////
		///////////////////////////////////////////////////

		int measureHowOften = 1;
		TimeSeries ts = new TimeSeries(com, 2, measureHowOften, false);

		//LambdaBar lt1 = new LambdaBar(com, 1);
		//LambdaTilda lt2 = new LambdaTilda(com, 2);

		//ArrayList<ITimeSeriesQuantity> tsq = new ArrayList<ITimeSeriesQuantity>();
		//tsq.add(lt1);
		//tsq.add(lt2);

		int[][][] dat = ts.gridTimeSeries();
		double[] datFlat = ArrayFlattener.flatten(dat);
		for (int i = 0; i < datFlat.length; i++)
		{
			System.out.println(datFlat[i]);
		}
	

	}

}
