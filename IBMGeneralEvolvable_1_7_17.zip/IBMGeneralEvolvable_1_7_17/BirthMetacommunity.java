import java.io.Serializable;

public class BirthMetacommunity implements IBirthProcess, Serializable
{
	//private Community com;
	private double birthRate;
	private ISpecies speciesOwner;
	private double[][] birthGrid;

	public BirthMetacommunity(double birthRate)
	{
		//this.com = com;
		this.birthRate = birthRate;
	}
	
	public double getBirthRate(Location loc)
	{
		return this.birthRate * birthGrid[loc.row()][loc.col()];
	}
	
	public void scaleByDt(double dt)
	{
		this.birthRate *= dt;
		
	}

	@Override
	public void setSpeciesOwner(ISpecies species)
	{
		this.speciesOwner= species;
			
	}

	@Override
	public void setupAfterCommunityIsCreated(Community com)
	{
		birthGrid = speciesOwner.getBirthGrid().getSpecificDemographyGrid();
	}
}
