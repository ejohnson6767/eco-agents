import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

public class InvasionCommunity extends Community implements Serializable
{
	private ISpecies invader;
	private int invaderValue;
	// private int timeStepCounter;
	// private int timeAfterAddStraightToPatch;
	// private int[] bestPatches;
	private int tooLowAbund;
	private int tooHighAbund;
	private ArrayList<Location> invaderLocations;

	private int equilibriumAbund;
	private int timeSinceInvaderRegulation;
	private int timeSinceInvaderRegulationFromZeroDensity;

	private int regulateInvadersThisOften;
	private int invasionStart;
	private boolean useOldInvaderTraits;
	private int archiveOldTraitsThisOften;
	private boolean overwrite;
	private int invaderHomeIndex;
	private Random generator;
	private double initialDensity;
	private boolean isFancy;

	public InvasionCommunity(int gridLength, double dt, ArrayList<ISpecies> speciesList) throws Exception
	{
		super(gridLength, dt, speciesList);
	}

	public int getTimeSinceInvaderRegulation()
	{
		return this.timeSinceInvaderRegulation;
	}

	public int getTimeSinceInvaderRegulationFromZeroDensity()
	{
		return this.timeSinceInvaderRegulationFromZeroDensity;
	}

	public void setBlandInvasionParameters(int invaderValue, int invasionStart, double initialDensity, boolean overwrite)
	{
		setInvaderValue(invaderValue);
		this.equilibriumAbund = (int) Math.round((this.tooHighAbund + this.tooLowAbund) / (double) 2.0);
		this.invaderLocations = new ArrayList<Location>();
		this.overwrite = overwrite;
		this.invasionStart = (int) Math.round(invasionStart / this.dt);
		this.invaderHomeIndex = this.invader.getHomeGridIndex();
		this.initialDensity = initialDensity;
		this.generator = this.env.getGenerator(this.invaderHomeIndex);
		this.isFancy = false;
	}

	public void setFancyInvasionParameters(int invaderValue, int invasionStart, double tooLow, double tooHigh, boolean overwrite, int regulateInvadersThisOften, int archiveOldTraitsThisOften)
	{
		setInvaderValue(invaderValue);
		this.tooLowAbund = (int) Math.round(tooLow * this.env.getTotalSites());
		System.out.println(this.tooLowAbund);

		this.tooHighAbund = (int) Math.round(tooHigh * this.env.getTotalSites());
		System.out.println(this.tooHighAbund);

		this.equilibriumAbund = (int) Math.round((this.tooHighAbund + this.tooLowAbund) / (double) 2.0);
		System.out.println(this.equilibriumAbund);
		System.out.println((this.equilibriumAbund - this.tooLowAbund));
		System.out.println((this.tooHighAbund - this.equilibriumAbund));
		if ((this.equilibriumAbund - this.tooLowAbund) < 1 || (this.tooHighAbund - this.equilibriumAbund) < 1)
		{
			throw new IllegalStateException("ERROR: the program wants to add or remove less than one individual");
		}
		this.invaderLocations = new ArrayList<Location>();
		this.regulateInvadersThisOften = regulateInvadersThisOften;
		this.archiveOldTraitsThisOften = archiveOldTraitsThisOften;

		this.useOldInvaderTraits = true;
		if (this.archiveOldTraitsThisOften == 0)
		{
			this.useOldInvaderTraits = false;
		}
		else
		{
			TraitList traitList = this.invader.getTraitList();
			if (traitList != null)
			{
				traitList.setTimeBetweenOldTraitUpdates(this.archiveOldTraitsThisOften);
			}
		}
		this.timeSinceInvaderRegulation = 0;
		this.timeSinceInvaderRegulationFromZeroDensity = 0;
		this.overwrite = overwrite;

		this.invasionStart = (int) Math.round(invasionStart / this.dt);

		this.invaderHomeIndex = this.invader.getHomeGridIndex();
		this.generator = this.env.getGenerator(this.invaderHomeIndex);
		this.isFancy = true;
	}

	public void invasionHousekeepingFancy()
	{
		this.timeSinceInvaderRegulation++;
		this.timeSinceInvaderRegulationFromZeroDensity++;
		if (this.timeStep > this.invasionStart)
		{
			if (this.timeStep % this.regulateInvadersThisOften == 0 && this.timeStep / this.regulateInvadersThisOften != 0)
			{
				regulateInvaders();
			}

			TraitList traitList = this.invader.getTraitList();
			if (traitList != null)
			{
				traitList.checkForOldTraitUpdate(this);
			}
		}
	}

	public void invasionHousekeepingBland()
	{
		if (this.timeStep == this.invasionStart)
		{
			
			AddCritters ac = new AddCritters(this, this.invaderValue, this.overwrite);
			ac.addCrittersRandomly(this.equilibriumAbund);
			//addInvadersFromZeroDensity((int) Math.round(this.initialDensity * this.env.getTotalSites()), this.overwrite);
		}
	}

	public void step() throws Exception
	{
		if (this.isFancy)
		{
			CommunityUtilsStep.step(this);
			invasionHousekeepingFancy();
		}
		else
		{
			CommunityUtilsStep.step(this);
			invasionHousekeepingBland();
		}

	}

	public void step(int numSteps) throws Exception
	{
		if (this.isFancy)
		{
			for (int i = 0; i < numSteps; i++)
			{
				CommunityUtilsStep.step(this);
				invasionHousekeepingFancy();
			}
		}
		else
		{
			for (int i = 0; i < numSteps; i++)
			{
				CommunityUtilsStep.step(this);
				invasionHousekeepingBland();
			}
		}
	}

	public void stepAndScatter() throws Exception
	{
		if (this.isFancy)
		{
			CommunityUtilsStep.stepAndScatter(this);
			invasionHousekeepingFancy();
		}
		else
		{
			CommunityUtilsStep.stepAndScatter(this);
			invasionHousekeepingBland();
		}
	}

	public void stepAndScatter(int numSteps) throws Exception
	{
		if (this.isFancy)
		{
			for (int i = 0; i < numSteps; i++)
			{
				CommunityUtilsStep.stepAndScatter(this);
				invasionHousekeepingFancy();
			}
		}
		else
		{
			for (int i = 0; i < numSteps; i++)
			{
				CommunityUtilsStep.stepAndScatter(this);
				invasionHousekeepingBland();
			}
		}
	}

	public void setInvaderValue(int invaderValue)
	{
		this.invaderValue = invaderValue;
		this.invader = this.speciesList.get(invaderValue - 1);
		this.invader.setIsInvader(true);
		this.invader.setInitialAbundance(0);
	}

	public void setInvader(ISpecies invader)
	{
		this.invader = invader;
		this.invaderValue = invader.getGridProxy();
		this.invader.setIsInvader(true);
		this.invader.setInitialAbundance(0);

	}

/*	public void getInvaderLocations()
	{
		this.invaderLocations = new ArrayList<Location>();

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col, this.invaderHomeIndex) == this.invaderValue)
				{
					this.invaderLocations.add(new Location(row, col));
				}
			}
		}

		// System.out.println("time step is " + this.timeStep);
		
		 * if (this.timeStep > 200) { TraitList list = this.invader.getTraitList(); if (list != null) { double[][] tracker = list.getList().get(0).getSpatialDistributionTracker(); for (int i = 0; i < invaderLocations.size(); i++) { Location loc = this.invaderLocations.get(i); if (tracker[loc.row()][loc.col()] == 0) { System.out.println("MISSED INVADER AT ROW " + loc.row() + " AND COL " + loc.col() + ". time step is " + this.timeStep); } } } }
		 
	}

	public void addInvaders(int invadersToAdd, boolean overwrite)
	{
		if (SpeciesTraitQuestions.isIndividualBased(this.invader))
		{
			// TraitList traitList = this.invader.getTraitList();
			// traitList.getList().get(0).initializeSpatialDistributionTracker(this);
			// System.out.println("adding invaders with IB traits");
			addInvadersWithTraits(invadersToAdd, overwrite);
		}
		else
		{
			// System.out.println("adding invaders without IB traits");
			addInvadersNoTraits(invadersToAdd, overwrite);
		}
	}

	public void addInvadersFromZeroDensity(int invadersToAdd, boolean overwrite)
	{
		if (SpeciesTraitQuestions.isIndividualBased(this.invader))
		{
			addInvadersFromZeroDensityWithTraits(invadersToAdd, overwrite);
		}
		else
		{
			// System.out.println("boom");
			addInvadersFromZeroDensityNoTraits(invadersToAdd, overwrite);
		}
	}

	public void addInvadersWithTraits(int invadersToAdd, boolean overwrite)
	{
		// System.out.println("ADDING INVADERS WITH TRAITS");
		TraitList traitList = this.invader.getTraitList();
		int addedCounter = 0;
		while (addedCounter < invadersToAdd)
		{
			int k = 0;
			while (true)
			{
				int randLocationIndex = generator.nextInt(this.invaderLocations.size());
				Location loc = this.invaderLocations.get(randLocationIndex);

				int dispersalRadius = this.invader.getDispersalAbility(loc);
				// System.out.println("disp radius is " + dispersalRadius);
				int dispersalLength = dispersalRadius * 2 + 1;
				int randRow = generator.nextInt(dispersalLength) - dispersalRadius;
				int randCol = generator.nextInt(dispersalLength) - dispersalRadius;
				// System.out.println("rand row is " + randRow);
				// System.out.println("rand col is " + randCol);

				int newRow = WrapAround.wrapAround(loc.row() + randRow, gridLength);
				int newCol = WrapAround.wrapAround(loc.col() + randCol, gridLength);
				Location newLoc = new Location(newRow, newCol);
				Location3D newLoc3D = new Location3D(newRow, newCol, this.invaderHomeIndex);

				// if the algorithm fails to place a critter over 100 times, the overwriting is ok.
				if (k > 100)
				{
					// if it's occupied, no big deal...
					if (env.isOccupied(newLoc3D))
					{
						// just make sure that it's at a site that's not paved over
						if (this.invader.canRecruitIfCritterCanOverwriteHeterospecifics(this, newLoc))
						{
							// System.out.println("INSIDE");
							int deadSpeciesVal = this.env.getGridValue(newLoc3D);

							this.env.add(newLoc3D, this.invaderValue);
							traitList.addToAllSpatialDistributionTrackers(newLoc, loc);

							this.invaderLocations.add(newLoc);
							addedCounter++;

							// have to get rid of the traits of the overwritten species
							TraitList deadSpeciesTL = this.speciesList.get(deadSpeciesVal - 1).getTraitList();
							if (deadSpeciesTL != null)
							{
								deadSpeciesTL.removeFromAllSpatialDistributionTrackers(newLoc);
							}
							// System.out.println("DONE WITH INSIDE");

							break;
						}
					}
					else
					{
						if (this.invader.canRecruit(this, newLoc))
						{
							this.env.add(newLoc3D, this.invaderValue);
							traitList.addToAllSpatialDistributionTrackers(newLoc, loc);
							this.invaderLocations.add(newLoc);
							addedCounter++;
							break;
						}
					}
				}
				// if you can overwrite, and the spot is occupied, 
				if (overwrite && this.env.isOccupied(newLoc3D))
				{
					// System.out.println("overwrite and occupied");
					// System.out.println("number of invaders is " + this.invaderLocations.size());
					
					// then make sure there's not a paved over site, add the critter, and delete the traits of the overwritten critter.
					if (this.invader.canRecruitIfCritterCanOverwriteHeterospecifics(this, newLoc))
					{
						// System.out.println("INSIDE");
						int deadSpeciesVal = this.env.getGridValue(newLoc3D);

						this.env.add(newLoc3D, this.invaderValue);
						traitList.addToAllSpatialDistributionTrackers(newLoc, loc);

						this.invaderLocations.add(newLoc);
						addedCounter++;

						TraitList deadSpeciesTL = this.speciesList.get(deadSpeciesVal - 1).getTraitList();
						if (deadSpeciesTL != null)
						{
							deadSpeciesTL.removeFromAllSpatialDistributionTrackers(newLoc);
						}
						// System.out.println("DONE WITH INSIDE");
						break;
					}
				}
				else
				{
					// System.out.println("oher option");
					if (this.invader.canRecruit(this, newLoc))
					{
						this.env.add(newLoc3D, this.invaderValue);
						traitList.addToAllSpatialDistributionTrackers(newLoc, loc);
						this.invaderLocations.add(newLoc);
						addedCounter++;
						break;
					}
				}
				k++;
			}
		}

	}

	public void addInvadersNoTraits(int invadersToAdd, boolean overwrite)
	{
		// System.out.println("ADDING INVADERS WITHOUT TRAITS");
		int addedCounter = 0;
		int dispersalRadius = this.invader.getBaselineDispersalAbility();
		int dispersalLength = dispersalRadius * 2 + 1;
		while (addedCounter < invadersToAdd)
		{
			int k = 0;
			while (true)
			{

				int randLocationIndex = generator.nextInt(this.invaderLocations.size());
				Location loc = this.invaderLocations.get(randLocationIndex);

				int randRow = generator.nextInt(dispersalLength) - dispersalRadius;
				int randCol = generator.nextInt(dispersalLength) - dispersalRadius;
				int newRow = WrapAround.wrapAround(loc.row() + randRow, gridLength);
				int newCol = WrapAround.wrapAround(loc.col() + randCol, gridLength);
				Location newLoc = new Location(newRow, newCol);
				Location3D newLoc3D = new Location3D(newRow, newCol, this.invaderHomeIndex);

				if (k > 100)
				{
					System.out.println("IN K LOOP");
					if (this.invader.canRecruitIfCritterCanOverwriteHeterospecifics(this, newLoc))
					{
						this.env.add(newLoc3D, this.invaderValue);
						this.invaderLocations.add(newLoc);
						addedCounter++;
						// System.out.println("added counter is " + addedCounter + " out of " + invadersToAdd);

						break;
					}
				}
				else if (overwrite && this.env.isOccupied(newLoc3D))
				{

					if (this.invader.canRecruitIfCritterCanOverwriteHeterospecifics(this, newLoc))
					{
						this.env.add(newLoc3D, this.invaderValue);
						this.invaderLocations.add(newLoc);
						addedCounter++;
						// System.out.println("added counter is " + addedCounter + " out of " + invadersToAdd);

						break;
					}
				}
				else
				{

					if (this.invader.canRecruit(this, newLoc))
					{
						this.env.add(newLoc3D, this.invaderValue);
						this.invaderLocations.add(newLoc);
						addedCounter++;
						// System.out.println("added counter is " + addedCounter + " out of " + invadersToAdd);

						break;
					}
				}
				k++;

			}
		}
	}

	public void addInvadersFromZeroDensityNoTraits(int invadersToAdd, boolean overwrite)
	{
		System.out.println("ADDING INVADERS FROM ZERO DENSITY WITHOUT TRAITS");
		int addedCounter = 0;
		while (addedCounter < invadersToAdd)
		{
			int k = 0;
			while (true)
			{

				int newRow = generator.nextInt(this.gridLength);
				int newCol = generator.nextInt(this.gridLength);
				Location newLoc = new Location(newRow, newCol);
				Location3D newLoc3D = new Location3D(newRow, newCol, this.invaderHomeIndex);

				if (k > 100)
				{
					System.out.println("IN K LOOP");
					// System.out.println("overwrite and occupied");
					if (this.invader.canRecruitIfCritterCanOverwriteHeterospecifics(this, newLoc))
					{
						this.env.add(newLoc3D, this.invaderValue);
						this.invaderLocations.add(newLoc);
						addedCounter++;
						break;
					}
				}
				else if (overwrite && this.env.isOccupied(newLoc3D))
				{
					// System.out.println("overwrite and occupied");
					if (this.invader.canRecruitIfCritterCanOverwriteHeterospecifics(this, newLoc))
					{
						this.env.add(newLoc3D, this.invaderValue);
						this.invaderLocations.add(newLoc);
						addedCounter++;
						break;
					}
				}
				else
				{
					// System.out.println("the other case");

					if (this.invader.canRecruit(this, newLoc))
					{
						this.env.add(newLoc3D, this.invaderValue);
						this.invaderLocations.add(newLoc);
						addedCounter++;
						break;
					}
				}
				k++;

			}
		}
	}

	public void addInvadersFromZeroDensityWithTraits(int invadersToAdd, boolean overwrite)
	{
		System.out.println("ADDING INVADERS FROM ZERO DENSITY WITH TRAITS");
		System.out.println(this.useOldInvaderTraits);
		TraitList invaderTraits = this.invader.getTraitList();
		int addedCounter = 0;

		while (addedCounter < invadersToAdd)
		{
			int k = 0;
			while (true)
			{

				int newRow = generator.nextInt(this.gridLength);
				int newCol = generator.nextInt(this.gridLength);
				Location newLoc = new Location(newRow, newCol);
				Location3D newLoc3D = new Location3D(newRow, newCol, this.invaderHomeIndex);

				if (k > 100)
				{
					if (env.isOccupied(newLoc3D))
					{
						int deadSpeciesVal = this.env.getGridValue(newLoc3D);
						this.env.add(newLoc3D, this.invaderValue);
						invaderTraits.addToAllSpatialDistributionTrackersBaselineTraits(newLoc);
						addedCounter++;

						TraitList deadSpeciesTL = this.speciesList.get(deadSpeciesVal - 1).getTraitList();
						if (deadSpeciesTL != null)
						{
							deadSpeciesTL.removeFromAllSpatialDistributionTrackers(newLoc);
						}
						break;
					}
					else
					{
						this.env.add(newLoc3D, this.invaderValue);
						invaderTraits.addToAllSpatialDistributionTrackersBaselineTraits(newLoc);
						addedCounter++;
					}
				}
				if (overwrite && this.useOldInvaderTraits && invaderTraits.hasOldTraitArchive())
				{

					if (this.invader.canRecruitIfCritterCanOverwriteHeterospecifics(this, newLoc))
					{
						int deadSpeciesVal = this.env.getGridValue(newLoc3D);
						this.env.add(newLoc3D, this.invaderValue);
						invaderTraits.addToAllSpatialDistributionTrackersRandomOldTraits(newLoc);
						addedCounter++;

						TraitList deadSpeciesTL = this.speciesList.get(deadSpeciesVal - 1).getTraitList();
						if (deadSpeciesTL != null)
						{
							deadSpeciesTL.removeFromAllSpatialDistributionTrackers(newLoc);
						}
						break;
					}
				}
				else if (overwrite)
				{

					if (this.invader.canRecruitIfCritterCanOverwriteHeterospecifics(this, newLoc))
					{

						this.env.add(newLoc3D, this.invaderValue);
						invaderTraits.addToAllSpatialDistributionTrackersBaselineTraits(newLoc);
						addedCounter++;
						break;
					}
				}
				else if (this.useOldInvaderTraits && invaderTraits.hasOldTraitArchive())
				{

					if (this.invader.canRecruit(this, newLoc))
					{
						this.env.add(newLoc3D, this.invaderValue);
						invaderTraits.addToAllSpatialDistributionTrackersRandomOldTraits(newLoc);
						addedCounter++;
						break;
					}
				}
				else
				{

					if (this.invader.canRecruit(this, newLoc))
					{
						this.env.add(newLoc3D, this.invaderValue);
						invaderTraits.addToAllSpatialDistributionTrackersBaselineTraits(newLoc);
						addedCounter++;
						break;
					}
				}
				k++;
			}
		}
	}

	public void removeInvadersWithTraits(int numberToRemove)
	{
		TraitList traitList = this.invader.getTraitList();
		int numberRemoved = 0;
		while (numberRemoved < numberToRemove)
		{
			int randLocationIndex = generator.nextInt(this.invaderLocations.size());
			Location loc = this.invaderLocations.get(randLocationIndex);
			this.env.remove(loc.row(), loc.col(), this.invaderHomeIndex);
			traitList.removeFromAllSpatialDistributionTrackers(loc);
			this.invaderLocations.remove(randLocationIndex);
			numberRemoved++;

		}

	}

	public void removeInvadersNoTraits(int numberToRemove)
	{
		int numberRemoved = 0;
		while (numberRemoved < numberToRemove)
		{
			int randLocationIndex = generator.nextInt(this.invaderLocations.size());
			Location loc = this.invaderLocations.get(randLocationIndex);
			this.env.remove(loc.row(), loc.col(), this.invaderHomeIndex);
			this.invaderLocations.remove(randLocationIndex);
			numberRemoved++;

		}
	}

	public void removeInvaders(int numberToRemove)
	{
		if (SpeciesTraitQuestions.isIndividualBased(this.invader))
		{
			removeInvadersWithTraits(numberToRemove);
		}
		else
		{
			removeInvadersNoTraits(numberToRemove);
		}
	}*/

	/*
	 * If there are no invaders, add some to each of the invader's good patches. If it's too low, add new invaders the dispersal distance around a randomly selected invader, overwriting residents as neccessary. If it's too high, delete randomly selected invaders
	 */
	public void regulateInvaders()
	{
		//getInvaderLocations();
		ModifyAbundance ma = new ModifyAbundance(this, this.invaderValue);
		ma.findCurSpeciesLocations();
		
		int invaderAbund = ma.getCurSpeciesLocations().size();
		// System.out.println("invader abund is " + invaderAbund);
		if (invaderAbund == 0)
		{
			System.out.println("THERE ARE NO INVADERS, ADDING SOME");
			//addInvadersFromZeroDensity(this.equilibriumAbund, this.overwrite);
			AddCritters ac = new AddCritters(this, this.invaderValue, this.overwrite);
			ac.addCrittersRandomly(this.equilibriumAbund);
			// this.timeAfterAddStraightToPatch = 0;
			// invader.addXIndividualsToEnv(numberToAdd, env);
			this.timeSinceInvaderRegulation = 0;
			this.timeSinceInvaderRegulationFromZeroDensity = 0;
		}
		else if (invaderAbund < this.tooLowAbund)
		{
			System.out.println("too low... gonna add some invaders");
			int numberToAdd = this.equilibriumAbund - invaderAbund;

			AddCritters ac = new AddCritters(this, this.invaderValue, this.overwrite, ma.getCurSpeciesLocations());
			ac.addCrittersNearby(numberToAdd);
			
			//addInvaders(numberToAdd, this.overwrite);
			this.timeSinceInvaderRegulation = 0;
			// System.out.println("done with adding");

		}
		else if (invaderAbund > this.tooHighAbund)
		{
			int numberToRemove = invaderAbund - this.equilibriumAbund;
			 System.out.println("invader density too high. Removing " + numberToRemove + " individuals.");
			//removeInvaders(numberToRemove);
			RemoveCritters ac = new RemoveCritters(this, this.invaderValue, ma.getCurSpeciesLocations());
			ac.removeCritters(numberToRemove);
			
			this.timeSinceInvaderRegulation = 0;

		}
	}

}
