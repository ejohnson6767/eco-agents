import java.io.Serializable;

public class TerminateIfAnyoneDies implements ITerminateCondition, Serializable
{
	private Community com;
	public TerminateIfAnyoneDies(Community com)
	{
		this.com = com;
	}
	
	public boolean shouldTerminate()
	{
		boolean shouldTerminate = false;
		int[] abunds = this.com.getAbundances();
		for (int i = 0; i < abunds.length; i++)
		{
			if(abunds[i] == 0)
			{
				shouldTerminate = true;
				break;
			}
		}
		return shouldTerminate;
	}
	
}
