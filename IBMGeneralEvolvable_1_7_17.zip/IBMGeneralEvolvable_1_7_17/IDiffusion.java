import java.io.Serializable;

public interface IDiffusion extends Serializable
{

	boolean isIndividualBased();

	int getDiffusion(int row, int col);

	double[][] getSpatialDistributionTracker();

	void setSpeciesOwner(ISpecies species);

	int getDiffusion();

	void setupAfterCommunityIsCreated(Community com);

}
