// this class allows the critters to navigate the environmental grid as if it were a donut (like pacman)
// since the two methods have the exact same behavior is a square grid envrironment, these two methods could and should (eventually) be refactored into one method.
////// However, this would take time and -  in the meantime - the two methods add clarifaction conceptual clarification when used in conjuction with actual grid locations
// while loops in the methods allow for dispersal which is greater than the length of the grid
public class WrapAround
{

	private static boolean periodic = true;
	private static boolean reflect = false;
	private static boolean fallOff = false;
	
	/*
	 * public static int wrapAround(int rowOrCol, int gridLength) { if (rowOrCol > gridLength - 1 || rowOrCol < 0) {
	 * 
	 * return (rowOrCol + gridLength)% gridLength; } return rowOrCol; }
	 */

	// finds the row (on the other side... if there is one)

	public static int wrapAround(int rowOrCol, int gridLength)
	{
		if(periodic)
		{
			return wrapAroundPeriodic(rowOrCol, gridLength);
		} else if(reflect)
		{
			return wrapAroundReflect(rowOrCol, gridLength);
		} else
		{
			return wrapAroundFallOff(rowOrCol, gridLength);
		}
	}
	
	public static void periodic()
	{
		periodic = true;
		reflect = false;
		fallOff = false;
	}
	
	public static void reflect()
	{
		periodic = false;
		reflect = true;
		fallOff = false;
	}
	
	public static void fallOff()
	{
		periodic = false;
		reflect = false;
		fallOff = true;
	}
	
	public static int wrapAroundPeriodic(int rowOrCol, int gridLength)
	{
		if (rowOrCol > gridLength - 1)
		{
			while (rowOrCol > gridLength - 1)
			{
				rowOrCol = rowOrCol - gridLength;
			}
		}
		else if (rowOrCol < 0)
		{
			while (rowOrCol < 0)
			{
				rowOrCol = gridLength + rowOrCol;
			}
		}
		return rowOrCol;
	}

	public static int wrapAroundReflect(int rowOrCol, int gridLength)
	{
		// System.out.println("new thang");
		if (rowOrCol > gridLength - 1)
		{
			while (rowOrCol > gridLength - 1)
			{
				// System.out.println("loop too big");
				rowOrCol = gridLength - (1 + rowOrCol - gridLength);
				// System.out.println(rowOrCol);
			}
		}
		else if (rowOrCol < 0)
		{
			while (rowOrCol < 0)
			{
				// System.out.println("loop too small");
				rowOrCol = (-1 * rowOrCol) - 1;
			}
		}
		return rowOrCol;
	}

	public static int wrapAroundFallOff(int rowOrCol, int gridLength)
	{
		// System.out.println("new thang");
		if (rowOrCol > gridLength - 1)
		{
			rowOrCol = -1;
		}
		else if (rowOrCol < 0)
		{
			rowOrCol = -1;
		}
		return rowOrCol;
	}

	public static boolean isOffGrid(int rowOrCol, int gridLength)
	{
		boolean toReturn = false;
		if (rowOrCol > gridLength - 1)
		{
			toReturn = true;
		}
		else if (rowOrCol < 0)
		{
			toReturn = true;

		}
		return toReturn;
	}

	// finds the row (on the other side... if there is one)
	public static int wrapAroundForPatches(int rowOrCol, int gridLength)
	{
		if (rowOrCol > gridLength - 1)
		{
			while (rowOrCol > gridLength - 1)
			{
				rowOrCol = rowOrCol - gridLength;
			}
		}
		else if (rowOrCol < 0)
		{
			while (rowOrCol < 0)
			{
				rowOrCol = gridLength + rowOrCol;
			}
		}
		return rowOrCol;
	}

	// unused but potentially useful methods
	/*
	 * public static boolean doesRowWrapAround(int Row, int gridLength) { if (Row > gridLength - 1) { return true; } else if (Row < 0) { return true; } return false;
	 * 
	 * }
	 * 
	 * 
	 * public static boolean doesColWrapAround(int Col, int gridLength) { if (Col > gridLength - 1) { return true; } else if (Col < 0) { return true; } return false;
	 * 
	 * }
	 * 
	 * public static boolean doesRowWrapNorth(int Row, int gridLength) { if (Row < 0) { return true; } return false; }
	 * 
	 * public static boolean doesColWrapWest(int Col, int gridLength) { if (Col < 0) { return true; } return false; }
	 * 
	 * public static boolean doesRowWrapSouth(int Row, int gridLength) { if (Row > gridLength - 1) { return true; } return false; }
	 * 
	 * public static boolean doesColWrapEast(int Col, int gridLength) { if (Col > gridLength - 1) { return true; } return false; }
	 */

}
