import java.io.Serializable;
import java.util.ArrayList;

public class DeathAdditive implements IDeathProcess, Serializable
{
	private Community com;
	private ISpecies speciesOwner;
	private double deathRate;
	private int speciesValue;

	public DeathAdditive(double deathRate)
	{
		//this.com = com;
		this.deathRate = deathRate;
	}
	
	public double getDeathRate(Location loc)
	{
		
		double realizedDeathRate = this.deathRate;
		ArrayList<IEffect> lvEffects= this.speciesOwner.getAffectingLVEffects();
		
		for(IEffect lv : lvEffects)
		{
		realizedDeathRate +=  lv.getEffect(loc);
		}

		return realizedDeathRate;
	}
	
	
	
	public void scaleByDt(double dt)
	{
		this.deathRate *= dt;
		
	}
	
	public void setSpeciesOwner(ISpecies species)
	{
		this.speciesOwner = species;
		
	}
	
	public void setupAfterCommunityIsCreated(Community com)
	{
		this.com = com;
		this.speciesValue = this.speciesOwner.getGridProxy();
	}
}
