import java.io.Serializable;
import java.util.ArrayList;

public class LocalLVAllSpecies implements Serializable
{
	private Community com;
	private boolean allSameDiffusion;
	private int allSameDiffusionRadius;
	private Environment env;
	private int gridLength;
	private boolean dontDoAnything;

	public LocalLVAllSpecies(Community com)
	{
		this.com = com;
		this.env = this.com.getEnvironment();
		this.gridLength = this.env.getGridLength();
		this.allSameDiffusion = false;
	}

	public void setBooleans()
	{
		//// System.out.println("SETTING BOOLEANS");
		int participatingSpecies = 0;
		// reset the "all have the same diffusion" boolean at the highest level of organization - all species
		// if this stays true, then the program will use the fillLV method in this class
		this.dontDoAnything = false;
		markDiffusionAllSameBetweenSpecies();
		ArrayList<ISpecies> speciesList = this.com.getSpeciesList();
		boolean noDiffusionYet = true;
		// boolean markFalseForFirstSpecies = true;
		int firstDiffusionSpeciesIndex = 0;
		for (int k = 0; k < speciesList.size(); k++)
		{
			ISpecies curSpecies = speciesList.get(k);

			// get all of the LV effects for a single species
			LocalLV curLocalLV = curSpecies.getLocalLV();
			//// System.out.println("species " + (k + 1) + "....");
			if (curLocalLV != null)
			{
				//// System.out.println("has a lvEffects... ");
				// if the species doesn't effect other species, don't bother
				curLocalLV.markDiffusionAllSameBetweenHeteros();

				// this species has lv effects, so update the counter
				participatingSpecies++;
				// reset the "all have the same diffusion" boolean at the second highest level of organization - one species (meaning all of one species effects on other species)
				// get the list of all of the species's effects
				LVEffectsOnOneHetero[] lVEffectsAllHeteros = curLocalLV.getLVEffectsOnAllHeteros();

				int effectsOnOtherSpeciesCounter = 0;
				for (int j = 0; j < lVEffectsAllHeteros.length; j++)
				{
					// get all of the effects a species has on ONE of it's heterospecifics
					LVEffectsOnOneHetero lVEffectsOnOneHetero = lVEffectsAllHeteros[j];
					// reset the "all have the same diffusion" boolean at the slowest level of organization - all of one species effects on one other species
					if (lVEffectsOnOneHetero != null)
					{
						effectsOnOtherSpeciesCounter++;
						//// System.out.println(" and non negligible effects on species " + (j + 1));
						lVEffectsOnOneHetero.markDiffusionAllSameWithinHetero();
						// if the species isn't around, don't bother
						if (curSpecies.isOnGrid())
						{
							IEffect[] lVEffects = lVEffectsOnOneHetero.getLVEffects();
							//// System.out.println("there are " + lVEffects.length + " effects");
							if (noDiffusionYet)
							{
								this.allSameDiffusionRadius = lVEffects[0].getDiffusion().getDiffusion();
								noDiffusionYet = false;
								firstDiffusionSpeciesIndex = k;
							}
							curLocalLV.setSameDiffusionRadius(this.allSameDiffusionRadius);
							for (int i = 0; i < lVEffects.length; i++)
							{
								//// System.out.println("with " + (i + 1) + " effect value of " + lVEffects[i].getEffectValue().getEffectValue());
								IEffect lvEffect = lVEffects[i];
								if (lvEffect.isIndividualBased())
								{
									// markFalseForFirstSpecies = false;
									//// System.out.println("INDIVIDUAL BASED. MARK DIFFUSION NOT SAME");
									lVEffectsOnOneHetero.markDiffusionNotAllSameWithinHetero();
									curLocalLV.markDiffusionNotAllSameBetweenHeteros();
									markDiffusionNotAllSameBetweenSpecies();

								}
								else if (lvEffect.getDiffusion().getDiffusion() != this.allSameDiffusionRadius)
								{
									//// System.out.println("DIFFERENT DIFFUSIONS. MARK DIFFUSION NOT SAME");
									lVEffectsOnOneHetero.markDiffusionNotAllSameWithinHetero();
									curLocalLV.markDiffusionNotAllSameBetweenHeteros();
									markDiffusionNotAllSameBetweenSpecies();
								}
							}
						}
					}
					else
					{
						// System.out.println(" has no effects on species " + (j + 1));
					}
				}
				// System.out.println("species " + (k+1) + " effects " + effectsOnOtherSpeciesCounter + " other species");
				if (effectsOnOtherSpeciesCounter == 0)
				{

					curLocalLV.markDiffusionNotAllSameBetweenHeteros();
				}
			}
			else
			{
				//// System.out.println("has no lv effects");
			}
		}

		// if there are no species with any lv effects, don't do anything
		if (participatingSpecies == 0)
		{
			//// System.out.println("dont do anything, because there are no species with lv effects");
			this.dontDoAnything = true;
		}
		else
		{
			// if there's only one species with lv effects, just use the grid filling method for that species
			if (participatingSpecies == 1)
			{
				//// System.out.println("diffusion not all same between species... but only bc there is one participating species");
				markDiffusionNotAllSameBetweenSpecies();
			}

			if (!this.allSameDiffusion)
			{
				ISpecies curSpecies = speciesList.get(firstDiffusionSpeciesIndex);
				LocalLV curLocalLV = curSpecies.getLocalLV();
				LVEffectsOnOneHetero[] lVEffectsAllHeteros = curLocalLV.getLVEffectsOnAllHeteros();
				for (int j = 0; j < lVEffectsAllHeteros.length; j++)
				{

					// get all of the effects a species has on ONE of it's heterospecifics
					LVEffectsOnOneHetero lVEffectsOnOneHetero = lVEffectsAllHeteros[j];
					if (lVEffectsOnOneHetero != null)
					{
						lVEffectsOnOneHetero.markDiffusionNotAllSameWithinHetero();
						curLocalLV.markDiffusionNotAllSameBetweenHeteros();
						markDiffusionNotAllSameBetweenSpecies();
					}

				}
			}

		}
		//// System.out.println();
	}

	private void markDiffusionAllSameBetweenSpecies()
	{
		this.allSameDiffusion = true;

	}

	private void markDiffusionNotAllSameBetweenSpecies()
	{
		this.allSameDiffusion = false;

	}

	public void doLocalLVStuff()
	{
		//// System.out.println("DOING LV STUFF");
		if (!this.dontDoAnything)
		{
			if (this.allSameDiffusion)
			{
				//// System.out.println("FILL LV - ALL SAME DIFFUSION");
				fillLVAllSameDiffusion();
			}
			else
			{
				ArrayList<ISpecies> speciesList = this.com.getSpeciesList();
				for (int k = 0; k < speciesList.size(); k++)
				{
					//// System.out.println("species " + (k + 1) + "....");

					ISpecies curSpecies = speciesList.get(k);
					LocalLV curLocalLV = curSpecies.getLocalLV();
					if (curLocalLV != null)
					{
						//// System.out.println("has an lv effect...");
						if (curLocalLV.diffusionAllSameBetweenHeteros())
						{
							//// System.out.println("FILL LV - ALL SAME WITH LOCAL LV");
							curLocalLV.fillLVSameDiffusionForAllHeteros();
						}
						else
						{
							LVEffectsOnOneHetero[] lVEffectsAllHeteros = curLocalLV.getLVEffectsOnAllHeteros();
							for (int j = 0; j < lVEffectsAllHeteros.length; j++)
							{
								LVEffectsOnOneHetero lVEffectsOnOneHetero = lVEffectsAllHeteros[j];
								if (lVEffectsOnOneHetero != null)
								{
									//// System.out.println("has effects on species " + (j + 1));
									if (lVEffectsOnOneHetero.diffusionAllSameWithinHetero())
									{
										//// System.out.println("FILL LV - ALL SAME BETWEEN HETEROS.");

										lVEffectsOnOneHetero.fillLVSameDiffusionForOneHetero();
									}
									else
									{
										IEffect[] lVEffects = lVEffectsOnOneHetero.getLVEffects();
										for (int i = 0; i < lVEffects.length; i++)
										{
											IEffect lVEffect = lVEffects[i];

											//// System.out.println("lv effect of species is not null");
											if (lVEffect.isIndividualBased())
											{
												//// System.out.println("FILL LV - INDIVIDUAL BASED LV.");
												lVEffects[i].fillLV();
											}
											else
											{
												if (lVEffect.getDiffusion().getDiffusion() != 0)
												{
													if (lVEffect.getEffectValue().getEffectValue() != 0)
													{
														//// System.out.println("FILL LV - NON IB LV.");
														lVEffects[i].fillLV();
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		//// System.out.println();
		//// System.out.println();
		//// System.out.println();
	}

	private void fillLVAllSameDiffusion()
	{
		//System.out.println("fill lv all same diffusion no IB");

		// ////System.out.println("the species value is " + this.speciesValue);

		/// ////System.out.println("disp is " + dispersalRadius);

		// ////System.out.println("possible neighbors " + possibleNeighbors);

		// int diffusion = this.com.getSpeciesList().get(0).getLocalLV().getLVEffectsOnAllHeteros()[0].getLVEffects()[0].getDiffusionRadius();

		int numberOfSpecies = this.com.getNumberOfSpecies();

		int[][][] totalGrid = new int[numberOfSpecies][this.gridLength][this.gridLength];

		int[][][] posPropagule = new int[numberOfSpecies][gridLength][3];

		// this second main loop determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius

		// this algorithm scans right across the grid, goes down one line, scans again, and so on (just like reading). It's time complexity is O(n) (where n is the number of microsites) compared to O(n^2) of a trivial moving window algorithm.
		// It works by summing all of the
		// cumulative birth rates in the topmost row, the bottommost row, and everything in between. This is where the last dimension on pos array comes in:
		// 0 is TOP, 1 is MID, and 2 is BOT. when you to the next gid locationCommunity com,, your cumulative growth rate is TOPnew + MIDnew + BOTnew. MIDnew is simply MIDnorth + BOTnorth - TOPnew.
		// (where north indicates the position above you). TOPnew can be written TOPwest - TOPwest.leftMost + TOPnew.rightmost. BOTnew can be written BOTwest - BOTwest.leftMost + BOTnew.rightmost.
		// the TOP, MID, and BOT are all recorded.
		int row = 0;
		int col = 0;

		// pos = new double[numberOfSpecies][gridLength][3];
		int row2 = row - this.allSameDiffusionRadius;
		for (int col2 = col - this.allSameDiffusionRadius; col2 <= col + this.allSameDiffusionRadius; col2++)
		{
			int realRow = WrapAround.wrapAround(row2, gridLength);
			int realCol = WrapAround.wrapAround(col2, gridLength);
			int gridValue = env.getGridValue(realRow, realCol, 0);
			if (gridValue != 0)
			{

				posPropagule[gridValue - 1][col][0]++;

			}
		}
		// ////System.out.println("col == " + col + " first is " + first[1]);

		for (int col2 = col - this.allSameDiffusionRadius; col2 <= col + this.allSameDiffusionRadius; col2++)
		{
			for (row2 = row - this.allSameDiffusionRadius + 1; row2 <= row + this.allSameDiffusionRadius - 1; row2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, 0);
				if (gridValue != 0)
				{

					posPropagule[gridValue - 1][col][1]++;

				}
			}
		}
		// ////System.out.println("col == 0 middle is " + middle[1]);

		row2 = row + this.allSameDiffusionRadius;
		for (int col2 = col - this.allSameDiffusionRadius; col2 <= col + this.allSameDiffusionRadius; col2++)
		{
			int realRow = WrapAround.wrapAround(row2, gridLength);
			int realCol = WrapAround.wrapAround(col2, gridLength);
			int gridValue = env.getGridValue(realRow, realCol, 0);
			if (gridValue != 0)
			{

				posPropagule[gridValue - 1][col][2]++;

			}
		}

		// ACTUALLY ADD TO PROPAGULE RAIN GRID
		for (int i = 0; i < numberOfSpecies; i++)
		{
			totalGrid[i][row][col] = (posPropagule[i][col][0] + posPropagule[i][col][1] + posPropagule[i][col][2]);
		}

		int gridValue = env.getGridValue(row, col, 0);
		if (gridValue != 0)
		{
			totalGrid[gridValue - 1][row][col]--;
		}

		for (col = 1; col < gridLength; col++)
		{

			// generate new top
			int NWRow = WrapAround.wrapAround(row - this.allSameDiffusionRadius, gridLength);
			int NWCol = WrapAround.wrapAround(col - 1 - this.allSameDiffusionRadius, gridLength);
			int NERow = WrapAround.wrapAround(row - this.allSameDiffusionRadius, gridLength);
			int NECol = WrapAround.wrapAround(col + this.allSameDiffusionRadius, gridLength);

			int SWRow = WrapAround.wrapAround(row + this.allSameDiffusionRadius, gridLength);
			int SWCol = WrapAround.wrapAround(col - 1 - this.allSameDiffusionRadius, gridLength);
			int SERow = WrapAround.wrapAround(row + this.allSameDiffusionRadius, gridLength);
			int SECol = WrapAround.wrapAround(col + this.allSameDiffusionRadius, gridLength);

			for (int i = 0; i < numberOfSpecies; i++)
			{
				posPropagule[i][col][0] = posPropagule[i][col - 1][0];
			}
			int gridValueNW = env.getGridValue(NWRow, NWCol, 0);
			if (gridValueNW != 0)
			{
				posPropagule[gridValueNW - 1][col][0]--;
			}

			int gridValueNE = env.getGridValue(NERow, NECol, 0);
			if (gridValueNE != 0)
			{
				posPropagule[gridValueNE - 1][col][0]++;
			}

			int[] leftSideOfOldMid = new int[numberOfSpecies];
			int col2 = col - this.allSameDiffusionRadius - 1;
			for (row2 = row - this.allSameDiffusionRadius + 1; row2 <= row + this.allSameDiffusionRadius - 1; row2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				gridValue = env.getGridValue(realRow, realCol, 0);
				if (gridValue != 0)
				{

					leftSideOfOldMid[gridValue - 1]++;

				}
			}

			int[] rightSideOfNewMid = new int[numberOfSpecies];
			col2 = col + this.allSameDiffusionRadius;
			for (row2 = row - this.allSameDiffusionRadius + 1; row2 <= row + this.allSameDiffusionRadius - 1; row2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				gridValue = env.getGridValue(realRow, realCol, 0);
				if (gridValue != 0)
				{

					rightSideOfNewMid[gridValue - 1]++;

				}
			}

			for (int i = 0; i < numberOfSpecies; i++)
			{
				posPropagule[i][col][1] = posPropagule[i][col - 1][1] - leftSideOfOldMid[i] + rightSideOfNewMid[i];
			}

			for (int i = 0; i < numberOfSpecies; i++)
			{
				posPropagule[i][col][2] = posPropagule[i][col - 1][2];
			}
			int gridValueSW = env.getGridValue(SWRow, SWCol, 0);
			if (gridValueSW != 0)
			{
				posPropagule[gridValueSW - 1][col][2]--;
			}

			int gridValueSE = env.getGridValue(SERow, SECol, 0);
			if (gridValueSE != 0)
			{
				posPropagule[gridValueSE - 1][col][2]++;
			}

			// ACTUALLY ADD TO PROPAGULE RAIN GRID
			for (int i = 0; i < numberOfSpecies; i++)
			{
				totalGrid[i][row][col] = (posPropagule[i][col][0] + posPropagule[i][col][1] + posPropagule[i][col][2]);
			}

			gridValue = env.getGridValue(row, col, 0);
			if (gridValue != 0)
			{
				totalGrid[gridValue - 1][row][col]--;
			}

		}

		for (row = 1; row < gridLength; row++)

		{
			col = 0;

			for (int i = 0; i < numberOfSpecies; i++)
			{
				posPropagule[i][col][0] = 0;
			}

			row2 = row - this.allSameDiffusionRadius;
			for (int col2 = col - this.allSameDiffusionRadius; col2 <= col + this.allSameDiffusionRadius; col2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				gridValue = env.getGridValue(realRow, realCol, 0);
				if (gridValue != 0)
				{

					posPropagule[gridValue - 1][col][0]++;

				}
			}

			for (int i = 0; i < numberOfSpecies; i++)
			{
				posPropagule[i][col][1] += posPropagule[i][col][2] - posPropagule[i][col][0];
			}

			for (int i = 0; i < numberOfSpecies; i++)
			{
				posPropagule[i][col][2] = 0;
			}

			row2 = row + this.allSameDiffusionRadius;
			for (int col2 = col - this.allSameDiffusionRadius; col2 <= col + this.allSameDiffusionRadius; col2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				gridValue = env.getGridValue(realRow, realCol, 0);
				if (gridValue != 0)
				{

					posPropagule[gridValue - 1][col][2]++;

				}
			}

			// ACTUALLY ADD TO PROPAGULE RAIN GRID
			for (int i = 0; i < numberOfSpecies; i++)
			{
				totalGrid[i][row][col] = (posPropagule[i][col][0] + posPropagule[i][col][1] + posPropagule[i][col][2]);
			}

			gridValue = env.getGridValue(row, col, 0);
			if (gridValue != 0)
			{
				totalGrid[gridValue - 1][row][col]--;
			}

			for (col = 1; col < gridLength; col++)
			{

				// generate new top
				int NWRow = WrapAround.wrapAround(row - this.allSameDiffusionRadius, gridLength);
				int NWCol = WrapAround.wrapAround(col - 1 - this.allSameDiffusionRadius, gridLength);
				int NERow = WrapAround.wrapAround(row - this.allSameDiffusionRadius, gridLength);
				int NECol = WrapAround.wrapAround(col + this.allSameDiffusionRadius, gridLength);

				int SWRow = WrapAround.wrapAround(row + this.allSameDiffusionRadius, gridLength);
				int SWCol = WrapAround.wrapAround(col - 1 - this.allSameDiffusionRadius, gridLength);
				int SERow = WrapAround.wrapAround(row + this.allSameDiffusionRadius, gridLength);
				int SECol = WrapAround.wrapAround(col + this.allSameDiffusionRadius, gridLength);

				for (int i = 0; i < numberOfSpecies; i++)
				{
					posPropagule[i][col][0] = posPropagule[i][col - 1][0];
				}
				int gridValueNW = env.getGridValue(NWRow, NWCol, 0);
				if (gridValueNW != 0)
				{
					posPropagule[gridValueNW - 1][col][0]--;
				}

				int gridValueNE = env.getGridValue(NERow, NECol, 0);
				if (gridValueNE != 0)
				{
					posPropagule[gridValueNE - 1][col][0]++;
				}

				for (int i = 0; i < numberOfSpecies; i++)
				{
					posPropagule[i][col][1] += posPropagule[i][col][2] - posPropagule[i][col][0];
				}

				for (int i = 0; i < numberOfSpecies; i++)
				{
					posPropagule[i][col][2] = posPropagule[i][col - 1][2];
				}
				int gridValueSW = env.getGridValue(SWRow, SWCol, 0);
				if (gridValueSW != 0)
				{
					posPropagule[gridValueSW - 1][col][2]--;
				}

				int gridValueSE = env.getGridValue(SERow, SECol, 0);
				if (gridValueSE != 0)
				{
					posPropagule[gridValueSE - 1][col][2]++;
				}

				// ACTUALLY ADD TO PROPAGULE RAIN GRID
				for (int i = 0; i < numberOfSpecies; i++)
				{
					totalGrid[i][row][col] = (posPropagule[i][col][0] + posPropagule[i][col][1] + posPropagule[i][col][2]);
				}

				gridValue = env.getGridValue(row, col, 0);
				if (gridValue != 0)
				{
					totalGrid[gridValue - 1][row][col]--;
				}

			}
		}
		
		
		////if(com.getStepCallCounter() > 100)

		ArrayList<ISpecies> speciesList = this.com.getSpeciesList();
		for (int k = 0; k < speciesList.size(); k++)
		{
			ISpecies curSpecies = speciesList.get(k);
			LocalLV localLV = curSpecies.getLocalLV();
			if (localLV != null)
			{
				LVEffectsOnOneHetero[] lVEffectsOnAllHeteros = localLV.getLVEffectsOnAllHeteros();
				for (int i = 0; i < lVEffectsOnAllHeteros.length; i++)
				{
					LVEffectsOnOneHetero lVEffectsOnOneHetero = lVEffectsOnAllHeteros[i];
					if (lVEffectsOnOneHetero != null)
					{
						IEffect[] lVEffects = lVEffectsOnOneHetero.getLVEffects();

						for (int j = 0; j < lVEffects.length; j++)
						{
							// if (lVEffects[j].getDiffusionRadius() != 0)
							// {
							lVEffects[j].setLVEffectGrid(totalGrid[k]);
							// }
						}
					}
				}
			}

		}
	}

	public void resetAffectingLVEffectsAllSpecies()
	{
		ArrayList<ISpecies> speciesList = this.com.getSpeciesList();
		for (int k = 0; k < speciesList.size(); k++)
		{
			ISpecies curSpecies = speciesList.get(k);
			curSpecies.resetAffectingLVEffects();
			curSpecies.resetAffectingLVEffectsByIndicator();
		}

		for (int k = 0; k < speciesList.size(); k++)
		{
			ISpecies curSpecies = speciesList.get(k);
			LocalLV localLV = curSpecies.getLocalLV();
			if (localLV != null)
			{
				localLV.giveSpeciesTheirEffects();
			}
		}
	}
}
