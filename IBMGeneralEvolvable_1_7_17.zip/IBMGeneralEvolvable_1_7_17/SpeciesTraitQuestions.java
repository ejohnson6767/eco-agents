import java.util.ArrayList;

public class SpeciesTraitQuestions
{

	
	public static int HowManyIndividualBasedTraits(ISpecies curSpecies)
	{
		int counter = 0;
		ArrayList<Evolvable> traits = curSpecies.getEvolvableTraits();
		for (int i = 0; i < traits.size(); i++)
		{
			if (traits.get(i).isIndividualBased())
			{
				counter++;
			}
		}
		return counter;
	}

	public static boolean isIndividualBased(ISpecies species)
	{
		boolean toReturn = false;
		ArrayList<Evolvable> traits = species.getEvolvableTraits();
		for (int i = 0; i < traits.size(); i++)
		{

			if (traits.get(i).isIndividualBased())
			{
				toReturn = true;
				break;
			}
		}

		return toReturn;
	}

	
	public static boolean hasTraits(ISpecies species)
	{
		boolean toReturn = true;
		TraitList tl = null;
		if (tl == null)
		{
			toReturn = false;
		}
		return toReturn;
	}

	

}
