import java.io.Serializable;
import java.util.ArrayList;

public class ModifyAbundance implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected Environment env;
	protected ArrayList<Location> curSpeciesLocations;
	protected int curSpeciesHomeIndex;
	protected int curSpeciesValue;
	protected int gridLength;
	protected Community com;

	

	public ModifyAbundance(Community com, int speciesValue)
	{
		this.com = com;
		this.env = this.com.getEnvironment();
		this.gridLength = this.env.getGridLength();
		this.curSpeciesValue = speciesValue;
		this.curSpeciesHomeIndex = com.getSpeciesList().get(speciesValue - 1).getHomeGridIndex();
		this.curSpeciesLocations = null;
	}
	
	
	public void findCurSpeciesLocations()
	{
		this.curSpeciesLocations = new ArrayList<Location>();

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col, this.curSpeciesHomeIndex) == this.curSpeciesValue)
				{
					this.curSpeciesLocations.add(new Location(row, col));
				}
			}
		}
	}
	public ArrayList<Location> getCurSpeciesLocations()
	{
		return this.curSpeciesLocations;
	}
}
