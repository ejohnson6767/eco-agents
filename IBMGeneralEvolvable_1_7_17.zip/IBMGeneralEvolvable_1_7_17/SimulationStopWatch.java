import java.util.ArrayList;
import java.util.Arrays;

public class SimulationStopWatch
{
private static double dt = 1;
	private static boolean neverInoculate = false;
	private static boolean useStep2 = true;

	private static int gridLength = 100;

	private static boolean implementSharedDeathRate = true;
	private static double death = 0.16;

	private static double propToStart = 0.40;
	private static boolean useQuantCheat = true;
	private static double quantCheatInitProp = 0.05;
	private static double cmaxQuantCheat = 0.75;
	private static double cmaxSynmakesAA1 = 0.60;
	private static double cmaxSynmakesAA2 = 0.60;
	private static int stepsUntilInoculateCheater = 200;

	// how far can species dispersal in any direction
	private static int dispersalRadius = 3;
	private static int interactionRadius = 10;

	// how many amino acids does each critter produce?
	private static double KAAProduced = 8;

	private static ArrayList<Species> speciesList = new ArrayList<Species>();
	static
	{
		int quantCheatInitAbund = (int) Math.round(quantCheatInitProp * Math.pow(gridLength, 2));
		int synInitAbund = (int) Math.round((propToStart / (double) 2) * Math.pow(gridLength, 2));

		speciesList.add(new Species(0, quantCheatInitAbund, cmaxQuantCheat, death, 0, false, false, false, false, 1, 1, 0));

		speciesList.add(new Species(1, synInitAbund, cmaxSynmakesAA1, death, 0, false, true, false, false, 0, 1, 0));

		speciesList.add(new Species(2, synInitAbund, cmaxSynmakesAA2, death, 0, false, false, true, false, 1, 0, 0));

	}
	private static int numberOfSpecies = speciesList.size();

	// how many time steps in the simulation?
	private static int numSteps = 1000;

	public static void main(String[] args)
	{
		for (int r = 0; r < 20; r++)
		{
		
			Community com = new Community(gridLength, dt, dispersalRadius, interactionRadius, KAAProduced, useStep2, speciesList);
			
			long start = System.nanoTime();
			com.setSeed(20);
			for (int i = 0; i < numSteps; i++)
			{
				com.step();
			}
			long end = System.nanoTime();
			long nanoTime = end - start;
			
			 //System.out.println(nanoTime + " nanoseconds"); System.out.println(nanoTime/(double)1000000 + " milliseconds");
			 
			System.out.println("step2 " + nanoTime / (double) 1000000000 + " seconds");

			com = new Community(gridLength, dt, dispersalRadius, interactionRadius, KAAProduced, useStep2, speciesList);
			start = System.nanoTime();
			com.setSeed(20);
			for (int i = 0; i < numSteps; i++)
			{
				com.step2AAMovingWindowCGRMovingWindow();
			}
			end = System.nanoTime();
			nanoTime = end - start;
			
			/*System.out.println(nanoTime + " nanoseconds"); 
			System.out.println(nanoTime/(double)1000000 + " milliseconds");*/
			 
			System.out.println("step2g " + nanoTime / (double) 1000000000 + " seconds");
			
		}
	}
			
			
		/*	long start = System.nanoTime();
			double[][][] ar = new double[100][100][3];
			for (int i = 0; i < numSteps; i++)
			{
				ar = new double[100][100][3];
			}
			long end = System.nanoTime();
			long nanoTime = end - start;
			
			 * System.out.println(nanoTime + " nanoseconds"); System.out.println(nanoTime/(double)1000000 + " milliseconds");
			 
			System.out.println("instantiate " + nanoTime / (double) 1000000000 + " seconds");

			
			start = System.nanoTime();
			//com.setSeed(20);
			double[][][] ar1 = new double[100][100][3];
			for (int i = 0; i < numSteps; i++)
			{
				for(int r = 0; r < 100; r++)
				{
					for(int c = 0; c < 100; c++)
					{
						for(int s = 0; s < 3; s++)
						{
							ar1[r][c][s] = 0;
						}
					}
					
				}
			}
			end = System.nanoTime();
			nanoTime = end - start;
			
			System.out.println(nanoTime + " nanoseconds"); 
			System.out.println(nanoTime/(double)1000000 + " milliseconds");
			 
			System.out.println("manual fill " + nanoTime / (double) 1000000000 + " seconds");
			
			start = System.nanoTime();
			//com.setSeed(20);
			double[] ar2 = new double[1000000];
			for (int i = 0; i < numSteps; i++)
			{
				Arrays.fill(ar2, 0);
			}
			end = System.nanoTime();
			nanoTime = end - start;
			
			System.out.println(nanoTime + " nanoseconds"); 
			System.out.println(nanoTime/(double)1000000 + " milliseconds");
			 
			System.out.println("auto fill " + nanoTime / (double) 1000000000 + " seconds");
			*/
		
		

	
}
