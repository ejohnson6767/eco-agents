import java.io.Serializable;
import java.util.ArrayList;

public class BirthQuantCheat implements IBirthQuantCheat, IBirthProcess, Serializable
{
	// private Community com;
	private double gain;
	private IQuantCheatQ q;
	private double bMin;
	private ISpecies speciesOwner;
	private double theta;
	private double K;
	private boolean makesEnough;

	public BirthQuantCheat(double bMin, double gain, double K, double q, double theta)
	{
		this.bMin = bMin;
		this.gain = gain;
		this.q = new QuantCheatQ(q);
		this.theta = theta;
		this.K = K;
		this.makesEnough = false;
	}

	public BirthQuantCheat(double bMin, double gain, double K, double q, double theta, boolean makesEnough)
	{
		this.bMin = bMin;
		this.gain = gain;
		this.q = new QuantCheatQ(q);
		this.theta = theta;
		this.K = K;
		this.makesEnough = makesEnough;

	}

	public double getBirthRateBaseline(Location loc)
	{
		return this.bMin * (1 + this.gain * (1 - this.q.getQ(loc)));
	}

	public double getResourceLimitation(Location loc)
	{
		double min = 100000;
		ArrayList<ArrayList<IEffect>> lvEffects = this.speciesOwner.getAffectingLVEffectsByIndicator();
		for (int i = 0; i < lvEffects.size(); i++)
		{
			ArrayList<IEffect> oneIndicator = lvEffects.get(i);
			if (oneIndicator.size() != 0)
			{
				double localEffect = 0;
				for (int j = 0; j < oneIndicator.size(); j++)
				{
					localEffect += oneIndicator.get(j).getEffect(loc);
				}

				if (i == this.speciesOwner.getGridProxy())
				{
					if (!makesEnough)
					{
						double val = this.K * localEffect + this.q.getQ(loc);
						// double val = this.K * (localEffect + Math.pow(this.q.getQ(loc), this.theta));
						if (val < min)
						{
							min = val;
						}
					}
				}
				else
				{
					double val = this.K * localEffect;
					//// System.out.println("val is " + val);
					if (val < min)
					{
						min = val;
					}
				}
			}
			//// System.out.println("min is " + min);
		}
		//// System.out.println("");
		return min;

	}

	public void setQ(IQuantCheatQ q, int indicator)
	{
		this.q = q;
	}

	public double getBirthRate(Location loc)
	{
		return getBirthRateBaseline(loc) * getResourceLimitation(loc);
	}

	public void scaleByDt(double dt)
	{
		this.bMin *= dt;

	}

	@Override
	public void setSpeciesOwner(ISpecies species)
	{
		this.speciesOwner = species;
		this.q.setSpeciesOwner(species);

	}

	@Override
	public void setupAfterCommunityIsCreated(Community com)
	{
		this.q.setupAfterCommunityIsCreated(com);

	}

	public IQuantCheatQ getQ(int indicator)
	{
		return this.q;
	}

}
