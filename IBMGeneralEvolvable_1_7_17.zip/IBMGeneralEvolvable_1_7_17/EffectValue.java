import java.io.Serializable;

public class EffectValue implements IEffectValue, Serializable
{
	protected double effectValue;
	protected ISpecies speciesOwner;
	protected Community com;
	protected Environment env;
	protected int gridLength;
	protected double[][] spatialDistributionTracker;
	protected int envGridIndex;
	protected int speciesValue;

	public EffectValue(double effectVal)
	{
		this.effectValue = effectVal;
	}
	
	public double getEffectValue()
	{
		return this.effectValue;
	}

	public boolean isIndividualBased()
	{
		return false;
	}

	
	public double getEffectValue(int row, int col)
	{
		return this.effectValue;
	}

	@Override
	public void setSpeciesOwner(ISpecies species)
	{
		this.speciesOwner = species;
		
	}
	public void setupAfterCommunityIsCreated(Community com)
	{
		this.com = com;
		this.env = com.getEnvironment();
		this.gridLength = this.com.getEnvironment().getGridLength();
		this.spatialDistributionTracker = new double[gridLength][gridLength];
		this.envGridIndex = this.speciesOwner.getHomeGridIndex();
		this.speciesValue = this.speciesOwner.getGridProxy();
	}
	
	@Override
	public double[][] getSpatialDistributionTracker()
	{
		double[][] sdt = new double[this.gridLength][this.gridLength];
		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				if(this.env.getGridValue(row, col, this.envGridIndex) == this.speciesValue)
				{
					//System.out.println("effect val is " + this.effectValue);
					sdt[row][col] = this.effectValue;
				}
			}
		}
		
		return sdt;
	}


}
