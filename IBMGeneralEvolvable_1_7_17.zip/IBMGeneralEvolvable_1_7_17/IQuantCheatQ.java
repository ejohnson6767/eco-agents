
public interface IQuantCheatQ
{

	double getQ(Location loc);

	double[][] getSpatialDistributionTracker();

	void setSpeciesOwner(ISpecies species);

	void setupAfterCommunityIsCreated(Community com);

}
