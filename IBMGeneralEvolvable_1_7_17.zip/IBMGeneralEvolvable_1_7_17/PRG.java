import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

public class PRG implements Serializable
{
	private Community com;
	private int gridLength;
	private int commonDispersal;
	private Environment env;
	private int numberOfSpecies;

	public PRG(Community com)
	{
		this.com = com;
		this.env = this.com.getEnvironment();
		this.gridLength = this.env.getGridLength();
		this.numberOfSpecies = this.com.getNumberOfSpecies();
	}

	public void fillGrid()
	{
		this.com.resetPropaguleRainGrid();
		// if there are no individual based traits, do this subroutine
		if (!com.doesAnySpeciesHaveAnIndividualBasedTrait())
		{
			//System.out.println("no ib traits");
			
			if (allSameDispersalAndAllSameGrid())
			{
				fillGridMovingWindowAllSpeciesNoTraits();
			}
			else
			{
				ArrayList<ISpecies> speciesList = this.com.getSpeciesList();
				for (int j = 0; j < speciesList.size(); j++)
				{
					speciesList.get(j).getDispersalStrategy().doThing();
				}
			}
		}
		// this is the subroutine for if there are species with IB traits
		else
		{
			ArrayList<ISpecies> speciesList = this.com.getSpeciesList();
			for (int j = 0; j < speciesList.size(); j++)
			{
				//System.out.println("species  " + (j+1));
				ISpecies curSpecies = speciesList.get(j);
				// get the number of traits
				if (curSpecies.isOnGrid())
				{

					int numIBTraits = SpeciesTraitQuestions.HowManyIndividualBasedTraits(curSpecies);
					IDispersalTrait dt = curSpecies.getDispersalStrategy();
					if (numIBTraits > 0)
					{
						TraitList tl = curSpecies.getTraitList();
						if (dt.isIndividualBased())
						{
							// System.out.println("dispersal is individual based");
							DispersalIB dtIB = (DispersalIB) dt;
							// fill the discrete histogram (used for dispersal only and discrete trait only approaches to updating the propagule rain grid
							dtIB.fillDiscreteHistogram();
							// if dispersal is the only trait, use a special approach
							if (numIBTraits == 1)
							{
								tl.setDispersalIBOnly(true);
								tl.setOnlyDiscreteIBTraits(false);
								tl.resetAllTraitOptionsDispersalOnly();
								dtIB.fillPRGDispersalOnly();
							}
							// if dispersal is IB, and there are other discrete traits ...
							else if (tl.onlyDiscreteTraitsIB())
							{
								// and the biggest dispersal values is greater than 15, then use the discrete trait only approach to updating the propagule rain grid
								if (dtIB.getMaxTraitValue() > 30)
								{
									////System.out.println("weird discrete trait only approach");
									tl.setOnlyDiscreteIBTraits(true);
									tl.setDispersalIBOnly(false);
									// get the indexes of the discrete traits in the trait list
									ArrayList<Integer> indexes = tl.getDiscreteIBTraitIndexesInTraitList();
									// get all the possible combinations of traits that occur on the grid
									ArrayList<int[]> traitCombos = tl.makeCombinationsOfDiscreteTraits(indexes);
									// prime the trait list stuff
									// give the trait combos to the trait list class.
									tl.setDiscreteTraitCombos(traitCombos);
									// give the indexes to the traitlist class
									tl.setDiscreteTraitIndexes(indexes);
									// reset stuff, NOTE: indexes and traitcombos must be given first
									tl.resetDiscreteTraitBirthOptions();
									dtIB.fillPRGDiscreteOnlyIncludingDispersal(tl, indexes, traitCombos);
								}
								else
								{
									////System.out.println("DISPERSAL (LOW) IB AND OTHER DISCRETE TRAITS");
									// if dispersal is IB, and there are only other discrete traits, use the regular method <- faster when the max dispersal value is low enough
									tl.setOnlyDiscreteIBTraits(false);
									tl.setDispersalIBOnly(false);
									tl.resetAllTraitOptionsRegular();
									dtIB.fillPRGRegularIncludingDispersal();
								}
							}
							else
							{
								////System.out.println("DISPERSAL IB AND CONTINUOUS");
								// if dispersal is IB, and there are other continuous IB traits, use regular approach
								tl.setOnlyDiscreteIBTraits(false);
								tl.setDispersalIBOnly(false);
								tl.resetAllTraitOptionsRegular();
								dtIB.fillPRGRegularIncludingDispersal();
							}
						}
						else
						{
							//System.out.println("CONTINUOUS IB TRAITS");
							// if there are traits other than dispersal, use this approach.
							tl.setOnlyDiscreteIBTraits(false);
							tl.setDispersalIBOnly(false);
							tl.resetAllTraitOptionsRegular();
							fillGridBlandSingleSpeciesWithTraitsButNoIndividualBasedDispersal(dt, j);
						}
					}
					else
					{
						//System.out.println("regular shit");
						dt.doThing();
					}
				}
			}
		}
		//System.out.println("");
	}

	public void fillGridBlandSingleSpeciesWithTraitsButNoIndividualBasedDispersal(IDispersalTrait dt, int speciesIndex)
	{
		
		ISpecies curSpecies = this.com.getSpeciesList().get(speciesIndex);
		int gridLength = com.getEnvironment().getGridLength();
		int envGridIndex = curSpecies.getHomeGridIndex();
		double[][][] fecundityGrid = com.getFecundityGrid();
		Environment env = com.getEnvironment();
		int speciesValue = curSpecies.getGridProxy();
		int dispersalRadius = dt.getDispersalRadius();

		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				int gridValue = env.getGridValue(row, col, envGridIndex);
				if (gridValue == speciesValue)
				{
					//System.out.println("updating grid with traits");
					updateGridWithTraits(curSpecies, gridLength, row, col, dispersalRadius, fecundityGrid[envGridIndex][row][col]);

				}
			}
		}
	}

	public boolean allSameDispersalAndAllSameGrid()
	{
		boolean toReturn = true;
		ArrayList<ISpecies> speciesList = this.com.getSpeciesList();
		int refHomeGridIndex = 0;
		boolean firstSpeciesOnGrid = true;
		for (int i = 0; i < speciesList.size(); i++)
		{
			ISpecies curSpecies = speciesList.get(i);
			if (curSpecies.isOnGrid())
			{
				if (firstSpeciesOnGrid)
				{
					this.commonDispersal = curSpecies.getDispersalStrategy().getDispersalRadius();
					refHomeGridIndex = curSpecies.getHomeGridIndex();
					firstSpeciesOnGrid = false;
					continue;
				}
				IDispersalTrait dt = curSpecies.getDispersalStrategy();
				if (dt.getDispersalRadius() != this.commonDispersal || curSpecies.getHomeGridIndex() != refHomeGridIndex)
				{
					toReturn = false;
					break;
				}
			}
		}
		return toReturn;
	}

	public void updateGridWithTraits(ISpecies curSpecies, int gridLength, int row, int col, int dispersalRadius, double c)
	{
		double[][][][] propaguleRainGrid = com.getPropaguleRainGrid();
		Environment env = com.getEnvironment();
		int envGridIndex = curSpecies.getHomeGridIndex();
		TraitList traitList = curSpecies.getTraitList();
		int speciesVal = curSpecies.getGridProxy();

		int possibleNeighbors = (int) Math.pow(dispersalRadius * 2 + 1, 2) - 1;

		double cRealized = c / (double) possibleNeighbors;

		for (int row2 = row - dispersalRadius; row2 <= row + dispersalRadius; row2++)
		{
			for (int col2 = col - dispersalRadius; col2 <= col + dispersalRadius; col2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				propaguleRainGrid[envGridIndex][realRow][realCol][speciesVal - 1] += cRealized;
				traitList.updateBirthOptionsForEmptySite(row, col, realRow, realCol, cRealized, env);
				
			}
		}
	}

	
	
	public void fillGridMovingWindowAllSpeciesNoTraits()
	{
		///System.out.println("doing this");
		int numberOfSpecies = com.getNumberOfSpecies();
		////System.out.println("number of species " + numberOfSpecies);
		int gridLength = com.getEnvironment().getGridLength();
		////System.out.println("grid length is " + gridLength);
		double possibleNeighbors = Math.pow(this.commonDispersal * 2 + 1, 2) - 1;
		////System.out.println("possible neighbors " + possibleNeighbors);
		////System.out.println("dispersal radius is " + this.commonDispersal);
		double[][][] fecundityGrid = com.getFecundityGrid();
		double[][][][] propaguleRainGrid = com.getPropaguleRainGrid();

		Environment env = com.getEnvironment();
		double[][][] posPropagule = new double[numberOfSpecies][gridLength][3];

		// this second main loop determines who gives birth into empty site, depending on the cumulative realized birth rates within the this.commonDispersal

		// this algorithm scans right across the grid, goes down one line, scans again, and so on (just like reading). It's time complexity is O(n) (where n is the number of microsites) compared to O(n^2) of a trivial moving window algorithm.
		// It works by summing all of the
		// cumulative birth rates in the topmost row, the bottommost row, and everything in between. This is where the last dimension on pos array comes in:
		// 0 is TOP, 1 is MID, and 2 is BOT. when you to the next gid locationCommunity com,, your cumulative growth rate is TOPnew + MIDnew + BOTnew. MIDnew is simply MIDnorth + BOTnorth - TOPnew.
		// (where north indicates the position above you). TOPnew can be written TOPwest - TOPwest.leftMost + TOPnew.rightmost. BOTnew can be written BOTwest - BOTwest.leftMost + BOTnew.rightmost.
		// the TOP, MID, and BOT are all recorded.
		int row = 0;
		int col = 0;
		// the first loop is the most costly, each TOP, MID, and BOT is caclulated independently.

		// pos = new double[numberOfSpecies][gridLength][3];
		int row2 = row - this.commonDispersal;
		int realRow = WrapAround.wrapAround(row2, gridLength);

		for (int col2 = col - this.commonDispersal; col2 <= col + this.commonDispersal; col2++)
		{
			int realCol = WrapAround.wrapAround(col2, gridLength);
			int gridValue = env.getGridValue(realRow, realCol, 0);
			if (gridValue != 0)
			{

				posPropagule[gridValue - 1][col][0] += fecundityGrid[0][realRow][realCol];

			}
		}
		// System.out.println("col == " + col + " first is " + first[1]);

		for (int col2 = col - this.commonDispersal; col2 <= col + this.commonDispersal; col2++)
		{
			for (row2 = row - this.commonDispersal + 1; row2 <= row + this.commonDispersal - 1; row2++)
			{
				realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, 0);
				if (gridValue != 0)
				{

					posPropagule[gridValue - 1][col][1] += fecundityGrid[0][realRow][realCol];

				}
			}
		}
		// System.out.println("col == 0 middle is " + middle[1]);

		row2 = row + this.commonDispersal;
		realRow = WrapAround.wrapAround(row2, gridLength);
		for (int col2 = col - this.commonDispersal; col2 <= col + this.commonDispersal; col2++)
		{
			int realCol = WrapAround.wrapAround(col2, gridLength);
			int gridValue = env.getGridValue(realRow, realCol, 0);
			if (gridValue != 0)
			{

				posPropagule[gridValue - 1][col][2] += fecundityGrid[0][realRow][realCol];

			}
		}

		for (int i = 0; i < numberOfSpecies; i++)
		{
			propaguleRainGrid[0][row][col][i] = (posPropagule[i][col][0] + posPropagule[i][col][1] + posPropagule[i][col][2]) / possibleNeighbors;
		}

		for (col = 1; col < gridLength; col++)
		{

			// generate new top
			int NRow = WrapAround.wrapAround(row - this.commonDispersal, gridLength);
			int WCol = WrapAround.wrapAround(col - 1 - this.commonDispersal, gridLength);
			int ECol = WrapAround.wrapAround(col + this.commonDispersal, gridLength);
			int SRow = WrapAround.wrapAround(row + this.commonDispersal, gridLength);
		
			
			for (int s = 0; s < numberOfSpecies; s++)
			{
				posPropagule[s][col][0] = posPropagule[s][col - 1][0];
			}
			
			int NWGridValue = env.getGridValue(NRow, WCol, 0);
			if(NWGridValue != 0)
			{
				posPropagule[NWGridValue - 1][col][0] -= fecundityGrid[0][NRow][WCol];
			}
			int NEGridValue = env.getGridValue(NRow, ECol, 0);
			if(NEGridValue != 0)
			{
				posPropagule[NEGridValue - 1][col][0] += fecundityGrid[0][NRow][ECol];
			}
			
			
			

			double[] leftSideOfOldMid = new double[numberOfSpecies];
			int col2 = col - this.commonDispersal - 1;
			int realCol = WrapAround.wrapAround(col2, gridLength);
			for (row2 = row - this.commonDispersal + 1; row2 <= row + this.commonDispersal - 1; row2++)
			{
				realRow = WrapAround.wrapAround(row2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, 0);
				if (gridValue != 0)
				{

					leftSideOfOldMid[gridValue - 1] += fecundityGrid[0][realRow][realCol];

				}
			}

			double[] rightSideOfNewMid = new double[numberOfSpecies];
			col2 = col + this.commonDispersal;
			realCol = WrapAround.wrapAround(col2, gridLength);

			for (row2 = row - this.commonDispersal + 1; row2 <= row + this.commonDispersal - 1; row2++)
			{
				realRow = WrapAround.wrapAround(row2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, 0);
				if (gridValue != 0)
				{
					rightSideOfNewMid[gridValue - 1] += fecundityGrid[0][realRow][realCol];
				}
			}

			for (int s = 0; s < numberOfSpecies; s++)
			{
				posPropagule[s][col][1] = posPropagule[s][col - 1][1] - leftSideOfOldMid[s] + rightSideOfNewMid[s];
			}

			for (int s = 0; s < numberOfSpecies; s++)
			{
				posPropagule[s][col][2] = posPropagule[s][col - 1][2];
			}
			
			int SWGridValue = env.getGridValue(SRow, WCol, 0);
			if(SWGridValue != 0)
			{
				posPropagule[SWGridValue - 1][col][2] -= fecundityGrid[0][SRow][WCol];
			}
			int SEGridValue = env.getGridValue(SRow, ECol, 0);
			if(SEGridValue != 0)
			{
				posPropagule[SEGridValue - 1][col][2] += fecundityGrid[0][SRow][ECol];
			}
			

			for (int i = 0; i < numberOfSpecies; i++)
			{
				propaguleRainGrid[0][row][col][i] = (posPropagule[i][col][0] + posPropagule[i][col][1] + posPropagule[i][col][2]) / possibleNeighbors;
			}

		}

		for (row = 1; row < gridLength; row++)
		{
			col = 0;
			// if we're on a new row, but not the first row, the TOPnew and BOTnew must be calculated independently

			for (int s = 0; s < numberOfSpecies; s++)
			{
				posPropagule[s][col][0] = 0;
			}
			row2 = row - this.commonDispersal;
			realRow = WrapAround.wrapAround(row2, gridLength);
			for (int col2 = col - this.commonDispersal; col2 <= col + this.commonDispersal; col2++)
			{

				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, 0);
				if (gridValue != 0)
				{

					posPropagule[gridValue - 1][col][0] += fecundityGrid[0][realRow][realCol];

				}
			}

			for (int s = 0; s < numberOfSpecies; s++)
			{
				posPropagule[s][col][1] += posPropagule[s][col][2] - posPropagule[s][col][0];
			}

			for (int s = 0; s < numberOfSpecies; s++)
			{
				posPropagule[s][col][2] = 0;
			}
			row2 = row + this.commonDispersal;
			realRow = WrapAround.wrapAround(row2, gridLength);
			for (int col2 = col - this.commonDispersal; col2 <= col + this.commonDispersal; col2++)
			{
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, 0);
				if (gridValue != 0)
				{

					posPropagule[gridValue - 1][col][2] += fecundityGrid[0][realRow][realCol];

				}
			}

			for (int i = 0; i < numberOfSpecies; i++)
			{
				propaguleRainGrid[0][row][col][i] = (posPropagule[i][col][0] + posPropagule[i][col][1] + posPropagule[i][col][2]) / possibleNeighbors;
			}

			for (col = 1; col < gridLength; col++)
			{
				// generate new top
				int NRow = WrapAround.wrapAround(row - this.commonDispersal, gridLength);
				int WCol = WrapAround.wrapAround(col - 1 - this.commonDispersal, gridLength);
				int ECol = WrapAround.wrapAround(col + this.commonDispersal, gridLength);
				int SRow = WrapAround.wrapAround(row + this.commonDispersal, gridLength);
				
				
				
				
				for (int s = 0; s < numberOfSpecies; s++)
				{
					posPropagule[s][col][0] = posPropagule[s][col - 1][0];
				}
				
				int NWGridValue = env.getGridValue(NRow, WCol, 0);
				if(NWGridValue != 0)
				{
					posPropagule[NWGridValue - 1][col][0] -= fecundityGrid[0][NRow][WCol];
				}
				int NEGridValue = env.getGridValue(NRow, ECol, 0);
				if(NEGridValue != 0)
				{
					posPropagule[NEGridValue - 1][col][0] += fecundityGrid[0][NRow][ECol];
				}

				
				
				
				for (int s = 0; s < numberOfSpecies; s++)
				{
					posPropagule[s][col][1] += posPropagule[s][col][2] - posPropagule[s][col][0];
				}

				
				
				
				for (int s = 0; s < numberOfSpecies; s++)
				{
					posPropagule[s][col][2] = posPropagule[s][col - 1][2];
				}
				
				int SWGridValue = env.getGridValue(SRow, WCol, 0);
				if(SWGridValue != 0)
				{
					posPropagule[SWGridValue - 1][col][2] -= fecundityGrid[0][SRow][WCol];
				}
				int SEGridValue = env.getGridValue(SRow, ECol, 0);
				if(SEGridValue != 0)
				{
					posPropagule[SEGridValue - 1][col][2] += fecundityGrid[0][SRow][ECol];
				}

				for (int i = 0; i < numberOfSpecies; i++)
				{
					propaguleRainGrid[0][row][col][i] = (posPropagule[i][col][0] + posPropagule[i][col][1] + posPropagule[i][col][2]) / possibleNeighbors;
				}

			}
		}

	}

//	public void fillGridMovingWindowAllSpeciesNoTraitsOld()
//	{
//		int numberOfSpecies = com.getNumberOfSpecies();
//		int gridLength = com.getEnvironment().getGridLength();
//		double possibleNeighbors = Math.pow(this.commonDispersal * 2 + 1, 2) - 1;
//		// System.out.println("possible neighbors " + possibleNeighbors);
//		// System.out.println("dispersal radius is " + this.commonDispersal);
//		double[][][][] fecundityGrid = com.getFecundityGrid();
//		double[][][][] propaguleRainGrid = com.getPropaguleRainGrid();
//
//		Environment env = com.getEnvironment();
//		double[][][] posPropagule = new double[numberOfSpecies][gridLength][3];
//
//		// this second main loop determines who gives birth into empty site, depending on the cumulative realized birth rates within the this.commonDispersal
//
//		// this algorithm scans right across the grid, goes down one line, scans again, and so on (just like reading). It's time complexity is O(n) (where n is the number of microsites) compared to O(n^2) of a trivial moving window algorithm.
//		// It works by summing all of the
//		// cumulative birth rates in the topmost row, the bottommost row, and everything in between. This is where the last dimension on pos array comes in:
//		// 0 is TOP, 1 is MID, and 2 is BOT. when you to the next gid locationCommunity com,, your cumulative growth rate is TOPnew + MIDnew + BOTnew. MIDnew is simply MIDnorth + BOTnorth - TOPnew.
//		// (where north indicates the position above you). TOPnew can be written TOPwest - TOPwest.leftMost + TOPnew.rightmost. BOTnew can be written BOTwest - BOTwest.leftMost + BOTnew.rightmost.
//		// the TOP, MID, and BOT are all recorded.
//		int row = 0;
//		int col = 0;
//		// the first loop is the most costly, each TOP, MID, and BOT is caclulated independently.
//
//		// pos = new double[numberOfSpecies][gridLength][3];
//		int row2 = row - this.commonDispersal;
//		int realRow = WrapAround.wrapAround(row2, gridLength);
//
//		for (int col2 = col - this.commonDispersal; col2 <= col + this.commonDispersal; col2++)
//		{
//			int realCol = WrapAround.wrapAround(col2, gridLength);
//			int gridValue = env.getGridValue(realRow, realCol, 0);
//			if (gridValue != 0)
//			{
//
//				posPropagule[gridValue - 1][col][0] += fecundityGrid[0][realRow][realCol][gridValue - 1];
//
//			}
//		}
//		// System.out.println("col == " + col + " first is " + first[1]);
//
//		for (int col2 = col - this.commonDispersal; col2 <= col + this.commonDispersal; col2++)
//		{
//			for (row2 = row - this.commonDispersal + 1; row2 <= row + this.commonDispersal - 1; row2++)
//			{
//				realRow = WrapAround.wrapAround(row2, gridLength);
//				int realCol = WrapAround.wrapAround(col2, gridLength);
//				int gridValue = env.getGridValue(realRow, realCol, 0);
//				if (gridValue != 0)
//				{
//
//					posPropagule[gridValue - 1][col][1] += fecundityGrid[0][realRow][realCol][gridValue - 1];
//
//				}
//			}
//		}
//		// System.out.println("col == 0 middle is " + middle[1]);
//
//		row2 = row + this.commonDispersal;
//		realRow = WrapAround.wrapAround(row2, gridLength);
//		for (int col2 = col - this.commonDispersal; col2 <= col + this.commonDispersal; col2++)
//		{
//			int realCol = WrapAround.wrapAround(col2, gridLength);
//			int gridValue = env.getGridValue(realRow, realCol, 0);
//			if (gridValue != 0)
//			{
//
//				posPropagule[gridValue - 1][col][2] += fecundityGrid[0][realRow][realCol][gridValue - 1];
//
//			}
//		}
//
//		for (int i = 0; i < numberOfSpecies; i++)
//		{
//			propaguleRainGrid[0][row][col][i] = (posPropagule[i][col][0] + posPropagule[i][col][1] + posPropagule[i][col][2]) / possibleNeighbors;
//		}
//
//		for (col = 1; col < gridLength; col++)
//		{
//
//			// generate new top
//			int NWRow = WrapAround.wrapAround(row - this.commonDispersal, gridLength);
//			int NWCol = WrapAround.wrapAround(col - 1 - this.commonDispersal, gridLength);
//			int NERow = WrapAround.wrapAround(row - this.commonDispersal, gridLength);
//			int NECol = WrapAround.wrapAround(col + this.commonDispersal, gridLength);
//
//			int SWRow = WrapAround.wrapAround(row + this.commonDispersal, gridLength);
//			int SWCol = WrapAround.wrapAround(col - 1 - this.commonDispersal, gridLength);
//			int SERow = WrapAround.wrapAround(row + this.commonDispersal, gridLength);
//			int SECol = WrapAround.wrapAround(col + this.commonDispersal, gridLength);
//
//			for (int s = 0; s < numberOfSpecies; s++)
//			{
//				posPropagule[s][col][0] = posPropagule[s][col - 1][0] - fecundityGrid[0][NWRow][NWCol][s] + fecundityGrid[0][NERow][NECol][s];
//			}
//
//			double[] leftSideOfOldMid = new double[numberOfSpecies];
//			int col2 = col - this.commonDispersal - 1;
//			int realCol = WrapAround.wrapAround(col2, gridLength);
//			for (row2 = row - this.commonDispersal + 1; row2 <= row + this.commonDispersal - 1; row2++)
//			{
//				realRow = WrapAround.wrapAround(row2, gridLength);
//				int gridValue = env.getGridValue(realRow, realCol, 0);
//				if (gridValue != 0)
//				{
//
//					leftSideOfOldMid[gridValue - 1] += fecundityGrid[0][realRow][realCol][gridValue - 1];
//
//				}
//			}
//
//			double[] rightSideOfNewMid = new double[numberOfSpecies];
//			col2 = col + this.commonDispersal;
//			realCol = WrapAround.wrapAround(col2, gridLength);
//
//			for (row2 = row - this.commonDispersal + 1; row2 <= row + this.commonDispersal - 1; row2++)
//			{
//				realRow = WrapAround.wrapAround(row2, gridLength);
//				int gridValue = env.getGridValue(realRow, realCol, 0);
//				if (gridValue != 0)
//				{
//					rightSideOfNewMid[gridValue - 1] += fecundityGrid[0][realRow][realCol][gridValue - 1];
//				}
//			}
//
//			for (int s = 0; s < numberOfSpecies; s++)
//			{
//				posPropagule[s][col][1] = posPropagule[s][col - 1][1] - leftSideOfOldMid[s] + rightSideOfNewMid[s];
//			}
//
//			for (int s = 0; s < numberOfSpecies; s++)
//			{
//				posPropagule[s][col][2] = posPropagule[s][col - 1][2] - fecundityGrid[0][SWRow][SWCol][s] + fecundityGrid[0][SERow][SECol][s];
//			}
//
//			for (int i = 0; i < numberOfSpecies; i++)
//			{
//				propaguleRainGrid[0][row][col][i] = (posPropagule[i][col][0] + posPropagule[i][col][1] + posPropagule[i][col][2]) / possibleNeighbors;
//			}
//
//		}
//
//		for (row = 1; row < gridLength; row++)
//		{
//			col = 0;
//			// if we're on a new row, but not the first row, the TOPnew and BOTnew must be calculated independently
//
//			for (int s = 0; s < numberOfSpecies; s++)
//			{
//				posPropagule[s][col][0] = 0;
//			}
//			row2 = row - this.commonDispersal;
//			realRow = WrapAround.wrapAround(row2, gridLength);
//			for (int col2 = col - this.commonDispersal; col2 <= col + this.commonDispersal; col2++)
//			{
//
//				int realCol = WrapAround.wrapAround(col2, gridLength);
//				int gridValue = env.getGridValue(realRow, realCol, 0);
//				if (gridValue != 0)
//				{
//
//					posPropagule[gridValue - 1][col][0] += fecundityGrid[0][realRow][realCol][gridValue - 1];
//
//				}
//			}
//
//			for (int s = 0; s < numberOfSpecies; s++)
//			{
//				posPropagule[s][col][1] += posPropagule[s][col][2] - posPropagule[s][col][0];
//			}
//
//			for (int s = 0; s < numberOfSpecies; s++)
//			{
//				posPropagule[s][col][2] = 0;
//			}
//			row2 = row + this.commonDispersal;
//			realRow = WrapAround.wrapAround(row2, gridLength);
//			for (int col2 = col - this.commonDispersal; col2 <= col + this.commonDispersal; col2++)
//			{
//				int realCol = WrapAround.wrapAround(col2, gridLength);
//				int gridValue = env.getGridValue(realRow, realCol, 0);
//				if (gridValue != 0)
//				{
//
//					posPropagule[gridValue - 1][col][2] += fecundityGrid[0][realRow][realCol][gridValue - 1];
//
//				}
//			}
//
//			for (int i = 0; i < numberOfSpecies; i++)
//			{
//				propaguleRainGrid[0][row][col][i] = (posPropagule[i][col][0] + posPropagule[i][col][1] + posPropagule[i][col][2]) / possibleNeighbors;
//			}
//
//			for (col = 1; col < gridLength; col++)
//			{
//				// generate new top
//				int NWRow = WrapAround.wrapAround(row - this.commonDispersal, gridLength);
//				int NWCol = WrapAround.wrapAround(col - 1 - this.commonDispersal, gridLength);
//				int NERow = WrapAround.wrapAround(row - this.commonDispersal, gridLength);
//				int NECol = WrapAround.wrapAround(col + this.commonDispersal, gridLength);
//
//				int SWRow = WrapAround.wrapAround(row + this.commonDispersal, gridLength);
//				int SWCol = WrapAround.wrapAround(col - 1 - this.commonDispersal, gridLength);
//				int SERow = WrapAround.wrapAround(row + this.commonDispersal, gridLength);
//				int SECol = WrapAround.wrapAround(col + this.commonDispersal, gridLength);
//
//				for (int s = 0; s < numberOfSpecies; s++)
//				{
//					posPropagule[s][col][0] = posPropagule[s][col - 1][0] - fecundityGrid[0][NWRow][NWCol][s] + fecundityGrid[0][NERow][NECol][s];
//				}
//
//				for (int s = 0; s < numberOfSpecies; s++)
//				{
//					posPropagule[s][col][1] += posPropagule[s][col][2] - posPropagule[s][col][0];
//				}
//
//				for (int s = 0; s < numberOfSpecies; s++)
//				{
//					posPropagule[s][col][2] = posPropagule[s][col - 1][2] - fecundityGrid[0][SWRow][SWCol][s] + fecundityGrid[0][SERow][SECol][s];
//				}
//
//				for (int i = 0; i < numberOfSpecies; i++)
//				{
//					propaguleRainGrid[0][row][col][i] = (posPropagule[i][col][0] + posPropagule[i][col][1] + posPropagule[i][col][2]) / possibleNeighbors;
//				}
//
//			}
//		}
//
//	}
	
	
}
