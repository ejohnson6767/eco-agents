import java.io.Serializable;
import java.util.ArrayList;

public interface ISpecies extends Serializable
{

	double getBirthRate(Location loc);
	
	double getDeathRate(Location loc);
	
	
	
	
	void setGridProxy(int i);
	
	void setInoculateWhen(int i);
	
	int getInoculateWhen();
	int getGridProxy();
	String getSpeciesName();
	boolean getInoculateOverwrite();
	int getInitialAbundance();
	

	boolean canRecruitAtEmptySite(Community community, Location locs);

	boolean isInvader();

	void setIsInvader(boolean b);

	void setInitialAbundance(int i);

	boolean hasVariableRecruitment();

	//double getRecruitment(Location emptySiteLoc);

	double getFitness(Location locs);

	void speciesGridLengthConcordanceWithEnvironentGridLength(Environment env);

	void setRecruitmentGrid(GenericDemographyGrid grid, double[] rates) throws Exception;
	void setBirthGrid(GenericDemographyGrid grid, double[] rates) throws Exception;
	void setDeathGrid(GenericDemographyGrid grid, double[] rates) throws Exception;




	

	//int getDispersalAbility(Location location);

	//int getBaselineDispersalAbility();


	//Evolvable getIndividualBasedDispersalTrait();


	boolean isOnGrid();

	//int getPossibleNeighbors();

	boolean useMovingWindowForPropaguleRain();

	TraitList getTraitList();

	void setTraitList(TraitList traitList);

	ArrayList<Evolvable> getEvolvableTraits();

	void addTrait(Evolvable trait);

	boolean canRecruitIfCritterCanOverwriteHeterospecifics(Community com, Location newLoc);

	boolean canRecruit(Community com, Location newLoc);

	double[][] getRecruitmentGrid();

	int getHomeGridIndex();

	void setHomeGridValue(int i);

	void setEnvGridValuesThatAffectRecruitment(int[] i);

	IDispersalTrait getDispersalStrategy();

	void setDispersalStrategy(IDispersalTrait dispersalIB);

	void setupSpeciesAfterCommunityIsCreated(Community community);

	LocalLV getLocalLV();

	IBirthProcess getBirthProcess();

	IDeathProcess getDeathProcess();

	void setLocalEffects(LocalLV lv1);

	void setBirthProcess(IBirthProcess bl);

	void setDeathProcess(IDeathProcess d2);


	void addAffectingLVEffect(IEffect lVEffects);

	ArrayList<IEffect> getAffectingLVEffects();

	//void setLVEffect(ILVEffect lvEffectIB, int affectedSpeciesValue, int affectedSpeciesLVEffectValue);

	
	void setLocalEffect(int a, double b, int c);
	void setLocalEffect(int a, double b, int c, int d);

	void setLocalEffect(int a, IEffect lv1) throws Exception;

	void setAbundance(int i);

	int getAbundance();

	void resetAffectingLVEffects();

	void addAffectingLVEffectByIndicator(IEffect lvEffect);

	ArrayList<ArrayList<IEffect>> getAffectingLVEffectsByIndicator();

	void resetAffectingLVEffectsByIndicator();

	DemographyGridKit getBirthGrid();

	DummyTrait getDummyTrait();

	void addDummyTrait(DummyTrait dummyTrait);

	void setBirthGrid(double[][] grid);

	


	//double getEStar(Community com, Location location);

	
	
	//double makeBirthEffects();
	
	//double makeDeathEffects();
	
}
