import java.io.Serializable;
import java.util.Random;

public class MutationFunctionStandard implements Serializable
{
	protected IEvolveProb evolveProb;
	protected IMutationMagnitude mutationMagnitude;
	protected Random generator;

	public MutationFunctionStandard(double evolveProb, double mutationMagnitude)
	{
		this.evolveProb = new EvolveProb(evolveProb);
		this.mutationMagnitude = new MutationMagnitude(mutationMagnitude);
	}
	

	public IEvolveProb getEvolveProb()
	{
		return this.evolveProb;
	}

	
	public IMutationMagnitude getMutationMagnitude()
	{
		return this.mutationMagnitude;
	}
	
	public void setEvolveProb(IEvolveProb evolveProb)
	{
		this.evolveProb = evolveProb;
	}
	
	public void setMutationMagnitude(IMutationMagnitude mm)
	{
		this.mutationMagnitude = mm;
	}
	
	public void setGenerator(Random generator)
	{
		this.generator = generator;
	}

}
