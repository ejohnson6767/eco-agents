import java.io.Serializable;
import java.util.ArrayList;

public class BirthQuadratic implements IBirthProcess, Serializable
{
	private Community com;
	private ISpecies speciesOwner;
	//private double birthRate;
	private int speciesValue;
	private double peak;
	private double[][] birthGrid;
	private double slope;
	private double dt;

	public BirthQuadratic(double peak, double slope)
	{
		// this.com = com;
		this.peak = peak;
		this.slope = slope;
		
	}

	public double getBirthRate(Location loc)
	{	
		//System.out.println("location is " + this.birthGrid[loc.row()][loc.col()]);
		//System.out.println("abs dif is " + Math.abs(this.peak - this.birthGrid[loc.row()][loc.col()]));

		double dif = slope * Math.pow(Math.abs(this.peak - this.birthGrid[loc.row()][loc.col()]), 2);
		if(dif > 1)
		{
			dif = 1;
		}
		//System.out.println("birth looks like " + ((1 - dif) * this.dt));
		return (1 - dif) * this.dt;
	}

	
	
	public void scaleByDt(double dt)
	{
		this.dt = dt;

	}

	public void setSpeciesOwner(ISpecies species)
	{
		this.speciesOwner = species;

	}

	public void setupAfterCommunityIsCreated(Community com)
	{
		this.com = com;
		this.speciesValue = this.speciesOwner.getGridProxy();
		this.birthGrid = this.speciesOwner.getBirthGrid().getSpecificDemographyGrid();
		this.dt = com.getDt();
	}

}
