
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class EffectValueQuantCheatIB extends EffectValueIB implements IEffectValue, Evolvable, Serializable
{
	//private Community com;
	//Environment env;
	private int baselineTrait;
	//private int speciesValue;
	//private boolean useAltApproach;
	//private int speciesIndex;
	//private int envGridIndex;
	//private int possibleNeighbors;
	private int affectedSpeciesValue;
	private int affectedSpeciesLVEffectValue;
	private IEffect lvEffect;
	//private double effectPerSite;
	//private double[][] lVEffectGrid;

	public EffectValueQuantCheatIB(IMutationFunction mf, int affectedSpeciesValue, int affectedSpeciesLVEffectValue, IEffect lvEffectToOverwrite)
	{
		super(mf, affectedSpeciesValue, affectedSpeciesLVEffectValue, lvEffectToOverwrite);
		// this.com = com;
	}

	public boolean isIndividualBased()
	{
		return this.isIndividualBased;
	}



	public double getBaselineTrait()
	{
		return this.baselineTrait;
	}

	public void setSpeciesOwner(ISpecies species)
	{
		//this.species = species;
		this.lvEffect.setSpeciesOwner(this.species);
	}

	public void setupAfterCommunityIsCreated(Community com)
	{
		//this.com = com;
	
		//this.gridLength = this.com.getEnvironment().getGridLength();
		this.baselineTrait = (int) getTraitAverage();
		//IDiffusion dif =this.lvEffect.getDiffusion();
		//this.lvEffect.getDiffusion().setupAfterCommunityIsCreated(com);
		//this.spatialDistributionTracker = new double[gridLength][gridLength];
		
	}

	public double[][] getSpatialDistributionTracker()
	{
		return this.spatialDistributionTracker;
	}

	
	public double getEffectValue()
	{
		return getTraitAverage();
	}


	public double getEffect(Location loc)
	{
		return this.lvEffect.getEffect(loc);
	}


	public int getDiffusion()
	{
		return (int) Math.round(getTraitAverage());
	}


	public int getDiffusion(int row, int col)
	{
		return (int) this.spatialDistributionTracker[row][col];
	}

	@Override
	public double getEffectValue(int row, int col)
	{
		return this.spatialDistributionTracker[row][col];
	}

}
