import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class MakeGrids
{
	private Random generator = new Random();
	private int[][] grid;
	private int gridLength;
	private int totalSites;
	private static double exp = 2.718282;
	private int[][] beforeAfter = new int[2][3];

	public MakeGrids(int[][] grid)
	{
		this.grid = grid;
		this.gridLength = grid.length;
		this.totalSites = this.gridLength * this.gridLength;

	}

	public MakeGrids(int gridLength, int[] abundances)
	{
		this.gridLength = gridLength;
		this.grid = new int[gridLength][gridLength];
		this.grid = makePercolationGrid(abundances);

		this.totalSites = this.gridLength * this.gridLength;
	}

	public MakeGrids(int gridLength)
	{
		this.grid = new int[gridLength][gridLength];
		this.gridLength = grid.length;
		this.totalSites = this.gridLength * this.gridLength;
	}
	
	public void setRandomGenerator(Random generator)
	{
		this.generator = generator;
	}

	public static double[][][] makeRandomPCFunction(int maxPCDist, int controlledPCDist, int numStates)
	{
		Random generator = new Random();
		double[][][] PCGoal = new double[maxPCDist][numStates][numStates];

		for (int i = 0; i < maxPCDist; i++)
		{
			for (int j = 0; j < numStates; j++)
			{
				for (int k = 0; k < numStates; k++)
				{
					if (i > controlledPCDist - 1)
					{
						PCGoal[i][j][k] = 1 / (double) numStates;
					}
					else
					{
						PCGoal[i][j][k] = generator.nextDouble();
					}
				}
			}
		}
		return PCGoal;
	}

	/*
	 * randomly places critters on a grid
	 */
	public int[][] makePercolationGrid(int[] abundances)
	{
		// System.out.println("starting makePercolationGrid");
		int numSpecies = abundances.length;
		int[] abundanceCounter = new int[numSpecies];
		double[] placeCritterProbs = new double[numSpecies];

		// whether the number of added critters (totalAbundanceCounter) equals the number that need to be added will be determine when the algorithm is finished
		int totalAbundanceCounter = 0;
		int total = 0;
		for (int i = 0; i < numSpecies; i++)
		{
			total += abundances[i];
		}

		// the relative proportions of species will determine their probability of being picked to be added. Critters are added in this random way to give fully random spatial distributions
		for (int i = 0; i < numSpecies; i++)
		{
			placeCritterProbs[i] = abundances[i] / (double) total;
			// System.out.println("placeCriterProbs " + i + " is " + placeCritterProbs[i]) ;
		}

		// main loop. only breaks once all species are added
		while (true)
		{
			//System.out.println("in the loop");
			// get a random number to decide which species is going to be added...
			double rand = generator.nextDouble();
			int speciesIndexToAdd = 0;
			for (int i = 0; i < numSpecies; i++)
			{
				if (placeCritterProbs[i] > rand)
				{
					speciesIndexToAdd = i;
				}
			}

		/*	System.out.println("");
			System.out.println("totalAbundanceCounter is " + totalAbundanceCounter);
			System.out.println("abundanceGoal is " + total);*/
			
			// ... if all the critters of the chosen species has been added, continue the loop and try again for a different species...
			if (abundanceCounter[speciesIndexToAdd] == abundances[speciesIndexToAdd])
			{
				//System.out.println("continuing");
				continue;
			}

			// otherwise, search for an empty site and place the critter there
			else
			{

				boolean foundASpot = false;
				while (!foundASpot)
				{
					// System.out.println("trying to find a spot");
					int row = generator.nextInt(this.gridLength);
					int col = generator.nextInt(this.gridLength);
					if (grid[row][col] == 0)
					{
						grid[row][col] = speciesIndexToAdd + 1;
						abundanceCounter[speciesIndexToAdd]++;
						totalAbundanceCounter++;
						foundASpot = true;

					}
				}
			}

			/*System.out.println("");
			System.out.println("totalAbundanceCounter is " + totalAbundanceCounter);
			System.out.println("abundanceGoal is " + total);*/

			// grid is finished when all critters have been added
			if (totalAbundanceCounter == total)
			{
				break;
			}
		}

		return grid;
	}

	/*
	 * gives a vector of abundances
	 */
	public int[] getAbundances(int numSpecies)
	{
		int[] abund = new int[numSpecies];
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				int gridValue = this.grid[row][col];
				if (gridValue != 0)
				{
					abund[gridValue - 1]++;
				}
			}
		}
		return abund;
	}
	
	/*
	 * gives a vector of abundances
	 */
	public static int[] getAbundances(int[][] grid, int numSpecies)
	{
		int gridLength = grid.length;
		int[] abund = new int[numSpecies];
		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				int gridValue = grid[row][col];
				if (gridValue != 0)
				{
					abund[gridValue - 1]++;
				}
			}
		}
		return abund;
	}

	public int[] getAbundancesIncludingE(int numSpecies)
	{

		int[] abund = new int[numSpecies];
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				int gridValue = this.grid[row][col];
				if (gridValue != 0)
				{
					abund[gridValue - 1]++;
				}
			}
		}

		int[] abundancesIncludingE = new int[abund.length + 1];
		int total = 0;
		for (int i = 0; i < abund.length; i++)
		{
			abundancesIncludingE[i + 1] = abund[i];
			total += abund[i];

		}
		// stick all the abundances, including the empty sites at index 0, into one vector
		abundancesIncludingE[0] = this.totalSites - total;

		return abundancesIncludingE;
	}

	/*
	 * gives a vector of abundances
	 */
	public int[] getAbundances()
	{
		int gridLength = grid.length;
		ArrayList<Integer> types = new ArrayList<Integer>();

		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				int gridValue = grid[row][col];

				boolean neverSeen = true;
				for (int i = 0; i < types.size(); i++)
				{
					if (gridValue == types.get(i))
					{
						neverSeen = false;
						break;
					}
				}
				if (neverSeen)
				{
					types.add(gridValue);
				}

			}
		}

		int[] abund = new int[types.size() - 1];
		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				int gridValue = grid[row][col];
				if (gridValue != 0)
				{
					abund[gridValue - 1]++;
				}
			}
		}

		return abund;
	}

	public int[] getAbundancesIncludingE()
	{
		int gridLength = grid.length;
		ArrayList<Integer> types = new ArrayList<Integer>();

		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				int gridValue = grid[row][col];

				boolean neverSeen = true;
				for (int i = 0; i < types.size(); i++)
				{
					if (gridValue == types.get(i))
					{
						neverSeen = false;
						break;
					}
				}
				if (neverSeen)
				{
					types.add(gridValue);
				}

			}
		}

		int[] abund = new int[types.size()];
		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				int gridValue = grid[row][col];
				abund[gridValue]++;
			}
		}

		return abund;
	}

	/*
	 * gives a vector of abundances
	 */
	public static int[] getAbundances(int[][] grid)
	{
		int gridLength = grid.length;
		ArrayList<Integer> types = new ArrayList<Integer>();

		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				int gridValue = grid[row][col];

				boolean neverSeen = true;
				for (int i = 0; i < types.size(); i++)
				{
					if (gridValue == types.get(i))
					{
						neverSeen = false;
						break;
					}
				}
				if (neverSeen)
				{
					types.add(gridValue);
				}

			}
		}

		int[] abund = new int[types.size() - 1];
		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				int gridValue = grid[row][col];
				if (gridValue != 0)
				{
					abund[gridValue - 1]++;
				}
			}
		}

		return abund;
	}

	public static int[] getAbundancesIncludingE(int[][] grid)
	{
		int gridLength = grid.length;
		ArrayList<Integer> types = new ArrayList<Integer>();

		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				int gridValue = grid[row][col];

				boolean neverSeen = true;
				for (int i = 0; i < types.size(); i++)
				{
					if (gridValue == types.get(i))
					{
						neverSeen = false;
						break;
					}
				}
				if (neverSeen)
				{
					types.add(gridValue);
				}

			}
		}

		int[] abund = new int[types.size()];
		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				int gridValue = grid[row][col];
				abund[gridValue]++;
			}
		}

		return abund;
	}

	/**
	 * takes an empty grid, adds critters, and tries to satisfy pair correlation function (averaged over each species in the landscape) for each possible pair of grid states (e.g.species 1, empty site). 
	 * calls on percolation grid - do NOT call percolation grid first unless you plan on have twice as many critters as the abundance parameter supplies.
	 * The algorithm works as follows: all the critters are added. Then, grid states are swapped. I call this cell swapping. If the swapped configuration gets you closer to your goal (param:PCGoal), then keep that configuration. If the swapped configuration is worse, revert back to the original state, but occasionally accept the swap with probability P(accept) = exp(-lambda* how close you are to your goal") where "how close you are to your goal is defined by the method getPCStat. 
	 * 
	 * @param abundances a vector of abundances 
	 * @param PCGoal the Pair Correlation Function(s) that the algorithm seeks to satisfy. There are three indexes (levels). The first is the distance between pairs, the second is the focal grid state, and the third is the pair grid state.
	 * @param lambda the higher the lambda, the greater the probability that you won't accept worse configurations after cell swaps
	 * @param epsilon if the difference between the grid's pair correlation function and the pair correlation function goal is less than epsilon, the algorithm will stop
	 * @param maxTries try this many cell swaps before giving up
	 * @return a time series of the PCStat statistic (my objective function), so you can observe the convergence over time
	 */
	public ArrayList<Double> makePairCorrelationGridFromScratch(int[] abundances, double[][][] PCGoal, double lambda, double epsilon, int maxTries)
	{
		// the object to return, a time series of "closeness" stats
		ArrayList<Double> stats = new ArrayList<Double>();
		// start by adding all the critters you need
		//System.out.println("got here");
		this.grid = makePercolationGrid(abundances);

		// the abundances vector supplied only includes species abundances. However, the algorithm tracks the pair correlations of empty sites, which are important grid states.
		// so we must find the number of empty cells
		int[] abundancesIncludingE = new int[abundances.length + 1];
		int total = 0;
		for (int i = 0; i < abundances.length; i++)
		{
			abundancesIncludingE[i + 1] = abundances[i];
			total += abundances[i];

		}
		// stick all the abundances, including the empty sites at index 0, into one vector
		abundancesIncludingE[0] = this.totalSites - total;

		// the max pair distance considered int the pair correlation function
		int maxR = PCGoal.length;
		//System.out.println("MAXR IS " + maxR);
		// the number of distinct cell states (empty sites included) that the grid contains
		int numStates = PCGoal[0].length;

		// gets the starting pair correlation state...
		double[][][] beforePC = getPCFunction(abundancesIncludingE, maxR);
		// and calculates how close it is to what we want (see getPCStat)
		double beforePCStat = getPCStat(beforePC, PCGoal);
		// instantiate the PCStat that is calculated after the cell swaps. Must be done outside of the main loop so that it can be used as the break criteria i.e. when the algorithm is finished.
		double afterPCStat = 0.0;
		//System.out.println("got here");
		int k = 0;
		do
		{
			// System.out.println(" ");
			// System.out.println("iteration " + k);
			// swap cells
			double[][][] afterPC = switchRandomStates(beforePC, abundancesIncludingE);

			// now how close is the grid configuration
			afterPCStat = getPCStat(afterPC, PCGoal);

			// System.out.println("iteration " + k);
			// System.out.println("afterPC was " + afterPCStat + " and beforePC was " + beforePCStat + ". Dif is " + (afterPCStat - beforePCStat));

			// if the post-cell-swap config is worse...
			if (afterPCStat > beforePCStat)
			{
				// System.out.println("no improvement");

				// ... then reject it with some probability and revert back to the pre-cell-swap config...
				if (generator.nextDouble() > Math.pow(exp, (-1 * lambda * afterPCStat)))
				{

					// System.out.println("didn't accept by chance with P(accept) " + Math.pow(exp, (-1 * lambda * afterPCStat)));

					// System.out.println("beforePC is now " + beforePCStat );

					// reverts back using the beforeAfter instance var, which is updated in the switchRandomStates method
					this.grid[this.beforeAfter[0][0]][this.beforeAfter[0][1]] = this.beforeAfter[0][2];
					this.grid[this.beforeAfter[1][0]][this.beforeAfter[1][1]] = this.beforeAfter[1][2];
				}
				// ... otherwise, accept the worse config. Helps to get us out of local minima
				else
				{
					// System.out.println("accept by chance with P(accept) " + Math.pow(exp, (-1 * lambda * afterPCStat)));
					beforePC = afterPC;
					beforePCStat = afterPCStat;
				}
			}
			// if the post-cell-swap config is better, just accept the change
			else
			{
				// System.out.println("accept");
				beforePC = afterPC;
				beforePCStat = afterPCStat;

			}
			// updates k, the maxTries counter
			k++;
			// adds the closeness statistic
			stats.add(beforePCStat);

			// System.out.println("PCStat is " + beforePCStat);
			// quit trying if you've tried maxTries times...
			if (k > maxTries)
			{
				break;
			}
			// ... or quit if you're close enough to the config that you want.
		} while (afterPCStat > epsilon);

		return stats;

	}

	
	
	
	
	/**
	 * takes an empty grid, adds critters, and tries to satisfy pair correlation function (averaged over each species in the landscape) for each possible pair of grid states (e.g.species 1, empty site). 
	 * does not call on percolation grid. 
	 * The algorithm works as follows: all the critters are added. Then, grid states are swapped. I call this cell swapping. If the swapped configuration gets you closer to your goal (param:PCGoal), then keep that configuration. If the swapped configuration is worse, revert back to the original state, but occasionally accept the swap with probability P(accept) = exp(-lambda* how close you are to your goal") where "how close you are to your goal is defined by the method getPCStat. 
	 * 
	 * @param abundances a vector of abundances 
	 * @param PCGoal the Pair Correlation Function(s) that the algorithm seeks to satisfy. There are three indexes (levels). The first is the distance between pairs, the second is the focal grid state, and the third is the pair grid state.
	 * @param lambda the higher the lambda, the greater the probability that you won't accept worse configurations after cell swaps
	 * @param epsilon if the difference between the grid's pair correlation function and the pair correlation function goal is less than epsilon, the algorithm will stop
	 * @param maxTries try this many cell swaps before giving up
	 * @return a time series of the PCStat statistic (my objective function), so you can observe the convergence over time
	 */
	public ArrayList<Double> makePairCorrelationGrid(int[] abundances, double[][][] PCGoal, double lambda, double epsilon, int maxTries)
	{
		// the object to return, a time series of "closeness" stats
		ArrayList<Double> stats = new ArrayList<Double>();
		// start by adding all the critters you need

		// the abundances vector supplied only includes species abundances. However, the algorithm tracks the pair correlations of empty sites, which are important grid states.
		// so we must find the number of empty cells
		int[] abundancesIncludingE = new int[abundances.length + 1];
		int total = 0;
		for (int i = 0; i < abundances.length; i++)
		{
			abundancesIncludingE[i + 1] = abundances[i];
			total += abundances[i];

		}
		// stick all the abundances, including the empty sites at index 0, into one vector
		abundancesIncludingE[0] = this.totalSites - total;

		// the max pair distance considered int the pair correlation function
		int maxR = PCGoal.length;
		// the number of distinct cell states (empty sites included) that the grid contains
		int numStates = PCGoal[0].length;

		// gets the starting pair correlation state...
		double[][][] beforePC = getPCFunction(abundancesIncludingE, maxR);
		// and calculates how close it is to what we want (see getPCStat)
		double beforePCStat = getPCStat(beforePC, PCGoal);
		// instantiate the PCStat that is calculated after the cell swaps. Must be done outside of the main loop so that it can be used as the break criteria i.e. when the algorithm is finished.
		double afterPCStat = 0.0;
		int k = 0;
		do
		{
			// swap cells
			double[][][] afterPC = switchRandomStates(beforePC, abundancesIncludingE);

			// now how close is the grid configuration
			afterPCStat = getPCStat(afterPC, PCGoal);

			// System.out.println("iteration " + k);
			// System.out.println("afterPC was " + afterPCStat + " and beforePC was " + beforePCStat + ". Dif is " + (afterPCStat - beforePCStat));

			// if the post-cell-swap config is worse...
			if (afterPCStat > beforePCStat)
			{
				// System.out.println("no improvement");

				// ... then reject it with some probability and revert back to the pre-cell-swap config...
				if (generator.nextDouble() > Math.pow(exp, (-1 * lambda * afterPCStat)))
				{

					// System.out.println("didn't accept by chance with P(accept) " + Math.pow(exp, (-1 * lambda * afterPCStat)));

					// System.out.println("beforePC is now " + beforePCStat );

					// reverts back using the beforeAfter instance var, which is updated in the switchRandomStates method
					this.grid[this.beforeAfter[0][0]][this.beforeAfter[0][1]] = this.beforeAfter[0][2];
					this.grid[this.beforeAfter[1][0]][this.beforeAfter[1][1]] = this.beforeAfter[1][2];
				}
				// ... otherwise, accept the worse config. Helps to get us out of local minima
				else
				{
					// System.out.println("accept by chance with P(accept) " + Math.pow(exp, (-1 * lambda * afterPCStat)));
					beforePC = afterPC;
					beforePCStat = afterPCStat;
				}
			}
			// if the post-cell-swap config is better, just accept the change
			else
			{
				// System.out.println("accept");
				beforePC = afterPC;
				beforePCStat = afterPCStat;

			}
			// updates k, the maxTries counter
			k++;
			// adds the closeness statistic
			stats.add(beforePCStat);

			/*System.out.println(" ");
			System.out.println("iteration " + k);
			System.out.println("PCStat is " + beforePCStat);*/
			// quit trying if you've tried maxTries times...
			if (k > maxTries)
			{
				break;
			}
			// ... or quit if you're close enough to the config that you want.
		} while (afterPCStat > epsilon);

		return stats;

	}

	
	
	
	
	/**
	 * get the current grid state
	 * @return a grid
	 */
	public int[][] getGrid()
	{
		return this.grid;
	}

	/**
	 * makes and returns a deep grid copy
	 * @return a deep grid copy
	 */
	public int[][] copyGrid()
	{
		int[][] result = new int[this.grid.length][];
		for (int i = 0; i < this.grid.length; i++)
		{
			result[i] = Arrays.copyOf(this.grid[i], this.grid[i].length);

		}
		return result;
	}

	/**
	 * calculates the statistic which determines when the makePairCorrelationGrid algorithm is close enough; the statistic is a meausre of closenes.
	 * each ELEMENT of the pair correlation function is considered equally (conditional probability that state j is paired with state k at a distance of i).
	 * the absolute value of the distance between each element of the current PC (curPC) and its corresponding element of the PC Goal are summed.
	 * the contribution of each pair of elements is divided by the total number of elements so that the final statistic is somewhere between 0 and 1.
	 * @param curPC the current pair correlation function
	 * @param PCNeeded the goal. the pair corrlelation function that you seek to get close to
	 * @return the statistic in the java doc description; a measure of closeness
	 * 
	 */
	public double getPCStat(double[][][] curPC, double[][][] PCNeeded)
	{

		int MaxR = curPC.length;
		int numStates = curPC[0].length;
		double stats = MaxR * numStates * numStates;
		double total = 0;
		for (int i = 0; i < MaxR; i++)
		{
			for (int j = 0; j < numStates; j++)
			{
				for (int k = 0; k < numStates; k++)
				{
					total += Math.abs(PCNeeded[i][j][k] - curPC[i][j][k]) / stats;
				}
			}

		}

		return total;

	}

	/**
	 * switches two different cell states at two randomly chosen locations. returns the post-cell-swap pair correlation function
	 * 
	 * @param PC the pair correlation function state pre-cell-swap
	 * @param abundancesIncludingE a vector of abundances
	 * @return post-cell-swap pair correlation function
	 */
	public double[][][] switchRandomStates(double[][][] PC, int[] abundancesIncludingE)
	{

		int numStates = abundancesIncludingE.length;
		int maxR = PC.length;
		// This method creates the post-cell-swap statistic by modifying the pre-cell-swap PCfunction state.
		// Since the makePairCorrelation method compares the PC closeness statistic from before and after the cells swap,...
		// we need to make a deep copy of the pre-cell-swap state (param PC), so that we don't accidently change both the pre-cell-swap PCFunction and the post-cell-swap PCFunction with the same operations.
		double[][][] PCCopy = new double[PC.length][PC[0].length][PC[0].length];
		for (int i = 0; i < maxR; i++)
		{
			for (int j = 0; j < numStates; j++)
			{
				for (int k = 0; k < numStates; k++)
				{
					PCCopy[i][j][k] = PC[i][j][k];
				}
			}

		}

		// get two random sites with two different values. Obviously, if we swap sites with the same states, nothing will change
		int gridValue1 = 0;
		int gridValue2 = 0;
		int row1 = 0;
		int col1 = 0;
		int row2 = 0;
		int col2 = 0;
		while (true)
		{
			row1 = generator.nextInt(this.gridLength);
			col1 = generator.nextInt(this.gridLength);
			row2 = generator.nextInt(this.gridLength);
			col2 = generator.nextInt(this.gridLength);
			gridValue1 = this.grid[row1][col1];
			gridValue2 = this.grid[row2][col2];
			if (gridValue1 != gridValue2)
			{
				break;
			}
		}

		// this part is tricky. We need to check whether the pair correlation distances of the two random sites overlap.
		// if they do overlap, then the regular old getSingleSpotPC function will tell us that we have two more pairs than we actually do.
		// the two pairs in question is a double counting of the two cell states at the two random sites
		// to remedy this, I use a method called getSingleSpotPCOverlap
		int overlapVal = doesOverlap(row1, col1, row2, col2);

		if (overlapVal <= maxR)
		{
			// subtract to see what you will lose from swapping cells
			PCCopy = subtractPCArrays(PCCopy, getSingleSpotPCOverlap(row1, col1, maxR, abundancesIncludingE, overlapVal, gridValue2));
			PCCopy = subtractPCArrays(PCCopy, getSingleSpotPC(row2, col2, maxR, abundancesIncludingE));
			// SWAP THE CELL STATES
			this.grid[row1][col1] = gridValue2;
			this.grid[row2][col2] = gridValue1;
			// add to see what you have gained from the new configuration
			PCCopy = addPCArrays(PCCopy, getSingleSpotPCOverlap(row1, col1, maxR, abundancesIncludingE, overlapVal, gridValue1));
			PCCopy = addPCArrays(PCCopy, getSingleSpotPC(row2, col2, maxR, abundancesIncludingE));
		}
		else
		{
			// subtract to see what you will lose from swapping cells
			PCCopy = subtractPCArrays(PCCopy, getSingleSpotPC(row1, col1, maxR, abundancesIncludingE));
			PCCopy = subtractPCArrays(PCCopy, getSingleSpotPC(row2, col2, maxR, abundancesIncludingE));
			// SWAP THE CELL STATES
			this.grid[row1][col1] = gridValue2;
			this.grid[row2][col2] = gridValue1;
			// add to see what you have gained from the new configuration
			PCCopy = addPCArrays(PCCopy, getSingleSpotPC(row1, col1, maxR, abundancesIncludingE));
			PCCopy = addPCArrays(PCCopy, getSingleSpotPC(row2, col2, maxR, abundancesIncludingE));
		}

		// update this instance var so that the makePairCorrelationGrid function know what the cell-swap sites/grid-states are in case it needs to revert back the pre-cell-swap site config
		this.beforeAfter[0][0] = row1;
		this.beforeAfter[0][1] = col1;
		this.beforeAfter[0][2] = gridValue1;
		this.beforeAfter[1][0] = row2;
		this.beforeAfter[1][1] = col2;
		this.beforeAfter[1][2] = gridValue2;

		return PCCopy;
	}

	/** calculates the difference (element-wise) between two pair correlation function
	 * @param PC1 a pair correlation function
	 * @param PC2 a pair correlation function whose elements will be subtracted
	 * @return an array of differences between two pair correlation functions
	 */
	public double[][][] subtractPCArrays(double[][][] PC1, double[][][] PC2)
	{
		int MaxRMinus1 = PC1.length;
		int numStates = PC1[0].length;
		for (int i = 0; i < MaxRMinus1; i++)
		{
			for (int j = 0; j < numStates; j++)
			{
				for (int k = 0; k < numStates; k++)
				{
					PC1[i][j][k] -= PC2[i][j][k];
				}
			}

		}

		return PC1;

	}

	/** calculates the sum (element-wise) between two pair correlation function
	 * @param PC1 a pair correlation function
	 * @param PC2 a pair correlation function whose elements will be added
	 * @return an array of sums of two pair correlation functions
	 */
	public double[][][] addPCArrays(double[][][] PC1, double[][][] PC2)
	{
		int MaxRMinus1 = PC1.length;
		int numStates = PC1[0].length;
		for (int i = 0; i < MaxRMinus1; i++)
		{
			for (int j = 0; j < numStates; j++)
			{
				for (int k = 0; k < numStates; k++)
				{
					PC1[i][j][k] += PC2[i][j][k];
				}
			}

		}

		return PC1;

	}

	/**
	 * calculates the total number of pairs in the range of the pair correlation function
	 * @param row the row of the focal site
	 * @param col tje column of the focal site
	 * @param maxR the maximum distance of pairs that is considered in the pair correlation function
	 * @param abundancesIncludingE a vector of abundances
	 * @return the contribution of a single site to the total average pair correlation function
	 */
	public double[][][] getSingleSpotPCRaw(int row, int col, int maxR, int[] abundancesIncludingE)
	{

		int local = grid[row][col];
		int numStates = abundancesIncludingE.length;
		double[][][] extras = new double[maxR][numStates][numStates];

		for (int i = 1; i <= maxR; i++)
		{
			int[] pos = new int[2];

			// calculate the number of neighbors in one square ring around the focal site
			int l = ((i * 2 + 1) * 4) - 4;
			int lOver4 = l / 4;
			int lOver2 = l / 2;

			// bisection algorithm finds the cell state of any neighbor in the square ring in the fewest operations
			for (int n = 0; n < l; n++)
			{
				if (n / lOver2 == 0)
				{
					if (n / lOver4 == 0)
					{
						pos[0] = -i;
						pos[1] = -i + (n % lOver4);
					}
					else
					{
						pos[0] = -i + (n % lOver4);
						pos[1] = i;
					}
				}
				else
				{
					if (n / lOver4 == 2)
					{
						pos[0] = i;
						pos[1] = i - (n % lOver4);
					}
					else
					{
						pos[0] = i - (n % lOver4);
						pos[1] = -i;
					}
				}

				pos[0] = WrapAround.wrapAround(row + pos[0], this.gridLength);
				pos[1] = WrapAround.wrapAround(col + pos[1], this.gridLength);
				int gridValue = grid[pos[0]][pos[1]];
				extras[i - 1][local][gridValue]++;
				extras[i - 1][gridValue][local]++;

			}
		}

		return extras;
	}

	/**
	 * calculates the contribution of a site site the pair corrlelation function
	 * @param row the row of the focal site
	 * @param col tje column of the focal site
	 * @param maxR the maximum distance of pairs that is considered in the pair correlation function
	 * @param abundancesIncludingE a vector of abundances
	 * @return the contribution of a single site to the total average pair correlation function
	 */
	/*
	 * public double[][][] getSingleSpotPC(int row, int col, int maxR, int[] abundancesIncludingE) {
	 * 
	 * int local = grid[row][col]; int numStates = abundancesIncludingE.length; double[][][] extras = new double[maxR][numStates][numStates];
	 * 
	 * for (int i = 1; i <= maxR; i++) { int[] pos = new int[2];
	 * 
	 * // calculate the number of neighbors in one square ring around the focal site int l = ((i * 2 + 1) * 4) - 4; int lOver4 = l / 4; int lOver2 = l / 2;
	 * 
	 * // bisection algorithm finds the cell state of any neighbor in the square ring in the fewest operations for (int n = 0; n < l; n++) { if (n / lOver2 == 0) { if (n / lOver4 == 0) { pos[0] = -i; pos[1] = -i + (n % lOver4); } else { pos[0] = -i + (n % lOver4); pos[1] = i; } } else { if (n / lOver4 == 2) { pos[0] = i; pos[1] = i - (n % lOver4); } else { pos[0] = i - (n % lOver4); pos[1] = -i; } }
	 * 
	 * pos[0] = WrapAround.wrapAround(row + pos[0], this.gridLength); pos[1] = WrapAround.wrapAround(col + pos[1], this.gridLength); int gridValue = grid[pos[0]][pos[1]]; extras[i - 1][local][gridValue]++; extras[i - 1][gridValue][local]++;
	 * 
	 * } }
	 * 
	 * // divides the "raw" neighbor counts by the number of possible neighbors (l) and the total abundances, to find the contribution of the site to the grid averaged pair correlation function. for (int i = 0; i < maxR; i++) { int l = (((i + 1) * 2 + 1) * 4) - 4; for (int j = 0; j < numStates; j++) { for (int k = 0; k < numStates; k++) { extras[i][j][k] /= (double) (l * abundancesIncludingE[j]); } } }
	 * 
	 * return extras; }
	 */
	/**
	 * calculates the contribution of a site site the pair corrlelation function
	 * @param row the row of the focal site
	 * @param col tje column of the focal site
	 * @param maxR the maximum distance of pairs that is considered in the pair correlation function
	 * @param abundancesIncludingE a vector of abundances
	 * @return the contribution of a single site to the total average pair correlation function
	 */
	public double[][][] getSingleSpotPC(int row, int col, int maxR, int[] abundancesIncludingE)
	{

		int local = grid[row][col];
		int numStates = abundancesIncludingE.length;
		double[][][] extras = new double[maxR][numStates][numStates];

		for (int i = 1; i <= maxR; i++)
		{
			int[] pos = new int[2];

			// calculate the number of neighbors in one square ring around the focal site
			int l = ((i * 2 + 1) * 4) - 4;
			int lOver4 = l / 4;
			int lOver2 = l / 2;

			// bisection algorithm finds the cell state of any neighbor in the square ring in the fewest operations

			for (int n = 0; n < lOver4; n++)
			{
				pos[0] = -i;
				pos[1] = -i + (n % lOver4);
				pos[0] = WrapAround.wrapAround(row + pos[0], this.gridLength);
				pos[1] = WrapAround.wrapAround(col + pos[1], this.gridLength);
				int gridValue = grid[pos[0]][pos[1]];
				extras[i - 1][local][gridValue]++;
				extras[i - 1][gridValue][local]++;
			}
			for (int n = lOver4; n < lOver2; n++)
			{
				pos[0] = -i + (n % lOver4);
				pos[1] = i;
				pos[0] = WrapAround.wrapAround(row + pos[0], this.gridLength);
				pos[1] = WrapAround.wrapAround(col + pos[1], this.gridLength);
				int gridValue = grid[pos[0]][pos[1]];
				extras[i - 1][local][gridValue]++;
				extras[i - 1][gridValue][local]++;
			}
			for (int n = lOver2; n < 3 * lOver4; n++)
			{
				pos[0] = i;
				pos[1] = i - (n % lOver4);
				pos[0] = WrapAround.wrapAround(row + pos[0], this.gridLength);
				pos[1] = WrapAround.wrapAround(col + pos[1], this.gridLength);
				int gridValue = grid[pos[0]][pos[1]];
				extras[i - 1][local][gridValue]++;
				extras[i - 1][gridValue][local]++;
			}
			for (int n = 3 * lOver4; n < l; n++)
			{
				pos[0] = i - (n % lOver4);
				pos[1] = -i;
				pos[0] = WrapAround.wrapAround(row + pos[0], this.gridLength);
				pos[1] = WrapAround.wrapAround(col + pos[1], this.gridLength);
				int gridValue = grid[pos[0]][pos[1]];
				extras[i - 1][local][gridValue]++;
				extras[i - 1][gridValue][local]++;
			}
		}

		// divides the "raw" neighbor counts by the number of possible neighbors (l) and the total abundances, to find the contribution of the site to the grid averaged pair correlation function.
		for (int i = 0; i < maxR; i++)
		{
			int l = (((i + 1) * 2 + 1) * 4) - 4;
			for (int j = 0; j < numStates; j++)
			{
				for (int k = 0; k < numStates; k++)
				{
					extras[i][j][k] /= (double) (l * abundancesIncludingE[j]);
				}
			}
		}

		return extras;
	}

	/**
	 * calculates the contribution of a site site the pair corrlelation function, and corrects for overapping pair correlation function ranges
	 * @param row the row of the focal site
	 * @param col tje column of the focal site
	 * @param maxR the maximum distance of pairs that is considered in the pair correlation function
	 * @param abundancesIncludingE a vector of abundances
	 * @return the contribution of a single site to the total average pair correlation function
	 */
	public double[][][] getSingleSpotPCOverlap(int row, int col, int maxR, int[] abundancesIncludingE, int overLapRadius, int gridValueNotToCount)
	{

		int local = grid[row][col];
		int numStates = abundancesIncludingE.length;
		double[][][] extras = new double[maxR][numStates][numStates];
		// correction for overlap
		extras[overLapRadius - 1][local][gridValueNotToCount]--;
		extras[overLapRadius - 1][gridValueNotToCount][local]--;

		for (int i = 1; i <= maxR; i++)
		{
			int[] pos = new int[2];

			// calculate the number of neighbors in one square ring around the focal site
			int l = ((i * 2 + 1) * 4) - 4;
			int lOver4 = l / 4;
			int lOver2 = l / 2;

			// bisection algorithm finds the cell state of any neighbor in the square ring in the fewest operations
			for (int n = 0; n < l; n++)
			{
				if (n / lOver2 == 0)
				{
					if (n / lOver4 == 0)
					{
						pos[0] = -i;
						pos[1] = -i + (n % lOver4);
					}
					else
					{
						pos[0] = -i + (n % lOver4);
						pos[1] = i;
					}
				}
				else
				{
					if (n / lOver4 == 2)
					{
						pos[0] = i;
						pos[1] = i - (n % lOver4);
					}
					else
					{
						pos[0] = i - (n % lOver4);
						pos[1] = -i;
					}
				}

				pos[0] = WrapAround.wrapAround(row + pos[0], this.gridLength);
				pos[1] = WrapAround.wrapAround(col + pos[1], this.gridLength);
				int gridValue = grid[pos[0]][pos[1]];
				extras[i - 1][local][gridValue]++;
				extras[i - 1][gridValue][local]++;

			}
		}
		// divides the "raw" neighbor counts by the number of possible neighbors (l) and the total abundances, to find the contribution of the site to the grid averaged pair correlation function.

		for (int i = 0; i < maxR; i++)
		{
			int l = (((i + 1) * 2 + 1) * 4) - 4;
			for (int j = 0; j < numStates; j++)
			{
				for (int k = 0; k < numStates; k++)
				{
					extras[i][j][k] /= (double) (l * abundancesIncludingE[j]);
				}
			}
		}

		return extras;
	}

	/**
	 * gives the possible overlap between two sites 
	 * 
	 * @param row1
	 * @param col1
	 * @param row2
	 * @param col2
	 * @return the distance between the neighbor ranges of two sites
	 */
	public int doesOverlap(int row1, int col1, int row2, int col2)
	{
		int rowDist1 = WrapAround.wrapAround(row1 - row2, this.gridLength);
		int colDist1 = WrapAround.wrapAround(col1 - col2, this.gridLength);
		int rowDist2 = WrapAround.wrapAround(row2 - row1, this.gridLength);
		int colDist2 = WrapAround.wrapAround(col2 - col1, this.gridLength);
		int rowDist = min(rowDist1, rowDist2);
		int colDist = min(colDist1, colDist2);
		// System.out.println("overlap is " + max(rowDist, colDist));
		return max(rowDist, colDist);
	}

	public int max(int val1, int val2)
	{
		if (val1 > val2)
		{
			return val1;
		}
		else
		{
			return val2;
		}
	}

	public int min(int val1, int val2)
	{
		if (val1 > val2)
		{
			return val2;
		}
		else
		{
			return val1;
		}
	}

	/*
	*//**
		* caluculates the pair correlelation function (averaged over each cell in the grid)
		* @param numStates the number of distinct grid states
		* @param endRadius the maximum "radius" of the VonNeumann (think 8 cell neighborhood) to be considered in the pair correlation function
		* @return the pair correlation function
		*/
	/*
	 * public double[][][] getPCFunction(int numStates, int endRadius) { double[][][] PCFunc = new double[endRadius][numStates][numStates]; // double[] possibleNeighbors = new double[endRadius]; for (int i = 0; i < endRadius; i++) {
	 * 
	 * PCFunc[i] = getPCRaw(numStates, i + 1); if (i != 0) { for (int k = 0; k < numStates; k++) { for (int l = 0; l < numStates; l++) { PCFunc[i][k][l] -= PCFunc[i - 1][k][l];
	 * 
	 * }
	 * 
	 * } } } for (int i = 0; i < endRadius; i++) { for (int k = 0; k < numStates; k++) { for (int l = 0; l < numStates; l++) { double possibleNeighbors = (((i + 1) * 2 + 1) * 4) - 4; PCFunc[i][k][l] /= (double) possibleNeighbors; } } }
	 * 
	 * return PCFunc; }
	 */

	public double[][][] getPCFunction(int[] abundancesIncludingE, int endRadius)
	{
		int numStates = abundancesIncludingE.length;
		double[][][] PCFunc = new double[endRadius][numStates][numStates];
		// double[] possibleNeighbors = new double[endRadius];
		for (int i = 0; i < endRadius; i++)
		{
			// for each pair distance ("rings" of a VonNeumann neighborhood) calculate the total number of pairs in the ENTIRE VonNeumamm neighborhood
			PCFunc[i] = getPCRaw(numStates, i + 1);
		}
		// subtract all the pairs in the next smallest neighbor hood to just get the number of pairs in the VonNeumann square "ring" i.e. the pair correlation distance
		for (int i = endRadius - 1; i > 0; i--)
		{
			for (int k = 0; k < numStates; k++)
			{
				for (int l = 0; l < numStates; l++)
				{
					// System.out.println("RAW" + i + " " + k + " " + l + " is " + PCFunc[i][k][l]);
					PCFunc[i][k][l] -= PCFunc[i - 1][k][l];
				}
			}
		}

		// average each pair count over the number of possible neighbors in the pair distance square "ring" and the total number of cell states of that type
		for (int i = 0; i < endRadius; i++)
		{
			for (int k = 0; k < numStates; k++)
			{
				for (int l = 0; l < numStates; l++)
				{
					int possibleNeighbors = (((i + 1) * 2 + 1) * 4) - 4;
					PCFunc[i][k][l] /= (double) (possibleNeighbors * abundancesIncludingE[k]);
					// System.out.println(i + " " + k + " " + l + " is " + PCFunc[i][k][l]);
				}
			}
		}
		return PCFunc;
	}

	public static double[][][] getPCFunction(int[][] grid, int endRadius)
	{
		int[] abundancesIncludingE = MakeGrids.getAbundancesIncludingE(grid);
		int numStates = abundancesIncludingE.length;
		/*System.out.println("end radius is " + endRadius);
		System.out.println("numStates is " + numStates);*/
		double[][][] PCFunc = new double[endRadius][numStates][numStates];
		// double[] possibleNeighbors = new double[endRadius];
		for (int i = 0; i < endRadius; i++)
		{
			// for each pair distance ("rings" of a VonNeumann neighborhood) calculate the total number of pairs in the ENTIRE VonNeumamm neighborhood
			PCFunc[i] = MakeGrids.getPCRaw(grid, numStates, i + 1);
		}
		// System.out.println(PCFunc[endRadius][1][1]);
		// subtract all the pairs in the next smallest neighbor hood to just get the number of pairs in the VonNeumann square "ring" i.e. the pair correlation distance
		for (int i = endRadius - 1; i > 0; i--)
		{
			for (int k = 0; k < numStates; k++)
			{
				for (int l = 0; l < numStates; l++)
				{
					//System.out.println("RAW" + i + " " + k + " " + l + " is " + PCFunc[i][k][l]);

					PCFunc[i][k][l] -= PCFunc[i - 1][k][l];

				}

			}
		}

		// average each pair count over the number of possible neighbors in the pair distance square "ring" and the total number of cell states of that type
		for (int i = 0; i < endRadius; i++)
		{
			for (int k = 0; k < numStates; k++)
			{
				for (int l = 0; l < numStates; l++)
				{
					int possibleNeighbors = (((i + 1) * 2 + 1) * 4) - 4;
					PCFunc[i][k][l] /= (double) (possibleNeighbors * abundancesIncludingE[k]);
					//System.out.println(i + " " + k + " " + l + " is " + PCFunc[i][k][l]);
				}
			}
		}

		return PCFunc;
	}

	/*
	 * public double[][] getPC(int numStates, int radius) { int possibleNeighbors = (int) (Math.pow(radius * 2 + 1, 2) - 1); // System.out.println("possibleNeighbors is " + possibleNeighbors); // double[][] EGrid = new double[this.gridLength][this.gridLength]; double[][][] posE = new double[this.gridLength][3][numStates]; double[][] PC = new double[numStates][numStates]; int[] baseCounter = new int[numStates];
	 * 
	 * // this algorithm scans right across the grid, goes down one line, scans again, and so on (just like reading). It's time complexity is O(n) (where n is the number of microsites) compared to O(n^2) of a trivial moving window algorithm. // It works by summing all of the // cumulative birth rates in the topmost row, the bottommost row, and everything in between. These values are stored in the pos array. // 0 is TOP, 1 is MID, and 2 is BOT. when you to the next gid location, your cumulative growth rate is TOPnew + MIDnew + BOTnew. MIDnew is simply MIDnorth + BOTnorth - TOPnew. // (where north indicates the position above you). TOPnew can be written TOPold - TOPold.leftMost + TOPnew.rightmost. BOTnew can be written BOTold - BOTold.leftMost + BOTnew.rightmost. // In actuality, the algorithm is more complex because there are different subroutines that depend on your grid position. When both the row and the column are 0 // (i.e. the first microsite you investigate, you have to go ahead
	 * and find the values of every neighbor, and then store these in the pos array. When the row is is still zero but you've gotten // past the first cell, the new top can be rexpressed as TOPold - TOPold.leftMost + TOPnew.rightmost. Same with the bottom. For the MID, you essentialy do the same thing, except the righmost and // lestmost values are sums over multiple rows. If you've gotten past the first row but the column is zero, then you have to caculate a new top and bottom. If you're in the meat // of the grid, follow the basic procedure outlined in the beginning of this description. for (int row = 0; row < this.gridLength; row++) { for (int col = 0; col < this.gridLength; col++) { int base = grid[row][col]; baseCounter[base]++; // the first loop is the most costly, each TOP, MID, and BOT is caclulated independently. if (row == 0 && col == 0) { // pos = new double[this.numberOfSpecies][this.gridLength][3];
	 * 
	 * // use this to make sure there are no negative values. diagnostic tells you where the algorithm fucks up for (int q = 0; q < this.gridLength; q++) { for (int w = 0; w < 3; w++) { for (int e = 0; e < numStates; e++) { if (posE[q][w][e] < 0) { System.out.println("row is " + row); System.out.println("col is " + col); System.out.println(posE[q][w][e]); throw new IllegalStateException(); } } } }
	 * 
	 * int row2 = row - radius; for (int col2 = col - radius; col2 <= col + radius; col2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); int gridValue = grid[realRow][realCol];
	 * 
	 * posE[col][0][gridValue]++;
	 * 
	 * }
	 * 
	 * // System.out.println("col == " + col + " first is " + first[1]);
	 * 
	 * for (int col2 = col - radius; col2 <= col + radius; col2++) { for (row2 = row - radius + 1; row2 <= row + radius - 1; row2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); int gridValue = grid[realRow][realCol]; posE[col][1][gridValue]++;
	 * 
	 * } }
	 * 
	 * 
	 * // System.out.println("col == 0 middle is " + middle[1]);
	 * 
	 * row2 = row + radius; for (int col2 = col - radius; col2 <= col + radius; col2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); int gridValue = grid[realRow][realCol]; posE[col][2][gridValue]++;
	 * 
	 * }
	 * 
	 * 
	 * } else if (row == 0) {
	 * 
	 * // generate new top int NWRow = WrapAround.wrapAround(row - radius, this.gridLength); int NWCol = WrapAround.wrapAround(col - 1 - radius, this.gridLength); int NERow = WrapAround.wrapAround(row - radius, this.gridLength); int NECol = WrapAround.wrapAround(col + radius, this.gridLength);
	 * 
	 * int SWRow = WrapAround.wrapAround(row + radius, this.gridLength); int SWCol = WrapAround.wrapAround(col - 1 - radius, this.gridLength); int SERow = WrapAround.wrapAround(row + radius, this.gridLength); int SECol = WrapAround.wrapAround(col + radius, this.gridLength);
	 * 
	 * // double[] NWCorner = new double[numStates]; // double[] NECorner = new double[numStates];
	 * 
	 * for (int s = 0; s < numStates; s++) { int NWCorner = 0; int NECorner = 0; if (grid[NWRow][NWCol] == s) { NWCorner = 1; }
	 * 
	 * if (grid[NERow][NECol] == s) { NECorner = 1; } posE[col][0][s] = posE[col - 1][0][s] - NWCorner + NECorner; }
	 * 
	 * 
	 * 
	 * double[] leftSideOfOldMid = new double[numStates]; int col2 = col - radius - 1; for (int row2 = row - radius + 1; row2 <= row + radius - 1; row2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); int gridValue = grid[realRow][realCol];
	 * 
	 * leftSideOfOldMid[gridValue]++; }
	 * 
	 * 
	 * double[] rightSideOfNewMid = new double[numStates]; col2 = col + radius; for (int row2 = row - radius + 1; row2 <= row + radius - 1; row2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); int gridValue = grid[realRow][realCol];
	 * 
	 * rightSideOfNewMid[gridValue]++; }
	 * 
	 * for (int s = 0; s < numStates; s++) { posE[col][1][s] = posE[col - 1][1][s] - leftSideOfOldMid[s] + rightSideOfNewMid[s]; }
	 * 
	 * 
	 * 
	 * for (int s = 0; s < numStates; s++) { int SWCorner = 0; int SECorner = 0; if (grid[SWRow][SWCol] == s) { SWCorner = 1; }
	 * 
	 * if (grid[SERow][SECol] == s) { SECorner = 1; } posE[col][2][s] = posE[col - 1][2][s] - SWCorner + SECorner; }
	 * 
	 * 
	 * }
	 * 
	 * // if we're on a new row, but not the first row, the TOPnew and BOTnew must be calculated independently else if (col == 0) { for (int s = 0; s < numStates; s++) { posE[col][0][s] = 0; }
	 * 
	 * int row2 = row - radius; for (int col2 = col - radius; col2 <= col + radius; col2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); int gridValue = grid[realRow][realCol];
	 * 
	 * posE[col][0][gridValue]++;
	 * 
	 * }
	 * 
	 * 
	 * for (int s = 0; s < numStates; s++) { posE[col][1][s] += posE[col][2][s] - posE[col][0][s]; }
	 * 
	 * 
	 * for (int s = 0; s < numStates; s++) { posE[col][2][s] = 0; }
	 * 
	 * 
	 * row2 = row + radius; for (int col2 = col - radius; col2 <= col + radius; col2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); int gridValue = grid[realRow][realCol];
	 * 
	 * posE[col][2][gridValue]++; }
	 * 
	 * 
	 * } else {
	 * 
	 * // generate new top int NWRow = WrapAround.wrapAround(row - radius, this.gridLength); int NWCol = WrapAround.wrapAround(col - 1 - radius, this.gridLength); int NERow = WrapAround.wrapAround(row - radius, this.gridLength); int NECol = WrapAround.wrapAround(col + radius, this.gridLength);
	 * 
	 * int SWRow = WrapAround.wrapAround(row + radius, this.gridLength); int SWCol = WrapAround.wrapAround(col - 1 - radius, this.gridLength); int SERow = WrapAround.wrapAround(row + radius, this.gridLength); int SECol = WrapAround.wrapAround(col + radius, this.gridLength);
	 * 
	 * for (int s = 0; s < numStates; s++) { int NWCorner = 0; int NECorner = 0; if (grid[NWRow][NWCol] == s) { NWCorner = 1; }
	 * 
	 * if (grid[NERow][NECol] == s) { NECorner = 1; } posE[col][0][s] = posE[col - 1][0][s] - NWCorner + NECorner; }
	 * 
	 * 
	 * 
	 * for (int s = 0; s < numStates; s++) { posE[col][1][s] += posE[col][2][s] - posE[col][0][s]; }
	 * 
	 * 
	 * for (int s = 0; s < numStates; s++) { int SWCorner = 0; int SECorner = 0; if (grid[SWRow][SWCol] == s) { SWCorner = 1; }
	 * 
	 * if (grid[SERow][SECol] == s) { SECorner = 1; } posE[col][2][s] = posE[col - 1][2][s] - SWCorner + SECorner; }
	 * 
	 * 
	 * 
	 * } for (int s = 0; s < numStates; s++) { int correctForMiddle = 0; // if (grid[row][col] == s) // { // correctForMiddle = -1; // } PC[base][s] += (posE[col][0][s] + posE[col][1][s] + posE[col][2][s] + correctForMiddle); } } }
	 * 
	 * for (int k = 0; k < numStates; k++) { for (int l = 0; l < numStates; l++) { PC[k][l] /= (double) (baseCounter[k] * possibleNeighbors); } }
	 * 
	 * return PC; }
	 */

	public double[][] getPCRaw(int numStates, int radius)
	{
		// int possibleNeighbors = (int) (Math.pow(radius * 2 + 1, 2) - 1);
		// System.out.println("possibleNeighbors is " + possibleNeighbors);
		// double[][] EGrid = new double[this.gridLength][this.gridLength];
		double[][][] posE = new double[this.gridLength][3][numStates];
		double[][] PC = new double[numStates][numStates];
		// int[] baseCounter = new int[numStates];

		// this algorithm scans right across the grid, goes down one line, scans again, and so on (just like reading). It's time complexity is O(n) (where n is the number of microsites) compared to O(n*r) (where r is the number of sites within the neighborhood of the focal cell) of a trivial cell-counting algorithm.
		// It works by summing all of the
		// cumulative birth rates in the topmost row, the bottommost row, and everything in between. These values are stored in the pos array.
		// 0 is TOP, 1 is MID, and 2 is BOT. when you to the next grid location (scanning right across the grid, like a printer), your cumulative growth rate is TOPnew + MIDnew + BOTnew. MIDnew is simply MIDnorth + BOTnorth - TOPnew.
		// (where north indicates the position above you). TOPnew can be written TOPold - TOPold.leftMost + TOPnew.rightmost. BOTnew can be written BOTold - BOTold.leftMost + BOTnew.rightmost.
		// In actuality, the algorithm is more complex because there are different subroutines that depend on your grid position. When both the row and the column are 0
		// (i.e. the first microsite you investigate, you have to go ahead and find the values of every neighbor, and then store these in the pos array. When the row is is still zero but you've gotten
		// past the first cell, the new top can be rexpressed as TOPold - TOPold.leftMost + TOPnew.rightmost. Same with the bottom. For the MID, you essentialy do the same thing, except the righmost and
		// lestmost values are sums over multiple rows. If you've gotten past the first row but the column is zero, then you have to caculate a new top and bottom. If you're in the meat
		// of the grid, follow the basic procedure outlined in the beginning of this description.
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				int base = grid[row][col];
				// baseCounter[base]++;
				// the first loop is the most costly, each TOP, MID, and BOT is caclulated independently.
				if (row == 0 && col == 0)
				{
					// pos = new double[this.numberOfSpecies][this.gridLength][3];

					int row2 = row - radius;
					for (int col2 = col - radius; col2 <= col + radius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = grid[realRow][realCol];

						posE[col][0][gridValue]++;

					}

					// System.out.println("col == " + col + " first is " + first[1]);

					for (int col2 = col - radius; col2 <= col + radius; col2++)
					{
						for (row2 = row - radius + 1; row2 <= row + radius - 1; row2++)
						{
							int realRow = WrapAround.wrapAround(row2, this.gridLength);
							int realCol = WrapAround.wrapAround(col2, this.gridLength);
							int gridValue = grid[realRow][realCol];
							posE[col][1][gridValue]++;

						}
					}

					// System.out.println("col == 0 middle is " + middle[1]);

					row2 = row + radius;
					for (int col2 = col - radius; col2 <= col + radius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = grid[realRow][realCol];
						posE[col][2][gridValue]++;

					}

				}
				else if (row == 0)
				{

					// generate new top
					int NWRow = WrapAround.wrapAround(row - radius, this.gridLength);
					int NWCol = WrapAround.wrapAround(col - 1 - radius, this.gridLength);
					int NERow = WrapAround.wrapAround(row - radius, this.gridLength);
					int NECol = WrapAround.wrapAround(col + radius, this.gridLength);

					int SWRow = WrapAround.wrapAround(row + radius, this.gridLength);
					int SWCol = WrapAround.wrapAround(col - 1 - radius, this.gridLength);
					int SERow = WrapAround.wrapAround(row + radius, this.gridLength);
					int SECol = WrapAround.wrapAround(col + radius, this.gridLength);

					// double[] NWCorner = new double[numStates];
					// double[] NECorner = new double[numStates];

					for (int s = 0; s < numStates; s++)
					{
						int NWCorner = 0;
						int NECorner = 0;
						if (grid[NWRow][NWCol] == s)
						{
							NWCorner = 1;
						}

						if (grid[NERow][NECol] == s)
						{
							NECorner = 1;
						}
						posE[col][0][s] = posE[col - 1][0][s] - NWCorner + NECorner;
					}

					double[] leftSideOfOldMid = new double[numStates];
					int col2 = col - radius - 1;
					for (int row2 = row - radius + 1; row2 <= row + radius - 1; row2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = grid[realRow][realCol];

						leftSideOfOldMid[gridValue]++;
					}

					double[] rightSideOfNewMid = new double[numStates];
					col2 = col + radius;
					for (int row2 = row - radius + 1; row2 <= row + radius - 1; row2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = grid[realRow][realCol];

						rightSideOfNewMid[gridValue]++;
					}

					for (int s = 0; s < numStates; s++)
					{
						posE[col][1][s] = posE[col - 1][1][s] - leftSideOfOldMid[s] + rightSideOfNewMid[s];
					}

					for (int s = 0; s < numStates; s++)
					{
						int SWCorner = 0;
						int SECorner = 0;
						if (grid[SWRow][SWCol] == s)
						{
							SWCorner = 1;
						}

						if (grid[SERow][SECol] == s)
						{
							SECorner = 1;
						}
						posE[col][2][s] = posE[col - 1][2][s] - SWCorner + SECorner;
					}

				}

				// if we're on a new row, but not the first row, the TOPnew and BOTnew must be calculated independently
				else if (col == 0)
				{
					for (int s = 0; s < numStates; s++)
					{
						posE[col][0][s] = 0;
					}

					int row2 = row - radius;
					for (int col2 = col - radius; col2 <= col + radius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = grid[realRow][realCol];

						posE[col][0][gridValue]++;

					}

					for (int s = 0; s < numStates; s++)
					{
						posE[col][1][s] += posE[col][2][s] - posE[col][0][s];
					}

					for (int s = 0; s < numStates; s++)
					{
						posE[col][2][s] = 0;
					}

					row2 = row + radius;
					for (int col2 = col - radius; col2 <= col + radius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = grid[realRow][realCol];

						posE[col][2][gridValue]++;
					}

				}
				else
				{

					// generate new top
					int NWRow = WrapAround.wrapAround(row - radius, this.gridLength);
					int NWCol = WrapAround.wrapAround(col - 1 - radius, this.gridLength);
					int NERow = WrapAround.wrapAround(row - radius, this.gridLength);
					int NECol = WrapAround.wrapAround(col + radius, this.gridLength);

					int SWRow = WrapAround.wrapAround(row + radius, this.gridLength);
					int SWCol = WrapAround.wrapAround(col - 1 - radius, this.gridLength);
					int SERow = WrapAround.wrapAround(row + radius, this.gridLength);
					int SECol = WrapAround.wrapAround(col + radius, this.gridLength);

					for (int s = 0; s < numStates; s++)
					{
						int NWCorner = 0;
						int NECorner = 0;
						if (grid[NWRow][NWCol] == s)
						{
							NWCorner = 1;
						}

						if (grid[NERow][NECol] == s)
						{
							NECorner = 1;
						}
						posE[col][0][s] = posE[col - 1][0][s] - NWCorner + NECorner;
					}

					for (int s = 0; s < numStates; s++)
					{
						posE[col][1][s] += posE[col][2][s] - posE[col][0][s];
					}

					for (int s = 0; s < numStates; s++)
					{
						int SWCorner = 0;
						int SECorner = 0;
						if (grid[SWRow][SWCol] == s)
						{
							SWCorner = 1;
						}

						if (grid[SERow][SECol] == s)
						{
							SECorner = 1;
						}
						posE[col][2][s] = posE[col - 1][2][s] - SWCorner + SECorner;
					}

				}
				int correctForMiddle = 0;

				for (int s = 0; s < numStates; s++)
				{
					correctForMiddle = 0;
					if (base == s)
					{

						correctForMiddle = -1;
					}
					PC[base][s] += (posE[col][0][s] + posE[col][1][s] + posE[col][2][s] + correctForMiddle);
				}

				/*
				 * if (row == 2 && col == 2) { System.out.println(); for (int g = 1; g <= 3; g++) { for (int h = 1; h <= 3; h++) { System.out.print(this.grid[g][h] + "  "); } System.out.println(" "); } for (int s = 0; s < numStates; s++) { correctForMiddle = 0; if (base == s) {
				 * 
				 * correctForMiddle = -1; } System.out.println("PCFuncRaw: base is " + base + ". cor with " + s + " is " + (posE[col][0][s] + posE[col][1][s] + posE[col][2][s] + correctForMiddle)); } }
				 */
			}
		}

		/*
		 * for (int k = 0; k < numStates; k++) { for (int l = 0; l < numStates; l++) { PC[k][l] /= (double) (baseCounter[k]); } }
		 */

		return PC;
	}

	public static double[][] getPCRaw(int[][] grid, int numStates, int radius)
	{
		int gridLength = grid.length;
		// int possibleNeighbors = (int) (Math.pow(radius * 2 + 1, 2) - 1);
		// System.out.println("possibleNeighbors is " + possibleNeighbors);
		// double[][] EGrid = new double[gridLength][gridLength];
		double[][][] posE = new double[gridLength][3][numStates];
		double[][] PC = new double[numStates][numStates];
		// int[] baseCounter = new int[numStates];

		// this algorithm scans right across the grid, goes down one line, scans again, and so on (just like reading). It's time complexity is O(n) (where n is the number of microsites) compared to O(n*r) (where r is the number of sites within the neighborhood of the focal cell) of a trivial cell-counting algorithm.
		// It works by summing all of the
		// cumulative birth rates in the topmost row, the bottommost row, and everything in between. These values are stored in the pos array.
		// 0 is TOP, 1 is MID, and 2 is BOT. when you to the next grid location (scanning right across the grid, like a printer), your cumulative growth rate is TOPnew + MIDnew + BOTnew. MIDnew is simply MIDnorth + BOTnorth - TOPnew.
		// (where north indicates the position above you). TOPnew can be written TOPold - TOPold.leftMost + TOPnew.rightmost. BOTnew can be written BOTold - BOTold.leftMost + BOTnew.rightmost.
		// In actuality, the algorithm is more complex because there are different subroutines that depend on your grid position. When both the row and the column are 0
		// (i.e. the first microsite you investigate, you have to go ahead and find the values of every neighbor, and then store these in the pos array. When the row is is still zero but you've gotten
		// past the first cell, the new top can be rexpressed as TOPold - TOPold.leftMost + TOPnew.rightmost. Same with the bottom. For the MID, you essentialy do the same thing, except the righmost and
		// lestmost values are sums over multiple rows. If you've gotten past the first row but the column is zero, then you have to caculate a new top and bottom. If you're in the meat
		// of the grid, follow the basic procedure outlined in the beginning of this description.
		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				int base = grid[row][col];
				// baseCounter[base]++;
				// the first loop is the most costly, each TOP, MID, and BOT is caclulated independently.
				if (row == 0 && col == 0)
				{
					// pos = new double[numberOfSpecies][gridLength][3];

					int row2 = row - radius;
					for (int col2 = col - radius; col2 <= col + radius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, gridLength);
						int realCol = WrapAround.wrapAround(col2, gridLength);
						int gridValue = grid[realRow][realCol];

						posE[col][0][gridValue]++;

					}

					// System.out.println("col == " + col + " first is " + first[1]);

					for (int col2 = col - radius; col2 <= col + radius; col2++)
					{
						for (row2 = row - radius + 1; row2 <= row + radius - 1; row2++)
						{
							int realRow = WrapAround.wrapAround(row2, gridLength);
							int realCol = WrapAround.wrapAround(col2, gridLength);
							int gridValue = grid[realRow][realCol];
							posE[col][1][gridValue]++;

						}
					}

					// System.out.println("col == 0 middle is " + middle[1]);

					row2 = row + radius;
					for (int col2 = col - radius; col2 <= col + radius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, gridLength);
						int realCol = WrapAround.wrapAround(col2, gridLength);
						int gridValue = grid[realRow][realCol];
						posE[col][2][gridValue]++;

					}

				}
				else if (row == 0)
				{

					// generate new top
					int NWRow = WrapAround.wrapAround(row - radius, gridLength);
					int NWCol = WrapAround.wrapAround(col - 1 - radius, gridLength);
					int NERow = WrapAround.wrapAround(row - radius, gridLength);
					int NECol = WrapAround.wrapAround(col + radius, gridLength);

					int SWRow = WrapAround.wrapAround(row + radius, gridLength);
					int SWCol = WrapAround.wrapAround(col - 1 - radius, gridLength);
					int SERow = WrapAround.wrapAround(row + radius, gridLength);
					int SECol = WrapAround.wrapAround(col + radius, gridLength);

					// double[] NWCorner = new double[numStates];
					// double[] NECorner = new double[numStates];

					for (int s = 0; s < numStates; s++)
					{
						int NWCorner = 0;
						int NECorner = 0;
						if (grid[NWRow][NWCol] == s)
						{
							NWCorner = 1;
						}

						if (grid[NERow][NECol] == s)
						{
							NECorner = 1;
						}
						posE[col][0][s] = posE[col - 1][0][s] - NWCorner + NECorner;
					}

					double[] leftSideOfOldMid = new double[numStates];
					int col2 = col - radius - 1;
					for (int row2 = row - radius + 1; row2 <= row + radius - 1; row2++)
					{
						int realRow = WrapAround.wrapAround(row2, gridLength);
						int realCol = WrapAround.wrapAround(col2, gridLength);
						int gridValue = grid[realRow][realCol];

						leftSideOfOldMid[gridValue]++;
					}

					double[] rightSideOfNewMid = new double[numStates];
					col2 = col + radius;
					for (int row2 = row - radius + 1; row2 <= row + radius - 1; row2++)
					{
						int realRow = WrapAround.wrapAround(row2, gridLength);
						int realCol = WrapAround.wrapAround(col2, gridLength);
						int gridValue = grid[realRow][realCol];

						rightSideOfNewMid[gridValue]++;
					}

					for (int s = 0; s < numStates; s++)
					{
						posE[col][1][s] = posE[col - 1][1][s] - leftSideOfOldMid[s] + rightSideOfNewMid[s];
					}

					for (int s = 0; s < numStates; s++)
					{
						int SWCorner = 0;
						int SECorner = 0;
						if (grid[SWRow][SWCol] == s)
						{
							SWCorner = 1;
						}

						if (grid[SERow][SECol] == s)
						{
							SECorner = 1;
						}
						posE[col][2][s] = posE[col - 1][2][s] - SWCorner + SECorner;
					}

				}

				// if we're on a new row, but not the first row, the TOPnew and BOTnew must be calculated independently
				else if (col == 0)
				{
					for (int s = 0; s < numStates; s++)
					{
						posE[col][0][s] = 0;
					}

					int row2 = row - radius;
					for (int col2 = col - radius; col2 <= col + radius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, gridLength);
						int realCol = WrapAround.wrapAround(col2, gridLength);
						int gridValue = grid[realRow][realCol];

						posE[col][0][gridValue]++;

					}

					for (int s = 0; s < numStates; s++)
					{
						posE[col][1][s] += posE[col][2][s] - posE[col][0][s];
					}

					for (int s = 0; s < numStates; s++)
					{
						posE[col][2][s] = 0;
					}

					row2 = row + radius;
					for (int col2 = col - radius; col2 <= col + radius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, gridLength);
						int realCol = WrapAround.wrapAround(col2, gridLength);
						int gridValue = grid[realRow][realCol];

						posE[col][2][gridValue]++;
					}

				}
				else
				{

					// generate new top
					int NWRow = WrapAround.wrapAround(row - radius, gridLength);
					int NWCol = WrapAround.wrapAround(col - 1 - radius, gridLength);
					int NERow = WrapAround.wrapAround(row - radius, gridLength);
					int NECol = WrapAround.wrapAround(col + radius, gridLength);

					int SWRow = WrapAround.wrapAround(row + radius, gridLength);
					int SWCol = WrapAround.wrapAround(col - 1 - radius, gridLength);
					int SERow = WrapAround.wrapAround(row + radius, gridLength);
					int SECol = WrapAround.wrapAround(col + radius, gridLength);

					for (int s = 0; s < numStates; s++)
					{
						int NWCorner = 0;
						int NECorner = 0;
						if (grid[NWRow][NWCol] == s)
						{
							NWCorner = 1;
						}

						if (grid[NERow][NECol] == s)
						{
							NECorner = 1;
						}
						posE[col][0][s] = posE[col - 1][0][s] - NWCorner + NECorner;
					}

					for (int s = 0; s < numStates; s++)
					{
						posE[col][1][s] += posE[col][2][s] - posE[col][0][s];
					}

					for (int s = 0; s < numStates; s++)
					{
						int SWCorner = 0;
						int SECorner = 0;
						if (grid[SWRow][SWCol] == s)
						{
							SWCorner = 1;
						}

						if (grid[SERow][SECol] == s)
						{
							SECorner = 1;
						}
						posE[col][2][s] = posE[col - 1][2][s] - SWCorner + SECorner;
					}

				}
				int correctForMiddle = 0;

				for (int s = 0; s < numStates; s++)
				{
					correctForMiddle = 0;
					if (base == s)
					{

						correctForMiddle = -1;
					}
					PC[base][s] += (posE[col][0][s] + posE[col][1][s] + posE[col][2][s] + correctForMiddle);
				}

				/*
				 * if (row == 2 && col == 2) { System.out.println(); for (int g = 1; g <= 3; g++) { for (int h = 1; h <= 3; h++) { System.out.print(grid[g][h] + "  "); } System.out.println(" "); } for (int s = 0; s < numStates; s++) { correctForMiddle = 0; if (base == s) {
				 * 
				 * correctForMiddle = -1; } System.out.println("PCFuncRaw: base is " + base + ". cor with " + s + " is " + (posE[col][0][s] + posE[col][1][s] + posE[col][2][s] + correctForMiddle)); } }
				 */
			}
		}

		/*
		 * for (int k = 0; k < numStates; k++) { for (int l = 0; l < numStates; l++) { PC[k][l] /= (double) (baseCounter[k]); } }
		 */

		return PC;
	}
}
