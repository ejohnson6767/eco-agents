import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class DispersalIB extends DiscreteTrait implements IDispersalTrait, Evolvable
{
	// private Community com;
	// Environment env;
	// private int speciesValue;
	private boolean useAltApproach;
	// private int speciesIndex;
	// private int envGridIndex;
	private int possibleNeighbors;
	private int baselineTrait;

	public DispersalIB(IMutationFunction mf)
	{
		super(mf);
		this.useAltApproach = false;
		// this.com = com;
	}
	
	
	public void startEvolution()
	{
		this.isEvolving = true;
		this.isIndividualBased = true;
		// setUpAfterCommunityIsCreated(com, this.species.getGridProxy());
		initializeSpatialDistributionTracker();
		IDispersalTrait dt =  this.species.getDispersalStrategy();
		if(dt.isIndividualBased())
		{
			this.baselineTrait = (int) ((DispersalIB) dt).getTraitAverage();
		} else
		{
			//System.out.println("not individual based");
			this.baselineTrait = dt.getDispersalRadius();
		}
		this.species.setDispersalStrategy(this);

		//System.out.println("made species " + species.getGridProxy() + " individual-based and evolvable");
		//System.out.println("is individual based " + this.isIndividualBased);
	}

	public void startBeingIndividualBased()
	{
		this.isIndividualBased = true;
		// setUpAfterCommunityIsCreated(com, this.species.getGridProxy());
		initializeSpatialDistributionTracker();
		IDispersalTrait dt =  this.species.getDispersalStrategy();
		if(dt.isIndividualBased())
		{
			this.baselineTrait = (int) ((DispersalIB) dt).getTraitAverage();
		} else
		{
			//System.out.println("not individual based");
			this.baselineTrait = dt.getDispersalRadius();
		}
		this.species.setDispersalStrategy(this);
		//System.out.println("made species " + species.getGridProxy() + " individual-based ");
	}

	public void initializeSpatialDistributionTracker()
	{
		this.spatialDistributionTracker = this.species.getDispersalStrategy().getSpatialDistributionTracker();
	}

	public void fillPRGDiscreteOnlyIncludingDispersal(TraitList tl, ArrayList<Integer> indexes, ArrayList<int[]> traitCombos)
	{		
		for (int i = 1; i < this.discreteHistogram.length; i++)
		{
			// System.out.println("discrete histogram bin " + (i + 1) + " is " + this.discreteHistogram[i]);
			if (this.discreteHistogram[i] != 0)
			{
				fillGridAllDiscreteIBTraitsAllTraitComboSingleDispersal(tl, i, indexes, traitCombos);
			}
		}
	}
	
	public void fillGridAllDiscreteIBTraitsAllTraitComboSingleDispersal(TraitList tl, int dispersalRadius, ArrayList<Integer> indexes, ArrayList<int[]> traitComboGoal)
	{
		// int dispersalRadius = curSpecies.getDispersalStrategy().getDispersalRadius();
		int possibleNeighbors = (int) Math.pow(dispersalRadius * 2 + 1, 2) - 1;
		// System.out.println("possible neighbors " + possibleNeighbors);
		// System.out.println("dispersal radius is " + dispersalRadius);
		double[][][] fecundityGrid = com.getFecundityGrid();
		double[][][][] propaguleRainGrid = com.getPropaguleRainGrid();

		int comboLength = traitComboGoal.size();

		Environment env = com.getEnvironment();
		double[][][] posPropagule = new double[comboLength][gridLength][3];

		// this second main loop determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius

		// this algorithm scans right across the grid, goes down one line, scans again, and so on (just like reading). It's time complexity is O(n) (where n is the number of microsites) compared to O(n^2) of a trivial moving window algorithm.
		// It works by summing all of the
		// cumulative birth rates in the topmost row, the bottommost row, and everything in between. This is where the last dimension on pos array comes in:
		// 0 is TOP, 1 is MID, and 2 is BOT. when you to the next gid locationCommunity com,, your cumulative growth rate is TOPnew + MIDnew + BOTnew. MIDnew is simply MIDnorth + BOTnorth - TOPnew.
		// (where north indicates the position above you). TOPnew can be written TOPwest - TOPwest.leftMost + TOPnew.rightmost. BOTnew can be written BOTwest - BOTwest.leftMost + BOTnew.rightmost.
		// the TOP, MID, and BOT are all recorded.

		int row = 0;
		int col = 0;
		// pos = new double[numberOfSpecies][gridLength][3];
		int row2 = row - dispersalRadius;
		for (int col2 = col - dispersalRadius; col2 <= col + dispersalRadius; col2++)
		{
			int realRow = WrapAround.wrapAround(row2, gridLength);
			int realCol = WrapAround.wrapAround(col2, gridLength);
			int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
			if (gridValue == speciesValue)
			{
				Location loc = new Location(realRow, realCol);
				if (getTrait(loc) == dispersalRadius)
				{
					int[] curTraits = tl.getTraitArrayAtLocation(indexes, loc);
					for (int i = 0; i < comboLength; i++)
					{
						if (Arrays.equals(curTraits, traitComboGoal.get(i)))
						{
							posPropagule[i][col][0] += fecundityGrid[envGridIndex][realRow][realCol];
						}
					}
				}
			}
		}
		// System.out.println("col == " + col + " first is " + first[1]);

		for (int col2 = col - dispersalRadius; col2 <= col + dispersalRadius; col2++)
		{
			for (row2 = row - dispersalRadius + 1; row2 <= row + dispersalRadius - 1; row2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{
					Location loc = new Location(realRow, realCol);
					if (getTrait(loc) == dispersalRadius)
					{
						int[] curTraits = tl.getTraitArrayAtLocation(indexes, loc);
						for (int i = 0; i < comboLength; i++)
						{
							if (Arrays.equals(curTraits, traitComboGoal.get(i)))
							{
								posPropagule[i][col][1] += fecundityGrid[envGridIndex][realRow][realCol];
							}
						}
					}
				}

			}
		}
		// System.out.println("col == 0 middle is " + middle[1]);

		row2 = row + dispersalRadius;
		for (int col2 = col - dispersalRadius; col2 <= col + dispersalRadius; col2++)
		{
			int realRow = WrapAround.wrapAround(row2, gridLength);
			int realCol = WrapAround.wrapAround(col2, gridLength);
			int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
			if (gridValue == speciesValue)
			{
				Location loc = new Location(realRow, realCol);
				if (getTrait(loc) == dispersalRadius)
				{
					int[] curTraits = tl.getTraitArrayAtLocation(indexes, loc);
					for (int i = 0; i < comboLength; i++)
					{
						if (Arrays.equals(curTraits, traitComboGoal.get(i)))
						{
							posPropagule[i][col][2] += fecundityGrid[envGridIndex][realRow][realCol];
						}
					}
				}
			}
		}

		if (env.getGridValue(row, col, envGridIndex) == 0)
		{
			for (int i = 0; i < comboLength; i++)
			{
				double valToAdd = (posPropagule[i][col][0] + posPropagule[i][col][1] + posPropagule[i][col][2]) / (double) possibleNeighbors;
				tl.updateDiscreteTraitBirthOptions(row, col, i, valToAdd);
				propaguleRainGrid[envGridIndex][row][col][speciesIndex] += valToAdd;
			}
		}

		row = 0;
		for (col = 1; col < gridLength; col++)
		{

			// generate new top
			int NWRow = WrapAround.wrapAround(row - dispersalRadius, gridLength);
			int NWCol = WrapAround.wrapAround(col - 1 - dispersalRadius, gridLength);
			int NERow = WrapAround.wrapAround(row - dispersalRadius, gridLength);
			int NECol = WrapAround.wrapAround(col + dispersalRadius, gridLength);

			int SWRow = WrapAround.wrapAround(row + dispersalRadius, gridLength);
			int SWCol = WrapAround.wrapAround(col - 1 - dispersalRadius, gridLength);
			int SERow = WrapAround.wrapAround(row + dispersalRadius, gridLength);
			int SECol = WrapAround.wrapAround(col + dispersalRadius, gridLength);

			for (int i = 0; i < comboLength; i++)
			{
				posPropagule[i][col][0] = posPropagule[i][col - 1][0];
			}

			int gridValue = env.getGridValue(NWRow, NWCol, envGridIndex);
			if (gridValue == speciesValue)
			{
				Location loc = new Location(NWRow, NWCol);
				if (getTrait(loc) == dispersalRadius)
				{
					int[] curTraits = tl.getTraitArrayAtLocation(indexes, loc);
					for (int i = 0; i < comboLength; i++)
					{
						if (Arrays.equals(curTraits, traitComboGoal.get(i)))
						{
							posPropagule[i][col][0] -= fecundityGrid[envGridIndex][NWRow][NWCol];
						}
					}
				}
			}

			gridValue = env.getGridValue(NERow, NECol, envGridIndex);
			if (gridValue == speciesValue)
			{
				Location loc = new Location(NERow, NECol);
				if (getTrait(loc) == dispersalRadius)
				{
					int[] curTraits = tl.getTraitArrayAtLocation(indexes, loc);
					for (int i = 0; i < comboLength; i++)
					{
						if (Arrays.equals(curTraits, traitComboGoal.get(i)))
						{
							posPropagule[i][col][0] += fecundityGrid[envGridIndex][NERow][NECol];
						}
					}
				}
			}

			for (int i = 0; i < comboLength; i++)
			{
				posPropagule[i][col][1] = posPropagule[i][col - 1][1];
			}

			int col2 = col - dispersalRadius - 1;
			for (row2 = row - dispersalRadius + 1; row2 <= row + dispersalRadius - 1; row2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{
					Location loc = new Location(realRow, realCol);
					if (getTrait(loc) == dispersalRadius)
					{
						int[] curTraits = tl.getTraitArrayAtLocation(indexes, loc);
						for (int i = 0; i < comboLength; i++)
						{
							if (Arrays.equals(curTraits, traitComboGoal.get(i)))
							{
								posPropagule[i][col][1] -= fecundityGrid[envGridIndex][realRow][realCol];
							}
						}
					}
				}
			}

			col2 = col + dispersalRadius;
			for (row2 = row - dispersalRadius + 1; row2 <= row + dispersalRadius - 1; row2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{
					Location loc = new Location(realRow, realCol);
					if (getTrait(loc) == dispersalRadius)
					{
						int[] curTraits = tl.getTraitArrayAtLocation(indexes, loc);
						for (int i = 0; i < comboLength; i++)
						{
							if (Arrays.equals(curTraits, traitComboGoal.get(i)))
							{
								posPropagule[i][col][1] += fecundityGrid[envGridIndex][realRow][realCol];
							}
						}
					}
				}
			}

			for (int i = 0; i < comboLength; i++)
			{
				posPropagule[i][col][2] = posPropagule[i][col - 1][2];
			}

			gridValue = env.getGridValue(SWRow, SWCol, envGridIndex);
			if (gridValue == speciesValue)
			{
				Location loc = new Location(SWRow, SWCol);
				if (getTrait(loc) == dispersalRadius)
				{
					int[] curTraits = tl.getTraitArrayAtLocation(indexes, loc);
					for (int i = 0; i < comboLength; i++)
					{

						if (Arrays.equals(curTraits, traitComboGoal.get(i)))
						{
							posPropagule[i][col][2] -= fecundityGrid[envGridIndex][SWRow][SWCol];
						}
					}
				}
			}

			gridValue = env.getGridValue(SERow, SECol, envGridIndex);
			if (gridValue == speciesValue)
			{
				Location loc = new Location(SERow, SECol);
				if (getTrait(loc) == dispersalRadius)
				{
					int[] curTraits = tl.getTraitArrayAtLocation(indexes, loc);
					for (int i = 0; i < comboLength; i++)
					{
						if (Arrays.equals(curTraits, traitComboGoal.get(i)))
						{
							posPropagule[i][col][2] += fecundityGrid[envGridIndex][SERow][SECol];
						}
					}
				}
			}

			if (env.getGridValue(row, col, envGridIndex) == 0)
			{
				for (int i = 0; i < comboLength; i++)
				{
					double valToAdd = (posPropagule[i][col][0] + posPropagule[i][col][1] + posPropagule[i][col][2]) / (double) possibleNeighbors;
					tl.updateDiscreteTraitBirthOptions(row, col, i, valToAdd);
					propaguleRainGrid[envGridIndex][row][col][speciesIndex] += valToAdd;
				}
			}

		}

		for (row = 1; row < gridLength; row++)
		{
			col = 0;
			// if we're on a new row, but not the first row, the TOPnew and BOTnew must be calculated independently
			for (int i = 0; i < comboLength; i++)
			{
				posPropagule[i][col][0] = 0;
			}
			row2 = row - dispersalRadius;
			for (int col2 = col - dispersalRadius; col2 <= col + dispersalRadius; col2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{
					Location loc = new Location(realRow, realCol);
					if (getTrait(loc) == dispersalRadius)
					{
						int[] curTraits = tl.getTraitArrayAtLocation(indexes, loc);
						for (int i = 0; i < comboLength; i++)
						{
							if (Arrays.equals(curTraits, traitComboGoal.get(i)))
							{
								posPropagule[i][col][0] += fecundityGrid[envGridIndex][realRow][realCol];
							}
						}
					}
				}
			}

			for (int i = 0; i < comboLength; i++)
			{
				posPropagule[i][col][1] += posPropagule[i][col][2] - posPropagule[i][col][0];
			}

			for (int i = 0; i < comboLength; i++)
			{
				posPropagule[i][col][2] = 0;
			}

			row2 = row + dispersalRadius;
			for (int col2 = col - dispersalRadius; col2 <= col + dispersalRadius; col2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{
					Location loc = new Location(realRow, realCol);
					if (getTrait(loc) == dispersalRadius)
					{
						int[] curTraits = tl.getTraitArrayAtLocation(indexes, loc);
						for (int i = 0; i < comboLength; i++)
						{
							if (Arrays.equals(curTraits, traitComboGoal.get(i)))
							{
								posPropagule[i][col][2] += fecundityGrid[envGridIndex][realRow][realCol];
							}
						}
					}
				}
			}

			if (env.getGridValue(row, col, envGridIndex) == 0)
			{
				for (int i = 0; i < comboLength; i++)
				{
					double valToAdd = (posPropagule[i][col][0] + posPropagule[i][col][1] + posPropagule[i][col][2]) / (double) possibleNeighbors;
					tl.updateDiscreteTraitBirthOptions(row, col, i, valToAdd);
					propaguleRainGrid[envGridIndex][row][col][speciesIndex] += valToAdd;
				}
			}

			for (col = 1; col < gridLength; col++)
			{

				// generate new top
				int NWRow = WrapAround.wrapAround(row - dispersalRadius, gridLength);
				int NWCol = WrapAround.wrapAround(col - 1 - dispersalRadius, gridLength);
				int NERow = WrapAround.wrapAround(row - dispersalRadius, gridLength);
				int NECol = WrapAround.wrapAround(col + dispersalRadius, gridLength);

				int SWRow = WrapAround.wrapAround(row + dispersalRadius, gridLength);
				int SWCol = WrapAround.wrapAround(col - 1 - dispersalRadius, gridLength);
				int SERow = WrapAround.wrapAround(row + dispersalRadius, gridLength);
				int SECol = WrapAround.wrapAround(col + dispersalRadius, gridLength);

				for (int i = 0; i < comboLength; i++)
				{
					posPropagule[i][col][0] = posPropagule[i][col - 1][0];
				}

				int gridValue = env.getGridValue(NWRow, NWCol, envGridIndex);
				if (gridValue == speciesValue)
				{
					Location loc = new Location(NWRow, NWCol);
					if (getTrait(loc) == dispersalRadius)
					{
						int[] curTraits = tl.getTraitArrayAtLocation(indexes, loc);
						for (int i = 0; i < comboLength; i++)
						{
							if (Arrays.equals(curTraits, traitComboGoal.get(i)))
							{
								posPropagule[i][col][0] -= fecundityGrid[envGridIndex][NWRow][NWCol];
							}
						}
					}
				}

				gridValue = env.getGridValue(NERow, NECol, envGridIndex);
				if (gridValue == speciesValue)
				{
					Location loc = new Location(NERow, NECol);
					if (getTrait(loc) == dispersalRadius)
					{
						int[] curTraits = tl.getTraitArrayAtLocation(indexes, loc);
						for (int i = 0; i < comboLength; i++)
						{
							if (Arrays.equals(curTraits, traitComboGoal.get(i)))
							{
								posPropagule[i][col][0] += fecundityGrid[envGridIndex][NERow][NECol];
							}
						}
					}
				}

				for (int i = 0; i < comboLength; i++)
				{
					posPropagule[i][col][1] += posPropagule[i][col][2] - posPropagule[i][col][0];
				}

				for (int i = 0; i < comboLength; i++)
				{
					posPropagule[i][col][2] = posPropagule[i][col - 1][2];
				}

				gridValue = env.getGridValue(SWRow, SWCol, envGridIndex);
				if (gridValue == speciesValue)
				{
					Location loc = new Location(SWRow, SWCol);
					if (getTrait(loc) == dispersalRadius)
					{
						int[] curTraits = tl.getTraitArrayAtLocation(indexes, loc);
						for (int i = 0; i < comboLength; i++)
						{
							if (Arrays.equals(curTraits, traitComboGoal.get(i)))
							{
								posPropagule[i][col][2] -= fecundityGrid[envGridIndex][SWRow][SWCol];
							}
						}
					}
				}

				gridValue = env.getGridValue(SERow, SECol, envGridIndex);
				if (gridValue == speciesValue)
				{
					Location loc = new Location(SERow, SECol);
					if (getTrait(loc) == dispersalRadius)
					{
						int[] curTraits = tl.getTraitArrayAtLocation(indexes, loc);
						for (int i = 0; i < comboLength; i++)
						{
							if (Arrays.equals(curTraits, traitComboGoal.get(i)))
							{
								posPropagule[i][col][2] += fecundityGrid[envGridIndex][SERow][SECol];
							}
						}
					}
				}
				if (env.getGridValue(row, col, envGridIndex) == 0)
				{
					for (int i = 0; i < comboLength; i++)
					{
						double valToAdd = (posPropagule[i][col][0] + posPropagule[i][col][1] + posPropagule[i][col][2]) / (double) possibleNeighbors;
						tl.updateDiscreteTraitBirthOptions(row, col, i, valToAdd);
						propaguleRainGrid[envGridIndex][row][col][speciesIndex] += valToAdd;
					}
				}
			}
		}
	}

	

	public void fillPRGDispersalOnly()
	{
		TraitList tl = this.species.getTraitList();
		// fillDiscreteHistogram();

		for (int i = 1; i < this.discreteHistogram.length; i++)
		{
			// System.out.println("discrete histogram bin " + (i + 1) + " is " + this.discreteHistogram[i]);
			if (this.discreteHistogram[i] != 0)
			{
				fillGridMovingWindowSingleDispersal(i, tl);
			}
		}
	}

	public void fillGridMovingWindowSingleDispersal(int dispersalRadius, TraitList tl)
	{
		int possibleNeighbors = (int) Math.pow(dispersalRadius * 2 + 1, 2) - 1;
		double[][][] fecundityGrid = com.getFecundityGrid();
		double[][][][] propaguleRainGrid = com.getPropaguleRainGrid();

		double[][] posPropagule = new double[gridLength][3];

		// this second main loop determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius

		// this algorithm scans right across the grid, goes down one line, scans again, and so on (just like reading). It's time complexity is O(n) (where n is the number of microsites) compared to O(n^2) of a trivial moving window algorithm.
		// It works by summing all of the
		// cumulative birth rates in the topmost row, the bottommost row, and everything in between. This is where the last dimension on pos array comes in:
		// 0 is TOP, 1 is MID, and 2 is BOT. when you to the next gid locationCommunity com,, your cumulative growth rate is TOPnew + MIDnew + BOTnew. MIDnew is simply MIDnorth + BOTnorth - TOPnew.
		// (where north indicates the position above you). TOPnew can be written TOPwest - TOPwest.leftMost + TOPnew.rightmost. BOTnew can be written BOTwest - BOTwest.leftMost + BOTnew.rightmost.
		// the TOP, MID, and BOT are all recorded.

		int row = 0;
		int col = 0;
		// pos = new double[numberOfSpecies][gridLength][3];
		int row2 = row - dispersalRadius;
		for (int col2 = col - dispersalRadius; col2 <= col + dispersalRadius; col2++)
		{
			int realRow = WrapAround.wrapAround(row2, gridLength);
			int realCol = WrapAround.wrapAround(col2, gridLength);

			if (this.spatialDistributionTracker[realRow][realCol] == dispersalRadius)
			{

				posPropagule[col][0] += fecundityGrid[envGridIndex][realRow][realCol];
			}

		}
		// System.out.println("col == " + col + " first is " + first[1]);

		for (int col2 = col - dispersalRadius; col2 <= col + dispersalRadius; col2++)
		{
			for (row2 = row - dispersalRadius + 1; row2 <= row + dispersalRadius - 1; row2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				if (this.spatialDistributionTracker[realRow][realCol] == dispersalRadius)
				{

					posPropagule[col][1] += fecundityGrid[envGridIndex][realRow][realCol];
				}

			}
		}
		// System.out.println("col == 0 middle is " + middle[1]);

		row2 = row + dispersalRadius;
		for (int col2 = col - dispersalRadius; col2 <= col + dispersalRadius; col2++)
		{
			int realRow = WrapAround.wrapAround(row2, gridLength);
			int realCol = WrapAround.wrapAround(col2, gridLength);

			if (this.spatialDistributionTracker[realRow][realCol] == dispersalRadius)
			{
				posPropagule[col][2] += fecundityGrid[envGridIndex][realRow][realCol];
			}
		}

		if (env.getGridValue(row, col, envGridIndex) == 0)
		{
			/*
			 * correctForMiddle = 0; if (this.spatialDistributionTracker[row][col] == dispersalRadius) { correctForMiddle -= fecundityGrid[envGridIndex][row][col][speciesIndex]; }
			 */
			double valToAdd = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2]) / (double) possibleNeighbors;
			tl.updateDispersalOptions(row, col, dispersalRadius, valToAdd);
			propaguleRainGrid[envGridIndex][row][col][speciesIndex] += valToAdd;
		}

		row = 0;
		for (col = 1; col < this.gridLength; col++)
		{

			// generate new top
			int NRow = WrapAround.wrapAround(row - dispersalRadius, gridLength);
			int WCol = WrapAround.wrapAround(col - 1 - dispersalRadius, gridLength);
			int ECol = WrapAround.wrapAround(col + dispersalRadius, gridLength);
			int SRow = WrapAround.wrapAround(row + dispersalRadius, gridLength);


			double NW = 0;
			if (this.spatialDistributionTracker[NRow][WCol] == dispersalRadius)
			{
				NW = fecundityGrid[envGridIndex][NRow][WCol];
			}
			double NE = 0;
			if (this.spatialDistributionTracker[NRow][ECol] == dispersalRadius)
			{
				NE = fecundityGrid[envGridIndex][NRow][ECol];
			}

			posPropagule[col][0] = posPropagule[col - 1][0] - NW + NE;

			double leftSideOfOldMid = 0;
			int col2 = col - dispersalRadius - 1;
			for (row2 = row - dispersalRadius + 1; row2 <= row + dispersalRadius - 1; row2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);

				if (this.spatialDistributionTracker[realRow][realCol] == dispersalRadius)
				{
					leftSideOfOldMid += fecundityGrid[envGridIndex][realRow][realCol];
				}

			}

			double rightSideOfNewMid = 0;
			col2 = col + dispersalRadius;
			for (row2 = row - dispersalRadius + 1; row2 <= row + dispersalRadius - 1; row2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);

				if (this.spatialDistributionTracker[realRow][realCol] == dispersalRadius)
				{
					rightSideOfNewMid += fecundityGrid[envGridIndex][realRow][realCol];
				}

			}

			posPropagule[col][1] = posPropagule[col - 1][1] - leftSideOfOldMid + rightSideOfNewMid;

			double SW = 0;
			if (this.spatialDistributionTracker[SRow][WCol] == dispersalRadius)
			{
				SW = fecundityGrid[envGridIndex][SRow][WCol];
			}
			double SE = 0;
			if (this.spatialDistributionTracker[SRow][ECol] == dispersalRadius)
			{
				SE = fecundityGrid[envGridIndex][SRow][ECol];
			}
			posPropagule[col][2] = posPropagule[col - 1][2] - SW + SE;

			if (env.getGridValue(row, col, envGridIndex) == 0)
			{
				double valToAdd = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2]) / (double) possibleNeighbors;
				tl.updateDispersalOptions(row, col, dispersalRadius, valToAdd);
				propaguleRainGrid[envGridIndex][row][col][speciesIndex] += valToAdd;
			}

		}

		for (row = 1; row < this.gridLength; row++)
		{
			col = 0;
			// if we're on a new row, but not the first row, the TOPnew and BOTnew must be calculated independently

			posPropagule[col][0] = 0;

			row2 = row - dispersalRadius;
			for (int col2 = col - dispersalRadius; col2 <= col + dispersalRadius; col2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				if (this.spatialDistributionTracker[realRow][realCol] == dispersalRadius)
				{

					posPropagule[col][0] += fecundityGrid[envGridIndex][realRow][realCol];

				}
			}

			posPropagule[col][1] += posPropagule[col][2] - posPropagule[col][0];

			posPropagule[col][2] = 0;

			row2 = row + dispersalRadius;
			for (int col2 = col - dispersalRadius; col2 <= col + dispersalRadius; col2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				if (this.spatialDistributionTracker[realRow][realCol] == dispersalRadius)
				{
					posPropagule[col][2] += fecundityGrid[envGridIndex][realRow][realCol];

				}
			}

			if (env.getGridValue(row, col, envGridIndex) == 0)
			{
				/*
				 * correctForMiddle = 0; if (this.spatialDistributionTracker[row][col] == dispersalRadius) { correctForMiddle -= fecundityGrid[envGridIndex][row][col][speciesIndex]; }
				 */
				double valToAdd = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2]) / (double) possibleNeighbors;
				tl.updateDispersalOptions(row, col, dispersalRadius, valToAdd);
				propaguleRainGrid[envGridIndex][row][col][speciesIndex] += valToAdd;
			}

			for (col = 1; col < this.gridLength; col++)
			{

				// generate new top
				int NRow = WrapAround.wrapAround(row - dispersalRadius, gridLength);
				int WCol = WrapAround.wrapAround(col - 1 - dispersalRadius, gridLength);
				int ECol = WrapAround.wrapAround(col + dispersalRadius, gridLength);
				int SRow = WrapAround.wrapAround(row + dispersalRadius, gridLength);

				double NW = 0;
				if (this.spatialDistributionTracker[NRow][WCol] == dispersalRadius)
				{
					NW = fecundityGrid[envGridIndex][NRow][WCol];
				}
				double NE = 0;
				if (this.spatialDistributionTracker[NRow][ECol] == dispersalRadius)
				{
					NE = fecundityGrid[envGridIndex][NRow][ECol];
				}

				posPropagule[col][0] = posPropagule[col - 1][0] - NW + NE;

				posPropagule[col][1] += posPropagule[col][2] - posPropagule[col][0];

				double SW = 0;
				if (this.spatialDistributionTracker[SRow][WCol] == dispersalRadius)
				{
					SW = fecundityGrid[envGridIndex][SRow][WCol];
				}
				double SE = 0;
				if (this.spatialDistributionTracker[SRow][ECol] == dispersalRadius)
				{
					SE = fecundityGrid[envGridIndex][SRow][ECol];
				}
				posPropagule[col][2] = posPropagule[col - 1][2] - SW + SE;

				if (this.env.getGridValue(row, col, this.envGridIndex) == 0)
				{
					double valToAdd = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2]) / (double) possibleNeighbors;
					tl.updateDispersalOptions(row, col, dispersalRadius, valToAdd);
					propaguleRainGrid[envGridIndex][row][col][speciesIndex] += valToAdd;
				}
			}
		}
	}

	public void fillPRGRegularIncludingDispersal()
	{
		// System.out.println("dispersal evolving");
		double[][][] fecundityGrid = com.getFecundityGrid();
		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				int gridValue = env.getGridValue(row, col, envGridIndex);
				if (gridValue == speciesValue)
				{
					int dispersalRadius = (int) getTrait(new Location(row, col));
					// System.out.println("dispersalRadius is " + dispersalRadius);
					updateGridWithTraits(row, col, dispersalRadius, fecundityGrid[envGridIndex][row][col]);
				}
			}
		}
	}

	public void updateGridWithTraits(int row, int col, int dispersalRadius, double c)
	{
		double[][][][] propaguleRainGrid = com.getPropaguleRainGrid();

		TraitList traitList = this.species.getTraitList();

		int possibleNeighbors = (int) Math.pow(dispersalRadius * 2 + 1, 2) - 1;
		double cRealized = c / (double) possibleNeighbors;

		for (int row2 = row - dispersalRadius; row2 <= row + dispersalRadius; row2++)
		{
			for (int col2 = col - dispersalRadius; col2 <= col + dispersalRadius; col2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				propaguleRainGrid[envGridIndex][realRow][realCol][this.speciesValue - 1] += cRealized;

				traitList.updateBirthOptionsForEmptySite(row, col, realRow, realCol, cRealized, env);
				// System.out.println("adding to DAOptions");

				// DAOptions.get(speciesVal-1).get(realRow).get(realCol).add(new double[] { cRealized, (double) dispersalRadius });
			}
		}

		// curSpecies.getTraitList().updateAllTraits(com, row, col, c);
	}

	public int getDispersalRadius(Location loc)
	{
		return (int) getTrait(loc);
	}

	public void setupAfterCommunityIsCreated(Community com)
	{
		//this.baselineTrait = getTraitAverage();
	}

	@Override
	public double getBaselineTrait()
	{
		//System.out.println("Getting baseline TRAIT: " + com.getAbundances()[this.speciesIndex] );
		if(com.getAbundances()[this.speciesIndex] != 0)
		{
			//System.out.println("not zero. Getting trait average");
			return (int) getTraitAverage();
		} else
		{
			//System.out.println(this.baselineTrait);
			return this.baselineTrait;
		}
	}

	public int getDispersalRadius()
	{
		throw new IllegalStateException("should not be calling this method");
	}

	public void setSpeciesOwner(ISpecies species)
	{
		this.species = species;

	}


	@Override
	public void doThing()
	{
		throw new IllegalStateException("should not be calling this method");
	}



}
