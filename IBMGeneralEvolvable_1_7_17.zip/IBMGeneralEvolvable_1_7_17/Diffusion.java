import java.io.Serializable;

public class Diffusion implements IDiffusion, Serializable
{

	private int diffusion;
	private Community com;
	private int gridLength;
	private Environment env;
	private ISpecies speciesOwner;
	private int envGridIndex;
	private int speciesValue;

	public Diffusion(int diffusion)
	{
		this.diffusion = diffusion;
	}
	
	public void setupAfterCommunityIsCreated(Community com)
	{
		this.com = com;
		this.env = this.com.getEnvironment();
		this.gridLength = this.env.getGridLength();
		//System.out.println(gridLength);

		this.envGridIndex = this.speciesOwner.getHomeGridIndex();
		//System.out.println(this.envGridIndex);
		this.speciesValue = this.speciesOwner.getGridProxy();
		//System.out.println(this.speciesValue);
	}
	
	public void setSpeciesOwner(ISpecies species)
	{
		this.speciesOwner = species;
	}

	

	public boolean isIndividualBased()
	{

		return false;
	}

	public int getDiffusion(int row, int col)
	{
		return this.diffusion;
	}


	public double[][] getSpatialDistributionTracker()
	{
		//System.out.println("getting sdt from bland diffusion ");
		double[][] sdt = new double[this.gridLength][this.gridLength];
		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				if(this.env.getGridValue(row, col, envGridIndex) == this.speciesValue)
				{
					//System.out.println(this.diffusion);
					sdt[row][col] = this.diffusion;
				}
			}
		}
		
		return sdt;
	}

	@Override
	public int getDiffusion()
	{
		return this.diffusion;
	}

}
