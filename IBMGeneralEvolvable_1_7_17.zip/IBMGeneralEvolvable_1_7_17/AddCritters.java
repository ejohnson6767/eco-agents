import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

public class AddCritters extends ModifyAbundance implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected ISpecies curSpecies;
	protected Community com;
	protected boolean overwrite;
	protected Random generator;
	protected Location referenceLocation;
	protected int dispersalLength;
	protected boolean stepPrimer;

	public AddCritters(Community com, int speciesValue, boolean overwrite)
	{

		super(com, speciesValue);

		this.com = com;
		this.env = com.getEnvironment();
		this.gridLength = this.env.getGridLength();
		this.curSpeciesValue = speciesValue;
		this.curSpecies = com.getSpeciesList().get(this.curSpeciesValue - 1);
		this.overwrite = overwrite;
		this.curSpeciesHomeIndex = this.curSpecies.getHomeGridIndex();
		this.generator = com.getEnvironment().getGenerator(this.curSpeciesHomeIndex);
		this.curSpeciesLocations = null;
		this.referenceLocation = new Location(0, 0);
		this.dispersalLength = this.gridLength;
		this.stepPrimer = true;
	}

	public AddCritters(Community com, int speciesValue, boolean overwrite, boolean stepPrimer)
	{
		this(com, speciesValue, overwrite);
		this.stepPrimer = stepPrimer;
	}

	public AddCritters(Community com, int speciesValue, boolean overwrite, ArrayList<Location> curSpeciesLocations)
	{

		super(com, speciesValue);

		this.com = com;
		this.env = com.getEnvironment();
		this.gridLength = this.env.getGridLength();
		this.curSpeciesValue = speciesValue;
		this.curSpecies = com.getSpeciesList().get(this.curSpeciesValue - 1);
		this.overwrite = overwrite;
		this.curSpeciesHomeIndex = this.curSpecies.getHomeGridIndex();
		this.generator = com.getEnvironment().getGenerator(this.curSpeciesHomeIndex);
		this.curSpeciesLocations = curSpeciesLocations;
		this.referenceLocation = new Location(0, 0);
		this.dispersalLength = this.gridLength;
	}

	public AddCritters(Community com, int speciesValue, boolean overwrite, ArrayList<Location> curSpeciesLocations, boolean stepPrimer)
	{
		this(com, speciesValue, overwrite, curSpeciesLocations);
		this.stepPrimer = stepPrimer;
	}

	public void setReferenceLocation(int row, int col)
	{
		this.referenceLocation = new Location(row, col);
	}

	public void setDispersalLength(int dispersalLength)
	{
		this.dispersalLength = dispersalLength;
	}

	public boolean tryToAddCritter(TraitList curSpeciesTraits, Location3D newLoc3D, Location newLoc, Location oldLoc, boolean useOldLoc)
	{
		boolean added = false;
		if (overwrite)
		{

			if (this.curSpecies.canRecruitIfCritterCanOverwriteHeterospecifics(this.com, newLoc))
			{
				addCritter(curSpeciesTraits, newLoc3D, newLoc, oldLoc, useOldLoc);
				added = true;
			}

		}
		else
		{
			if (this.curSpecies.canRecruit(this.com, newLoc))
			{
				addCritter(curSpeciesTraits, newLoc3D, newLoc, oldLoc, useOldLoc);
				added = true;
			}
		}

		return added;
	}

	public boolean tryToAddCritterOverwritingAlwaysPermitted(TraitList curSpeciesTraits, Location3D newLoc3D, Location newLoc, Location oldLoc, boolean useOldLoc)
	{
		boolean added = false;

		if (this.curSpecies.canRecruitIfCritterCanOverwriteHeterospecifics(this.com, newLoc))
		{
			addCritter(curSpeciesTraits, newLoc3D, newLoc, oldLoc, useOldLoc);
			added = true;
		}
		return added;
	}

	public void addCritterNearby(TraitList curSpeciesTraits)
	{
		int k = 0;
		while (true)
		{
			NearbySpot ns = new NearbySpot(this.gridLength, this.generator, this.curSpecies, this.curSpeciesHomeIndex, this.curSpeciesLocations);
			ns.find();
			Location oldLoc = ns.getOldLocation();
			Location newLoc = ns.getNewLocation2D();
			Location3D newLoc3D = ns.getNewLocation3D();
			boolean added = false;

			if (k < 100)
			{
				added = tryToAddCritter(curSpeciesTraits, newLoc3D, newLoc, oldLoc, true);
			}
			else
			{
				added = tryToAddCritterOverwritingAlwaysPermitted(curSpeciesTraits, newLoc3D, newLoc, oldLoc, true);
			}

			if (added)
			{
				this.curSpeciesLocations.add(newLoc);
				break;
			}

			k++;
		}
	}

	public void addCrittersNearby(int invadersToAdd)
	{
		if (this.curSpeciesLocations == null)
		{
			findCurSpeciesLocations();
		}
		TraitList curSpeciesTraits = this.curSpecies.getTraitList();
		for (int i = 0; i < invadersToAdd; i++)
		{
			addCritterNearby(curSpeciesTraits);
		}

		if (this.stepPrimer)
		{
			CommunityUtilsStep.stepPrimer(this.com);
		}
	}

	public void addCritter(TraitList tl, Location3D newLoc3D, Location newLoc, Location oldLoc, boolean useOldLoc)
	{
		int deadSpeciesVal = this.env.getGridValue(newLoc3D);
		this.env.add(newLoc3D, this.curSpeciesValue);
		if (tl != null)
		{
			if (useOldLoc)
			{
				// System.out.println("traitlist add to old loc");
				tl.addToAllSpatialDistributionTrackers(newLoc, oldLoc);
			}
			else
			{
				if (tl.hasOldTraitArchive())
				{
					// System.out.println("trait list has old trait archive");
					tl.addToAllSpatialDistributionTrackersRandomOldTraits(newLoc);
				}
				else
				{
					tl.addToAllSpatialDistributionTrackersBaselineTraits(newLoc);
				}
			}

		}

		if (deadSpeciesVal != 0)
		{
			// System.out.println("dead species val is not zero");
			TraitList deadSpeciesTL = this.com.getSpeciesList().get(deadSpeciesVal - 1).getTraitList();
			if (deadSpeciesTL != null)
			{
				deadSpeciesTL.removeFromAllSpatialDistributionTrackers(newLoc);
			}
		}
	}

	public void addCrittersRandomly(int invadersToAdd)
	{
		TraitList curSpeciesTraits = this.curSpecies.getTraitList();
		for (int i = 0; i < invadersToAdd; i++)
		{
			addCritterRandomly(curSpeciesTraits);
		}

		if (this.stepPrimer)
		{
			CommunityUtilsStep.stepPrimer(this.com);
		}
	}

	public void addCrittersRandomlyWithLimitations(int invadersToAdd, int[] offLimitSpeciesValues)
	{
		TraitList curSpeciesTraits = this.curSpecies.getTraitList();
		for (int i = 0; i < invadersToAdd; i++)
		{
			addCritterRandomlyWithLimitations(curSpeciesTraits, offLimitSpeciesValues);
		}
		if (this.stepPrimer)
		{
			CommunityUtilsStep.stepPrimer(this.com);
		}
	}

	public void addCritterRandomly(TraitList curSpeciesTraits)
	{
		int k = 0;
		while (true)
		{
			int randRow = this.referenceLocation.row() + this.generator.nextInt(this.dispersalLength);
			int randCol = this.referenceLocation.col() + this.generator.nextInt(this.dispersalLength);

			Location newLoc = new Location(randRow, randCol);
			Location3D newLoc3D = new Location3D(randRow, randCol, this.curSpeciesHomeIndex);
			boolean added = false;

			if (k < 100)
			{
				added = tryToAddCritter(curSpeciesTraits, newLoc3D, newLoc, null, false);
			}
			else
			{
				added = tryToAddCritterOverwritingAlwaysPermitted(curSpeciesTraits, newLoc3D, newLoc, null, false);
			}

			if (added)
			{
				break;
			}

			k++;
		}
	}

	public void addCritterRandomlyWithLimitations(TraitList curSpeciesTraits, int[] offLimitSpeciesValues)
	{
		int k = 0;
		while (true)
		{

			int randRow = this.referenceLocation.row() + this.generator.nextInt(this.dispersalLength);
			int randCol = this.referenceLocation.col() + this.generator.nextInt(this.dispersalLength);

			Location newLoc = new Location(randRow, randCol);
			Location3D newLoc3D = new Location3D(randRow, randCol, this.curSpeciesHomeIndex);
			boolean added = false;

			int gridValue = this.env.getGridValue(newLoc3D);
			boolean shouldTry = true;
			for (int i = 0; i < offLimitSpeciesValues.length; i++)
			{
				if (gridValue == offLimitSpeciesValues[i])
				{
					shouldTry = false;
					break;
				}
			}

			if (shouldTry)
			{

				if (k < 100)
				{
					added = tryToAddCritter(curSpeciesTraits, newLoc3D, newLoc, null, false);
				}
				else
				{
					added = tryToAddCritterOverwritingAlwaysPermitted(curSpeciesTraits, newLoc3D, newLoc, null, false);
				}
			}

			if (added)
			{
				break;
			}

			k++;
		}
	}

	public void addCrittersUniformly(int crittersToAdd)
	{
		TraitList curSpeciesTraits = this.curSpecies.getTraitList();
		System.out.println("init is " + crittersToAdd);
		int initLength = (int) Math.round(Math.sqrt(crittersToAdd));
		System.out.println("initLength is " + initLength);
		if (initLength * 2 + 2 > this.dispersalLength)
		{
			throw new IllegalArgumentException("inoculated too many inidividuals");
		}

		int distBetweenIndividuals = (int) Math.round(this.dispersalLength / (double) (initLength + 2));
		System.out.println("dist between individuals " + distBetweenIndividuals);
		int distFromEdge = distBetweenIndividuals; // (int) Math.round(distBetweenIndividuals / (double) 2);
		System.out.println("dist from edge " + distFromEdge);

		// while (true)
		// {
		int col = distFromEdge + this.referenceLocation.col();
		while (col < ((this.referenceLocation.col() + this.dispersalLength) - distFromEdge))
		{
			col += distBetweenIndividuals;
		}
		col -= distBetweenIndividuals;

		int totalEdgeDist = distFromEdge + (this.referenceLocation.col() + this.dispersalLength) - 1 - col;
		distFromEdge = (int) Math.round(totalEdgeDist / (double) 2);
		// }

		col = distFromEdge + this.referenceLocation.col();

		while (col < ((this.referenceLocation.col() + this.dispersalLength) - distFromEdge))
		{
			int row = distFromEdge + this.referenceLocation.row();
			while (row < ((this.referenceLocation.row() + this.dispersalLength) - distFromEdge))
			{
				Location newLoc = new Location(row, col);
				Location3D newLoc3D = new Location3D(row, col, this.curSpeciesHomeIndex);
				tryToAddCritter(curSpeciesTraits, newLoc3D, newLoc, null, false);
				row += distBetweenIndividuals;
			}
			col += distBetweenIndividuals;
		}

		if (this.stepPrimer)
		{
			CommunityUtilsStep.stepPrimer(this.com);
		}

	}

}
