
public interface IQuantCheatQLV
{
	double getQ(Location loc);
	//void setQ(double q);
	boolean isIndividualBased();
	double[][] getSpatialDistributionTracker();
	double getQ();
	void setupAfterCommunityIsCreated(Community com);
	void setSpeciesOwner(ISpecies species);
}
