import java.io.Serializable;

public interface IEffectValue extends Serializable
{

	boolean isIndividualBased();

	double getEffectValue(int row, int col);

	double getEffectValue();

	void setSpeciesOwner(ISpecies species);

	void setupAfterCommunityIsCreated(Community com);

	double[][] getSpatialDistributionTracker();


}
