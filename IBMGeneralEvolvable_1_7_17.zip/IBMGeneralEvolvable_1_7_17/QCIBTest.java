import java.awt.Dimension;
import java.awt.DisplayMode;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.util.ArrayList;

import com.jogamp.opengl.glu.GLU;

public class QCIBTest
{
	// community constructor params //int envLength, int numSpecies, int radius, double fractionToFill, int initAbund)
	// varying area lots little
	// length radius 20 19 18 17 16 15 14 13 12 11 10 9 8 7 6 5 4 3 2 1
	// width radius 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39

	// varying perim lots
	// length radius 20 17 15 14 13 12 11 10 9 8 7 6 5 4
	// width radius 20 24 27 28 31 33 36 40 44 49 56 66 80 100

	// varying perim lots
	// length radius 50 30 21 16 13 11 8
	// width radius 1 2 3 4 5 6 8
	// private static Community community;
	private static Community com;

	// how long should the donut be?
	private static int gridLength = 100;

	// construct species and put them in an array list. The format for species is given below:

	// Species(int speciesName, int initialAbundance, double cmax, double d, int dispersalRadius,
	// boolean makesAA1, boolean makesAA2, boolean makesAA3,
	// int AA1K, int AA2K, int AA3K)
	private static double dt = 0.1;

	private static double r1 = 1;
	private static double r2 = 1;

	private static double n1Death = 0.2;
	private static double n2Death = 0.2;

	private static int n1InitAbund = 2000;
	private static int n2InitAbund = 2000;

	private static int n1DispersalRadius = 3;
	private static int n2DispersalRadius = 3;



	private static ArrayList<ISpecies> speciesList = new ArrayList<ISpecies>();


	public static void main(String[] args) throws Exception
	{
		speciesList.add(new Species(r2, n2Death, n2DispersalRadius));
		speciesList.add(new Species(r1, n1Death, n1DispersalRadius));
		//speciesList.add(new Species(r3, n3Death, n3DispersalRadius));

		// bmin, gain, K, q, theta
		double death = 0.05;
		double bmin1 = 1.0;
		double bmin2 = 1.0;
		double gain1 = 0.02;
		double gain2 = 0.02;
		double K = 4;
		double q1 = 0.9;
		double q2 = 0.9;
		double theta1 = 0;
		double theta2 = 0;
		int diffusion1 = 3;
		int diffusion2 = 3;

		IBirthProcess bpQCn1 = new BirthQuantCheat(bmin1, gain1, K, q1, theta1);
		IBirthProcess bpQCn2 = new BirthQuantCheat(bmin2, gain2, K, q2, theta2);

		speciesList.get(0).setBirthProcess(bpQCn1);
		speciesList.get(1).setBirthProcess(bpQCn2);

		speciesList.get(0).setDeathProcess(new DeathStandard(death));
		speciesList.get(1).setDeathProcess(new DeathStandard(death));

		IEffect lv1 = new Effect(q1, diffusion1, 1);
		IEffect lv2 = new Effect(q2, diffusion2, 2);

		speciesList.get(0).setLocalEffect(1, lv1);
		speciesList.get(0).setLocalEffect(2, lv1);

		speciesList.get(1).setLocalEffect(1, lv2);
		speciesList.get(1).setLocalEffect(2, lv2);
		
		IMutationFunction mfQn1 = new MutationFunctionContinuousBoundedBetweenZeroAndOne(0.2, 0.05);
		Evolvable evolveQn1 = new QuantCheatQIB(mfQn1, 1);
		
		IMutationFunction mfQn2 = new MutationFunctionContinuousBoundedBetweenZeroAndOne(0.2, 0.05);
		Evolvable evolveQn2 = new QuantCheatQIB(mfQn2, 2);

		speciesList.get(0).addTrait(evolveQn1);
		speciesList.get(1).addTrait(evolveQn2);
		

		com = new Community(gridLength, dt, speciesList);
		evolveQn2.startEvolution();
		evolveQn1.startEvolution();
		
		
		AddCritters ac = new AddCritters(com, 1, false);
		ac.addCrittersRandomly(n1InitAbund);
		ac = new AddCritters(com, 2, false);
		ac.addCrittersRandomly(n2InitAbund);
		
		Scramble s = new Scramble(com);
		s.scramble();
	
		System.out.println("done");
		com.stepAndScrambleThroughTime(10);
		System.out.println("done");
		
		for (int i = 0; i < 1000000; i++)
		{
			com.step();
		}
		
	}
}
