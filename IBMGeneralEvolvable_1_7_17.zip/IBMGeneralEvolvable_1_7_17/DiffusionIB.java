import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;

public class DiffusionIB extends DiscreteTrait implements IDiffusion, Evolvable, Serializable
{
	// private Community com;
	// Environment env;
	private int baselineTrait;
	// private int speciesValue;
	// private boolean useAltApproach;
	// private int speciesIndex;
	// private int envGridIndex;
	// private int possibleNeighbors;
	private int affectedSpeciesValue;
	private int affectedSpeciesLVEffectValue;
	private IEffect lvEffect;
	// private double effectPerSite;
	// private double[][] lVEffectGrid;

	public DiffusionIB(IMutationFunction mf, int affectedSpeciesValue, int affectedSpeciesLVEffectValue, IEffect lvEffectToOverwrite)
	{
		super(mf);
		this.lvEffect = lvEffectToOverwrite;
		this.affectedSpeciesValue = affectedSpeciesValue;
		this.affectedSpeciesLVEffectValue = affectedSpeciesLVEffectValue;
	}

	public double[][] getLVEffectGrid()
	{
		return this.lvEffect.getLVEffectGrid();
	}

	/*
	 * public double getEffectPerSite() { return this.effectPerSite; }
	 */

	/*
	 * public LVEffectIB(IMutationFunction mf, int affectedSpeciesValue, int affectedSpeciesLVEffectValue) { super(mf); this.lvEffect = null; this.useAltApproach = false; this.affectedSpeciesValue = affectedSpeciesValue; this.affectedSpeciesLVEffectValue = affectedSpeciesLVEffectValue; // this.com = com; }
	 */

	public void initializeSpatialDistributionTracker() throws Exception
	{

		LocalLV localLV = this.species.getLocalLV();
		if (localLV == null)
		{
			// System.out.println("there is no local lv");
			this.species.setLocalEffect(this.affectedSpeciesValue, this.lvEffect);
			this.spatialDistributionTracker = this.lvEffect.getDiffusion().getSpatialDistributionTracker();

			this.baselineTrait = this.lvEffect.getDiffusion().getDiffusion();

			this.lvEffect.setDiffusion(this);

		}
		else
		{
			LVEffectsOnOneHetero[] allHeteros = localLV.getLVEffectsOnAllHeteros();
			if (allHeteros.length < this.affectedSpeciesValue)
			{
				// System.out.println("hetero length is " + allHeteros.length + ". expanding.");
				this.species.setLocalEffect(this.affectedSpeciesValue, this.lvEffect);
				this.spatialDistributionTracker = this.lvEffect.getDiffusion().getSpatialDistributionTracker();

				this.baselineTrait = this.lvEffect.getDiffusion().getDiffusion();

				this.lvEffect.setDiffusion(this);

			}
			else
			{
				LVEffectsOnOneHetero LVEffects = allHeteros[this.affectedSpeciesValue - 1];
				IEffect[] lvEffects = LVEffects.getLVEffects();
				if (lvEffects.length < this.affectedSpeciesLVEffectValue)
				{
					// System.out.println("lv effects is " + lvEffects.length + ". expanding.");

					this.species.setLocalEffect(this.affectedSpeciesValue, this.lvEffect);
					this.spatialDistributionTracker = this.lvEffect.getDiffusion().getSpatialDistributionTracker();
					this.baselineTrait = this.lvEffect.getDiffusion().getDiffusion();

					this.lvEffect.setDiffusion(this);

				}
				else
				{
					// System.out.println("everything is chill. just gotta replace the lvEffect");
					IEffect lvEffectToOverwrite = lvEffects[this.affectedSpeciesLVEffectValue - 1];
					this.spatialDistributionTracker = lvEffectToOverwrite.getDiffusion().getSpatialDistributionTracker();

					// lvEffectToOverwrite = snew LVEffect(((LVEffect) lvEffectToOverwrite).getEffectValue(), ((LVEffect) lvEffectToOverwrite).getDiffusionRadius() );
					this.lvEffect = lvEffectToOverwrite;

					IDiffusion dif = this.lvEffect.getDiffusion();
					if (dif.isIndividualBased())
					{
						this.baselineTrait = (int) ((DiffusionIB) dif).getTraitAverage();
					}
					else
					{
						//System.out.println("not individual based");
						this.baselineTrait = dif.getDiffusion();
					}

					this.lvEffect.setDiffusion(this);

					this.species.getLocalLV().setupAfterCommunityIsCreated(this.com);

				}
			}

		}
	}

	public void startEvolution() throws Exception
	{

		this.isEvolving = true;
		this.isIndividualBased = true;
		// setUpAfterCommunityIsCreated(com, this.species.getGridProxy());
		initializeSpatialDistributionTracker();
		this.lvEffect.setupAfterCommunityIsCreated(this.com);

		LocalLVAllSpecies lvAll = new LocalLVAllSpecies(com);
		lvAll.resetAffectingLVEffectsAllSpecies();
		// lvAll.setBooleans();
		// lvAll.doLocalLVStuff();

		System.out.println("made species " + species.getGridProxy() + " individual-based and evolvable");
		// System.out.println("is individual based " + this.isIndividualBased);
	}

	public void startBeingIndividualBased() throws Exception
	{
		this.isIndividualBased = true;
		// setUpAfterCommunityIsCreated(com, this.species.getGridProxy());
		initializeSpatialDistributionTracker();
		this.lvEffect.setupAfterCommunityIsCreated(this.com);

		LocalLVAllSpecies lvAll = new LocalLVAllSpecies(com);
		lvAll.resetAffectingLVEffectsAllSpecies();

		// lvAll.setBooleans();
		// lvAll.doLocalLVStuff();

		System.out.println("made species " + species.getGridProxy() + " individual-based ");
	}

	public boolean isIndividualBased()
	{
		return this.isIndividualBased;
	}

	public double getBaselineTrait()
	{
		// System.out.println("Getting baseline TRAIT: " + com.getAbundances()[this.speciesIndex] );
		if (com.getAbundances()[this.speciesIndex] != 0)
		{
			// System.out.println("not zero. Getting trait average");
			return (int) getTraitAverage();
		}
		else
		{
			// System.out.println(this.baselineTrait);
			return this.baselineTrait;
		}
	}

	public void setSpeciesOwner(ISpecies species)
	{
		this.lvEffect.setSpeciesOwner(this.species);
	}

	public void setupAfterCommunityIsCreated(Community com)
	{
		// this.com = com;
		// this.baselineTrait = (int) getTraitAverage();
		// this.lvEffect.getEffectValue().setupAfterCommunityIsCreated(com);
		// this.spatialDistributionTracker = new double[gridLength][gridLength];
		// this.gridLength = this.com.getEnvironment().getGridLength();

	}

	public double[][] getSpatialDistributionTracker()
	{
		return this.spatialDistributionTracker;
	}

	public IEffectValue getEffectValue()
	{
		return this.lvEffect.getEffectValue();
	}

	public double getEffect(Location loc)
	{
		return this.lvEffect.getEffect(loc);
	}

	public int getDiffusion()
	{
		return (int) Math.round(getTraitAverage());
	}

	public int getDiffusion(int row, int col)
	{
		return (int) this.spatialDistributionTracker[row][col];
	}

}
