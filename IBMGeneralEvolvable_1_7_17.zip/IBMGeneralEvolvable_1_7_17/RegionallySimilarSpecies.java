import java.io.Serializable;
import java.util.ArrayList;

public class RegionallySimilarSpecies implements Serializable
{

	private double[][] speciesRateByLocationMatrix;
	private int numberOfSpecies;
	private ArrayList<ISpecies> speciesList;
	private double percentOfMaxRegionalDif;
	private GenericDemographyGrid grid;
	private boolean commonBadlands;
	

	public RegionallySimilarSpecies(GenericDemographyGrid grid, ArrayList<ISpecies> speciesList, boolean commonBadlands)
	{
		this.speciesList = speciesList;
		this.grid = grid;
		this.commonBadlands = commonBadlands;
		if (this.commonBadlands)
		{ 
			
			if (this.speciesList.size() != this.grid.getNumberOfNonZeroPatchTypes())
			{
				throw new IllegalArgumentException("number of species doesn't match the number of distinct patch types, disregarding the matrix/badlands habitat");
			}
		}
		else
		{
			if (this.speciesList.size() != this.grid.getNumberOfPatchTypes())
			{
				throw new IllegalArgumentException("number of species doesn't match the number of distinct patch types");
			}
		}

		this.numberOfSpecies = grid.getNumberOfNonZeroPatchTypes();
	}
	
	
	public GenericDemographyGrid getGenericDemographyGrid()
	{
		return this.grid;
	}
	
	public double[][] getSpeciesRateByLocationMatrix()
	{
		return this.speciesRateByLocationMatrix;
	}

	public void applyToSpeciesBirth() throws Exception
	{
		////System.out.println("there are this many species: " + this.numberOfSpecies);
		for (int i = 0; i < this.numberOfSpecies; i++)
		{
			double[] rates = new double[this.grid.getNumberOfPatchTypes()];
			for (int j = 0; j < rates.length; j++)
			{
				rates[j] = this.speciesRateByLocationMatrix[i][j];
			}
			
			this.speciesList.get(i).setBirthGrid(this.grid, rates);
		}
	}
	
	public void applyToSpeciesDeath() throws Exception
	{
		for (int i = 0; i < this.numberOfSpecies; i++)
		{
			double[] rates = new double[this.grid.getNumberOfPatchTypes()];
			for (int j = 0; j < rates.length; j++)
			{
				rates[j] = this.speciesRateByLocationMatrix[i][j];
			}
			
			this.speciesList.get(i).setBirthGrid(this.grid, rates);
		}
	}
	
	public void applyToSpeciesRecruitment() throws Exception
	{
		for (int i = 0; i < this.numberOfSpecies; i++)
		{
			double[] rates = new double[this.grid.getNumberOfPatchTypes()];
			for (int j = 0; j < rates.length; j++)
			{
				rates[j] = this.speciesRateByLocationMatrix[i][j];
			}
			
			this.speciesList.get(i).setBirthGrid(this.grid, rates);
		}
	}

	public void makeSpeciesRateByLocationMatrix( double high, double low, double percentOfMaxRegionalDif, double badlands)
	{
		// if an error is thrown because the max percent of regional difference is too high, then try again until it's low enough.
		// the greater the disparity between the highest and lowest rates, the greater the max percent of regional difference can be.
		// similarly, the few species in the system, the greater the max percent of regional difference can be.
		int counter = 0;
		while (true)
		{
			try
			{
				percentOfMaxRegionalDif = percentOfMaxRegionalDif - (0.01 * counter);
				// System.out.println("high is " + percentOfMaxRegionalDif);

				tryToMakeSpeciesRateByLocationMatrix( high, low, percentOfMaxRegionalDif, badlands);
				break;
			} catch (IllegalStateException e)
			{
				// System.out.println("making compMatrix time number " + counter);
				counter++;
			}
		}
		
		/*for (int i = 0; i < speciesRateByLocationMatrix.length; i++)
		{
			for (int j = 0; j < speciesRateByLocationMatrix[0].length; j++)
			{
				System.out.print(this.speciesRateByLocationMatrix[i][j] + "   ");
			}
			 System.out.println();
			 
		}*/
		
	}

	public void tryToMakeSpeciesRateByLocationMatrix( double high, double low, double percentOfMaxRegionalDif, double badlands)
	{
		int numSpecies = this.speciesList.size();
		// if here is only one species in the system, then the matrix becomes a vector; the badlands/matrix habitat is given the badlands argument, and the other habitat is give the high argument.
		if (numSpecies == 1)
		{
			this.speciesRateByLocationMatrix = new double[numSpecies][numSpecies + 1];
			this.speciesRateByLocationMatrix[0][0] = badlands;
			this.speciesRateByLocationMatrix[0][1] = high;

		}
		else
		{

			// pre- matrix is set up with integer specifying the competitive rank of each species. 1 is the worst. n is the best
			double[][] preMatrix = new double[numSpecies][numSpecies];

			// the algorithm scans fills up a row of the matrix (representing a single species' rates in mutliple locations).
			// the first column is always zero. This is the badlands, for which each species shares the same rate.
			// in the three species case, the matrix would look like...

			// 3 2 1
			// 1 3 2
			// 2 1 3
			for (int j = 0; j < numSpecies; j++)
			{
				int topRowValue = numSpecies - j;
				preMatrix[0][j] = topRowValue;
				for(int i = 1; i < numSpecies; i++)
				{
					int valToAdd = topRowValue + i;
					if(valToAdd > numSpecies)
					{
						valToAdd -= numSpecies;
					}
					preMatrix[i][j] = valToAdd;
				}
			}
			
		/*	
			for (int i = 0; i < numSpecies; i++)
			{
				for (int j = 0; j < numSpecies; j++)
				{
					System.out.print(preMatrix[i][j] + "   ");
				}
				System.out.println("");
					
			}*/

			if (this.commonBadlands)
			{
				double[][] preMatrixWithBadlands = new double[numSpecies][numSpecies + 1];

				for (int i = 0; i < numSpecies; i++)
				{
					for (int j = 0; j < numSpecies; j++)
					{
						preMatrixWithBadlands[i][j + 1] = preMatrix[i][j];

					}
				}

				preMatrix = preMatrixWithBadlands;
			}
			
			/*for (int i = 0; i < numSpecies; i++)
			{
				for (int j = 0; j < numSpecies+1; j++)
				{
					System.out.print(preMatrix[i][j] + "   ");
				}
				System.out.println("");
					
			}*/
			// old version, made matrixes like this...
			// 0 1 2 3
			// 0 2 3 1
			// 0 3 1 2
			/*
			 * for (int i = 0; i < numSpecies; i++) { for (int j = 0; j < numSpecies; j++) {
			 * 
			 * int comp = numSpecies - j - i; if (comp > 0) { preCompMatrix[i][j + 1] = comp - 1; } else { preCompMatrix[i][j + 1] = numSpecies + comp - 1; } } }
			 */

			/*
			 * // puts values in the bestpatches instance variable for (int i = 0; i < numSpecies; i++) { for (int j = 0; j < numSpecies; j++) { // System.out.print(preCompMatrix[i][j + 1] + " "); // System.out.print(preCompMatrix[i][j+1] + " "); if (preCompMatrix[i][j + 1] == (numSpecies - 1)) {
			 * 
			 * if(i == 0) { System.out.println("about to add to invader"); }
			 * 
			 * // this.speciesList.get(i).setBestPatchType(j+1);
			 * 
			 * //this.bestPatches[i] = (j + 1);
			 * 
			 * // test
			 * 
			 * if (i == 0) { System.out.println("speciesList approach: " + this.speciesList.get(i).getBestPatchType()); System.out.println("invader approach: " + this.speciesList.get(this.invaderValue - 1).getBestPatchType());
			 * 
			 * }
			 * 
			 * } } // System.out.println(""); }
			 */

			// fill up the competitive matrix with actual birth rates
			double dif = (high - low) / ((numSpecies) - 1);

			double regionalDif = (dif * percentOfMaxRegionalDif) / ((numSpecies) - 1);

			if (this.commonBadlands)
			{
				this.speciesRateByLocationMatrix = new double[numSpecies][numSpecies + 1];
				for (int i = 0; i < numSpecies; i++)
				{
					this.speciesRateByLocationMatrix[i][0] = badlands;

					for (int j = 0; j < numSpecies; j++)
					{
						/*System.out.println("dif is " + dif);
						System.out.println("pre mat is " + preMatrix[i][j+1]);
						System.out.println("dif with pre mat is " + (preMatrix[i][j+1] * dif));
						System.out.println("toal is " +(low + preMatrix[i][j+1] * dif));
						System.out.println("");*/
						this.speciesRateByLocationMatrix[i][j + 1] = (low + (preMatrix[i][j + 1]-1) * dif) + (regionalDif * (numSpecies - i));

					}
				}
			}
			else
			{

				this.speciesRateByLocationMatrix = new double[numSpecies][numSpecies];
				for (int i = 0; i < numSpecies; i++)
				{

					for (int j = 0; j < numSpecies; j++)
					{
						/*System.out.println("dif is " + dif);
						System.out.println("dif with pre mat is " + (preMatrix[i][j] * dif));
						System.out.println("toal is " +(low + preMatrix[i][j] * dif));
						System.out.println("");*/
						this.speciesRateByLocationMatrix[i][j] = (low + preMatrix[i][j] * dif) + (regionalDif * (numSpecies - i));

					}
				}

			}

			
			for (int s = 0; s < this.numberOfSpecies; s++)
			{
				for (int c = 0; c < this.numberOfSpecies + 1; c++)
				{
					if (this.speciesRateByLocationMatrix[s][c] > 1)
					{
						//System.out.println("br is " + this.speciesRateByLocationMatrix[s][c]);
						
						throw new IllegalStateException("birth probability is > 1");
					}
				}
			}

			this.percentOfMaxRegionalDif = percentOfMaxRegionalDif;

		}
	}
	
	public double getPercentOfMaxRegionalDif()
	{
		return this.percentOfMaxRegionalDif;
	}

}
