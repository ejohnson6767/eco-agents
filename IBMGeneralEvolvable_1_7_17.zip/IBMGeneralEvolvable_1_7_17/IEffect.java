import java.io.Serializable;

public interface IEffect extends Serializable
{

	void setupAfterCommunityIsCreated(Community com);

	void setSpeciesOwner(ISpecies speciesOwner);

	void setLVEffectGrid(int[][] totalGrid);

	IEffectValue getEffectValue();
	
	IDiffusion getDiffusion();

	void fillLV();

	double getEffect(Location loc);

	double[][] getLVEffectGrid();

	void setDiffusion(IDiffusion d);
	void setEffectValue(IEffectValue e);

	boolean isIndividualBased();

	void fillLVTest() throws Exception;

	int getSpeciesValue();

	int getIndicator();

}
