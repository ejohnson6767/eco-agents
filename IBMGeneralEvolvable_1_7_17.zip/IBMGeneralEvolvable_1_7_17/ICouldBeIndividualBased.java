import java.io.Serializable;

public interface ICouldBeIndividualBased extends Serializable
{
	public void doThing();

}
