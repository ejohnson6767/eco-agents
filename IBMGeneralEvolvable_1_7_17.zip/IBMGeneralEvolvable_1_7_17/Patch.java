import java.io.Serializable;

// encapsulates information concerning patches (i.e. communities) within an environmental grid: the top-left corner, the length of square patch, 
//// and the type of patch (what species it favors)

// NOTE TO SELF: row and col instances should be encapsulated in a single Location. Doesn't matter much for this dinky program, but would be best practice.
public class Patch implements Serializable
{

	private int row;
	private int col;
	private int rowLength;
	private int colLength;
	private int patchType;
	
	public Patch(int row, int col, int rowLength, int colLength, int patchType)
	{
		this.row = row;
		this.col = col;
		this.rowLength = rowLength;
		this.colLength = colLength;
		this.patchType = patchType;
	}
	
	public int getRow()
	{
		return this.row;
	}
	
	public int getCol()
	{
		return this.col;
	}
	
	public int getRowLength()
	{
		return this.rowLength;
	}
	
	public int getColLength()
	{
		return this.colLength;
	}
	
	public int getPatchType()
	{
		return this.patchType;
	}
}
