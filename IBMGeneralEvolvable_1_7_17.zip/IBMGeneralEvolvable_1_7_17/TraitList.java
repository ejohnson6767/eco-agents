import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Random;

public class TraitList implements Serializable
{
	protected double[][][] dispersalOptions;

	private ArrayList<Evolvable> traits;
	protected HashMap<Integer, ArrayList<BrLocCollection>> birthOptions;

	protected ArrayList<ArrayList<Double>> oldTraits;
	private int gridLength;
	// private int[][] spatialDistributionTracker;
	private ISpecies species;
	private ArrayList<ITradeOff> tradeOffs;
	private int oldTraitsTimer;
	private int timeBetweenOldTraitUpdates;
	private boolean hasOldTraitArchive;
	private Random generator;

	protected Environment env;
	protected int speciesValue;
	protected int speciesIndex;
	protected int envGridIndex;
	protected Community com;

	private double[][][] discreteTraitBirthOptions;
	private ArrayList<int[]> discreteTraitCombos;
	private ArrayList<Integer> discreteTraitIndexes;

	// private int[][] spatialDistributionTracker;

	// private int[] discreteHistogram;
	private int maxDiscreteTraitValues = 5;
	private boolean useDispersalOnly;

	private boolean discreteOnly;

	public TraitList(ArrayList<Evolvable> traits)
	{
		this.traits = traits;
		this.tradeOffs = new ArrayList<ITradeOff>();
		this.gridLength = this.traits.get(0).getGridLength();
		for (int i = 0; i < this.traits.size(); i++)
		{
			if (this.gridLength != this.traits.get(i).getGridLength())
			{
				throw new IllegalArgumentException("grid lengths must be the same");
			}
		}
		this.birthOptions = new HashMap<Integer, ArrayList<BrLocCollection>>(10);
		this.oldTraits = new ArrayList<ArrayList<Double>>();
		this.oldTraitsTimer = 0;
		this.timeBetweenOldTraitUpdates = 0;
		this.hasOldTraitArchive = false;
		this.dispersalOptions = new double[this.gridLength][this.gridLength][0];
		this.species = null;
		// this.discreteHistogram = new int[this.maxDiscreteTraitValues];
		this.useDispersalOnly = false;
		// this.spatialDistributionTracker = new int[gridLength][gridLength];
	}

	public void setDiscreteTraitCombos(ArrayList<int[]> dto)
	{
		this.discreteTraitCombos = dto;
	}

	public void resetDiscreteTraitBirthOptions()
	{
		// System.out.println("there are " + dto.size() + " discrete trait options");
		/*
		 * for(int[] d : dto) { System.out.println(d[0]);
		 * 
		 * }
		 */

		this.discreteTraitBirthOptions = new double[this.gridLength][this.gridLength][this.discreteTraitCombos.size()];
	}

	public void setDiscreteTraitIndexes(ArrayList<Integer> dti)
	{
		this.discreteTraitIndexes = dti;
	}

	public void setupAfterCommunityisCreated(Community com)
	{
		this.com = com;
		this.env = this.com.getEnvironment();
		this.speciesValue = this.species.getGridProxy();
		this.speciesIndex = this.speciesValue - 1;
		this.gridLength = this.com.getEnvironment().getGridLength();
		this.envGridIndex = this.species.getHomeGridIndex();
		for (Evolvable t : this.traits)
		{
			t.setupContinuousTraitAfterCommunityIsCreated(com);
			t.setupAfterCommunityIsCreated(com);
		}
	}

	public void setRandomGenerator(Random generator)
	{
		this.generator = generator;
		for (int i = 0; i < this.traits.size(); i++)
		{
			this.traits.get(i).setRandomGenerator(generator);
		}
	}

	public Evolvable getDispersalTrait()
	{
		return (Evolvable) this.species.getDispersalStrategy();

	}

	public void setTimeBetweenOldTraitUpdates(int timeBetweenOldTraitUpdates)
	{
		// this.hasOldTraitArchive = true;
		this.timeBetweenOldTraitUpdates = timeBetweenOldTraitUpdates;
	}

	public boolean hasOldTraitArchive()
	{
		return this.hasOldTraitArchive;
	}

	public void checkForOldTraitUpdate(Community com)
	{
		if (this.timeBetweenOldTraitUpdates != 0)
		{
			if (this.oldTraitsTimer == this.timeBetweenOldTraitUpdates)
			{
				// System.out.println("updating old traits at " + this.oldTraitsTimer);
				oldTraitUpdate(com);
				this.hasOldTraitArchive = true;
				this.oldTraitsTimer = 0;

			}

			this.oldTraitsTimer++;
		}
	}

	public ArrayList<ArrayList<Double>> getOldTraitArchive()
	{
		return this.oldTraits;
	}

	public void oldTraitUpdate(Community com)
	{
		this.oldTraits = new ArrayList<ArrayList<Double>>();
		ArrayList<Evolvable> individualBasedTraits = new ArrayList<Evolvable>();
		for (int i = 0; i < this.traits.size(); i++)
		{
			if (this.traits.get(i).isIndividualBased())
			{
				individualBasedTraits.add(this.traits.get(i));
			}
		}

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (env.getGridValue(row, col, envGridIndex) == speciesValue)

				{
					ArrayList<Double> localTraits = new ArrayList<Double>();
					for (int i = 0; i < individualBasedTraits.size(); i++)
					{
						localTraits.add(individualBasedTraits.get(i).getTrait(new Location(row, col)));
					}
					this.oldTraits.add(localTraits);
				}
			}
		}
	}

	public TraitList(ArrayList<Evolvable> traits, ArrayList<ITradeOff> tradeOffs)
	{
		this.traits = traits;
		this.tradeOffs = tradeOffs;
		this.gridLength = this.traits.get(0).getGridLength();
		for (int i = 0; i < this.traits.size(); i++)
		{
			if (this.gridLength != this.traits.get(i).getGridLength())
			{
				throw new IllegalArgumentException("grid lengths must be the same");
			}
		}
		this.birthOptions = new HashMap<Integer, ArrayList<BrLocCollection>>(gridLength * gridLength);
		// this.spatialDistributionTracker = new int[gridLength][gridLength];
	}

	public void setSpeciesOwner(ISpecies species)
	{
		for (int i = 0; i < this.traits.size(); i++)
		{
			this.traits.get(i).setContinuousTraitSpeciesOwner(species);
			this.traits.get(i).setSpeciesOwner(species);
		}
		this.species = species;

	}

	public ArrayList<Evolvable> getList()
	{
		return this.traits;
	}

	public ArrayList<ITradeOff> getTradeOffList()
	{
		return this.tradeOffs;
	}

	public void startTradeOff(Community com, int indexInTradeOffList)
	{
		this.tradeOffs.get(indexInTradeOffList).startTradeOff(com);

		setRandomGenerator(com.getEnvironment().getGenerator(this.species.getHomeGridIndex()));
	}

	/*
	 * public void updateBirthOptions(Community com, int row, int col, double c) { // System.out.println("updating trait options"); int dispersalAbility = this.species.getDispersalAbility(new Location(row, col)); Environment env = com.getEnvironment(); int possibleNeighbors = (int) Math.pow(dispersalAbility * 2 + 1, 2) - 1; double cRealized = c / (double) possibleNeighbors;
	 * 
	 * int dispersalRadius = this.species.getDispersalAbility(new Location(row, col));
	 * 
	 * for (int row2 = row - dispersalRadius; row2 <= row + dispersalRadius; row2++) { for (int col2 = col - dispersalRadius; col2 <= col + dispersalRadius; col2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); updateBirthOptionsForEmptySite(row, col, realRow, realCol, cRealized, env); } }
	 * 
	 * }
	 */

	public void updateBirthOptionsForEmptySite(int row, int col, int realRow, int realCol, double cRealized, Environment env)
	{
		// System.out.println("update birth options for empty site");
		if (env.getGridValue(realRow, realCol, this.species.getHomeGridIndex()) == 0)
		{
			int key = (realRow * this.gridLength) + realCol;
			// ArrayList<brLocCollection> value = this.birthOptions.get(key);
			if (this.birthOptions.containsKey(key))
			{
				this.birthOptions.get(key).add(new BrLocCollection(cRealized, new Location(row, col)));
			}
			else
			{
				this.birthOptions.put(key, new ArrayList<BrLocCollection>() {
					{
						add(new BrLocCollection(cRealized, new Location(row, col)));
					}
				});
			}
		}
	}

	/*
	 * public void updateAllTraits(Community com, int row, int col, double c) { updateBirthOptions(com, row, col, c); for (int i = 0; i < this.traits.size(); i++) { Evolvable trait = this.traits.get(i); if(trait.isIndividualBased()) { trait.updateTraitOptions(com, row, col); } }
	 * 
	 * }
	 */

	public Location getLocationOfProgeniter(Location loc)
	{

		double theBirthProb = generator.nextDouble();
		double compareTo = 0;
		double sum = 0;
		int DA = 0;

		int row = loc.row();
		int col = loc.col();
		int key = (row * this.gridLength) + col;
		ArrayList<BrLocCollection> brLoc = this.birthOptions.get(key);
		int len = brLoc.size();
		double[] cumTrait = new double[len];
		cumTrait[0] = brLoc.get(0).getBr();
		sum += brLoc.get(0).getBr();
		for (int j = 1; j < len; j++)
		{
			double valueToAdd = brLoc.get(j).getBr();
			cumTrait[j] = valueToAdd + cumTrait[j - 1];
			sum += valueToAdd;
		}

		// System.out.println("sum is " + sum);
		// System.out.println("cum trait is " + cumDA[len-1]);

		/*
		 * for (int j = 0; j < len; j++) { System.out.println("cum da is of option " + (j+1)+ " is " + cumTrait[j] / sum); }
		 */

		for (int j = 0; j < len; j++)
		{
			compareTo = cumTrait[j] / sum;

			if (theBirthProb < compareTo)
			{
				DA = j;
				// System.out.println("picked " + (j+1) + " out of " + len);
				break;
			}
		}

		return brLoc.get(DA).getLoc();
	}

	public int getDispersalOfProgeniter(Location loc)
	{
		// System.out.println("here");
		double theBirthProb = generator.nextDouble();
		double compareTo = 0;
		double sum = 0;
		int DA = 0;

		int row = loc.row();
		int col = loc.col();
		double[] brLoc = this.dispersalOptions[row][col];
		int len = brLoc.length;
		double[] cumTrait = new double[len];
		cumTrait[0] = brLoc[0];
		sum += brLoc[0];
		for (int j = 1; j < len; j++)
		{
			double valueToAdd = brLoc[j];
			cumTrait[j] = valueToAdd + cumTrait[j - 1];
			sum += valueToAdd;
		}

		// System.out.println("sum is " + sum);
		// System.out.println("cum trait is " + cumDA[len-1]);

		for (int j = 0; j < len; j++)
		{
			// System.out.println("cum da is of option " + (j + 1) + " is " + cumTrait[j] / sum);
		}

		for (int j = 0; j < len; j++)
		{
			compareTo = cumTrait[j] / sum;

			if (theBirthProb < compareTo)
			{
				DA = j;
				// System.out.println("picked " + (j+1) + " out of " + len);
				break;
			}
		}

		// System.out.println(DA+1);
		return (DA + 1);
	}

	public int getTraitComboIndexOfProgeniter(Location loc)
	{
		// System.out.println("here");
		double theBirthProb = generator.nextDouble();
		double compareTo = 0;
		double sum = 0;
		int DA = 0;

		int row = loc.row();
		int col = loc.col();
		double[] brLoc = this.discreteTraitBirthOptions[row][col];
		int len = brLoc.length;
		double[] cumTrait = new double[len];
		cumTrait[0] = brLoc[0];
		sum += brLoc[0];
		for (int j = 1; j < len; j++)
		{
			double valueToAdd = brLoc[j];
			cumTrait[j] = valueToAdd + cumTrait[j - 1];
			sum += valueToAdd;
		}

		// System.out.println("sum is " + sum);
		// System.out.println("cum trait is " + cumDA[len-1]);

		/*
		 * for (int j = 0; j < len; j++) { System.out.println("cum of option " + (j + 1) + " is " + cumTrait[j] / sum); }
		 */

		for (int j = 0; j < len; j++)
		{
			compareTo = cumTrait[j] / sum;

			if (theBirthProb < compareTo)
			{
				DA = j;
				// System.out.println("picked " + (j+1) + " out of " + len);
				break;
			}
		}

		// System.out.println(DA+1);
		return DA;
	}

	public void addToAllSpatialDistributionTrackers(Location loc, Location parentLoc)
	{

		for (int j = 0; j < this.traits.size(); j++)
		{
			if (this.traits.get(j).isIndividualBased())
			{
				this.traits.get(j).addToSpatialDistributionTracker(loc, parentLoc);
			}
		}
	}

	public void addToAllSpatialDistributionTrackersRandomOldTraits(Location loc)
	{

		if (this.hasOldTraitArchive)
		{
			ArrayList<Double> randTraits = this.oldTraits.get(generator.nextInt(this.oldTraits.size()));
			int counter = 0;
			for (int j = 0; j < this.traits.size(); j++)
			{
				if (this.traits.get(j).isIndividualBased())
				{
					this.traits.get(j).setTrait(loc, randTraits.get(counter));
					counter++;
				}
			}
		}
		else
		{
			addToAllSpatialDistributionTrackersBaselineTraits(loc);
		}

	}

	public void addToAllSpatialDistributionTrackersBaselineTraits(Location loc)
	{

		for (int j = 0; j < this.traits.size(); j++)
		{
			Evolvable trait = this.traits.get(j);
			if (trait.isIndividualBased())
			{
				trait.setTrait(loc, trait.getBaselineTrait());

			} 
			
		}
	}

	public void removeFromAllSpatialDistributionTrackers(Location loc)
	{
		for (int j = 0; j < this.traits.size(); j++)
		{
			if (this.traits.get(j).isIndividualBased())

			{
				this.traits.get(j).removeFromSpatialDistributionTracker(loc);
			}
		}
	}

	public void resetBirthOptions()
	{
		this.birthOptions = new HashMap<Integer, ArrayList<BrLocCollection>>(10);

	}

	/*
	 * public void resetAllTraitOptions() {
	 * 
	 * 
	 * if (!this.useAltApproach) { resetBirthOptions(); } else { // resetBirthOptions(); fillDiscreteHistogram(); this.dispersalOptions = new double[gridLength][this.gridLength][this.maxDiscreteTraitValues]; }
	 * 
	 * 
	 * 
	 * 
	 * if (this.useDispersalOnly) { //resetBirthOptions(); //((DiscreteTrait) this.species.getDispersalStrategy()).fillDiscreteHistogram(); this.dispersalOptions = new double[gridLength][this.gridLength][this.maxDiscreteTraitValues+1 ];
	 * 
	 * } else if(!this.discreteOnly)
	 * 
	 * { resetBirthOptions();
	 * 
	 * } }
	 */
	public void resetAllTraitOptionsRegular()
	{
		resetBirthOptions();
	}

	public void resetAllTraitOptionsDiscreteOnly()
	{
		this.discreteTraitBirthOptions = new double[this.gridLength][this.gridLength][this.discreteTraitCombos.size()];

	}

	public void resetAllTraitOptionsDispersalOnly()
	{
		// System.out.println("max dispersal is " + this.species.getDispersalStrategy().getMaxDispersalValue());
		this.dispersalOptions = new double[gridLength][this.gridLength][((DispersalIB) this.species.getDispersalStrategy()).getMaxTraitValue()];
	}

	public void enforceAllTradeOffs()
	{
		for (int i = 0; i < this.tradeOffs.size(); i++)
		{
			this.tradeOffs.get(i).enforceTradeOff();
		}
	}

	public ArrayList<double[]> getTraits()
	{
		ArrayList<double[]> toReturn = new ArrayList<double[]>();
		int traitLen = this.traits.size();
		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				int gridValue = this.env.getGridValue(row, col, this.envGridIndex);
				if(gridValue == this.speciesValue)
				{
					double[] traitsAtLoc = new double[traitLen];
					for (int i = 0; i < traitLen; i++)
					{
						traitsAtLoc[i] = this.traits.get(i).getTrait(new Location(row, col));
					}
					toReturn.add(traitsAtLoc);
				}
			}
		}
		return toReturn;
	}

	

	public void addToAllSpatialDistributionTrackers(Location loc)
	{
		/*
		 * if (!this.useAltApproach) { addToAllSpatialDistributionTrackersRegApproach(loc); } else { addToAllSpatialDistributionTrackersAltApproach(loc); }
		 */
		if (this.useDispersalOnly)
		{
			addToAllSpatialDistributionTrackersDispersalOnlyApproach(loc);
		}
		else if (this.discreteOnly)
		{
			addToAllSpatialDistributionTrackersDiscreteTraitOnlyApproach(loc);
		}
		else
		{
			addToAllSpatialDistributionTrackersRegApproach(loc);
		}
	}

	public void addToAllSpatialDistributionTrackersRegApproach(Location loc)
	{
		//System.out.println("trying to add to all spatial distribution trakcers");
		Location parentLoc = getLocationOfProgeniter(loc);
		for (int j = 0; j < this.traits.size(); j++)
		{
			if (this.traits.get(j).isIndividualBased())
			{
				//System.out.println("trait is IB");
				this.traits.get(j).addToSpatialDistributionTracker(loc, parentLoc);
				// this.traits.get(j).addToSpatialDistributionTracker(loc, disp);

			}
		}
	}

	public void addToAllSpatialDistributionTrackersDiscreteTraitOnlyApproach(Location loc)
	{
		// Location parentLoc = getLocationOfProgeniter(loc);
		// int disp = getDispersalOfProgeniter(loc);
		int traitComboIndex = getTraitComboIndexOfProgeniter(loc);
		//// System.out.println("trait combo index of progenitor is " + traitComboIndex);
		//// System.out.println("trait to add is " + this.discreteTraitCombos.get(traitComboIndex)[0]);
		for (int j = 0; j < this.discreteTraitIndexes.size(); j++)
		{

			// this.traits.get(j).addToSpatialDistributionTracker(loc, parentLoc);
			this.traits.get(this.discreteTraitIndexes.get(j)).addToSpatialDistributionTracker(loc, this.discreteTraitCombos.get(traitComboIndex)[j]);

		}
	}

	public void addToAllSpatialDistributionTrackersDispersalOnlyApproach(Location loc)
	{
		// Location parentLoc = getLocationOfProgeniter(loc);
		int disp = getDispersalOfProgeniter(loc);
		// int traitComboIndex = getTraitComboIndexOfProgeniter(loc);
		//// System.out.println("trait combo index of progenitor is " + traitComboIndex);
		//// System.out.println("trait to add is " + this.discreteTraitCombos.get(traitComboIndex)[0]);
		for (int j = 0; j < this.traits.size(); j++)
		{
			if (this.traits.get(j).isIndividualBased())

			{
				// this.traits.get(j).addToSpatialDistributionTracker(loc, parentLoc);
				this.traits.get(j).addToSpatialDistributionTracker(loc, disp);

			}
		}
	}

	public boolean useDispersalOnlyApproach()
	{
		return this.useDispersalOnly;
	}

	public void setUseDispersalOnlyApproach(boolean YorN)
	{
		this.useDispersalOnly = YorN;
	}

	/*
	 * public int[] getDiscreteHistogram() { return this.discreteHistogram; }
	 */

	public void updateDispersalOptions(int row, int col, int dispersalRadius, double valToAdd)
	{
		this.dispersalOptions[row][col][dispersalRadius - 1] += valToAdd;
	}

	public void updateDiscreteTraitBirthOptions(int row, int col, int comboIndex, double valToAdd)
	{
		this.discreteTraitBirthOptions[row][col][comboIndex] += valToAdd;

	}

	public boolean onlyDiscreteTraitsIB()
	{
		boolean toReturn = true;
		for (Evolvable trait : this.traits)
		{
			if (trait.isContinuous())
			{
				toReturn = false;
				break;
			}
		}
		return toReturn;
	}

	public int numberOfDiscreteTraits()
	{
		int counter = 0;
		for (Evolvable trait : this.traits)
		{
			if (trait.isDiscrete())
			{
				counter++;
			}
		}
		return counter;
	}

	public ArrayList<Integer> getDiscreteIBTraitIndexesInTraitList()
	{
		ArrayList<Integer> indexes = new ArrayList<Integer>();
		for (int i = 0; i < this.traits.size(); i++)
		{
			Evolvable trait = this.traits.get(i);
			if (trait.isIndividualBased())
			{
				if (trait.isDiscrete())
				{
					indexes.add(i);
				}
			}
		}

		return indexes;

	}

	public int[] getTraitArrayAtLocation(ArrayList<Integer> indexes, Location loc)
	{
		int indexesLength = indexes.size();
		int[] curTraits = new int[indexesLength];
		for (int i = 0; i < indexesLength; i++)
		{
			curTraits[i] = (int) this.traits.get(indexes.get(i)).getTrait(loc);
		}
		return curTraits;

	}

	public ArrayList<int[]> makeCombinationsOfDiscreteTraits(ArrayList<Integer> indexes)
	{
		ArrayList<int[]> traitCombos = new ArrayList<int[]>();
		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				if (this.env.getGridValue(row, col, this.envGridIndex) == this.speciesValue)
				{
					int[] curTraits = getTraitArrayAtLocation(indexes, new Location(row, col));

					if (isUnique(curTraits, traitCombos))
					{
						traitCombos.add(curTraits);
					}
				}
			}
		}
		return traitCombos;
	}
	/*
	 * public boolean equals(int[] vec1, int[] vec2) { boolean toReturn = true; for (int i = 0; i < vec2.length; i++) { if(vec1[i] != vec2[i]) { toReturn = false; break; } } return toReturn; }
	 */

	private boolean isUnique(int[] curTraits, ArrayList<int[]> traitCombos)
	{
		boolean toReturn = true;
		for (int i = 0; i < traitCombos.size(); i++)
		{
			int[] alreadyHave = traitCombos.get(i);

			if (Arrays.equals(alreadyHave, curTraits))
			{

				toReturn = false;
				break;
			}

		}

		/*
		 * if(toReturn == true) {
		 * 
		 * System.out.println("is unique"); System.out.println("curTrait is " + curTraits[0]); for (int i = 0; i < traitCombos.size(); i++) { System.out.println("compare to " + traitCombos.get(i)[0]);
		 * 
		 * } System.out.println();
		 * 
		 * }
		 */
		return toReturn;
	}

	public int findDispersalTraitIndex(IDispersalTrait dt)
	{
		int index = -1;
		for (int i = 0; i < this.traits.size(); i++)
		{

			if (this.traits.get(i).equals(dt))
			{
				index = i;
			}
		}
		return index;

	}

	public void setOnlyDiscreteIBTraits(boolean b)
	{
		this.discreteOnly = b;

	}

	public void setDispersalIBOnly(boolean b)
	{
		this.useDispersalOnly = b;

	}

	public void resetAllSpatialDistributionTrackers()
	{
		int len = this.traits.size();
		for (int i = 0; i < len; i++)
		{
			this.traits.get(i).resetSpatialDistributionTracker();
		}
		
	}
	
	public void addToAllSpatialDistributionTrackerForScrambling(Location loc, double[] traitValues)
	{
		//System.out.println("row is " + parentLoc.row());
		///System.out.println("col is " + parentLoc.col());

		//System.out.println("trait at parent location is " + DA);
		int len = this.traits.size();
		for (int i = 0; i < len; i++)
		{
			this.traits.get(i).addToSpatialDistributionTrackerForScrambling(loc, traitValues[i]);
		}
		//System.out.println("set the trait at the new location to " + DA);

	}
	

	/*
	 * public void updateDiscreteTraitHistograms(Location loc) { for(Evolvable trait : this.traits) { if(trait.isDiscrete()) { trait.updateDiscreteHistogram } }
	 * 
	 * }
	 */

}
