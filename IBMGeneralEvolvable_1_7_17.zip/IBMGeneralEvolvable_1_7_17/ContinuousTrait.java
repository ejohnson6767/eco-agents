
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class ContinuousTrait implements Serializable
{
	/**
	 * a grid that contains dispersal ability values for each species; zero where no individuals are present. Levels are row, col, species index.
	 */
	// protected double[][][][] traitOptions;
	protected HashMap<Integer, ArrayList<Double>> traitOptions;

	protected Random generator;

	protected double[][] spatialDistributionTracker;

	protected boolean isEvolving;

	protected int gridLength;

	// protected int maxDiscreteTraitValues = 5;

	protected ISpecies species;

	protected boolean isIndividualBased;

	// protected double baselineTrait;

	protected IMutationFunction mf;

	protected Environment env;
	protected int speciesValue;
	protected int speciesIndex;
	protected int envGridIndex;
	protected Community com;

	public ContinuousTrait(IMutationFunction mf)
	{

		// this.gridLength = gridLength;
		this.mf = mf;
		// this.spatialDistributionTracker = new double[gridLength][gridLength];
		// this.traitOptions = new double[this.gridLength][this.gridLength][this.maxDiscreteTraitValues][2];
		this.traitOptions = new HashMap<Integer, ArrayList<Double>>(10);
		this.isEvolving = false;
		this.isIndividualBased = false;
		this.spatialDistributionTracker = null;
		// this.tradeOff = null;
		// this.hasTradeOff = false;
		// this.tradeOffActive = false;
	}
	
	
	public double[] getArrayOfTraitValues()
	{
		ArrayList<Double> toReturn = new ArrayList<Double>();
		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				int gridValue = this.env.getGridValue(row, col, this.envGridIndex);
				if(gridValue == this.speciesValue)
				{
					toReturn.add(this.spatialDistributionTracker[row][col]);
				}
			}
		}
		
		double[] arr = new double[toReturn.size()];
		for (int i = 0; i < arr.length; i++)
		{
			arr[i] = toReturn.get(i);
		}
		
		return arr;
	}


	public boolean isContinuous()
	{
		return true;
	}

	public boolean isDiscrete()
	{
		return false;
	}

	public void setupContinuousTraitAfterCommunityIsCreated(Community com)
	{

		this.com = com;
		this.env = this.com.getEnvironment();
		this.speciesValue = this.species.getGridProxy();
		this.speciesIndex = this.speciesValue - 1;
		this.gridLength = this.com.getEnvironment().getGridLength();
		if (this.spatialDistributionTracker == null)
		{
			this.spatialDistributionTracker = new double[gridLength][gridLength];
		}
		this.envGridIndex = this.species.getHomeGridIndex();
		this.mf.getEvolveProb().setupAfterCommunityIsCreated(com);
		this.mf.getMutationMagnitude().setupAfterCommunityIsCreated(com);

	}

	public void setRandomGenerator(Random generator)
	{
		this.generator = generator;
		this.mf.setGenerator(generator);
	}

	// public void startTradeOff(Community com)
	// {
	// if(this.hasTradeOff)
	// {
	// this.tradeOffActive = true;
	// this.tradeOff.startTradeOff(com);
	// }
	//
	// }

	// public void setTradeOff(TradeOff tradeOff)
	// {
	// this.tradeOff = tradeOff;
	// this.hasTradeOff = true;
	// }

	// public TradeOff getTradeOff()
	// {
	// return this.tradeOff;
	// }

	public void setTrait(Location loc, double newTrait)
	{
		// System.out.println("setting trait to " + newTrait);
		this.spatialDistributionTracker[loc.row()][loc.col()] = newTrait;
	}

	public double getTraitAverage()
	{

		double total = 0;
		int counter = 0;
		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				if (this.env.getGridValue(row, col, envGridIndex) == speciesValue)
				{

					total += this.spatialDistributionTracker[row][col];
					counter++;
				}
			}
		}
		return total / (double) counter;
	}

	public double getTrait(Location loc)
	{
		return this.spatialDistributionTracker[loc.row()][loc.col()];
	}

	public boolean isIndividualBased()
	{
		return this.isIndividualBased;
	}

	public void removeFromSpatialDistributionTracker(Location loc)
	{
		this.spatialDistributionTracker[loc.row()][loc.col()] = 0;
	}

	public void stopEvolution()
	{
		this.isEvolving = false;
		System.out.println("stopping evolution");
	}

	public boolean isEvolving()
	{
		return this.isEvolving;
	}

	public void resetSpatialDistributionTracker()
	{
		this.spatialDistributionTracker = new double[gridLength][gridLength];
	}

	/*
	 * public static void test(Community com, int speciesValue) { Environment env = com.getEnvironment(); int gridLength = env.getGridLength(); com.getSpeciesList().get(0)com. int speciesValue = this.species.getGridProxy(); int dispersalRadius = this.species.getDispersalAbility(); int[][] tempGrid = new int[gridLength][gridLength];
	 * 
	 * for (int row = 0; row < gridLength; row++) { for (int col = 0; col < gridLength; col++) { if (env.getGridValue(row, col) != speciesValue && this.spatialDistributionTracker[row][col] != 0) { throw new IllegalStateException(); } }
	 * 
	 * }
	 * 
	 * }
	 */
	/*
	 * public void updateTraitOptions(Community com, int row, int col, double c) {
	 * 
	 * double birthRate = this.spatialDistributionTracker[row][col]; while ((this.traitOptionDonorCounter - 1) >= this.maxDiscreteTraitValues) { System.out.println("BLEERK;DGGJASDG;"); biggerMaxDiscreteTraitValues(com, (int) Math.round(this.maxDiscreteTraitValues * 1.5)); }
	 * 
	 * int possibleNeighbors = (int) Math.pow(birthRate * 2 + 1, 2); double cRealized = c / (double) possibleNeighbors;
	 * 
	 * int dispersalRadius = species.getDispersalAbility(new Location(row, col));
	 * 
	 * for (int row2 = row - dispersalRadius; row2 <= row + dispersalRadius; row2++) { for (int col2 = col - dispersalRadius; col2 <= col + dispersalRadius; col2++) { int realRow = WrapAround.wrapAround(row2, gridLength); int realCol = WrapAround.wrapAround(col2, gridLength);
	 * 
	 * this.traitOptions[realRow][realCol][this.traitOptionDonorCounter][0] = cRealized; this.traitOptions[realRow][realCol][this.traitOptionDonorCounter][1] = birthRate;
	 * 
	 * 
	 * // DAOptions.get(speciesVal-1).get(realRow).get(realCol).add(new double[] { cRealized, (double) dispersalRadius }); } } System.out.println("trait option donor counter is " + this.traitOptionDonorCounter); this.traitOptionDonorCounter++;
	 * 
	 * }
	 */

	/*
	 * public void updateTraitOptions(Community com, int row, int col, double c) {
	 * 
	 * while (true) { try {
	 * 
	 * double birthRate = this.spatialDistributionTracker[row][col];
	 * 
	 * int possibleNeighbors = (int) Math.pow(birthRate * 2 + 1, 2); double cRealized = c / (double) possibleNeighbors;
	 * 
	 * int dispersalRadius = species.getDispersalAbility(new Location(row, col));
	 * 
	 * for (int row2 = row - dispersalRadius; row2 <= row + dispersalRadius; row2++) { for (int col2 = col - dispersalRadius; col2 <= col + dispersalRadius; col2++) { int realRow = WrapAround.wrapAround(row2, gridLength); int realCol = WrapAround.wrapAround(col2, gridLength);
	 * 
	 * this.traitOptions[realRow][realCol][this.traitOptionDonorCounter][0] = cRealized; this.traitOptions[realRow][realCol][this.traitOptionDonorCounter][1] = birthRate;
	 * 
	 * // DAOptions.get(speciesVal-1).get(realRow).get(realCol).add(new double[] { cRealized, (double) dispersalRadius }); } } System.out.println("trait option donor counter is " + this.traitOptionDonorCounter); this.traitOptionDonorCounter++; break; } catch (ArrayIndexOutOfBoundsException e) { biggerMaxDiscreteTraitValues(com, (int) Math.round(this.maxDiscreteTraitValues * 1.5));
	 * 
	 * }
	 * 
	 * }
	 * 
	 * }
	 */

	public void addToSpatialDistributionTracker(Location loc, Location parentLoc)
	{
		// System.out.println("row is " + parentLoc.row());
		/// System.out.println("col is " + parentLoc.col());

		double traitValue = this.spatialDistributionTracker[parentLoc.row()][parentLoc.col()];
		// System.out.println("trait at parent location is " + traitValue);

		if (this.isEvolving)
		{
			// System.out.println("is evolving");
			traitValue = mf.mutate(traitValue, parentLoc);
			// System.out.println("evolved trait is " + DA);

		}
		// System.out.println();

		this.spatialDistributionTracker[loc.row()][loc.col()] = traitValue;
		// System.out.println("set the trait at the new location to " + DA);

	}

	public void addToSpatialDistributionTracker(Location loc, double traitValue)
	{
		// System.out.println("row is " + parentLoc.row());
		/// System.out.println("col is " + parentLoc.col());

		// System.out.println("trait at parent location is " + DA);

		if (this.isEvolving)
		{
			traitValue = mf.mutate(traitValue);
			// System.out.println("evolved trait is " + DA);

		}
		// System.out.println();

		this.spatialDistributionTracker[loc.row()][loc.col()] = traitValue;
		// System.out.println("set the trait at the new location to " + DA);

	}

	public void addToSpatialDistributionTrackerForScrambling(Location loc, double traitValue)
	{
		// System.out.println("row is " + parentLoc.row());
		/// System.out.println("col is " + parentLoc.col());

		// System.out.println("trait at parent location is " + DA);

		this.spatialDistributionTracker[loc.row()][loc.col()] = traitValue;
		// System.out.println("set the trait at the new location to " + DA);

	}

	public void setContinuousTraitSpeciesOwner(ISpecies species)
	{
		this.species = species;
		this.mf.getEvolveProb().setSpeciesOwner(this.species);
		this.mf.getMutationMagnitude().setSpeciesOwner(this.species);

	}

	public ISpecies getSpeciesOwner()
	{
		return this.species;
	}

	public double[][] getSpatialDistributionTracker()
	{
		return this.spatialDistributionTracker;
	}
	
	public void setSpatialDistributionTracker(double[][] newSdt)
	{
		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				this.spatialDistributionTracker[row][col] = newSdt[row][col];
			}
		}
	}

	public double[][] getSpatialDistributionTrackerData()
	{
		// System.out.println("initialize spatial tracker");
		double[][] tempGrid = new double[gridLength][gridLength];
		// int counter = 0;
		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				int gridValue = env.getGridValue(row, col, envGridIndex);
				if (gridValue == speciesValue)
				{
					tempGrid[row][col] = this.spatialDistributionTracker[row][col];
				}
				else
				{
					tempGrid[row][col] = 0 / (double) 0;
				}
			}
		}
		return tempGrid;
	}

	public int getGridLength()
	{
		return this.gridLength;
	}

}
