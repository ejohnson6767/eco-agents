import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

public class NearbySpot implements Serializable
{

	private int gridLength;
	private Random generator;
	private ArrayList<Location> curSpeciesLocations;
	private ISpecies curSpecies;
	private int curSpeciesHomeIndex;
	private Location oldLoc;
	private Location3D newLoc;

	NearbySpot(int gridLength, Random generator, ISpecies curSpecies, int curSpeciesHomeIndex, ArrayList<Location> curSpeciesLocations)
	{
		this.gridLength = gridLength;
		this.generator = generator;
		this.curSpecies = curSpecies;
		this.curSpeciesLocations = curSpeciesLocations;
		this.curSpeciesHomeIndex = curSpeciesHomeIndex;
	}
	
	public void find()
	{
		int randLocationIndex = generator.nextInt(curSpeciesLocations.size());
		this.oldLoc = curSpeciesLocations.get(randLocationIndex);

		int dispersalRadius = curSpecies.getDispersalStrategy().getDispersalRadius(this.oldLoc);
		// System.out.println("disp radius is " + dispersalRadius);
		int dispersalLength = dispersalRadius * 2 + 1;
		int randRow = generator.nextInt(dispersalLength) - dispersalRadius;
		int randCol = generator.nextInt(dispersalLength) - dispersalRadius;
		// System.out.println("rand row is " + randRow);
		// System.out.println("rand col is " + randCol);

		int newRow = WrapAround.wrapAround(this.oldLoc.row() + randRow, gridLength);
		int newCol = WrapAround.wrapAround(this.oldLoc.col() + randCol, gridLength);
		
		
		this.newLoc = new Location3D(newRow, newCol, curSpeciesHomeIndex);
	}
	
	public Location getOldLocation()
	{
		return this.oldLoc;
	}
	
	public Location3D getNewLocation3D()
	{
		return this.newLoc;
	}
	
	public Location getNewLocation2D()
	{
		return new Location(this.newLoc.row(), this.newLoc.col());
	}
}
