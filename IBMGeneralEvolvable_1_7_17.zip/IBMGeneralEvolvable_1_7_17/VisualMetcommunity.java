import java.awt.BorderLayout;
import java.util.LinkedList;
import java.util.ListIterator;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.DisplayMode;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.io.File;
import java.io.IOException;
import java.lang.Math;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.LinkedList;
import java.util.ListIterator;

import com.jogamp.opengl.GL2;
import com.jogamp.opengl.GLAutoDrawable;
import com.jogamp.opengl.GLCapabilities;
import com.jogamp.opengl.GLEventListener;
import com.jogamp.opengl.GLProfile;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.glu.GLU;
import com.jogamp.opengl.util.FPSAnimator;
import com.jogamp.opengl.util.texture.Texture;
import com.jogamp.opengl.util.texture.TextureIO;

import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.KeyStroke;

public class VisualMetcommunity implements GLEventListener
{

	// community constructor params //int envLength, int numSpecies, int radius, double fractionToFill, int initAbund)
	// varying area lots little
	// length radius 20 19 18 17 16 15 14 13 12 11 10 9 8 7 6 5 4 3 2 1
	// width radius 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39

	// varying perim lots
	// length radius 20 17 15 14 13 12 11 10 9 8 7 6 5 4
	// width radius 20 24 27 28 31 33 36 40 44 49 56 66 80 100

	// varying perim lots
	// length radius 50 30 21 16 13 11 8
	// width radius 1 2 3 4 5 6 8
	private static int timeStepCounter; // will give you an idea of how many time steps the simulation has been running for
	// private static Community community;
	private static Community community;

	////////////////////////////////////////////
	// regular community constructor arguments
	private static double dt = 1;
	private static int gridLength = 300;
	private static float[] pixels = new float[gridLength * gridLength * 3];
	private static float[] pixelBase = new float[gridLength * gridLength * 3];

	////////////////////////////////////////////
	// demographic traits
	private static int numSpecies = 2;
	private static double d = 0.2;
	private static int disp = 1;
	private static double initProp = 0.05;

	private static int n1EvolveStart = 300;
	private static int n2EvolveStart = 300000;
	private static int n3EvolveStart = 1000000;

	private static boolean useAltApproach = true;
	private static boolean hasRecruitmentGrid = false;

	private static ArrayList<ArrayList<Patch>> patchList;
	////////////////////////////////////// 
	// metacommunity parameters
	private static int lengthRadius = 20;
	private static int widthRadius = 20;
	private static double fractionToFill = 0.4;
	private static int sdOfCommunityDispersion = 600;

	
	private static double high = 0.9;
	private static double low = 0.6;
	private static double percentOfMaxRegionalDif = 0.0;
	private static double badlands = 0.20;
	
	private static int numPatches = 9;

	private static boolean pause = false;
	private static boolean inoculateCheater = false;

	private static ArrayList<ISpecies> speciesList = new ArrayList<ISpecies>();

	private static int numberOfSpecies;

	private static GraphicsEnvironment graphicsEnviorment;
	private static boolean isFullScreen = false;
	public static DisplayMode dm, dm_old;
	private static Dimension xgraphic;
	private static Point point = new Point(0, 0);

	private GLU glu = new GLU();

	private static float xRot, yRot, zRot;
	private static float xRotSpeed, yRotSpeed, zRotSpeed;

	private int texture;
	private float[] lightAmbient = { 1f, 1f, 1f, 1.0f };
	private float[] lightDiffuse = { 0f, 0f, 0f, 0f };
	private float[] lightPosition = { 0.0f, 0.0f, 0.0f, 0.0f };
	private static boolean light = false;

	// angle of rotation for the camera direction
	float angle = 0.0f;
	// actual vector representing the camera's direction
	float lx = 0.0f, ly = 0.0f, lz = -1.0f;
	// XZ position of the camera
	float x = 0.0f, y = 1.0f, z = 5.0f;

	private static int FPS = 1000;

	public static void drawPatches()
	{

		// gl.glLoadIdentity(); // Reset The View
		int theRow;
		int theCol;
		int newRow;
		int newCol;

		for (int j = 0; j < patchList.size(); j++)
		{
			// System.out.println("getting subpatchlist " + (j+1));
			ArrayList<Patch> patchSubList = patchList.get(j);

			/*
			 * if (j == 0) { gl.glColor4f(1.0f, 0.0f, 0.0f, 0.2f); } else if (j == 1) { gl.glColor4f(0.0f, 1.0f, 0.0f, 0.2f); } else if (j == 2) { gl.glColor4f(0.0f, 0.0f, 1.0f, 0.2f); } else if (j == 3) { gl.glColor4f(1.0f, 1.0f, 0.0f, 0.2f); } else { gl.glColor4f(0.0f, 1.0f, 1.0f, .2f); }
			 */
			for (int i = 0; i < patchSubList.size(); i++)
			{
				// System.out.println("getting patch " + (i+1));
				Patch loc = patchSubList.get(i);
				int rowLength = loc.getRowLength();
				int colLength = loc.getColLength();
				theRow = loc.getRow();
				theCol = loc.getCol();
				for (int r = 0; r < rowLength; r++)
				{
					for (int c = 0; c < colLength; c++)
					{
						if ((r == 0 || r == rowLength - 1) || ((r != 0 || r != rowLength - 1) && (c == 0 || c == colLength - 1)))
						{

							newRow = WrapAround.wrapAround(theRow + r, gridLength);
							newCol = WrapAround.wrapAround(theCol + c, gridLength);

							int start = ((newCol * gridLength) + newRow) * 3;
							float[] update = getColor(0);
							pixelBase[start] = update[0];
							pixelBase[start + 1] = update[1];
							pixelBase[start + 2] = update[2];
						}
					}

				}
			}
		}

	}

	public static float[] getColor(int speciesValue)
	{
		float[] update = new float[3];

		if (speciesValue == 0)
		{
			update[0] = 1.0f;
			update[1] = 1.0f;
			update[2] = 1.0f;
		}
		else if (speciesValue == 1)
		{
			update[0] = 0.0f;
			update[1] = 1.0f;
			update[2] = 0.0f;

		}
		else if (speciesValue == 2)
		{
			update[0] = 1.0f;
			update[1] = 0.0f;
			update[2] = 0.0f;
		}
		else if (speciesValue == 3)
		{
			update[0] = 0.0f;
			update[1] = 0.0f;
			update[2] = 1.0f;
		}
		else if (speciesValue == 4)
		{
			update[0] = 1.0f;
			update[1] = 1.0f;
			update[2] = 0.0f;
		}
		else if (speciesValue == 5)
		{
			update[0] = 0.0f;
			update[1] = 1.0f;
			update[2] = 1.0f;
		}
		else if (speciesValue == 6)
		{
			update[0] = 1.0f;
			update[1] = 0.0f;
			update[2] = 1.0f;
		}
		else if (speciesValue == 7)
		{
			update[0] = 0.5f;
			update[1] = 1.0f;
			update[2] = 0.0f;
		}
		else if (speciesValue == 8)
		{
			update[0] = 0.0f;
			update[1] = 0.5f;
			update[2] = 1.0f;
		}
		else if (speciesValue == 69)
		{
			update[0] = 1.0f;
			update[1] = 1.0f;
			update[2] = 1.0f;
		}
		else
		{
			update[0] = 0.5f;
			update[1] = 0.0f;
			update[2] = 1.0f;
		}

		return update;
	}

	public void updateOnePixel(int row, int col, int speciesValue)
	{
		int start = ((col * gridLength) + row) * 3;
		float[] update = getColor(speciesValue);
		pixels[start] = update[0];
		pixels[start + 1] = update[1];
		pixels[start + 2] = update[2];

	}

	public void updatePixels() throws Exception
	{

		if (timeStepCounter == n1EvolveStart)
		{

			TraitList tl = speciesList.get(0).getTraitList();
			if (tl != null)
			{
				ArrayList<Evolvable> list = tl.getList();
				for (Evolvable e : list)
				{
					e.startEvolution();
				}
			}
		}
		if (timeStepCounter == n2EvolveStart)
		{
			TraitList tl = speciesList.get(1).getTraitList();
			if (tl != null)
			{
				ArrayList<Evolvable> list = tl.getList();
				for (Evolvable e : list)
				{
					e.startEvolution();
				}
			}
		}
		if (timeStepCounter == n3EvolveStart)
		{

			TraitList tl = speciesList.get(2).getTraitList();
			if (tl != null)
			{
				ArrayList<Evolvable> list = tl.getList();
				for (Evolvable e : list)
				{
					e.startEvolution();
				}
			}
		}
		/*
		 * if(timeStepCounter == 600) { TraitList tl = speciesList.get(0).getTraitList(); if (tl != null) { ArrayList<Evolvable> list = tl.getList(); for (Evolvable e : list) { e.stopEvolution(); } } }
		 */
		int pixelLength = gridLength * gridLength * 3;
		// pixels = new float[pixelLength];
		for (int i = 0; i < pixelLength; i++)
		{
			pixels[i] = pixelBase[i];
		}

		if (!pause)
		{
			// community.evolutionHousekeeping();
			// CommunityUtilsStep.stepLVMovingWindowPropaguleRainMovingWindow(community);
			// CommunityUtilsStep.stepLVMovingWindowPropaguleRainBland(community);
			// CommunityUtilsStep.stepLVUpdatePropaguleRainMovingWindow(community);
			// CommunityUtilsStep.stepLVUpdatePropaguleRainBland(community);

			community.step();

			// System.out.println("prop rain - using alt approach");
			// long start = System.nanoTime();
			// community.step();
			// long end = System.nanoTime();
			// long nanoTime = end - start;
			// System.out.println("whole step " + timeStepCounter + " took " + nanoTime / (double) 1000000 + " milliseconds");
			// System.out.println();

			timeStepCounter++;
		}

		if (timeStepCounter / 500 != 0 && timeStepCounter % 500 == 0)
		{
			/*
			 * double[] abunds = community.getAbundances(false); for (int i = 0; i < 3; i++) { System.out.println("the abundance of species " + i + " is " + abunds[i]); } for (int i = 0; i < 3; i++) { System.out.println(); }
			 */

		}

		if (inoculateCheater)
		{
			CommunityUtilsInoculate.inoculateSpecies(community, 0, true);
			inoculateCheater = false;
		}
		/*
		 * if (community.getTimeStep() == 100) { ArrayList<Species> SL = community.getSpeciesList(); for (int s = 0; s < this.numberOfSpecies; s++) { Species tempSpecies = SL.get(s); System.out.println("species " + s + " has a birth rate of " + tempSpecies.getCmax()); System.out.println("species " + s + " has a death rate of " + tempSpecies.getD()); System.out.println(""); } }
		 */
		/*
		 * if(timeStepCounter > 500) { community.invaderCheck(speciesList.get(0), tooLow, tooHigh);
		 * 
		 * }
		 */
		// community.scatter2();

		int[][][] grid = community.getGrid();

		double[][] dGrid = new double[gridLength][gridLength];
		for (int i = 0; i < dGrid.length; i++)
		{
			Arrays.fill(dGrid[i], 1);
		}

		if (hasRecruitmentGrid)
		{
			dGrid = community.getSpeciesList().get(0).getRecruitmentGrid();
		}
		for (int i = 0; i < grid.length; i++)
		{

			for (int row = 0; row < gridLength; row++)
			{
				for (int col = 0; col < gridLength; col++)
				{
					if (hasRecruitmentGrid)
					{
						if (dGrid[row][col] == 0)
						{
							updateOnePixel(row, col, 69);
						}
					}

					int gridValue = grid[i][row][col];

					if (gridValue == 0)
					{
						continue;
					}

					int currentName = speciesList.get(gridValue - 1).getGridProxy();
					// System.out.println("current name is " + currentName);

					updateOnePixel(row, col, currentName);

					/*
					 * if (currentName == 1) { updateOnePixel(row, col, 1);
					 * 
					 * if ((community.getTimeStep()-1) / 500 != 0 && (community.getTimeStep()-1) % 500 == 0) { double[][][] AAGrid = community.getAAGrid(); System.out.println("Amino acid 1 at syn one's site is " + row + " " + col + " at time step " + (community.getTimeStep()-1) + " is " + AAGrid[row][col][0]); System.out.println("Amino acid 2 at syn two's site is " + row + " " + col + " at time step " + (community.getTimeStep()-1) + " is " + AAGrid[row][col][1]); System.out.println("");
					 * 
					 * }
					 * 
					 * } else if (currentName == 2) { updateOnePixel(row, col, 2);
					 * 
					 * } else if (currentName == 3) {
					 * 
					 * updateOnePixel(row, col, 4); } else if (currentName == 12) {
					 * 
					 * updateOnePixel(row, col, 3); } else { updateOnePixel(row, col, 0); }
					 */
				}
			}
		}

		if (timeStepCounter / 100 != 0 && timeStepCounter % 100 == 0)
		{
			System.out.println("Time Step: " + timeStepCounter);

			double[] abunds = community.getAbundances(true);
			for (int i = 0; i < abunds.length; i++)
			{
				System.out.println("species " + i + " abund is " + abunds[i]);
			}
			/*
			 * ArrayList<Evolvable> traits = speciesList.get(0).getEvolvableTraits(); for (int i = 0; i < traits.size(); i++) { System.out.println("trait average is " + traits.get(i).getTraitAverage()); }
			 * 
			 * traits = speciesList.get(1).getEvolvableTraits(); for (int i = 0; i < traits.size(); i++) { System.out.println("trait average is " + traits.get(i).getTraitAverage()); }
			 * 
			 * traits = speciesList.get(2).getEvolvableTraits(); for (int i = 0; i < traits.size(); i++) { System.out.println("trait average is " + traits.get(i).getTraitAverage()); }
			 */

			/*
			 * double[] d = getDispersal.getDispersalDistribution(community, 1); for (int i = 0; i < 10; i++) { System.out.println("disp " + (i+1) + " is " + d[i]); }
			 */
			// System.out.println("species 1 is individual based: " + speciesList.get(0).getEvolvableTraits().get(0).isIndividualBased());
			// System.out.println("species 2 is individual based: " + speciesList.get(1).getEvolvableTraits().get(0).isIndividualBased());

		}

	}

	/*
	 * public void drawTorus(GL2 gl, float r, float R, int nsides, int rings) {
	 * 
	 * float ringDelta = 2.0f * (float) Math.PI / rings; float sideDelta = 2.0f * (float) Math.PI / nsides; float theta = 0.0f, cosTheta = 1.0f, sinTheta = 0.0f;
	 * 
	 * gl.glFrontFace(GL2.GL_CW);
	 * 
	 * gl.glBindTexture(GL2.GL_TEXTURE_2D, this.texture); gl.glTexEnvf(GL2.GL_TEXTURE_ENV, GL2.GL_TEXTURE_ENV_MODE, GL2.GL_MODULATE);
	 * 
	 * for (int i = rings - 1; i >= 0; i--) { float theta1 = theta + ringDelta; float cosTheta1 = (float) Math.cos(theta1); float sinTheta1 = (float) Math.sin(theta1); gl.glBegin(GL2.GL_QUAD_STRIP); float phi = 0.0f; for (int j = nsides; j >= 0; j--) { phi += sideDelta; float cosPhi = (float) Math.cos(phi); float sinPhi = (float) Math.sin(phi); float dist = R + r * cosPhi; gl.glNormal3f(cosTheta1 * cosPhi, -sinTheta1 * cosPhi, sinPhi); gl.glVertex3f(cosTheta1 * dist, -sinTheta1 * dist, r * sinPhi); gl.glNormal3f(cosTheta * cosPhi, -sinTheta * cosPhi, sinPhi); gl.glVertex3f(cosTheta * dist, -sinTheta * dist, r * sinPhi); } gl.glEnd(); theta = theta1; cosTheta = cosTheta1; sinTheta = sinTheta1; } gl.glFrontFace(GL2.GL_CCW);
	 * 
	 * }
	 */
	// public void drawTorus(GL2 gl, double r, double c, int rSeg, int cSeg/*, int texture*/)

	/* void drawTorus( */

	/*
	 * { r = 0.07; c = 0.15; rSeg = 16; cSeg = 8; //texture = 0; gl.glFrontFace(GL2.GL_CW);
	 * 
	 * gl.glBindTexture(GL2.GL_TEXTURE_2D, this.texture); gl.glTexEnvf(GL2.GL_TEXTURE_ENV, GL2.GL_TEXTURE_ENV_MODE, GL2.GL_MODULATE);
	 * 
	 * double PI = 3.1415926535897932384626433832795; double TAU = 2 * PI;
	 * 
	 * for (int i = 0; i < rSeg; i++) { gl.glBegin(GL2.GL_QUAD_STRIP); for (int j = 0; j <= cSeg; j++) { for (int k = 0; k <= 1; k++) { double s = (i + k) % rSeg + 0.5; double t = j % (cSeg + 1);
	 * 
	 * double x = (c + r * Math.cos(s * TAU / rSeg)) * Math.cos(t * TAU / cSeg); double y = (c + r * Math.cos(s * TAU / rSeg)) * Math.sin(t * TAU / cSeg); double z = r * Math.sin(s * TAU / rSeg);
	 * 
	 * double u = (i + k) / (float) rSeg; double v = t / (float) cSeg;
	 * 
	 * gl.glTexCoord2d(u, v); //gl.glNormal3f(2 * x, 2 * y, 2 * z); gl.glVertex3d(2 * x, 2 * y, 2 * z); } } gl.glEnd(); }
	 * 
	 * //gl.glFrontFace(GL2.GL_CCW); }
	 */

	private void getSpeciesList()
	{
		// TODO Auto-generated method stub

	}

	void drawTorus(GL2 gl, double R, double r, int rSeg, int cSeg)
	{

		// this.texture = 0;

		gl.glFrontFace(GL2.GL_CW);

		gl.glBindTexture(GL2.GL_TEXTURE_2D, this.texture);
		gl.glTexEnvf(GL2.GL_TEXTURE_ENV, GL2.GL_TEXTURE_ENV_MODE, GL2.GL_MODULATE);

		double PI = Math.PI;
		double TAU = 2 * PI;

		for (int i = 0; i < rSeg; i++)
		{
			gl.glBegin(GL2.GL_QUAD_STRIP);
			for (int j = 0; j <= cSeg; j++)
			{
				for (int k = 0; k <= 1; k++)
				{
					double s = (i + k) % rSeg + 0.5;
					double t = j % (cSeg + 1);

					double x = (R + r * Math.cos(s * TAU / rSeg)) * Math.cos(t * TAU / cSeg);
					double y = (R + r * Math.cos(s * TAU / rSeg)) * Math.sin(t * TAU / cSeg);
					double z = r * Math.sin(s * TAU / rSeg);

					double u = (i + k) / (float) rSeg;
					double v = t / (float) cSeg;

					gl.glTexCoord2d(u, v);
					gl.glNormal3d(2 * x, 2 * y, 2 * z);
					gl.glVertex3d(2 * x, 2 * y, 2 * z);

					/*
					 * System.out.println("x is " + x); System.out.println("y is " + y);
					 * 
					 * System.out.println("z is " + z); System.out.println("");
					 */
				}
			}
			gl.glEnd();
		}

		gl.glFrontFace(GL2.GL_CCW);
	}

	public void drawSquare(GL2 gl, int row, int col)
	{

		// gl.glBegin(GL2.GL_QUADS);

		gl.glVertex3f((float) (row + .50), (float) (col + .50), 0.0f);
		gl.glVertex3f((float) (row + .50), (float) (col - .50), 0.0f);
		gl.glVertex3f((float) (row - .50), (float) (col - .50), 0.0f);
		gl.glVertex3f((float) (row - .50), (float) (col + .50), 0.0f);

		// gl.glEnd();

	}

	public void display(GLAutoDrawable drawable)
	{

		/*
		 * if(timeStepCounter % 30 == 0 && timeStepCounter / 30 != 0) { System.out.println("adding and removing critters"); community.addAndRemoveCritters(new double[] {1000,5000}); int[] abunds = community.getAbundances(); for (int i = 0; i < abunds.length; i++) { System.out.println(abunds[i]); } }
		 */
		final GL2 gl = drawable.getGL().getGL2();

		gl.glClearColor(0.4f, 0.5f, 1.0f, 1f);
		try
		{
			updatePixels();
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		ByteBuffer byteBuf = ByteBuffer.allocateDirect(pixels.length * Float.BYTES); // 4 bytes per float
		byteBuf.order(ByteOrder.nativeOrder());
		FloatBuffer buffer = byteBuf.asFloatBuffer();
		buffer.put(pixels);
		buffer.position(0);

		gl.glTexImage2D(GL2.GL_TEXTURE_2D, 0, GL2.GL_RGB, gridLength, gridLength, 0, GL2.GL_RGB, GL2.GL_FLOAT, buffer);

		gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_MAG_FILTER, GL2.GL_NEAREST);

		gl.glClear(GL2.GL_COLOR_BUFFER_BIT | GL2.GL_DEPTH_BUFFER_BIT); // Clear The Screen And The Depth Buffer
		gl.glLoadIdentity();
		// Reset The View
		/*
		 * glu.gluLookAt(x, y, z, x + lx, y + ly, z + lz, 0.0f, 1.0f, 0.0f); gl.glTranslatef(-5.0f, 1.0f, -10.0f); // Move Left 1.5 Units And Into The Screen 6.0
		 * 
		 * gl.glRotatef(xRot, 1.0f, 0.0f, 0.0f); gl.glRotatef(yRot, 0.0f, 1.0f, 0.0f); gl.glRotatef(zRot, 0.0f, 0.0f, 1.0f);
		 * 
		 * gl.glFrontFace(GL2.GL_CW);
		 * 
		 * gl.glBindTexture(GL2.GL_TEXTURE_2D, this.texture); gl.glTexEnvf(GL2.GL_TEXTURE_ENV, GL2.GL_TEXTURE_ENV_MODE, GL2.GL_MODULATE);
		 * 
		 * 
		 * // Drawing Using Triangl.gles
		 * 
		 * gl.glTranslatef(0f, 0f, -5.0f); gl.glRotatef(xrot, 1.0f, 0.0f, 0.0f); gl.glRotatef(yrot, 0.0f, 1.0f, 0.0f); gl.glRotatef(zrot, 0.0f, 0.0f, 1.0f); gl.glBindTexture(GL2.GL_TEXTURE_2D, texture); gl.glBegin(GL2.GL_QUADS); // Front Face gl.glTexCoord2f(0.0f, 0.0f); gl.glVertex3f(-1.0f, -1.0f, 1.0f); gl.glTexCoord2f(1.0f, 0.0f); gl.glVertex3f(1.0f, -1.0f, 1.0f); gl.glTexCoord2f(1.0f, 1.0f); gl.glVertex3f(1.0f, 1.0f, 1.0f); gl.glTexCoord2f(0.0f, 1.0f); gl.glVertex3f(-1.0f, 1.0f, 1.0f); // Back Face gl.glTexCoord2f(1.0f, 0.0f); gl.glVertex3f(-1.0f, -1.0f, -1.0f); gl.glTexCoord2f(1.0f, 1.0f); gl.glVertex3f(-1.0f, 1.0f, -1.0f); gl.glTexCoord2f(0.0f, 1.0f); gl.glVertex3f(1.0f, 1.0f, -1.0f); gl.glTexCoord2f(0.0f, 0.0f); gl.glVertex3f(1.0f, -1.0f, -1.0f); // Top Face gl.glTexCoord2f(0.0f, 1.0f); gl.glVertex3f(-1.0f, 1.0f, -1.0f); gl.glTexCoord2f(0.0f, 0.0f); gl.glVertex3f(-1.0f, 1.0f, 1.0f); gl.glTexCoord2f(1.0f, 0.0f); gl.glVertex3f(1.0f, 1.0f, 1.0f); gl.glTexCoord2f(1.0f, 1.0f);
		 * gl.glVertex3f(1.0f, 1.0f, -1.0f); // Bottom Face gl.glTexCoord2f(1.0f, 1.0f); gl.glVertex3f(-1.0f, -1.0f, -1.0f); gl.glTexCoord2f(0.0f, 1.0f); gl.glVertex3f(1.0f, -1.0f, -1.0f); gl.glTexCoord2f(0.0f, 0.0f); gl.glVertex3f(1.0f, -1.0f, 1.0f); gl.glTexCoord2f(1.0f, 0.0f); gl.glVertex3f(-1.0f, -1.0f, 1.0f); // Right face gl.glTexCoord2f(1.0f, 0.0f); gl.glVertex3f(1.0f, -1.0f, -1.0f); gl.glTexCoord2f(1.0f, 1.0f); gl.glVertex3f(1.0f, 1.0f, -1.0f); gl.glTexCoord2f(0.0f, 1.0f); gl.glVertex3f(1.0f, 1.0f, 1.0f); gl.glTexCoord2f(0.0f, 0.0f); gl.glVertex3f(1.0f, -1.0f, 1.0f); // Left Face gl.glTexCoord2f(0.0f, 0.0f); gl.glVertex3f(-1.0f, -1.0f, -1.0f); gl.glTexCoord2f(1.0f, 0.0f); gl.glVertex3f(-1.0f, -1.0f, 1.0f); gl.glTexCoord2f(1.0f, 1.0f); gl.glVertex3f(-1.0f, 1.0f, 1.0f); gl.glTexCoord2f(0.0f, 1.0f); gl.glVertex3f(-1.0f, 1.0f, -1.0f); gl.glEnd(); gl.glFlush(); xrot += .3f; yrot += .2f; zrot += .4;
		 * 
		 * double R = 1.5; double r = 1; int rSeg = 50; int cSeg = 50;
		 * 
		 * drawTorus(gl, R, r, rSeg, cSeg);
		 * 
		 * xRot += xRotSpeed; yRot += yRotSpeed; zRot += zRotSpeed;
		 * 
		 * gl.glLightfv(GL2.GL_LIGHT1, GL2.GL_AMBIENT, this.lightAmbient, 0); gl.glLightfv(GL2.GL_LIGHT1, GL2.GL_DIFFUSE, this.lightDiffuse, 0); gl.glLightfv(GL2.GL_LIGHT1, GL2.GL_POSITION, this.lightPosition, 0);
		 * 
		 * if (light) { gl.glEnable(GL2.GL_LIGHT1); gl.glEnable(GL2.GL_LIGHTING); } // System.out.println(xRotSpeed);
		 */gl.glLoadIdentity(); // Reset The View
		glu.gluLookAt(x, y, z, x + lx, y + ly, z + lz, 0.0f, 1.0f, 0.0f);
		// gl.glTranslatef(5.0f, 1.0f, -10.0f); // Move Left 1.5 Units And Into The Screen 6.0
		gl.glTranslatef(0.0f, 1.0f, -8.0f); // Move Left 1.5 Units And Into The Screen 6.0

		gl.glBegin(GL2.GL_QUADS);

		gl.glTexCoord2d(0, 1);
		gl.glVertex3d(-4, 4, 0.5);

		gl.glTexCoord2d(1, 1);
		gl.glVertex3d(4, 4, .5);

		gl.glTexCoord2d(1, 0);
		gl.glVertex3d(4, -4, .5);

		gl.glTexCoord2d(0, 0);
		gl.glVertex3d(-4, -4, .5);

		gl.glEnd();

		gl.glFlush();

		/*
		 * //final GL2 gl2 = drawable.getGL().getGL2();
		 * 
		 * //gl2.glClear(GL2.GL_COLOR_BUFFER_BIT | GL2.GL_DEPTH_BUFFER_BIT); // Clear The Screen And The Depth Buffer //gl2.glLoadIdentity(); // Reset The View gl.glLoadIdentity(); // Reset The View
		 * 
		 * glu.gluLookAt( x, y, z, x+lx, y+ly, z+lz, 0.0f, 1.0f, 0.0f);
		 * 
		 * 
		 * gl.glTranslatef(1.0f, 0.0f, -15.0f); // Move Left 1.5 Units And Into The Screen 6.0 makeFlatGrid(gl);
		 * 
		 * 
		 * gl.glFlush();
		 */

	}

	public void dispose(GLAutoDrawable drawable)
	{
		// TODO Auto-generated method stub

	}

	public void init(GLAutoDrawable drawable)
	{

		final GL2 gl = drawable.getGL().getGL2();
		gl.glShadeModel(GL2.GL_SMOOTH);
		gl.glClearColor(0f, 0f, 0f, 0f);
		gl.glClearDepth(1.0f);
		gl.glEnable(GL2.GL_DEPTH_TEST);
		gl.glDepthFunc(GL2.GL_LEQUAL);
		gl.glHint(GL2.GL_PERSPECTIVE_CORRECTION_HINT, GL2.GL_NICEST); 

		gl.glEnable(GL2.GL_TEXTURE_2D);
		try
		{
			File im = new File("IBM.png");
			System.out.println("found the data");
			Texture t = TextureIO.newTexture(im, true);
			this.texture = t.getTextureObject(gl);
		} catch (IOException e)
		{
			System.out.println("can't find the png");
			e.printStackTrace();

		}
	}

	public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height)
	{
		// TODO Auto-generated method stub
		final GL2 gl = drawable.getGL().getGL2();

		if (height <= 0)
			height = 1;
		final float h = (float) width / (float) height;
		gl.glViewport(0, 0, width, height);
		gl.glMatrixMode(GL2.GL_PROJECTION);
		gl.glLoadIdentity();
		glu.gluPerspective(45.0f, h, 1.0, 20.0);
		gl.glMatrixMode(GL2.GL_MODELVIEW);
		gl.glLoadIdentity();
	}

	public static void main(String[] args) throws Exception
	{
		//////////////////////////////////////////////////////
		// setup species
		for (int i = 0; i < numSpecies; i++)
		{
			speciesList.add(new Species(1, d, disp));
			IBirthProcess bp1 = new BirthMetacommunity(1);
			speciesList.get(i).setBirthProcess(bp1);
		}
 
		//////////////////////////////////////////////////////
		// individual based evolution
		IMutationFunction mfDisp = new MutationFunctionDiscreteBoundedByOne(0.1, 1);
		Evolvable dispEvolven1 = new DispersalIB(mfDisp);

		IMutationFunction mfDispn2 = new MutationFunctionDiscreteBoundedByOne(0.005, 1);
		Evolvable dispEvolven2 = new DispersalIB(mfDispn2);

		IMutationFunction mfEvolveProb = new MutationFunctionContinuousBoundedByZero(0.05, 0.03);
		Evolvable evolveProbEvolve = new EvolveProbIB(mfEvolveProb, mfDisp);

		IMutationFunction mfmm = new MutationFunctionContinuousBoundedByZero(0.05, 0.5);
		Evolvable mmEvolve = new MutationMagnitudeIB(mfmm, mfDisp);

		// speciesList.get(0).addTrait(dispEvolven1);
		// dispEvolven1.startEvolution();

		//////////////////////////////////////////////////////
		// setup metacommunity structure
		GenericDemographyGrid grid = new GenericDemographyGrid(gridLength);
		//grid.makePatchyGrid(speciesList.size(), lengthRadius, widthRadius, fractionToFill, sdOfCommunityDispersion);
		grid.setupForPatches(speciesList.size(), lengthRadius, widthRadius);
		
		int pt = 1;
		int dist = (int) Math.round(gridLength/(double)6);
		for(int i = 1; i <= 5; i++)
		{
			for(int j = 1; j <= 5; j++)
			{
				int row = dist * i;
				int col = dist * j;
				grid.placeSinglePatch(row, col, pt);
				if(pt == 1)
				{
					pt = 2;
				} else if(pt == 2)
				{
					pt = 1;
				}
			}
		}
		grid.finishSetupForPatches();
			
		
		//grid.addPatchesUniformly(speciesList.size(), numPatches, lengthRadius);
		RegionallySimilarSpecies rss = new RegionallySimilarSpecies(grid, speciesList, true);
		rss.makeSpeciesRateByLocationMatrix(high, low, percentOfMaxRegionalDif, badlands);
		rss.applyToSpeciesBirth();

		patchList = grid.getPatchList();
		drawPatches();
		System.out.println("regional disparity index " + rss.getPercentOfMaxRegionalDif());
		System.out.println("patches cover " + (grid.getPatchProportion() * 100) + "% of the landscape");
		System.out.println("patch area is " + grid.getPatchArea());
		System.out.println("patch perimeter is " + grid.getPatchPerimeter());
		System.out.println("there are " + grid.getPatchesPerSpecies() + " good patches per species.");

		//////////////////////////////////////////////////////
		// setup spatial variation in recruitment

		// GenericDemographyGrid grid = new GenericDemographyGrid(gridLength);
		// grid.makePatchyGrid(speciesList.size(), 30, 20, 0.3, 300);
		// grid.setSeed(20);
		// grid.makePercolationGrid(new double[] { 0.80 });

		// grid.makeCheckerboardGrid(gridLength/40, 40, true);
		// speciesList.get(0).setRecruitmentGrid(grid, new double[] { 0, 1 });
		// speciesList.get(1).setRecruitmentGrid(grid, new double[] { 0, 1 });

		// rss.makeSpeciesRateByLocationMatrix(0.8, 0.4, 0, 0.1);
		// rss.applyToSpeciesBirth();

		community = new Community(gridLength, dt, speciesList);

		int initAbund = (int) (Math.round(initProp * gridLength * gridLength) / (double) numSpecies);
		for (int i = 0; i < numSpecies; i++)
		{
			AddCritters ac = new AddCritters(community, (i + 1), false);
			ac.addCrittersRandomly(initAbund);
		}
	/*	community.step(100);

		int empBigger = 0;
		int counter = 0; 
		for (int i = 0; i < 100; i++)
		{
			LambdaTilda tl1 = new LambdaTilda(community, 1);
			LambdaTilda tl2 = new LambdaTilda(community, 2);
			double expFit1 = tl1.get();
			double expFit2 = tl2.get();

			EmpiricalFitness ef = new EmpiricalFitness(community);
			ef.beforeSteppingStuff();
			community.step();
			double[] fa = ef.getFitnessAverages();

			System.out.println("empirical fitness " + 1 + " " + fa[0]);
			System.out.println("expected fitness " + 1 + " " + expFit1);
			System.out.println("");
			System.out.println("empirical fitness " + 2 + " " + fa[1]);
			System.out.println("expected fitness " + 2 + " " + expFit2);

			System.out.println();
			counter = counter + 2;
			if(fa[0] > expFit1)
			{
				empBigger++;
			}
			if(fa[1] > expFit2)
			{
				empBigger++;
			}
		}
		
		System.out.println("empirical is bigger this often: " + (empBigger / (double) counter));*/
		// setUp open GL version 2
		final GLProfile profile = GLProfile.get(GLProfile.GL2);
		GLCapabilities capabilities = new GLCapabilities(profile);

		// The canvas
		final GLCanvas glcanvas = new GLCanvas(capabilities);
		VisualMetcommunity r = new VisualMetcommunity();
		glcanvas.addGLEventListener(r);
		glcanvas.setSize(900, 400);

		final FPSAnimator animator = new FPSAnimator(glcanvas, FPS, true);

		final JFrame frame = new JFrame("donut model");

		frame.getContentPane().add(glcanvas);

		// Shutdown
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e)
			{
				if (animator.isStarted())
					animator.stop();
				System.exit(0);
			}
		});

		frame.setSize(frame.getContentPane().getPreferredSize());
		/**
		 * Centers the screen on start up
		 * 
		 */
		graphicsEnviorment = GraphicsEnvironment.getLocalGraphicsEnvironment();

		GraphicsDevice[] devices = graphicsEnviorment.getScreenDevices();

		dm_old = devices[0].getDisplayMode();
		dm = dm_old;
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

		int windowX = Math.max(0, (screenSize.width - frame.getWidth()) / 2);
		int windowY = Math.max(0, (screenSize.height - frame.getHeight()) / 2);

		frame.setLocation(windowX, windowY);
		/**
				 * 
				 */
		frame.setVisible(true);
		/*
		 * Time to add Button Control
		 */
		JPanel p = new JPanel();
		p.setPreferredSize(new Dimension(0, 0));
		frame.add(p, BorderLayout.SOUTH);

		keyBindings(p, frame, r);
		animator.start();
	}

	public static void keyBindings(JPanel p, final JFrame frame, final VisualMetcommunity r)
	{

		ActionMap actionMap = p.getActionMap();
		InputMap inputMap = p.getInputMap();

		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0), "F1");
		actionMap.put("F1", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				fullScreen(frame);
			}
		});
		/**
		 * 
		 */
		/*
		 * 
		 */
		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_UP, 0), "UP");
		actionMap.put("UP", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				if (xRotSpeed > -8)
				{
					xRotSpeed -= 0.1f;
				}
			}
		});
		/**
		 * 
		 */
		/*
		 * 
		 */
		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_P, 0), "P");
		actionMap.put("P", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				if (pause)
				{
					pause = false;
				}
				else
				{
					pause = true;
				}
			}
		});
		/**
		 * 
		 */
		/*
		 * 
		 */

		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_I, 0), "I");
		actionMap.put("I", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				inoculateCheater = true;
			}
		});
		/**
		 * 
		 */
		/*
		 * 
		 */
		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_K, 0), "K");
		actionMap.put("K", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				int[][][] grid = community.getGrid();

				for (int i = 0; i < grid.length; i++)
				{

					for (int row = 0; row < gridLength; row++)
					{
						for (int col = 0; col < gridLength; col++)
						{
							if (grid[i][row][col] == 1)
							{
								grid[i][row][col] = 0;
							}
						}
					}
				}
			}
		});
		/**
		 * 
		 */
		/*
		 * 
		 */
		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_C, 0), "C");
		actionMap.put("C", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				int[][][] grid = community.getGrid();
				int mid = (int) Math.round(gridLength / (double) 2);

				for (int i = 0; i < grid.length; i++)
				{
					for (int row = mid - 80; row < mid + 80; row++)
					{
						for (int col = mid - 80; col < mid + 80; col++)
						{

							grid[i][row][col] = 0;

						}
					}
				}
			}
		});
		/**
		 * 
		 */
		/*
		 * 
		 */
		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, 0), "DOWN");
		actionMap.put("DOWN", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				if (xRotSpeed < 8)
				{
					xRotSpeed += 0.1f;
				}
			}
		});
		/** 
		 * 
		 */
		/*
		 * 
		 */
		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0), "LEFT");
		actionMap.put("LEFT", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				if (yRotSpeed < 8)
				{
					yRotSpeed += 0.1f;
				}
			}
		});
		/**
		 * 
		 */
		/*
		 * 
		 */
		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0), "RIGHT");
		actionMap.put("RIGHT", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				if (yRotSpeed > -8)
				{
					yRotSpeed -= 0.1f;
				}
			}
		});
		/**
		 * 
		 */
		/*
		 * 
		 */

		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_S, 0), "S");
		actionMap.put("S", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				float fraction = 0.1f;
				r.x -= r.lx * fraction;
				r.z -= r.lz * fraction;
			}
		});

		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_W, 0), "W");
		actionMap.put("W", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				float fraction = 0.1f;
				r.x += r.lx * fraction;
				r.z += r.lz * fraction;
			}
		});

		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_D, 0), "D");
		actionMap.put("D", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				float fraction = 0.1f;
				r.x += fraction;
			}
		});

		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_A, 0), "A");
		actionMap.put("A", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6576101918414437189L;

			public void actionPerformed(ActionEvent drawable)
			{
				// TODO Auto-generated method stub
				float fraction = 0.1f;
				r.x -= fraction;
			}
		});

	}

	protected static void fullScreen(JFrame f)
	{
		// TODO Auto-generated method stub
		if (!isFullScreen)
		{
			f.dispose();
			f.setUndecorated(true);
			f.setVisible(true);
			f.setResizable(false);
			xgraphic = f.getSize();
			point = f.getLocation();
			f.setLocation(0, 0);
			Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
			f.setSize((int) screenSize.getWidth(), (int) screenSize.getHeight());
			isFullScreen = true;
		}
		else
		{
			f.dispose();
			f.setUndecorated(false);
			f.setResizable(true);
			f.setLocation(point);
			f.setSize(xgraphic);
			f.setVisible(true);

			isFullScreen = false;
		}

	}

}