import java.io.Serializable;

public class LambdaBar implements Chessonable, ITimeSeriesQuantity, Serializable
{
	private int speciesValue;
	private Community com;
	private int returnLength;

	public LambdaBar(Community com, int speciesValue)
	{
		this.speciesValue = speciesValue;
		this.com = com;
		this.returnLength = 1;

	}

	public int getReturnLength()
	{
		return this.returnLength;
	}

	public Double get()
	{
		ISpecies aSpecies = com.getSpeciesList().get(this.speciesValue - 1);
		IDispersalTrait dt = aSpecies.getDispersalStrategy();
		double dTime = this.com.getDt();
		if (dt.isIndividualBased())
		{
			Environment env = com.getEnvironment();
			int gridLength = env.getGridLength();
			double total = 0;
			int counter = 0;
			for (int row = 0; row < gridLength; row++)
			{
				for (int col = 0; col < gridLength; col++)
				{
					total += aSpecies.getFitness(new Location(row, col));
					counter++;

				}
			}
			return total / (double) counter;
		}
		else
		{
			GetEGrid geg = new GetEGrid(this.com, this.speciesValue);
			double[][] EGrid = geg.getGrid(dt.getDispersalRadius());
			Environment env = com.getEnvironment();
			int gridLength = env.getGridLength();
			double total = 0;
			int counter = 0;
			for (int row = 0; row < gridLength; row++)
			{
				for (int col = 0; col < gridLength; col++)
				{

					Location loc = new Location(row, col);
					double lambda = 1 + (aSpecies.getBirthRate(loc) * EGrid[row][col]) - aSpecies.getDeathRate(loc);
					total += CorrectLambdaWithDt.correct(lambda, dTime);
					counter++;

				}
			}

			return total / (double) counter;
		}

	}

	public Double get(double[][] EGrid)
	{
		ISpecies aSpecies = com.getSpeciesList().get(this.speciesValue - 1);
		IDispersalTrait dt = aSpecies.getDispersalStrategy();
		double dTime = this.com.getDt();

		Environment env = com.getEnvironment();
		int gridLength = env.getGridLength();
		double total = 0;
		int counter = 0;
		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				Location loc = new Location(row, col);
				double lambda = 1 + (aSpecies.getBirthRate(loc) * EGrid[row][col]) - aSpecies.getDeathRate(loc);
				total += CorrectLambdaWithDt.correct(lambda, dTime);
				counter++;
			}
		}
		return total / (double) counter;
	}

}