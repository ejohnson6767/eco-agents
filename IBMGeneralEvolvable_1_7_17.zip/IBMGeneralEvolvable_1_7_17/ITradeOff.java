import java.io.Serializable;
import java.util.ArrayList;

public interface ITradeOff extends Serializable
{

	void startTradeOff(Community com);

	void enforceTradeOff();

	ArrayList<Evolvable> getTradeOffTraits();


}
