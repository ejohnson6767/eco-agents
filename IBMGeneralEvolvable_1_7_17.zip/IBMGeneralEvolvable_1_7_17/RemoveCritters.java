import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

public class RemoveCritters extends ModifyAbundance implements Serializable
{

	protected ISpecies curSpecies;
	protected Random generator;
	
	public RemoveCritters(Community com, int speciesValue)
	{
		super(com, speciesValue);
		this.env = com.getEnvironment();
		int curSpeciesValue = speciesValue;
		this.curSpecies = com.getSpeciesList().get(curSpeciesValue - 1);
		this.curSpeciesHomeIndex = this.curSpecies.getHomeGridIndex();
		this.generator = com.getEnvironment().getGenerator(this.curSpeciesHomeIndex);
		this.curSpeciesLocations = null;
	}
	
	public RemoveCritters(Community com, int speciesValue, ArrayList<Location> curSpeciesLocations)
	{
		super(com, speciesValue);
		this.env = com.getEnvironment();
		int curSpeciesValue = speciesValue;
		this.curSpecies = com.getSpeciesList().get(curSpeciesValue - 1);
		this.curSpeciesHomeIndex = this.curSpecies.getHomeGridIndex();
		this.generator = com.getEnvironment().getGenerator(this.curSpeciesHomeIndex);
		this.curSpeciesLocations = curSpeciesLocations;
	}
	

	public void removeCrittersWithTraits(int numberToRemove)
	{

		TraitList traitList = this.curSpecies.getTraitList();
		int numberRemoved = 0;
		while (numberRemoved < numberToRemove)
		{
			int randLocationIndex = generator.nextInt(this.curSpeciesLocations.size());
			Location loc = this.curSpeciesLocations.get(randLocationIndex);
			this.env.remove(loc.row(), loc.col(), this.curSpeciesHomeIndex);
			traitList.removeFromAllSpatialDistributionTrackers(loc);
			this.curSpeciesLocations.remove(randLocationIndex);
			numberRemoved++;

		}
		

	}

	public void removeCrittersNoTraits(int numberToRemove)
	{
		int numberRemoved = 0;
		while (numberRemoved < numberToRemove)
		{
			int randLocationIndex = generator.nextInt(this.curSpeciesLocations.size());
			Location loc = this.curSpeciesLocations.get(randLocationIndex);
			this.env.remove(loc.row(), loc.col(), this.curSpeciesHomeIndex);
			this.curSpeciesLocations.remove(randLocationIndex);
			numberRemoved++;
		}
	}

	public void removeCritters(int numberToRemove)
	{
		if (this.curSpeciesLocations == null)
		{
			findCurSpeciesLocations();
		}
		
		if (SpeciesTraitQuestions.isIndividualBased(this.curSpecies))
		{
			removeCrittersWithTraits(numberToRemove);
		}
		else
		{
			removeCrittersNoTraits(numberToRemove);
		}
		
		UpdateAbundances ua = new UpdateAbundances(com);
		ua.update();
		CommunityUtilsStep.stepPrimer(this.com);
	}

	
}

