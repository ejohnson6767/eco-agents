import java.io.Serializable;

public class LambdaDensityCovariance implements Chessonable, Serializable, ITimeSeriesQuantity
{
	private int speciesValue;
	private Community com;

	public LambdaDensityCovariance(Community com, int speciesValue)
	{
		this.speciesValue = speciesValue;
		this.com = com;
	}

	public Double get()
	{

		ISpecies aSpecies = com.getSpeciesList().get(this.speciesValue - 1);
		IDispersalTrait dt = aSpecies.getDispersalStrategy();
		double dTime = this.com.getDt();
		if (dt.isIndividualBased())
		{
			int homeGridIndex = aSpecies.getHomeGridIndex();
			Environment env = com.getEnvironment();
			int gridLength = env.getGridLength();
			int totalSites = env.getTotalSites();

			int OccupiedCounter = 0;
			int EmptyCounter = 0;
			double OccupiedFitnessTotal = 0;
			double EmptyFitnessTotal = 0;

			for (int row = 0; row < gridLength; row++)
			{
				for (int col = 0; col < gridLength; col++)
				{
					if (env.getGridValue(row, col, homeGridIndex) == speciesValue)
					{
						double lambda = aSpecies.getFitness(new Location(row, col));
						OccupiedFitnessTotal += CorrectLambdaWithDt.correct(lambda, dTime);
						OccupiedCounter++;
					}
					else
					{
						double lambda = aSpecies.getFitness(new Location(row, col));
						EmptyFitnessTotal += CorrectLambdaWithDt.correct(lambda, dTime);
						EmptyCounter++;
					}
				}
			}

			if (OccupiedCounter == 0)
			{
				OccupiedCounter = 1;
			}
			if (EmptyCounter == 0)
			{
				EmptyCounter = 1;
			}

			double proportionOfOccupiedSites = OccupiedCounter / (double) totalSites;
			double averageOccupied = (OccupiedFitnessTotal / (double) OccupiedCounter);
			double averageEmpty = (EmptyFitnessTotal / (double) EmptyCounter);

			return (1 - proportionOfOccupiedSites) * (averageOccupied - averageEmpty);

		}
		else
		{
			GetEGrid geg = new GetEGrid(this.com, this.speciesValue);
			double[][] EGrid = geg.getGrid(dt.getDispersalRadius());
			int homeGridIndex = aSpecies.getHomeGridIndex();
			Environment env = com.getEnvironment();
			int gridLength = env.getGridLength();
			int totalSites = env.getTotalSites();

			int OccupiedCounter = 0;
			int EmptyCounter = 0;
			double OccupiedFitnessTotal = 0;
			double EmptyFitnessTotal = 0;

			for (int row = 0; row < gridLength; row++)
			{
				for (int col = 0; col < gridLength; col++)
				{
					if (env.getGridValue(row, col, homeGridIndex) == speciesValue)
					{

						Location loc = new Location(row, col);
						double lambda = 1 + (aSpecies.getBirthRate(loc) * EGrid[row][col]) - aSpecies.getDeathRate(loc);
						OccupiedFitnessTotal += CorrectLambdaWithDt.correct(lambda, dTime);
						OccupiedCounter++;
					}
					else
					{
						Location loc = new Location(row, col);
						double lambda = 1 + (aSpecies.getBirthRate(loc) * EGrid[row][col]) - aSpecies.getDeathRate(loc);
						EmptyFitnessTotal += CorrectLambdaWithDt.correct(lambda, dTime);
						EmptyCounter++;
					}
				}
			}

			if (OccupiedCounter == 0)
			{
				OccupiedCounter = 1;
			}
			if (EmptyCounter == 0)
			{
				EmptyCounter = 1;
			}

			double proportionOfOccupiedSites = OccupiedCounter / (double) totalSites;
			double averageOccupied = (OccupiedFitnessTotal / (double) OccupiedCounter);
			double averageEmpty = (EmptyFitnessTotal / (double) EmptyCounter);

			return (1 - proportionOfOccupiedSites) * (averageOccupied - averageEmpty);
		}
	}

	public Double get(double[][] EGrid)
	{

		ISpecies aSpecies = com.getSpeciesList().get(this.speciesValue - 1);
		double dTime = this.com.getDt();

		int homeGridIndex = aSpecies.getHomeGridIndex();
		Environment env = com.getEnvironment();
		int gridLength = env.getGridLength();
		int totalSites = env.getTotalSites();

		int OccupiedCounter = 0;
		int EmptyCounter = 0;
		double OccupiedFitnessTotal = 0;
		double EmptyFitnessTotal = 0;

		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				if (env.getGridValue(row, col, homeGridIndex) == speciesValue)
				{

					Location loc = new Location(row, col);
					double lambda = 1 + (aSpecies.getBirthRate(loc) * EGrid[row][col]) - aSpecies.getDeathRate(loc);
					OccupiedFitnessTotal += CorrectLambdaWithDt.correct(lambda, dTime);
					OccupiedCounter++;
				}
				else
				{
					Location loc = new Location(row, col);
					double lambda = 1 + (aSpecies.getBirthRate(loc) * EGrid[row][col]) - aSpecies.getDeathRate(loc);
					EmptyFitnessTotal += CorrectLambdaWithDt.correct(lambda, dTime);
					EmptyCounter++;
				}
			}
		}

		if (OccupiedCounter == 0)
		{
			OccupiedCounter = 1;
		}
		if (EmptyCounter == 0)
		{
			EmptyCounter = 1;
		}

		double proportionOfOccupiedSites = OccupiedCounter / (double) totalSites;
		double averageOccupied = (OccupiedFitnessTotal / (double) OccupiedCounter);
		double averageEmpty = (EmptyFitnessTotal / (double) EmptyCounter);

		return (1 - proportionOfOccupiedSites) * (averageOccupied - averageEmpty);
	}

	

	@Override
	public int getReturnLength()
	{
		return 1;
	}

}
