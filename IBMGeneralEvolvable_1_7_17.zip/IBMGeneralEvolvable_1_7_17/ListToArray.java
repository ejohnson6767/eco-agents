import java.util.ArrayList;

public class ListToArray
{
	public static double[] doubleListToArray(ArrayList<Double> list)
	{
		int len = list.size();
		double[] toReturn  = new double[len];
		for (int i = 0; i < len; i++)
		{
			toReturn[i] = list.get(i);
		}
		return toReturn;
	}
	
	public static int[] integerListToArray(ArrayList<Integer> list)
	{
		int len = list.size();
		int[] toReturn  = new int[len];
		for (int i = 0; i < len; i++)
		{
			toReturn[i] = list.get(i);
		}
		return toReturn;
	}
}
