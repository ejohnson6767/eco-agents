import java.io.Serializable;
import java.util.ArrayList;

public class GetChessonQuantities implements Serializable
{
	InvasionCommunity com;
	ArrayList<Chessonable> chessonFunctions;

	public GetChessonQuantities(InvasionCommunity com, ArrayList<Chessonable> chessonFunctions)
	{
		this.com = com;
		this.chessonFunctions = chessonFunctions;
	}

	public void setChessonFunctions(ArrayList<Chessonable> chessonFunctions)
	{
		this.chessonFunctions = chessonFunctions;
	}

	public double[][] getChessonFunctionsOverTime(int numReps, int getAfterThisTimeSinceInvaderRegulation, int getAfterThisTimeSinceInvaderRegulationFromZeroDensity, int maxAvgStepsPerRep) throws Exception
	{
		double[][] toReturn = new double[numReps][this.chessonFunctions.size()];
		int counter = 0;
		int maxSteps = maxAvgStepsPerRep * numReps;
		while (counter < numReps)
		{
			this.com.step();
			if (com.getTimeSinceInvaderRegulation() >= getAfterThisTimeSinceInvaderRegulation
					&& com.getTimeSinceInvaderRegulationFromZeroDensity() >= getAfterThisTimeSinceInvaderRegulationFromZeroDensity)
			{
				for (int i = 0; i < this.chessonFunctions.size(); i++)
				{
					toReturn[counter][i] = (double) this.chessonFunctions.get(i).get();
					

				}
				counter++;
			}
			
			if(counter == maxSteps)
			{
				for (int i = 0; i < toReturn.length; i++)
				{
					for (int j = 0; j < toReturn[0].length; j++)
					{
						toReturn[i][j] = 1/0;
					}
				}
			}
		}
		return toReturn;
	}
	
	public double[] getChessonFunctionsAveragedOverTime(int numReps, int getAfterThisTimeSinceInvaderRegulation, int getAfterThisTimeSinceInvaderRegulationFromZeroDensity, int maxAvgStepsPerRep) throws Exception
	{
	
		double[][] matrix = getChessonFunctionsOverTime( numReps,  getAfterThisTimeSinceInvaderRegulation,  getAfterThisTimeSinceInvaderRegulationFromZeroDensity,  maxAvgStepsPerRep);
		double[] toReturn = new double[this.chessonFunctions.size()];
		for (int i = 0; i < this.chessonFunctions.size(); i++)
		{
			toReturn[i] = MeanAndSD.meanAcrossRows(matrix, i);
		}
		return toReturn;
	}
	
	public double[] getChessonFunctionsAveragedOverTime(double[][] timeByFunctionArray) throws Exception
	{
		double[] toReturn = new double[this.chessonFunctions.size()];
		for (int i = 0; i < this.chessonFunctions.size(); i++)
		{
			toReturn[i] = MeanAndSD.meanAcrossRows(timeByFunctionArray, i);
		}
		return toReturn;
	}

}
