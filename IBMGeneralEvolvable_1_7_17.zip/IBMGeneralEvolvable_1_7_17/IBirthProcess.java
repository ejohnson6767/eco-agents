import java.io.Serializable;

public interface IBirthProcess extends Serializable
{
	double getBirthRate(Location loc);

	void scaleByDt(double dt);

	void setSpeciesOwner(ISpecies species);

	void setupAfterCommunityIsCreated(Community com);
}
