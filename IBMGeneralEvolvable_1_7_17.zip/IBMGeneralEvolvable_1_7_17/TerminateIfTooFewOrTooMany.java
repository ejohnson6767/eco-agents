import java.io.Serializable;

public class TerminateIfTooFewOrTooMany implements ITerminateCondition, Serializable
{
	private Community com;
	private int tooMany;
	private int speciesValue;
	private int tooFew;
	public TerminateIfTooFewOrTooMany(Community com, int speciesValue, int tooFew, int tooMany)
	{
		this.com = com;
		this.speciesValue = speciesValue;
		this.tooMany = tooMany;
		this.tooFew = tooFew;
	}
	
	public TerminateIfTooFewOrTooMany(Community com, int speciesValue, double tooLarge)
	{
		this.com = com;
		this.speciesValue = speciesValue;
		this.tooMany = this.com.abundFromProp(tooLarge);
	}
	
	public boolean shouldTerminate()
	{
		boolean shouldTerminate = false;
		int[] abunds = this.com.getAbundances();
		
		System.out.println("abund is " + abunds[this.speciesValue - 1]);
			if(abunds[this.speciesValue - 1] <= tooFew)
			{
				shouldTerminate = true;
				
			} else if(abunds[this.speciesValue - 1] >= tooMany)
			{
				shouldTerminate = true;
			}
		
		return shouldTerminate;
	}
	
}