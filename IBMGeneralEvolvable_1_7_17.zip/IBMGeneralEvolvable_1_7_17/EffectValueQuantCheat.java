import java.io.Serializable;

public class EffectValueQuantCheat implements IEffectValue, Serializable
{
	private double K;
	private IQuantCheatQLV q;
	protected double effectValue;
	protected ISpecies speciesOwner;
	protected Community com;
	protected Environment env;
	protected int gridLength;
	protected double[][] spatialDistributionTracker;
	protected int envGridIndex;
	protected int speciesValue;

	public EffectValueQuantCheat(double K, double q)
	{
		
		this.K = K;
		this.q = new QuantCheatQLV(q);
		this.effectValue = K * q;
	}
	
	public boolean isIndividualBased()
	{
		if(this.q.isIndividualBased())
		{
			return true;
		} else
		{
			return false;
		}
	}

	
	public double getEffectValue(int row, int col)
	{
		return this.K * this.q.getQ(new Location(row, col));
	}

	public IQuantCheatQLV getQ()
	{
		
		return this.q;
	}

	public void setQ(IQuantCheatQLV q)
	{
		this.q = q;
		
	}

	@Override
	public double getEffectValue()
	{
		return this.K * this.q.getQ();
	}



	@Override
	public void setSpeciesOwner(ISpecies species)
	{
		this.speciesOwner = species;
		this.q.setSpeciesOwner(species);
		
	}
	public void setupAfterCommunityIsCreated(Community com)
	{
		this.com = com;
		this.q.setupAfterCommunityIsCreated(this.com);
		this.env = com.getEnvironment();
		this.gridLength = this.com.getEnvironment().getGridLength();
		//this.spatialDistributionTracker = new double[gridLength][gridLength];
		this.envGridIndex = this.speciesOwner.getHomeGridIndex();
		this.speciesValue = this.speciesOwner.getGridProxy();
	}

	@Override
	public double[][] getSpatialDistributionTracker()
	{
		return null;
	} 
}
