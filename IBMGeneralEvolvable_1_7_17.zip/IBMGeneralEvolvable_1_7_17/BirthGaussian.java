import java.io.Serializable;
import java.util.ArrayList;

public class BirthGaussian implements IBirthProcess, Serializable
{
	private Community com;
	private ISpecies speciesOwner;
	//private double birthRate;
	private int speciesValue;
	private double mean;
	private double sd; 
	private double[][] birthGrid;
	private double slope;
	private double dt;
	private final double pi = 3.14159265359;
	private double maxH;
	private boolean scale;

	public BirthGaussian(double mean, double sd, boolean scale)
	{
		// this.com = com;
		this.mean  = mean;
		this.sd = sd;
		this.maxH = normFunc(mean);
		this.scale = scale;
		
	}
	
	public double normFunc(double x)
	{
		return (1/(double)(sd * Math.sqrt(2*pi))) *  Math.exp( -1* (Math.pow((x - mean),2) / (2*Math.pow(sd, 2))));
	}

	public double getBirthRate(Location loc)
	{	
		//System.out.println("location is " + this.birthGrid[loc.row()][loc.col()]);
		//System.out.println("abs dif is " + Math.abs(this.peak - this.birthGrid[loc.row()][loc.col()]));

		double val = normFunc(this.birthGrid[loc.row()][loc.col()]);
		if(scale)
		{
			val = val / this.maxH;
		}
		return val * this.dt;
	}

	
	
	public void scaleByDt(double dt)
	{
		this.dt = dt;

	}

	public void setSpeciesOwner(ISpecies species)
	{
		this.speciesOwner = species;

	}

	public void setupAfterCommunityIsCreated(Community com)
	{
		this.com = com;
		this.speciesValue = this.speciesOwner.getGridProxy();
		this.birthGrid = this.speciesOwner.getBirthGrid().getSpecificDemographyGrid();
		this.dt = com.getDt();
	}

}
