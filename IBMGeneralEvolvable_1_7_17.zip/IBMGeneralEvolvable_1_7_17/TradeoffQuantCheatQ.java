import java.io.Serializable;
import java.util.ArrayList;

public class TradeoffQuantCheatQ implements ITradeOff, Serializable
{
	private Evolvable parentTrait;
	private ArrayList<Evolvable> tradeOffTraits;
	private boolean tradeOffActive;
	private ISpecies speciesOwner;

	public TradeoffQuantCheatQ()
	{
		this.parentTrait = null;
		this.tradeOffTraits = null;
		this.tradeOffActive = false;
	}
	
	public void setSpeciesOwner(ISpecies species)
	{
		this.speciesOwner = species;
	}
	
	public void setupAfterCommunityIsCreated()
	{
		this.speciesOwner.getBirthProcess();
	}
	

	public void startTradeOff(Community com)
	{
		System.out.println("STARTING TRADEOFF");
		this.tradeOffActive = true;
		ISpecies parentSpecies = parentTrait.getSpeciesOwner();
		ArrayList<Evolvable> parentSpeciesTraits = parentSpecies.getEvolvableTraits();
		System.out.println(parentSpecies);
		for (int i = 0; i < tradeOffTraits.size(); i++)
		{

			Evolvable trait = this.tradeOffTraits.get(i);
			boolean alreadyHave = false;
			for (int j = 0; j < parentSpeciesTraits.size(); j++)
			{
				if (parentSpeciesTraits.get(j) == trait)
				{
					System.out.println("parent species already has this trait");
					alreadyHave = true;
					break;
				}
			}
			if (!alreadyHave)
			{
				System.out.println("parent species does not have this trait yet");
				
				parentSpecies.addTrait(trait);
			}
			
			this.tradeOffTraits.get(i).startBeingIndividualBased(com);
		}

	}

	public ArrayList<Evolvable> getTradeOffTraits()
	{
		return this.tradeOffTraits;
	}

	public void enforceTradeOff()
	{
		if (this.tradeOffActive)
		{
			// int speciesValue = parentTrait.getSpeciesOwner().getGridProxy();
			double[][] tracker = parentTrait.getSpatialDistributionTracker();
			int gridLength = tracker.length;
			for (int row = 0; row < gridLength; row++)
			{
				for (int col = 0; col < gridLength; col++)
				{
					if (tracker[row][col] != 0)
					{
						enforceTradeOffSingleLocation(new Location(row, col));
					}
				}
			}
		}
	}

	
	
	public void enforceTradeOffSingleLocation(Location loc)
	{
		Evolvable dispersalTrait = this.parentTrait;
		Evolvable birthRateTrait = this.tradeOffTraits.get(0);

		double tradeOffVal = 0.9 - (dispersalTrait.getTrait(loc) * 0.1);
		birthRateTrait.setTrait(loc, tradeOffVal);
		//System.out.println("tradeOffVal is " + tradeOffVal);
	}

}
