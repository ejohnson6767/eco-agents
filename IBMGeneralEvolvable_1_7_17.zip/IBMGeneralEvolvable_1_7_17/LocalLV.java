import java.io.Serializable;
import java.util.ArrayList;


public class LocalLV implements Serializable
{

	// first level: the index of the species which is to be affected
	// second level: the different ways that the affected species can be affected
	private LVEffectsOnOneHetero[] lVEffectsOnAllHeteros;
	private ISpecies speciesOwner;
	private Community com;
	private boolean allSameDiffusion;
	private Environment env;
	private int gridLength;
	private int speciesValue;
	private int speciesIndex;
	private int envGridIndex;
	private double[][] values;
	private int[][] diffusionDist;
	private int commonDiffusionRadius;

	public LocalLV(double[][] values, int[][] diffusionDist)
	{

		this.values = values;
		this.diffusionDist = diffusionDist;
		if (values.length != diffusionDist.length)
		{
			throw new IllegalArgumentException();
		}
		for (int i = 0; i < values.length; i++)
		{
			if (values[i].length != diffusionDist[i].length)
			{
				throw new IllegalArgumentException();
			}
		}

		//System.out.println("values length is " + this.values.length);
		this.lVEffectsOnAllHeteros = new LVEffectsOnOneHetero[this.values.length];
		//System.out.println("heteros length is " + this.lVEffectsOnAllHeteros.length);
		this.allSameDiffusion = false;

	}

	public void giveSpeciesTheirEffects()
	{
		//System.out.println("GIVIG SPECIES THEIR EFFECTS");
		ArrayList<ISpecies> speciesList = this.com.getSpeciesList();
		for (int i = 0; i < lVEffectsOnAllHeteros.length; i++)
		{

			LVEffectsOnOneHetero oneHetero = lVEffectsOnAllHeteros[i];
			if (oneHetero != null)
			{
				IEffect[] lVEffects = oneHetero.getLVEffects();
				ISpecies aSpecies = speciesList.get(i);
				for (int j = 0; j < lVEffects.length; j++)
				{
					aSpecies.addAffectingLVEffect(lVEffects[j]);
					//System.out.println("ADDING BY INDICATOR METHOD CALL");
					aSpecies.addAffectingLVEffectByIndicator(lVEffects[j]);
				}
			}
		}
	}

	public void setSpeciesOwner(ISpecies speciesOwner)
	{
		this.speciesOwner = speciesOwner;

		/// System.out.println("LENGTH LENGTH LENGTH " + this.values[0].length);

		for (int i = 0; i < this.lVEffectsOnAllHeteros.length; i++)
		{
			if (lVEffectsOnAllHeteros[i] != null)
			{
				//System.out.println("SETTING SPECIES OWNER FOR HETERO " + (i + 1));
				lVEffectsOnAllHeteros[i].setSpeciesOwner(this.speciesOwner);
			}
		}

		if (this.values.length != 0)
		{
			for (int i = 0; i < this.values.length; i++)
			{
				//System.out.println("BLERIADSJFADS;");
				if (lVEffectsOnAllHeteros[i] != null)
				{
					lVEffectsOnAllHeteros[i] = new LVEffectsOnOneHetero(this.values[i], this.diffusionDist[i]);
				}
			}
		}
	}

	public void setupAfterCommunityIsCreated(Community com)
	{
		this.com = com;

		// extends the array of effects on heterospecifics (technically, also conspecifics) so that it's as long as the number of species in the community.
		extendHeteroArray(com.getNumberOfSpecies());

		for (int i = 0; i < lVEffectsOnAllHeteros.length; i++)
		{
			if (lVEffectsOnAllHeteros[i] != null)
			{
				lVEffectsOnAllHeteros[i].setupAfterCommunityIsCreated(com);
			}
		}

		
		giveSpeciesTheirEffects();

		this.env = this.com.getEnvironment();
		this.gridLength = this.env.getGridLength();
		this.speciesValue = this.speciesOwner.getGridProxy();
		this.speciesIndex = this.speciesValue - 1;
		this.envGridIndex = this.speciesOwner.getHomeGridIndex();
	}

	public LVEffectsOnOneHetero[] getLVEffectsOnAllHeteros()
	{
		return this.lVEffectsOnAllHeteros;
	}

	void fillLVSameDiffusionForAllHeteros()
	{

		// System.out.println("the species value is " + this.speciesValue);

		/// System.out.println("disp is " + dispersalRadius);

		// System.out.println("possible neighbors " + possibleNeighbors);

		int diffusion = this.commonDiffusionRadius;

		int[][] totalGrid = new int[this.gridLength][this.gridLength];

		int[][] posPropagule = new int[gridLength][3];

		// this second main loop determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius

		// this algorithm scans right across the grid, goes down one line, scans again, and so on (just like reading). It's time complexity is O(n) (where n is the number of microsites) compared to O(n^2) of a trivial moving window algorithm.
		// It works by summing all of the
		// cumulative birth rates in the topmost row, the bottommost row, and everything in between. This is where the last dimension on pos array comes in:
		// 0 is TOP, 1 is MID, and 2 is BOT. when you to the next gid locationCommunity com,, your cumulative growth rate is TOPnew + MIDnew + BOTnew. MIDnew is simply MIDnorth + BOTnorth - TOPnew.
		// (where north indicates the position above you). TOPnew can be written TOPwest - TOPwest.leftMost + TOPnew.rightmost. BOTnew can be written BOTwest - BOTwest.leftMost + BOTnew.rightmost.
		// the TOP, MID, and BOT are all recorded.
		int row = 0;
		int col = 0;

		// pos = new double[numberOfSpecies][gridLength][3];
		int row2 = row - diffusion;
		for (int col2 = col - diffusion; col2 <= col + diffusion; col2++)
		{
			int realRow = WrapAround.wrapAround(row2, gridLength);
			int realCol = WrapAround.wrapAround(col2, gridLength);
			int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
			if (gridValue == speciesValue)
			{

				posPropagule[col][0]++;

			}
		}
		// System.out.println("col == " + col + " first is " + first[1]);

		for (int col2 = col - diffusion; col2 <= col + diffusion; col2++)
		{
			for (row2 = row - diffusion + 1; row2 <= row + diffusion - 1; row2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{

					posPropagule[col][1]++;

				}
			}
		}
		// System.out.println("col == 0 middle is " + middle[1]);

		row2 = row + diffusion;
		for (int col2 = col - diffusion; col2 <= col + diffusion; col2++)
		{
			int realRow = WrapAround.wrapAround(row2, gridLength);
			int realCol = WrapAround.wrapAround(col2, gridLength);
			int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
			if (gridValue == speciesValue)
			{

				posPropagule[col][2]++;

			}
		}

		// ACTUALLY ADD TO PROPAGULE RAIN GRID
		int correctForMiddle = 0;
		if (env.getGridValue(row, col, envGridIndex) == speciesValue)
		{
			correctForMiddle--;
		}

		totalGrid[row][col] = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2] + correctForMiddle);

		for (col = 1; col < gridLength; col++)
		{

			// generate new top
			int NWRow = WrapAround.wrapAround(row - diffusion, gridLength);
			int NWCol = WrapAround.wrapAround(col - 1 - diffusion, gridLength);
			int NERow = WrapAround.wrapAround(row - diffusion, gridLength);
			int NECol = WrapAround.wrapAround(col + diffusion, gridLength);

			int SWRow = WrapAround.wrapAround(row + diffusion, gridLength);
			int SWCol = WrapAround.wrapAround(col - 1 - diffusion, gridLength);
			int SERow = WrapAround.wrapAround(row + diffusion, gridLength);
			int SECol = WrapAround.wrapAround(col + diffusion, gridLength);

			posPropagule[col][0] = posPropagule[col - 1][0];
			if (env.getGridValue(NWRow, NWCol, envGridIndex) == speciesValue)
			{
				posPropagule[col][0]--;
			}

			if (env.getGridValue(NERow, NECol, envGridIndex) == speciesValue)
			{
				posPropagule[col][0]++;
			}

			int leftSideOfOldMid = 0;
			int col2 = col - diffusion - 1;
			for (row2 = row - diffusion + 1; row2 <= row + diffusion - 1; row2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{

					leftSideOfOldMid++;

				}
			}

			int rightSideOfNewMid = 0;
			col2 = col + diffusion;
			for (row2 = row - diffusion + 1; row2 <= row + diffusion - 1; row2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{

					rightSideOfNewMid++;

				}
			}

			posPropagule[col][1] = posPropagule[col - 1][1] - leftSideOfOldMid + rightSideOfNewMid;

			posPropagule[col][2] = posPropagule[col - 1][2];
			if (env.getGridValue(SWRow, SWCol, envGridIndex) == speciesValue)
			{
				posPropagule[col][2]--;
			}

			if (env.getGridValue(SERow, SECol, envGridIndex) == speciesValue)
			{
				posPropagule[col][2]++;
			}
			// ACTUALLY ADD TO PROPAGULE RAIN GRID
			correctForMiddle = 0;
			if (env.getGridValue(row, col, envGridIndex) == speciesValue)
			{
				correctForMiddle--;
			}

			totalGrid[row][col] = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2] + correctForMiddle);
		}

		for (row = 1; row < gridLength; row++)
		{
			col = 0;

			posPropagule[col][0] = 0;

			row2 = row - diffusion;
			for (int col2 = col - diffusion; col2 <= col + diffusion; col2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{

					posPropagule[col][0]++;

				}
			}

			posPropagule[col][1] += posPropagule[col][2] - posPropagule[col][0];

			posPropagule[col][2] = 0;

			row2 = row + diffusion;
			for (int col2 = col - diffusion; col2 <= col + diffusion; col2++)
			{
				int realRow = WrapAround.wrapAround(row2, gridLength);
				int realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == speciesValue)
				{

					posPropagule[col][2]++;

				}
			}

			// ACTUALLY ADD TO PROPAGULE RAIN GRID
			correctForMiddle = 0;
			if (env.getGridValue(row, col, envGridIndex) == speciesValue)
			{
				correctForMiddle--;
			}

			totalGrid[row][col] = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2] + correctForMiddle);

			for (col = 1; col < gridLength; col++)
			{

				// generate new top
				int NWRow = WrapAround.wrapAround(row - diffusion, gridLength);
				int NWCol = WrapAround.wrapAround(col - 1 - diffusion, gridLength);
				int NERow = WrapAround.wrapAround(row - diffusion, gridLength);
				int NECol = WrapAround.wrapAround(col + diffusion, gridLength);

				int SWRow = WrapAround.wrapAround(row + diffusion, gridLength);
				int SWCol = WrapAround.wrapAround(col - 1 - diffusion, gridLength);
				int SERow = WrapAround.wrapAround(row + diffusion, gridLength);
				int SECol = WrapAround.wrapAround(col + diffusion, gridLength);

				posPropagule[col][0] = posPropagule[col - 1][0];
				if (env.getGridValue(NWRow, NWCol, envGridIndex) == speciesValue)
				{
					posPropagule[col][0]--;
				}

				if (env.getGridValue(NERow, NECol, envGridIndex) == speciesValue)
				{
					posPropagule[col][0]++;
				}

				posPropagule[col][1] += posPropagule[col][2] - posPropagule[col][0];

				posPropagule[col][2] = posPropagule[col - 1][2];
				if (env.getGridValue(SWRow, SWCol, envGridIndex) == speciesValue)
				{
					posPropagule[col][2]--;
				}

				if (env.getGridValue(SERow, SECol, envGridIndex) == speciesValue)
				{
					posPropagule[col][2]++;
				}

				// ACTUALLY ADD TO PROPAGULE RAIN GRID
				correctForMiddle = 0;
				if (env.getGridValue(row, col, envGridIndex) == speciesValue)
				{
					correctForMiddle--;
				}

				totalGrid[row][col] = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2] + correctForMiddle);

			}
		}

		for (int i = 0; i < this.lVEffectsOnAllHeteros.length; i++)
		{
			if(this.lVEffectsOnAllHeteros[i] != null)
			{
			IEffect[] lVEffectsOnOneHetero = this.lVEffectsOnAllHeteros[i].getLVEffects();
			for (int j = 0; j < lVEffectsOnOneHetero.length; j++)
			{
				IEffect lVEffect = lVEffectsOnOneHetero[j];
				if (lVEffect.getDiffusion().getDiffusion() != 0)
				{
					if (lVEffect.getEffectValue().getEffectValue() != 0)
					{
						lVEffect.setLVEffectGrid(totalGrid);
					}
				}
			}
			}

		}

	}

	public void markDiffusionNotAllSameBetweenHeteros()
	{
		this.allSameDiffusion = false;

	}

	public void markDiffusionAllSameBetweenHeteros()
	{
		this.allSameDiffusion = true;

	}

	public boolean diffusionAllSameBetweenHeteros()
	{
		return this.allSameDiffusion;
	}

	public void extendHeteroArray(int newLength)
	{
		//System.out.println("EXTENDING HETERO ARRAY");
		LVEffectsOnOneHetero[] temp = new LVEffectsOnOneHetero[newLength];
		for (int i = 0; i < this.lVEffectsOnAllHeteros.length; i++)
		{
			//System.out.println("replacing hetero " + (i + 1) + " with " + this.lVEffectsOnAllHeteros[i]);
			temp[i] = this.lVEffectsOnAllHeteros[i];
		}
		for (int i = this.lVEffectsOnAllHeteros.length; i < temp.length; i++)
		{
			//System.out.println("making new hetero " + (i + 1) + " with " + null);
			temp[i] = null; // new LVEffectsOnOneHetero(new double[] {}, new int[]{}, this.speciesOwner);
		}
		this.lVEffectsOnAllHeteros = temp;

	}

	public void setSameDiffusionRadius(int diffusionRadius)
	{
		this.commonDiffusionRadius = diffusionRadius;

	}

}
