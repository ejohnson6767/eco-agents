import java.io.Serializable;

public class TimeSeriesPairCorrelation implements ITimeSeriesQuantity, Serializable
{

	private Community com;
	private int radius;
	private int gridHeight;
	private int[][] focalPairedRadiusList;
	private int returnLength;

	public TimeSeriesPairCorrelation(Community com, int radius, int[][] focalPairedRadiusList)
	{
		this.com = com;
		this.radius = radius;
		this.gridHeight = 0;
		this.focalPairedRadiusList = focalPairedRadiusList;
		if(this.focalPairedRadiusList[0].length != 3)
		{
			throw new IllegalArgumentException("the second dimension of the param focalPairedRadius but be of length three: one column for focal state, one column for paired state, and one column for the radius of the pair correlation 'ring' ");
		}
		this.returnLength = this.focalPairedRadiusList.length;
		System.out.println("return length is " + this.returnLength );

	}
	
	public int getReturnLength()
	{
		return this.returnLength; 
	}
	
	public TimeSeriesPairCorrelation(Community com, int radius, int gridHeight, int[][] focalPairedRadiusList)
	{
		this(com, radius,  focalPairedRadiusList);
		this.gridHeight = gridHeight;
	}
	

	public double[] get()
	{
		double[][][] pcFunc = MakeGrids.getPCFunction(com.getEnvironment().getGrid()[this.gridHeight], this.radius);//[radius - 1][focalState][pairedState];
		double[] pcToReturn = new double[this.focalPairedRadiusList.length];
		for (int i = 0; i < pcToReturn.length; i++)
		{
			pcToReturn[i] = pcFunc[this.focalPairedRadiusList[i][2]][this.focalPairedRadiusList[i][0]][this.focalPairedRadiusList[i][1]];
		}
		
		return pcToReturn;
	}

}
