import java.io.Serializable;
import java.util.ArrayList;

public class BirthAdditive implements IBirthProcess, Serializable
{
	private Community com;
	private ISpecies speciesOwner;
	private double birthRate;
	private int speciesValue;

	public BirthAdditive(double birthRate)
	{
		// this.com = com;
		this.birthRate = birthRate;
	}

	public double getBirthRate(Location loc)
	{
	
		
		double realizedBirthRate = this.birthRate;
		ArrayList<IEffect> lvEffects= this.speciesOwner.getAffectingLVEffects();
		
		for(IEffect lv : lvEffects)
		{
			//System.out.println("getting lv ");
		realizedBirthRate += lv.getEffect(loc);
		}
		
		return realizedBirthRate;
	}

	
	
	public void scaleByDt(double dt)
	{
		this.birthRate *= dt;

	}

	public void setSpeciesOwner(ISpecies species)
	{
		this.speciesOwner = species;

	}

	public void setupAfterCommunityIsCreated(Community com)
	{
		this.com = com;
		this.speciesValue = this.speciesOwner.getGridProxy();
	}

}
