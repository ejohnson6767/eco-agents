import java.io.Serializable;
import java.util.ArrayList;

public interface IDispersalTrait extends Serializable
{
	public int getDispersalRadius(Location loc);
	public int getDispersalRadius();
	public void doThing();
	public void setupAfterCommunityIsCreated(Community com);
	public boolean isIndividualBased();
	public double[][] getSpatialDistributionTracker();
}
