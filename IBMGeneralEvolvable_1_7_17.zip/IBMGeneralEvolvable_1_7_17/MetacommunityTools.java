import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

public class MetacommunityTools implements Serializable
{
	private Community com;
	private Environment env;
	private int gridLength;
	private RegionallySimilarSpecies rss;
	

	public MetacommunityTools(Community com, RegionallySimilarSpecies rss)
	{
		this.com = com;
		this.env = this.com.getEnvironment();
		this.gridLength = this.env.getGridLength();
		this.rss = rss;
	}
	

	// note only have to get once for a sngle species.
	public double getEAverage(int speciesValue)
	{
		double[][] EGrid = getEGrid(speciesValue);
		double total = 0;
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				total += EGrid[row][col];
			}
		}	
		return total / (double) this.env.getTotalSites();
	}
	
	public double getEAverage(double[][] EGrid)
	{
		double total = 0;
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				total += EGrid[row][col];
			}
		}	
		return total / (double) this.env.getTotalSites();
	}
	
	public double getCAverage(int dispersalRadius)
	{
		double[][] CGrid = getCGrid(dispersalRadius);
		double total = 0;
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				total += CGrid[row][col];
			}
		}	
		return total / (double) this.env.getTotalSites();
	}
	
	public double getCAverage(double[][] CGrid)
	{
		double total = 0;
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				total += CGrid[row][col];
			}
		}	
		return total / (double) this.env.getTotalSites();
	}
	
	public double[][] getDifferenceGrid(double[][] EGrid, double EAverage)
	{
		double[][] differenceGrid = new double[this.gridLength][this.gridLength];
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				differenceGrid[row][col] = EGrid[row][col] - EAverage;
			}
		}
		return differenceGrid;
	}
	 
	public double[][] getMultipliedGrid(double[][] grid1, double[][] grid2)
	{
		double[][] multipliedGrid = new double[this.gridLength][this.gridLength];
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				multipliedGrid[row][col] = grid1[row][col] * grid2[row][col];
			}
		}
		return multipliedGrid;
	}
	
	public double[][] getEGrid(int speciesValue)
	{
		double[][] EGrid = new double[this.gridLength][this.gridLength];
		ISpecies aSpecies = this.com.getSpeciesList().get(speciesValue - 1);
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				EGrid[row][col] = aSpecies.getBirthRate(new Location(row, col));
			}
		}
		return EGrid;
	}
	
	
	public double getI(double[][] EGrid, double EAverage, double[][] CGrid, double CAverage)
	{
		double total = 0;
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				total += (EGrid[row][col] - EAverage)*(CGrid[row][col] - CAverage);
			}
		}
		return total / (double) this.env.getTotalSites();
	}
	
	public double[][] getEmptyGrid(int dispersalRadius)
	{
		// System.out.println("the species value is " + this.speciesValue);

		/// System.out.println("disp is " + dispersalRadius);

		// System.out.println("possible neighbors " + possibleNeighbors);

		double[][] emptyGrid = new double[this.gridLength][this.gridLength];
		double possibleNeighbors = Math.pow(dispersalRadius * 2 + 1, 2) - 1;
		double[][] posPropagule = new double[gridLength][3];

		// this second main loop determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius

		// this algorithm scans right across the grid, goes down one line, scans again, and so on (just like reading). It's time complexity is O(n) (where n is the number of microsites) compared to O(n^2) of a trivial moving window algorithm.
		// It works by summing all of the
		// cumulative birth rates in the topmost row, the bottommost row, and everything in between. This is where the last dimension on pos array comes in:
		// 0 is TOP, 1 is MID, and 2 is BOT. when you to the next gid locationCommunity com,, your cumulative growth rate is TOPnew + MIDnew + BOTnew. MIDnew is simply MIDnorth + BOTnorth - TOPnew.
		// (where north indicates the position above you). TOPnew can be written TOPwest - TOPwest.leftMost + TOPnew.rightmost. BOTnew can be written BOTwest - BOTwest.leftMost + BOTnew.rightmost.
		// the TOP, MID, and BOT are all recorded.
		int envGridIndex = 0;

		int row = 0;
		int col = 0;
		int row2 = 0;
		int col2 = 0;
		int realRow = 0;
		int realCol = 0;

		// pos = new double[numberOfSpecies][gridLength][3];
		row2 = row - dispersalRadius;
		realRow = WrapAround.wrapAround(row2, gridLength);
		for (col2 = col - dispersalRadius; col2 <= col + dispersalRadius; col2++)
		{
			realCol = WrapAround.wrapAround(col2, gridLength);
			int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
			if (gridValue == 0)
			{

				posPropagule[col][0] ++;

			}
		}
		// System.out.println("col == " + col + " first is " + first[1]);

		for (col2 = col - dispersalRadius; col2 <= col + dispersalRadius; col2++)
		{
			for (row2 = row - dispersalRadius + 1; row2 <= row + dispersalRadius - 1; row2++)
			{
				realRow = WrapAround.wrapAround(row2, gridLength);
				realCol = WrapAround.wrapAround(col2, gridLength);
				int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == 0)
				{

					posPropagule[col][1] ++;

				}
			}
		}
		// System.out.println("col == 0 middle is " + middle[1]);

		row2 = row + dispersalRadius;
		realRow = WrapAround.wrapAround(row2, gridLength);
		for (col2 = col - dispersalRadius; col2 <= col + dispersalRadius; col2++)
		{
			realCol = WrapAround.wrapAround(col2, gridLength);
			int gridValue = env.getGridValue(realRow, realCol, envGridIndex);
			if (gridValue == 0)
			{

				posPropagule[col][2] ++;

			}
		}

		double middle = 0;
		int gridValue = env.getGridValue(row, col, envGridIndex);
		if (gridValue == 0)
		{

			middle++;

		}

		// ACTUALLY ADD TO PROPAGULE RAIN GRID
		emptyGrid[row][col] = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2] - middle) / possibleNeighbors;

		for (col = 1; col < gridLength; col++)
		{

			// generate new top
			int NRow = WrapAround.wrapAround(row - dispersalRadius, gridLength);
			int WCol = WrapAround.wrapAround(col - 1 - dispersalRadius, gridLength);
			int ECol = WrapAround.wrapAround(col + dispersalRadius, gridLength);
			int SRow = WrapAround.wrapAround(row + dispersalRadius, gridLength);

			double NW = 0;
			if (this.env.getGridValue(NRow, WCol, envGridIndex) == 0)
			{
				NW++;
			}
			double NE = 0;
			if (this.env.getGridValue(NRow, ECol, envGridIndex) == 0)
			{
				NE++;
			}

			posPropagule[col][0] = posPropagule[col - 1][0] - NW + NE;

			double leftSideOfOldMid = 0;
			col2 = col - dispersalRadius - 1;
			realCol = WrapAround.wrapAround(col2, gridLength);

			for (row2 = row - dispersalRadius + 1; row2 <= row + dispersalRadius - 1; row2++)
			{
				realRow = WrapAround.wrapAround(row2, gridLength);
				gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == 0)
				{

					leftSideOfOldMid++;

				}
			}

			double rightSideOfNewMid = 0;
			col2 = col + dispersalRadius;
			realCol = WrapAround.wrapAround(col2, gridLength);
			for (row2 = row - dispersalRadius + 1; row2 <= row + dispersalRadius - 1; row2++)
			{
				realRow = WrapAround.wrapAround(row2, gridLength);
				gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == 0)
				{

					rightSideOfNewMid++;

				}
			}

			posPropagule[col][1] = posPropagule[col - 1][1] - leftSideOfOldMid + rightSideOfNewMid;

			double SW = 0;
			if (this.env.getGridValue(SRow, WCol, envGridIndex) == 0)
			{
				SW++;
			}
			double SE = 0;
			if (this.env.getGridValue(SRow, ECol, envGridIndex) == 0)
			{
				SE++;
			}

			posPropagule[col][2] = posPropagule[col - 1][2] - SW + SE;

			// ACTUALLY ADD TO PROPAGULE RAIN GRID
			middle = 0;
			gridValue = env.getGridValue(row, col, envGridIndex);
			if (gridValue == 0)
			{

				middle++;

			}
			// ACTUALLY ADD TO PROPAGULE RAIN GRID
			emptyGrid[row][col] = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2] - middle) / possibleNeighbors;
		}

		for (row = 1; row < gridLength; row++)
		{
			col = 0;

			posPropagule[col][0] = 0;

			row2 = row - dispersalRadius;
			realRow = WrapAround.wrapAround(row2, gridLength);
			for (col2 = col - dispersalRadius; col2 <= col + dispersalRadius; col2++)
			{
				realCol = WrapAround.wrapAround(col2, gridLength);
				gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == 0)
				{

					posPropagule[col][0]++;

				}
			}

			posPropagule[col][1] += posPropagule[col][2] - posPropagule[col][0];

			posPropagule[col][2] = 0;

			row2 = row + dispersalRadius;
			realRow = WrapAround.wrapAround(row2, gridLength);
			for (col2 = col - dispersalRadius; col2 <= col + dispersalRadius; col2++)
			{
				realCol = WrapAround.wrapAround(col2, gridLength);
				gridValue = env.getGridValue(realRow, realCol, envGridIndex);
				if (gridValue == 0)
				{

					posPropagule[col][2]++;

				}
			}

			middle = 0;
			gridValue = env.getGridValue(row, col, envGridIndex);
			if (gridValue == 0)
			{

				middle++;

			}
			// ACTUALLY ADD TO PROPAGULE RAIN GRID
			emptyGrid[row][col] = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2] - middle) / possibleNeighbors;

			for (col = 1; col < gridLength; col++)
			{

				// generate new top
				int NRow = WrapAround.wrapAround(row - dispersalRadius, gridLength);
				int WCol = WrapAround.wrapAround(col - 1 - dispersalRadius, gridLength);
				int ECol = WrapAround.wrapAround(col + dispersalRadius, gridLength);
				int SRow = WrapAround.wrapAround(row + dispersalRadius, gridLength);

				double NW = 0;
				if (this.env.getGridValue(NRow, WCol, envGridIndex) == 0)
				{
					NW++;
				}
				double NE = 0;
				if (this.env.getGridValue(NRow, ECol, envGridIndex) == 0)
				{
					NE++;
				}

				posPropagule[col][0] = posPropagule[col - 1][0] - NW + NE;

				posPropagule[col][1] += posPropagule[col][2] - posPropagule[col][0];

				double SW = 0;
				if (this.env.getGridValue(SRow, WCol, envGridIndex) == 0)
				{
					SW++;
				}
				double SE = 0;
				if (this.env.getGridValue(SRow, ECol, envGridIndex) == 0)
				{
					SE++;
				}

				posPropagule[col][2] = posPropagule[col - 1][2] - SW + SE;
				// ACTUALLY ADD TO PROPAGULE RAIN GRID
				middle = 0;
				gridValue = env.getGridValue(row, col, envGridIndex);
				if (gridValue == 0)
				{

					middle++;

				}
				// ACTUALLY ADD TO PROPAGULE RAIN GRID
				emptyGrid[row][col] = (posPropagule[col][0] + posPropagule[col][1] + posPropagule[col][2] - middle) / possibleNeighbors;

			}
		}

		return emptyGrid;

	}
	
	public double[][] getCGrid(int dispersalRadius)
	{
		double[][] CGrid = new double[this.gridLength][this.gridLength];
		double[][] emptyGrid = getEmptyGrid(dispersalRadius);
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				CGrid[row][col] = 1 - emptyGrid[row][col];
			}
		}
		
		return CGrid;
	}
	
	
	
	
	
}
