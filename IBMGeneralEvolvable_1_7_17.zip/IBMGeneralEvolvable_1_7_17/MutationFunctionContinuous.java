import java.io.Serializable;
import java.util.Random;

public class MutationFunctionContinuous extends MutationFunctionStandard implements IMutationFunction, Serializable
{

	public MutationFunctionContinuous(double evolveProb, double mutationMagnitude)
	{
		super(evolveProb, mutationMagnitude);		
	}
	
	public void setGenerator(Random generator)
	{
		this.generator = generator;
	}
	
	public double mutate(double traitValue)
	{
		
			// System.out.println("current br is " + curTrait);
			if (generator.nextDouble() < evolveProb.getEvolveProb())
			{
				double addTo =  generator.nextGaussian() * mutationMagnitude.getMutationMagnitude();
				

				if (generator.nextInt(2) == 1)
				{
					addTo *= -1;
				}

				traitValue += addTo;

				//System.out.print("trait mutated to " + traitValue);

			}
			// System.out.println("modified br is " + curTrait);
			// System.out.println();
			

			return traitValue;
		}

	public double mutate(double traitValue, Location parentLoc)
	{
		if (generator.nextDouble() < evolveProb.getEvolveProb(parentLoc))
		{
			double addTo =  generator.nextGaussian() * mutationMagnitude.getMutationMagnitude(parentLoc);
			

			if (generator.nextInt(2) == 1)
			{
				addTo *= -1;
			}

			traitValue += addTo;
			

			//System.out.print("trait mutated to " + traitValue);

		}
		// System.out.println("modified br is " + curTrait);
		// System.out.println();
		

		return traitValue;
	}

}
