import java.awt.Canvas;

import org.rosuda.JRI.Rengine;
import org.rosuda.REngine.REXP;

public class Gstat
{
	private double[][] grid;

	public Gstat(int gridLength)
	{
		Rengine engine = new Rengine(new String[] { "--vanilla" }, false, null);

		// how to load packages
		engine.eval("lib <- c('C:/Users/Evan/Documents/R/win-library/3.3' , 'C:/Program Files/R/R-3.3.1/library')");
		engine.eval("library(gstat, lib.loc = lib)");
		engine.eval("library(sp, lib.loc = lib)");
		engine.eval("library(reshape2, lib.loc = lib)");
		// check to see if the packages are loaded
		engine.eval("gstatl <- require('gstat')");
		engine.eval("spl <- require('sp')");
		System.out.println("gstat is loaded " + engine.eval("gstatl").asBool());
		System.out.println("sp is loaded " + engine.eval("spl").asBool());

		engine.eval("gridLength <- " + gridLength);
		engine.eval("xy <- expand.grid(1:gridLength, 1:gridLength)");
		engine.eval("names(xy) <- c('x','y')");
		System.out.println(engine.eval("class(xy)"));
		engine.eval("g.dummy <- gstat(formula = z ~ x + y  , locations= ~x+y, dummy=TRUE, beta=c(1, 0.02, 0.02), model=vgm(psill=0.025, range=10, model='Exp', anis = c(90, .9)), nmax=20)");
		System.out.println(engine.eval("class(g.dummy)"));
		engine.eval("yy <- predict(g.dummy, newdata=xy, nsim=1)");
		System.out.println(engine.eval("class(yy)"));
		engine.eval("gridded(yy) = ~x+y");
		System.out.println(engine.eval("class(yy)"));

		// how to plot images
		// engine.eval("pdf('C:/Users/Evan/Documents/My R Files/rengine.pdf')");
		// engine.eval("X11()");
		// System.out.println(engine.eval("dev.list()").asString());
		// IMPORTANT: plotted object must be saved to a temporary reference first
		// engine.eval("temp <- spplot(obj=yy[1])");
		// engine.eval("print(temp)");
		// engine.eval("dev.off()");

		//engine.eval("temp <- spplot(obj=yy[1])");
		// engine.eval("dev.off()");
		engine.eval("dat <- yy@data$sim1");
		engine.eval("minZ <- min(dat)");
		engine.eval("dat <- dat - minZ");
		engine.eval("maxZ <- max(dat)");
		engine.eval("dat <- dat/maxZ");
		engine.eval("yy@data$sim1 <- dat");
		System.out.println(engine.eval("class(dat)"));

		engine.eval("yy <- as.data.frame(yy)");
		engine.eval("res <- dcast(yy, x ~ y, value.var = 'sim1')");
		engine.eval("res <- as.matrix(res[,-1])");
		this.grid = engine.eval("res").asDoubleMatrix();
		/*
		 * double[] dat = engine.eval("dat").asDoubleArray(); for (int i = 0; i < dat.length; i++) { System.out.println(dat[i]); }
		 */
		System.out.println("All Done");
		engine.end();
	}
	
	public double[][] getGrid()
	{
		return this.grid;
	}

}
