import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

public class AddCrittersMultipleSpecies extends AddCritters implements Serializable
{

	private int[] speciesValueMultipleSpecies;
	private boolean[] overwriteMultipleSpecies;
	private Random queueGenerator;
	public AddCrittersMultipleSpecies(Community com, int[] speciesValues, boolean[] overwrite)
	{
		// the second two parameters are meaningless. The only method in the class will change these when it is needed
		super(com, 1, false);
		this.speciesValueMultipleSpecies = speciesValues;
		this.overwriteMultipleSpecies = overwrite;
		this.queueGenerator = this.com.env.getGenerator(this.com.getSpeciesList().get(0).getHomeGridIndex());
	}

	public void addCrittersRandomlyMultipleSpecies(int[] abundances)
	{
	
		// System.out.println("starting makePercolationGrid");
		int numSpecies = abundances.length;
		int[] abundanceCounter = new int[numSpecies];
		double[] placeCritterProbs = new double[numSpecies];

		// whether the number of added critters (totalAbundanceCounter) equals the number that need to be added will be determine when the algorithm is finished
		int totalAbundanceCounter = 0;
		int total = 0;
		for (int i = 0; i < numSpecies; i++)
		{
			total += abundances[i];
		}

		// the relative proportions of species will determine their probability of being picked to be added. Critters are added in this random way to give fully random spatial distributions
		if (total == 0)
		{
			for (int i = 0; i < numSpecies; i++)
			{
				placeCritterProbs[i] = 0;
				// System.out.println("placeCriterProbs " + i + " is " + placeCritterProbs[i]) ;
			}
		}
		else
		{
			for (int i = 0; i < numSpecies; i++)
			{
				placeCritterProbs[i] = abundances[i] / (double) total;
				// System.out.println("placeCriterProbs " + i + " is " + placeCritterProbs[i]) ;
			}
		}

		// main loop. only breaks once all species are added
		while (true)
		{
			// System.out.println("in the loop");
			// get a random number to decide which species is going to be added...
			double rand = this.queueGenerator.nextDouble();
			int speciesIndexToAdd = 0;
			for (int i = 0; i < numSpecies; i++)
			{
				if (placeCritterProbs[i] > rand)
				{
					speciesIndexToAdd = i;
				}
			}

			/*
			 * System.out.println(""); System.out.println("totalAbundanceCounter is " + totalAbundanceCounter); System.out.println("abundanceGoal is " + total);
			 */

			// ... if all the critters of the chosen species has been added, continue the loop and try again for a different species...

			// otherwise, search for an empty site and place the critter there
			if (abundanceCounter[speciesIndexToAdd] != abundances[speciesIndexToAdd])
			{
				this.overwrite = this.overwriteMultipleSpecies[speciesIndexToAdd];
				this.curSpeciesValue = this.speciesValueMultipleSpecies[speciesIndexToAdd];
				this.curSpecies = com.getSpeciesList().get(this.curSpeciesValue - 1);
				this.curSpeciesHomeIndex = this.curSpecies.getHomeGridIndex();
				this.generator = com.getEnvironment().getGenerator(this.curSpeciesHomeIndex);

				addCrittersRandomlyWithLimitations(1, this.speciesValueMultipleSpecies);

				abundanceCounter[speciesIndexToAdd]++;
				totalAbundanceCounter++;
			}
			else
			{
				if (totalAbundanceCounter == total)
				{
					break;
				}
			}
			/*
			 * System.out.println(""); System.out.println("totalAbundanceCounter is " + totalAbundanceCounter); System.out.println("abundanceGoal is " + total);
			 */
		}
		
		UpdateAbundances ua = new UpdateAbundances(com);
		ua.update();
		CommunityUtilsStep.stepPrimer(this.com);
	}
	
	
	
}
