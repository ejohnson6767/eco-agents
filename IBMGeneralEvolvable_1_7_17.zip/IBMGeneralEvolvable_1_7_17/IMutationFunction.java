import java.io.Serializable;
import java.util.Random;

public interface IMutationFunction extends Serializable
{
	double mutate(double currentTraitValue);
	void setGenerator(Random generator);
	double mutate(double traitValue, Location parentLoc);
	void setEvolveProb(IEvolveProb ep);
	void setMutationMagnitude(IMutationMagnitude mm);
	IEvolveProb getEvolveProb();
	IMutationMagnitude getMutationMagnitude();
}
