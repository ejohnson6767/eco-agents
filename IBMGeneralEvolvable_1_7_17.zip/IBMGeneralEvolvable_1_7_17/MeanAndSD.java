import java.util.ArrayList;

public class MeanAndSD

{
	public static double meanAcrossColumns(double[][] array, int row)
	{
		int length = array[0].length;
		// System.out.println("length is " + length);
		double total = 0;
		for (int i = 0; i < length; i++)
		{
			total += array[row][i];
		}
		double mean = total / (double) length;
		return mean;
	}

	public static double SDAcrossColumns(double[][] array, int row, double mean)
	{
		int length = array[0].length;
		double total = 0;
		for (int i = 0; i < length; i++)
		{
			total += Math.pow((array[row][i] - mean), 2);
		}
		double SD = Math.sqrt(total / (double) (length - 1));
		return SD;
	}

	public static double meanAcrossColumns(int[][] array, int row)
	{
		int length = array[0].length;
		// System.out.println("length is " + length);
		double total = 0;
		for (int i = 0; i < length; i++)
		{
			total += array[row][i];
		}
		double mean = total / (double) length;
		return mean;
	}

	public static double SDAcrossColumns(int[][] array, int row, double mean)
	{
		int length = array[0].length;
		double total = 0;
		for (int i = 0; i < length; i++)
		{
			total += Math.pow((array[row][i] - mean), 2);
		}
		double SD = Math.sqrt(total / (double) (length - 1));
		return SD;
	}

	public static double meanAcrossRows(double[][] array, int column)
	{
		int length = array.length;
		// System.out.println("length is " + length);
		double total = 0;
		for (int i = 0; i < length; i++)
		{
			total += array[i][column];
		}
		double mean = total / (double) length;
		return mean;
	}

	public static double SDAcrossRows(double[][] array, int column, double mean)
	{
		int length = array.length;
		double total = 0;
		for (int i = 0; i < length; i++)
		{
			total += Math.pow((array[i][column] - mean), 2);
		}
		double SD = Math.sqrt(total / (double) (length - 1));
		return SD;
	}

	public static double mean(double[] array)
	{

		int length = array.length;
		double total = 0;
		for (int i = 0; i < length; i++)
		{
			total += array[i];
		}
		double mean = total / (double) length;
		return mean;
	}

	public static double SD(double[] array, double mean)
	{
		int length = array.length;
		double total = 0;
		for (int i = 0; i < length; i++)
		{
			total += Math.pow((array[i] - mean), 2);
		}
		double SD = Math.sqrt(total / (double) (length - 1));
		return SD;
	}

	public static double mean(int[] array)
	{

		int length = array.length;
		double total = 0;
		for (int i = 0; i < length; i++)
		{
			total += array[i];
		}
		double mean = total / (double) length;
		return mean;
	}

	public static double SD(int[] array, double mean)
	{
		int length = array.length;
		double total = 0;
		for (int i = 0; i < length; i++)
		{
			total += Math.pow((array[i] - mean), 2);
		}
		double SD = Math.sqrt(total / (double) (length - 1));
		return SD;
	}
	
	public static double mean(ArrayList<Double> arrayList)
	{

		int length = arrayList.size();
		double total = 0;
		for (int i = 0; i < length; i++)
		{
			total += arrayList.get(i);
		}
		double mean = total / (double) length;
		return mean;
	}

	public static double SD(ArrayList<Double> arrayList, double mean)
	{
		int length = arrayList.size();
		double total = 0;
		for (int i = 0; i < length; i++)
		{
			total += Math.pow((arrayList.get(i) - mean), 2);
		}
		double SD = Math.sqrt(total / (double) (length - 1));
		return SD;
	}

	public static double sum(int[] array)
	{
		int length = array.length;
		double total = 0;
		for (int i = 0; i < length; i++)
		{
			total += array[i];
		}
		return (double) total;
	}

	public static double meanOfRowSumAcrossColumns(double[][] array)
	{
		int numRows = array.length;
		int numCols = array[0].length;
		// System.out.println("length is " + length);
		double total = 0;
		for (int c = 0; c < numCols; c++)
		{
			double rowSum = 0;

			for (int r = 0; r < numRows; r++)
			{
				rowSum += array[r][c];
			}
			total += rowSum;
		}
		double mean = total / (double) numCols;
		return mean;
	}
	
	public static double SDOfRowSumAcrossColumns(double[][] array, double mean)
	
	{
		int numRows = array.length;
		int numCols = array[0].length;
		// System.out.println("length is " + length);
		double total = 0;
		for (int c = 0; c < numCols; c++)
		{
			double rowSum = 0;

			for (int r = 0; r < numRows; r++)
			{
				rowSum += array[r][c];
			}
			total += Math.pow((rowSum - mean), 2);
		}
		double SD = total / (double) (numCols - 1);
		return SD;
	}

}
