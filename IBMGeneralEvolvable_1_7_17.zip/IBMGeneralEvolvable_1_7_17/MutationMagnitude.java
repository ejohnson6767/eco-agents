import java.io.Serializable;

public class MutationMagnitude implements IMutationMagnitude, Serializable
{

	private double mutationMagnitude;
	private Community com;
	private int gridLength;
	private Environment env;
	private ISpecies speciesOwner;
	private int envGridIndex;
	private int speciesValue;

	public MutationMagnitude(double mutationMagnitude)
	{
		this.mutationMagnitude = mutationMagnitude;
	}
	
	public void setupAfterCommunityIsCreated(Community com)
	{
		//System.out.println("DIFFUSION SETUP AFTER COMMUNITY IS CREATED");
		this.com = com;
		this.env = com.getEnvironment();
		this.gridLength = this.env.getGridLength();
		this.envGridIndex = this.speciesOwner.getHomeGridIndex();
		this.speciesValue = this.speciesOwner.getGridProxy();
	}
	
	public void setSpeciesOwner(ISpecies species)
	{
		this.speciesOwner = species;
	}


	public double getMutationMagnitude()
	{
		return this.mutationMagnitude;
	}
	
	public double getMutationMagnitude(Location parentLoc)
	{
		return this.mutationMagnitude;
	}
	

	public void setMutationMagnitude(double mutationMagnitude)
	{
		this.mutationMagnitude = mutationMagnitude;

	}

	public double[][] getSpatialDistributionTracker()
	{
		System.out.println("getting sdt from bland diffusion ");
		double[][] sdt = new double[this.gridLength][this.gridLength];
		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				if(this.env.getGridValue(row, col, envGridIndex) == this.speciesValue)
				{
					//System.out.println(this.diffusion);
					sdt[row][col] = this.mutationMagnitude;
				}
			}
		}
		
		return sdt;
	}

	@Override
	public boolean isIndividualBased()
	{
		// TODO Auto-generated method stub
		return false;
	}

}
