import java.io.Serializable;

public class DeathStandard implements IDeathProcess, Serializable
{
	//private Community com;
	private double deathRate;

	public DeathStandard(double deathRate)
	{
		//this.com = com;
		this.deathRate = deathRate;
	}
	
	public double getDeathRate(Location loc)
	{
		return this.deathRate;
	}

	
	public void scaleByDt(double dt)
	{
		this.deathRate *= dt;
		
	}

	@Override
	public void setSpeciesOwner(ISpecies species)
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setupAfterCommunityIsCreated(Community com)
	{
		// TODO Auto-generated method stub
		
	}
}
