import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArrayFlattener
{

	
	public static Number[] flattenWrapper(Object[] inputArray) throws IllegalArgumentException
	{

		if (inputArray == null)
			return null;

		List<Number> flatList = new ArrayList<Number>();

		for (Object element : inputArray)
		{
			if (element instanceof Object[])
			{
				flatList.addAll(Arrays.asList(flattenWrapper((Object[]) element)));
			} else if(element instanceof Object)
			{
				Class<?> c = element.getClass();
				if(c.isArray())
				{
					for (int i = 0; i < Array.getLength(element) ; i++)
					{
						Array.get(element, i);
						flatList.add((Number) Array.get(element, i));
					}
				} else if(c.isPrimitive())
				{
					flatList.add((Number) element);
				}
			}
			
		}
		
		return  flatList.toArray(new Number[flatList.size()]);
	}
	
	public static double[] flatten(Object[] inputArray)
	{
		Number[] flat = flattenWrapper(inputArray);
		double[] toReturn = new double[flat.length];
		for (int i = 0; i < toReturn.length; i++)
		{
			toReturn[i] =  flat[i].doubleValue();
		}
		return toReturn;
	}
	
	
	
}