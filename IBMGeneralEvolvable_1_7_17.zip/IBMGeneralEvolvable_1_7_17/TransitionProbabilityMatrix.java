import java.util.ArrayList;

public class TransitionProbabilityMatrix
{
	private Community com;
	private double[][][] transProbMat;
	private int gridLength;
	private ArrayList<int[][]>[] gridStateArchive;
	private Environment env;
	private int totalSites;
	
	public TransitionProbabilityMatrix(Community com, int archiveLength, int transProbMatLength)
	{
		this.com = com;
		this.env = this.com.getEnvironment();
		this.gridLength = this.env.getGridLength();
		this.totalSites = this.env.getTotalSites();
		this.gridStateArchive = new ArrayList[this.totalSites];
		this.transProbMat = new double[this.totalSites][this.totalSites][transProbMatLength];
	}
	
	
	public update 
	
}
