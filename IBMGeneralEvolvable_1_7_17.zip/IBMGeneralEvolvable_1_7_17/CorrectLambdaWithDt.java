
public class CorrectLambdaWithDt
{
	public static double correctPrint(double lambda, double dt)
	{
		double r = Math.log(lambda);
		System.out.println("r is " + r);
		double rTime = r/dt;
		System.out.println("r time is "+ rTime);
		System.out.println("corrected lambda is "+ Math.exp(rTime));
		return Math.exp(rTime);
	}
	
	public static double correct(double lambda, double dt)
	{
		double r = Math.log(lambda);
		double rTime = r/dt;
		return Math.exp(rTime);
	}
}
