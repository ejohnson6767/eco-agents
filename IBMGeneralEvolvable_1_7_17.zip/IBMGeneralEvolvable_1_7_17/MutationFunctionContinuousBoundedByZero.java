import java.io.Serializable;
import java.util.Random;

public class MutationFunctionContinuousBoundedByZero extends MutationFunctionStandard implements IMutationFunction, Serializable
{

	public MutationFunctionContinuousBoundedByZero(double evolveProb, double mutationMagnitude)
	{
		super(evolveProb, mutationMagnitude);		
	}
	
	public void setGenerator(Random generator)
	{
		//System.out.println("setting generator!!!");
		this.generator = generator;
	}
	
	public double mutate(double traitValue)
	{
		
			//System.out.println("a rand double is " + generator.nextDouble());
			//System.out.println("evolve prob is " + evolveProb.getEvolveProb());
			if (generator.nextDouble() < evolveProb.getEvolveProb())
			{
				//System.out.println("mutation!");
				//System.out.println("current trait is " + traitValue);
				double addTo =  generator.nextGaussian() * mutationMagnitude.getMutationMagnitude();
				

				if (generator.nextInt(2) == 1)
				{
					addTo *= -1;
				}

				traitValue += addTo;
				
				if(traitValue < 0)
				{
					traitValue = 0;
				}

				//System.out.print("trait mutated to " + traitValue);
				//System.out.println("modified trait is " + traitValue);
			}
			//System.out.println("modified trait is " + traitValue);
			// System.out.println();
			

			return traitValue;
		}

	public double mutate(double traitValue, Location parentLoc)
	{
		//System.out.println("a rand double is " + generator.nextDouble());
		//System.out.println("evolve prob is " + evolveProb.getEvolveProb());
		if (generator.nextDouble() < evolveProb.getEvolveProb(parentLoc))
		{
			//System.out.println("mutation!");
			//System.out.println("current trait is " + traitValue);
			double addTo =  generator.nextGaussian() * mutationMagnitude.getMutationMagnitude(parentLoc);
			

			if (generator.nextInt(2) == 1)
			{
				addTo *= -1;
			}

			traitValue += addTo;
			
			if(traitValue < 0)
			{
				traitValue = 0;
			}

			//System.out.print("trait mutated to " + traitValue);
			//System.out.println("modified trait is " + traitValue);

		}
		// System.out.println("modified br is " + curTrait);
		// System.out.println();
		

		return traitValue;
	}

}
