import java.io.Serializable;

public interface IEvolveProb extends Serializable
{
	double getEvolveProb();
	void setEvolveProb(double evolveProb);
	double getEvolveProb(Location parentLoc);
	double[][] getSpatialDistributionTracker();
	void setupAfterCommunityIsCreated(Community com);
	void setSpeciesOwner(ISpecies species);
	boolean isIndividualBased();
}
