import java.io.Serializable;

public class TerminateIfSpeciesDiesOrGrowsTooLarge implements ITerminateCondition, Serializable
{
	private Community com;
	private int tooLarge;
	private int speciesValue;
	
	public TerminateIfSpeciesDiesOrGrowsTooLarge(Community com, int speciesValue, int tooLarge)
	{
		this.com = com;
		this.speciesValue = speciesValue;
		this.tooLarge = tooLarge;
	}
	
	public TerminateIfSpeciesDiesOrGrowsTooLarge(Community com, int speciesValue, double tooLarge)
	{
		this.com = com;
		this.speciesValue = speciesValue;
		this.tooLarge = this.com.abundFromProp(tooLarge);
	}
	
	public boolean shouldTerminate()
	{
		boolean shouldTerminate = false;
		int[] abunds = this.com.getAbundances();
		
		//System.out.println("abund is " + abunds[this.speciesValue - 1]);
			if(abunds[this.speciesValue - 1] == 0)
			{
				shouldTerminate = true;
				
			} else if(abunds[this.speciesValue - 1] >= tooLarge)
			{
				shouldTerminate = true;
			}
		
		return shouldTerminate;
	}
	
}
	