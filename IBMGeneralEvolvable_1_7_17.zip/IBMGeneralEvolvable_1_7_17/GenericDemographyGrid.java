import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

/**
 * The Class PatchyEnvironment adds community "patches" to the Environment grid. They can be placed randomly or in clumps, at certain densities, and with certain sizes.
 *@author Evan Johnson
 *@version 2/27/16
 */
public class GenericDemographyGrid implements Serializable
{

	/** The generator of random numbers */
	private Random generator;

	/** The patch list. An arraylist of patch types - one for each species - contains arraylists of patches  */
	private ArrayList<ArrayList<Patch>> patchList;

	/** The patches per species. */
	private int patchesPerSpecies;

	/** The proportion of the environment grid that the patches occupy */
	private double patchProportion;

	/** The area of each patch */
	private int patchArea;

	/** The total number of patches in the environment */
	private int totalNumberOfPatches;

	private int lengthRadius;
	private int widthRadius;
	private int length;
	private int width;

	private int patchPerimeter;

	private double flipFraction;

	private int numberOfNonZeroPatchTypes;

	private int gridLength;

	private int[][] genericDemographyGrid;

	public GenericDemographyGrid(int gridLength)
	{
		this.gridLength = gridLength;
		this.genericDemographyGrid = new int[this.gridLength][this.gridLength];
		this.generator = new Random();
		// Arrays.fill(this.baselineBirthRateGrid, 1);
	}

	public Random getGenerator()
	{
		return this.generator;
	}

	public int getGridLength()
	{
		return this.gridLength;
	}

	public int[][] getGrid()
	{
		return this.genericDemographyGrid;
	}

	public void makePairCorrelationGrid(int[] abundances, double[][][] PCGoal, double lambda, double epsilon, int maxTries)
	{
		MakeGrids mg = new MakeGrids(this.gridLength);
		mg.setRandomGenerator(this.generator);
		mg.makePairCorrelationGridFromScratch(abundances, PCGoal, lambda, epsilon, maxTries);
		this.genericDemographyGrid = mg.getGrid();
	}

	public void setGenericDemographyGrid(int[][] grid)
	{
		this.genericDemographyGrid = grid;
	}

	public void setNumberOfPatchTypes(int numTypes)
	{
		this.numberOfNonZeroPatchTypes = numTypes - 1;
	}

	public void makePercolationGrid(double[] densityOfNonZeroCellTypes)
	{
		this.numberOfNonZeroPatchTypes = densityOfNonZeroCellTypes.length;
		int totalSites = this.gridLength * this.gridLength;
		double total = 0;
		for (int i = 0; i < densityOfNonZeroCellTypes.length; i++)
		{
			total += densityOfNonZeroCellTypes[i];
		}

		if (total >= 1)
		{
			throw new IllegalArgumentException();
		}

		int[] abunds = new int[densityOfNonZeroCellTypes.length];
		int totalAbunds = 0;

		for (int i = 0; i < densityOfNonZeroCellTypes.length; i++)
		{
			abunds[i] = (int) Math.round(densityOfNonZeroCellTypes[i] * totalSites);
			totalAbunds += abunds[i];
		}

		if (totalAbunds >= totalSites)
		{
			{
				throw new IllegalArgumentException();
			}
		}

		MakeGrids aGrid = new MakeGrids(this.gridLength);
		aGrid.setRandomGenerator(this.generator);
		this.genericDemographyGrid = aGrid.makePercolationGrid(abunds);

	}

	public void makeCheckerboardGrid(int subSquareLength, int numSubSquares, boolean zeroInUpperLeftQuarter)
	{

		this.numberOfNonZeroPatchTypes = 1;
		if ((numSubSquares * subSquareLength % 2 != 0) || (numSubSquares * subSquareLength != this.gridLength))
		{
			throw new IllegalArgumentException();
		}

		if (zeroInUpperLeftQuarter)
		{
			for (int row = 0; row < gridLength; row++)
			{
				for (int col = 0; col < gridLength; col++)
				{
					int rowSubSquare = row / subSquareLength;
					int colSubSquare = col / subSquareLength;
					if ((rowSubSquare + colSubSquare) % 2 == 0)
					{
						this.genericDemographyGrid[row][col] = 0;
					}
					else
					{

						this.genericDemographyGrid[row][col] = 1;
					}
				}
			}
		}
		else
		{
			for (int row = 0; row < gridLength; row++)
			{
				for (int col = 0; col < gridLength; col++)
				{
					int rowSubSquare = row / subSquareLength;
					int colSubSquare = col / subSquareLength;
					if ((rowSubSquare + colSubSquare) % 2 == 0)
					{
						this.genericDemographyGrid[row][col] = 1;
					}
					else
					{

						this.genericDemographyGrid[row][col] = 0;
					}
				}
			}
		}

	}

	public void makePatchyGrid(int numPatchTypes, int lengthRadius, int widthRadius, double fractionToFill, int sdOfCommunityDispersion)
	{
		this.length = lengthRadius * 2 + 1;
		this.width = widthRadius * 2 + 1;
		this.patchArea = this.length * this.width;
		this.patchPerimeter = (this.length * 2) + (this.width * 2);
		this.lengthRadius = lengthRadius;
		this.widthRadius = widthRadius;
		this.patchList = new ArrayList<ArrayList<Patch>>();
		this.numberOfNonZeroPatchTypes = numPatchTypes;

		// instantiate the nested arraylist of patches.
		for (int i = 0; i < this.numberOfNonZeroPatchTypes; ++i)
		{
			ArrayList<Patch> patchType = new ArrayList<Patch>();
			this.patchList.add(patchType);
		}
		/*
		 * this.oldCounter = 0; this.counter = 0;
		 */

		placePatches(this.numberOfNonZeroPatchTypes, fractionToFill, this.lengthRadius, this.widthRadius, sdOfCommunityDispersion);

		// instatiate instance variable with potentially useful data
		this.patchesPerSpecies = this.patchList.get(0).size();
		test();

		// patch proportion is important because it can inadvertently covary with patch size.
		this.patchProportion = (this.patchArea * this.numberOfNonZeroPatchTypes * this.patchesPerSpecies) / (double) (this.gridLength * this.gridLength);
		this.totalNumberOfPatches = this.patchesPerSpecies * this.numberOfNonZeroPatchTypes;
	}

	public int getNumberOfNonZeroPatchTypes()
	{
		return this.numberOfNonZeroPatchTypes;
	}

	public int getNumberOfPatchTypes()
	{
		return this.numberOfNonZeroPatchTypes + 1;
	}

	public int getlengthRadius()
	{
		return this.lengthRadius;
	}

	public int getWidthRadius()
	{
		return this.widthRadius;
	}

	public int getPatchPerimeter()
	{
		return this.patchPerimeter;
	}

	public int getPatchArea()
	{
		return this.patchArea;
	}

	public void test()
	{
		for (int i = 0; i < this.patchList.size(); i++)
		{
			// System.out.println("patch type " + (i+1) + " has " + this.patchList.get(i).size() + " patches.");
			if (this.patchList.get(i).size() != this.patchesPerSpecies)
			{

				// throw new IllegalStateException("Fuck ME");
			}
		}
	}

	/*
	 * public void ifTooManyPatchesDeleteOneForEachSpecies(int numSpecies, double fractionToFill) { double total = this.gridLength * this.gridLength; if ((fractionToFill - (this.oldCounter / total)) < ((counter / total) - fractionToFill)) {
	 * 
	 * for (int p = 0; p < numSpecies; p++) { ArrayList<Patch> singlePatchList = patchList.get(p); Patch singlePatch = singlePatchList.get(singlePatchList.size() - 1); int referenceRow = singlePatch.getRow(); int referenceCol = singlePatch.getCol();
	 * 
	 * for (int j = 0; j < patchLength; j++) { for (int i = 0; i < patchLength; i++) {
	 * 
	 * this.grid[WrapAround.wrapAroundForPatches(referenceRow + j, this.gridLength)][WrapAround.wrapAroundForPatches(referenceCol + i, this.gridLength)][1] = 0; } }
	 * 
	 * this.patchList.get(p).remove(this.patchList.get(p).size() - 1); } } }
	 */
	public void placePatches(int numSpecies, double fractionToFill, int lengthRadius, int widthRadius, int sdOfCommunityDispersion)
	{
		while (true)
		{
			try
			{
				tryToPlacePatches(numSpecies, fractionToFill, lengthRadius, widthRadius, sdOfCommunityDispersion);
				break;
			} catch (IllegalStateException maxPatchPlaceTriesExceeded)
			{
				System.out.println("couldn't find a place on the environment grid for the patch. resetting: start with a fresh grid and patch list.");
				this.genericDemographyGrid = new int[this.gridLength][this.gridLength];

				// start with fresh arraylists of patches
				this.patchList = new ArrayList<ArrayList<Patch>>();
				for (int i = 0; i < numSpecies; i++)
				{
					this.patchList.add(new ArrayList<Patch>());
				}

			}
		}

		// ifTooManyPatchesDeleteOneForEachSpecies(numSpecies, fractionToFill);
	}

	public void setupForPatches(int numPatchTypes, int patchLength, int patchWidth)
	{
		System.out.println("adding patches uniformly");
		this.genericDemographyGrid = new int[this.gridLength][this.gridLength];
		int rowLength = patchLength * 2 + 1;
		int colLength = patchWidth * 2 + 1;
		
		
		this.length = patchLength * 2 + 1;
		this.width = patchWidth * 2 + 1;
		this.patchArea = this.length * this.width;
		this.patchPerimeter = (this.length * 2) + (this.width * 2);
		this.lengthRadius = patchLength;
		this.widthRadius = patchWidth;
		this.patchList = new ArrayList<ArrayList<Patch>>();
		this.numberOfNonZeroPatchTypes = numPatchTypes;
		// instantiate the nested arraylist of patches.
				for (int i = 0; i < this.numberOfNonZeroPatchTypes; ++i)
				{
					
					ArrayList<Patch> patchType = new ArrayList<Patch>();
					this.patchList.add(patchType);
				}
	}
	
	public void placeSinglePatch(int midRow, int midCol, int patchType)
	{
		int p = patchType - 1;
		int referenceRow = midRow - this.lengthRadius;
		int referenceCol = midCol - this.widthRadius;

		for (int row2 = 0; row2 < this.length; row2++)
		{
			for (int col2 = 0; col2 < this.width; col2++)
			{
				////System.out.println("in here");
				int realRow = WrapAround.wrapAroundForPatches(referenceRow + row2, this.gridLength);
				int realCol = WrapAround.wrapAroundForPatches(referenceCol + col2, this.gridLength);
				this.genericDemographyGrid[realRow][realCol] = p + 1;
				////System.out.println((p+1));
			}
		}

		this.patchList.get(p).add(new Patch(WrapAround.wrapAround(referenceRow, this.gridLength), WrapAround.wrapAround(referenceCol, this.gridLength), this.length, this.width, p + 1));
		
	}
	
	public void finishSetupForPatches()
	{
		this.patchesPerSpecies = this.patchList.get(0).size();
		test();

		// patch proportion is important because it can inadvertently covary with patch size.
		this.patchProportion = (this.patchArea * this.numberOfNonZeroPatchTypes * this.patchesPerSpecies) / (double) (this.gridLength * this.gridLength);
		this.totalNumberOfPatches = this.patchesPerSpecies * this.numberOfNonZeroPatchTypes;

	}
	
	
	public void addPatchesUniformly(int numPatchTypes, int patchesToAdd, int patchRadius)
	{
		System.out.println("adding patches uniformly");
		this.genericDemographyGrid = new int[this.gridLength][this.gridLength];
		int rowLength = patchRadius * 2 + 1;
		int colLength = patchRadius * 2 + 1;
		
		
		this.length = patchRadius * 2 + 1;
		this.width = patchRadius * 2 + 1;
		this.patchArea = this.length * this.width;
		this.patchPerimeter = (this.length * 2) + (this.width * 2);
		this.lengthRadius = patchRadius;
		this.widthRadius = patchRadius;
		this.patchList = new ArrayList<ArrayList<Patch>>();
		this.numberOfNonZeroPatchTypes = numPatchTypes;

		// instantiate the nested arraylist of patches.
		for (int i = 0; i < this.numberOfNonZeroPatchTypes; ++i)
		{
			
			ArrayList<Patch> patchType = new ArrayList<Patch>();
			this.patchList.add(patchType);
		}

		System.out.println("init is " + patchesToAdd);
		int initLength = (int) Math.round(Math.sqrt(patchesToAdd));
		System.out.println("initLength is " + initLength);
		if (initLength * 2 + 2 > this.gridLength)
		{
			throw new IllegalArgumentException("inoculated too many inidividuals");
		}

		int distBetweenIndividuals = (int) Math.round(this.gridLength / (double) (initLength + 2));
		System.out.println("dist between individuals " + distBetweenIndividuals);
		int distFromEdge = distBetweenIndividuals; // (int) Math.round(distBetweenIndividuals / (double) 2);
		System.out.println("dist from edge " + distFromEdge);

		// while (true)
		// {
		int col = distFromEdge;
		while (col < ((this.gridLength) - distFromEdge))
		{
			col += distBetweenIndividuals;
		}
		col -= distBetweenIndividuals;

		int totalEdgeDist = distFromEdge + (this.gridLength) - 1 - col;
		distFromEdge = (int) Math.round(totalEdgeDist / (double) 2);
		// }

		col = distFromEdge;

		int p = 0;

		while (col < ((this.gridLength) - distFromEdge))
		{
			int row = distFromEdge;
			while (row < ((this.gridLength) - distFromEdge))
			{
				//System.out.println("in here");
				int referenceRow = row - patchRadius;
				int referenceCol = col - patchRadius;

				for (int row2 = 0; row2 < rowLength; row2++)
				{
					for (int col2 = 0; col2 < colLength; col2++)
					{
						System.out.println("in here");
						int realRow = WrapAround.wrapAroundForPatches(referenceRow + row2, this.gridLength);
						int realCol = WrapAround.wrapAroundForPatches(referenceCol + col2, this.gridLength);
						this.genericDemographyGrid[realRow][realCol] = p + 1;
						System.out.println((p+1));
					}
				}

				this.patchList.get(p).add(new Patch(WrapAround.wrapAround(referenceRow, this.gridLength), WrapAround.wrapAround(referenceCol, this.gridLength), rowLength, colLength, p + 1));
				p++;
				if(p >= numPatchTypes)
				{
					p = 0;
				}
				row += distBetweenIndividuals;
			}
			col += distBetweenIndividuals;
		}
		
		
		this.patchesPerSpecies = this.patchList.get(0).size();
		test();

		// patch proportion is important because it can inadvertently covary with patch size.
		this.patchProportion = (this.patchArea * this.numberOfNonZeroPatchTypes * this.patchesPerSpecies) / (double) (this.gridLength * this.gridLength);
		this.totalNumberOfPatches = this.patchesPerSpecies * this.numberOfNonZeroPatchTypes;

	}

	public void tryToPlacePatches(int numberOfPatchTypes, double fractionToFill, int lengthRadius, int widthRadius, int sdOfCommunityDispersion)
	{

		double total = this.gridLength * this.gridLength;
		int maxITERATIONS = (int) Math.floor(total * 2);
		int k = 0;
		int referenceRow = 0;
		int referenceCol = 0;
		int counter = 0;
		int futureCounter = 0;
		int rowRadius = 0;
		int colRadius = 0;
		int rowLength = 0;
		int colLength = 0;
		int numHorizontal = 0;
		int numVertical = 0;
		boolean isHoriz = true;

		// this is the starting position. it is referenced when the first patch is placed
		int tryRow = generator.nextInt(this.gridLength);
		int tryCol = generator.nextInt(this.gridLength);

		// add patches until the specified density of patches is acheived OR until the program tries to place patches and fail the maxITERATIONS number of times
		while ((counter / total) < fractionToFill)
		{
			if ((fractionToFill - (counter / total)) < ((futureCounter / total) - fractionToFill))
			{
				// System.out.println("not quite enough patches, but another round would be too many.");
				break;
			}

			// each new patch is one of a different species that the last
			for (int p = 0; p < numberOfPatchTypes; p++)
			{
				k = 0;
				// keep searching to empty spots, unless you fail the maxITERATIONS number of times
				tryLoop: while (k < maxITERATIONS)
				{

					// pull a Normal RV with a specified sd
					tryRow = (int) Math.round(tryRow + generator.nextGaussian() * sdOfCommunityDispersion);
					tryCol = (int) Math.round(tryCol + generator.nextGaussian() * sdOfCommunityDispersion);

					if (generator.nextInt(2) == 0)
					{
						rowRadius = this.lengthRadius;
						colRadius = this.widthRadius;
						rowLength = this.length;
						colLength = this.width;
						isHoriz = false;

					}
					else
					{
						colRadius = this.lengthRadius;
						rowRadius = this.widthRadius;
						colLength = this.length;
						rowLength = this.width;
						isHoriz = true;
					}

					referenceRow = tryRow - rowRadius;
					referenceCol = tryCol - colRadius;

					for (int row = 0; row < rowLength; row++)
					{
						for (int col = 0; col < colLength; col++)
						{
							int realRow = WrapAround.wrapAroundForPatches(referenceRow + row, this.gridLength);
							int realCol = WrapAround.wrapAroundForPatches(referenceCol + col, this.gridLength);
							if (this.genericDemographyGrid[realRow][realCol] != 0)
							{
								k++;
								continue tryLoop;
							}
						}
					}
					if (isHoriz)
					{
						numHorizontal++;
					}
					else
					{
						numVertical++;
					}

					for (int row = 0; row < rowLength; row++)
					{
						for (int col = 0; col < colLength; col++)
						{
							int realRow = WrapAround.wrapAroundForPatches(referenceRow + row, this.gridLength);
							int realCol = WrapAround.wrapAroundForPatches(referenceCol + col, this.gridLength);
							this.genericDemographyGrid[realRow][realCol] = p + 1;
						}
					}
					this.patchList.get(p).add(new Patch(WrapAround.wrapAround(referenceRow, this.gridLength), WrapAround.wrapAround(referenceCol, this.gridLength), rowLength, colLength, p + 1));
					k = 0;
					break;
				}
				if (k >= maxITERATIONS)
				{
					IllegalStateException maxPatchPlaceTriesExceeded = new IllegalStateException();
					throw maxPatchPlaceTriesExceeded;
				}
			}

			// this.oldCounter = this.counter;
			// each time n-species numbers of patches are placed, count up the total area of patches placed
			counter += this.patchArea * numberOfPatchTypes;
			futureCounter = counter + (this.patchArea * numberOfPatchTypes);
			if (numHorizontal > numVertical)
			{
				this.flipFraction = numHorizontal / (double) (numHorizontal + numVertical);
			}
			else
			{
				this.flipFraction = numVertical / (double) (numHorizontal + numVertical);

			}

		}
	}

	public double getFlipFraction()
	{
		return this.flipFraction;
	}

	/**
	 * Gets the patch list.
	 *
	 * @return the patch list
	 */
	public ArrayList<ArrayList<Patch>> getPatchList()
	{
		return this.patchList;
	}

	/**
	 * Gets the patches per species.
	 *
	 * @return the patches per species
	 */
	public int getPatchesPerSpecies()
	{
		return patchesPerSpecies;
	}

	/**
	 * Gets the total number of patches.
	 *
	 * @return the total number of patches
	 */
	public int getTotalNumberOfPatches()
	{
		return this.totalNumberOfPatches;
	}

	/**
	 * Gets the patch proportion.
	 *
	 * @return the proportion of patchy space to the total space of the environment
	 */
	public double getPatchProportion()
	{
		return this.patchProportion;
	}

	/**
	 * Gets the patch type at a particular location on the envrionment grid
	 *
	 * @param row the row
	 * @param col the col
	 * @return the patch type
	 */
	public double getPatchType(int row, int col)
	{
		return this.genericDemographyGrid[row][col];
	}

	public void setSeed(int ss)
	{
		this.generator.setSeed(ss);
	}

	// currently out of order, belongs in a another class
	/**
	 * Badlands counter.
	 *
	 * @return the double
	 */
	/*
	 * public double badlandsCounter() { int total = 0; int counter = 0; for (int j = 0; j < this.gridLength; j++) { for (int i = 0; i < this.gridLength; i++) { if (this.grid[j][i][1] == 0) { total++;
	 * 
	 * if (this.grid[j][i][1] != 0) { counter++; } } } } return total / counter; }
	 *//**
		* Gets the patch richness.
		*
		* @param patchType the patch type
		* @return the patch richness
		*/
	/*
	 * public int[][] getPatchRichness(int patchType) { // get the arraylist of the specified patchType List<Patch> thePatchType = this.patchList.get(patchType - 1);
	 * 
	 * // how many patches of this type are there? int numOfPatches = thePatchType.size();
	 * 
	 * // declare return array int[][] abundanceArray = new int[6][numOfPatches];
	 * 
	 * int theLength = thePatchType.get(0).getPatchLength();
	 * 
	 * for (int i = 0; i < numOfPatches; i++) { int counter0 = 0; int counter1 = 0; int counter2 = 0; int counter3 = 0; int counter4 = 0; int counter5 = 0;
	 * 
	 * Patch thePatch = thePatchType.get(i); int theRowReference = thePatch.getRow(); int theColReference = thePatch.getCol();
	 * 
	 * for (int r = 0; r < theLength; r++) { for (int c = 0; c < theLength; c++) { int val = this.grid[WrapAround.wrapAroundForPatches(theRowReference + r, this.gridLength)][WrapAround.wrapAroundForPatches(theColReference + c, this.gridLength)][1];
	 * 
	 * if (val == 0) { counter0++; } else if (val == 1) { counter1++; } else if (val == 2) { counter2++; } else if (val == 3) { counter3++; } else if (val == 4) { counter4++; } else if (val == 5) { counter5++; } } } abundanceArray[0][i] = counter0; abundanceArray[1][i] = counter1; abundanceArray[2][i] = counter2; abundanceArray[3][i] = counter3; abundanceArray[4][i] = counter4; abundanceArray[5][i] = counter5; }
	 * 
	 * return abundanceArray; }
	 */

}
