import java.util.Random;

public class DummyTrait extends ContinuousTrait implements Evolvable
{
	private double baselineTrait;
	private EmpiricalFitness iBFitness;

	public DummyTrait()
	{
		super(new MutationFunctionContinuous(0,0));
	}

	@Override
	public void setSpeciesOwner(ISpecies species)
	{
		// nothing needs to be done. species owner was already set in continuous trait		
	}

	@Override
	public void startEvolution() throws Exception
	{
		this.isEvolving = true;
		this.isIndividualBased = true;
		this.baselineTrait = 0;
		CommunityUtilsStep.stepPrimer(com);

	}
	
	public void setIBFitness(EmpiricalFitness ibf)
	{
		this.iBFitness = ibf;
	}
	
	

	@Override
	public void initializeSpatialDistributionTracker()
	{
		this.spatialDistributionTracker = new double[this.gridLength][this.gridLength];
	}

	@Override
	public void startBeingIndividualBased() throws Exception
	{
		this.isIndividualBased = true;
		this.baselineTrait = 0;		
		CommunityUtilsStep.stepPrimer(com);
	}

	@Override
	public double getBaselineTrait()
	{
		return this.baselineTrait;
	}

	@Override
	public void setupAfterCommunityIsCreated(Community com)
	{
		// do nothing.
		initializeSpatialDistributionTracker();

	}

	public void stopBeingIndividualBased()
	{
		this.isIndividualBased = false;
		CommunityUtilsStep.stepPrimer(com);

	}
	
	public void stopEvolution()
	{
		this.isEvolving = false;
		CommunityUtilsStep.stepPrimer(com);

	}
	
	public void addToSpatialDistributionTracker(Location loc, Location parentLoc)
	{
		//System.out.println("adding to spatial distribution tracker now");
		this.iBFitness.addToAfterGrid(this.species.getGridProxy(), parentLoc);

	}
	
	public void removeFromSpatialDistributionTracker(Location loc)
	{
		//System.out.println("adding to spatial distribution tracker now");
		this.iBFitness.removeFromAfterGrid(this.species.getGridProxy(), loc);

	}

	public void addToSpatialDistributionTracker(Location loc, double traitValue)
	{
		throw new IllegalStateException("should only be calling the adding function with location and parent location as params");
	}

	public void addToSpatialDistributionTrackerForScrambling(Location loc, double traitValue)
	{
		throw new IllegalStateException("should only be calling the adding function with location and parent location as params");
	}

	

}
