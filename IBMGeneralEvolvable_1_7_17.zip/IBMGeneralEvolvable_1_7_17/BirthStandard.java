import java.io.Serializable;

public class BirthStandard implements IBirthProcess, Serializable
{
	//private Community com;
	private double birthRate;

	public BirthStandard( double birthRate)
	{
		//this.com = com;
		this.birthRate = birthRate;
	}
	
	public double getBirthRate(Location loc)
	{
		return this.birthRate;
	}
	
	public void scaleByDt(double dt)
	{
		this.birthRate *= dt;
		
	}

	@Override
	public void setSpeciesOwner(ISpecies species)
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setupAfterCommunityIsCreated(Community com)
	{
		// TODO Auto-generated method stub
		
	}
}
