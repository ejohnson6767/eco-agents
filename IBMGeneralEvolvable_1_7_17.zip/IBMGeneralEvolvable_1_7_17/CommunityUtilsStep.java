import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

public class CommunityUtilsStep implements Serializable
{

	public static Integer determineEmptySiteWinner(double[] speciesCompValuesSum, Random generator)
	{
		int numberOfSpecies = speciesCompValuesSum.length;
		double theBirthProb = generator.nextDouble();
		double compareTo = 0;
		for (int spp = 0; spp < numberOfSpecies; spp++)
		{

			compareTo += speciesCompValuesSum[spp];
			////System.out.println("the birth prob is " + theBirthProb);
			////System.out.println("compare to is " + compareTo);
			if (theBirthProb < compareTo)
			{
				return spp;
			}
		}
		return null;
	}

	public static void stepPrimer(Community com)
	{
		com.individualBasedHousekeeping();
		
		LocalLVAllSpecies lv = new LocalLVAllSpecies(com);
		lv.setBooleans();
		lv.doLocalLVStuff();

		CommunityUtilsFecundity.fillGrid(com);

		PRG prg = new PRG(com);
		prg.fillGrid();
	}
	
	/**
	 * 
	 * Execute one time step where amino acid availibility affects fecundity. Amino acids are kept track of with a moving window algorithm. So are cumulative growth rates (which determine the probability of progeny being recruited in an empty site).
	 *  The probability of a birth in an empty site is determined by amount of amino acid that reaches that site.   
	 */

	public static void stepWithIndividualBasedTraits(Community com)
	{
		int numberOfSpecies = com.getNumberOfSpecies();
		int gridLength = com.getEnvironment().getGridLength();
		ArrayList<ISpecies> speciesList = com.getSpeciesList();
		Environment env = com.getEnvironment();
		double[][][][] propaguleRainGrid = com.getPropaguleRainGrid();

		// System.out.println("time step " + timeStep);
		CommunityUtilsInoculate.checkForInoculations(com);

		// instantiate a stack of grids that gives the competitive values in each location of each species, respectively
		ArrayList<Location3D> toRemoveLocation = new ArrayList<Location3D>();
		ArrayList<ISpecies> toRemoveCritter = new ArrayList<ISpecies>();

		ArrayList<Location3D> toAddLocation = new ArrayList<Location3D>();
		ArrayList<ISpecies> toAddCritter = new ArrayList<ISpecies>();

		// com second main determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius
		
		
		// CommunityUtilsPropaguleRain.fillGrid(com);
		// com second main loop determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius

		// com algorithm scans right across the grid, goes down one line, scans again, and so on (just like reading). It's time complexity is O(n) (where n is the number of microsites) compared to O(n^2) of a trivial moving window algorithm.
		// It works by summing all of the
		// cumulative birth rates in the topmost row, the bottommost row, and everything in between. com is where the last dimension on pos array comes in:
		// 0 is TOP, 1 is MID, and 2 is BOT. when you to the next gid location, your cumulative growth rate is TOPnew + MIDnew + BOTnew. MIDnew is simply MIDnorth + BOTnorth - TOPnew.
		// (where north indicates the position above you). TOPnew can be written TOPwest - TOPwest.leftMost + TOPnew.rightmost. BOTnew can be written BOTwest - BOTwest.leftMost + BOTnew.rightmost.
		// the TOP, MID, and BOT are all recorded.

		for (int i = 0; i < env.getHeight(); i++)
		{
			int envGridIndex = i;
			Random generator = env.getGenerator(i);
			for (int row = 0; row < gridLength; row++)
			{
				for (int col = 0; col < gridLength; col++)
				{

					/*
					 * System.out.println(""); System.out.println(""); System.out.println("");
					 */

					// if it's occupied, pull a random number to see if it dies
					int gridValue = env.getGridValue(row, col, envGridIndex);
					if (gridValue != 0)
					{
						////System.out.println("death rate is " + speciesList.get(gridValue - 1).getDeathRate(new Location(row, col)));
						if (generator.nextDouble() < speciesList.get(gridValue - 1).getDeathRate(new Location(row, col)))
						{
							////System.out.println("the generator double was less than death rate");
							// index it to remove at the end of the time step
							toRemoveLocation.add(new Location3D(row, col, envGridIndex));
							toRemoveCritter.add(speciesList.get(gridValue - 1));
						}
						// if it does die, go to the next row,col location
					}
					else
					{
						double[] speciesCompValuesSum = new double[numberOfSpecies];
						for (int s = 0; s < numberOfSpecies; s++)
						{
							speciesCompValuesSum[s] = propaguleRainGrid[envGridIndex][row][col][s];
						}

						Integer winnerIndex = determineEmptySiteWinner(speciesCompValuesSum, generator);
						if (winnerIndex != null)
						{
							ISpecies curSpecies = speciesList.get(winnerIndex);

							if (curSpecies.canRecruit(com, new Location(row, col)))
							{
								Location3D loc3D = new Location3D(row, col, envGridIndex);
								toAddCritter.add(curSpecies);
								toAddLocation.add(loc3D);

							}
						}
					}
				}
			}
		}

		// births
		for (int i = 0; i < toAddLocation.size(); i++)
		{
			Location3D loc = toAddLocation.get(i);
			ISpecies tempSpecies = toAddCritter.get(i);

			env.add(loc, tempSpecies.getGridProxy());
			if (SpeciesTraitQuestions.isIndividualBased(tempSpecies))
			{
				//System.out.println("species to add is IB");
				tempSpecies.getTraitList().addToAllSpatialDistributionTrackers(new Location(loc.row(), loc.col()));
			}

		}
		
		for (int i = 0; i < toRemoveLocation.size(); i++)
		{
			Location3D loc = toRemoveLocation.get(i);
			ISpecies tempSpecies = toRemoveCritter.get(i);
			env.remove(loc);
			if (SpeciesTraitQuestions.isIndividualBased(tempSpecies))
			{
				//System.out.println("species to remove is IB");
				tempSpecies.getTraitList().removeFromAllSpatialDistributionTrackers(new Location(loc.row(), loc.col()));
			}
		}

		/*UpdateAbundances ua = new UpdateAbundances(com);
		ua.update();*/

		com.updateTimeStepCounter();

		//CommunityUtilsStep.stepPrimer(com);
		
		// CommunityUtilsStep.CMAndDMMovingWindow(com);

	}

	/**
	 * 
	 * Execute one time step where amino acid availibility affects fecundity. Amino acids are kept track of with a moving window algorithm. So are cumulative growth rates (which determine the probability of progeny being recruited in an empty site).
	 *  The probability of a birth in an empty site is determined by amount of amino acid that reaches that site.   
	 */

	public static void stepWithoutIndividualBasedTraits(Community com)
	{
		int numberOfSpecies = com.getNumberOfSpecies();
		int gridLength = com.getEnvironment().getGridLength();
		ArrayList<ISpecies> speciesList = com.getSpeciesList();
		Environment env = com.getEnvironment();
		double[][][][] propaguleRainGrid = com.getPropaguleRainGrid();

		// System.out.println("time step " + timeStep);
		CommunityUtilsInoculate.checkForInoculations(com);

		// instantiate a stack of grids that gives the competitive values in each location of each species, respectively
		ArrayList<Location3D> toRemoveLocation = new ArrayList<Location3D>();

		ArrayList<Location3D> toAddLocation = new ArrayList<Location3D>();
		ArrayList<ISpecies> toAddCritter = new ArrayList<ISpecies>();

		// com second main determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius
		

		// CommunityUtilsPropaguleRain.fillGrid(com);
		// com second main loop determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius

		// com algorithm scans right across the grid, goes down one line, scans again, and so on (just like reading). It's time complexity is O(n) (where n is the number of microsites) compared to O(n^2) of a trivial moving window algorithm.
		// It works by summing all of the
		// cumulative birth rates in the topmost row, the bottommost row, and everything in between. com is where the last dimension on pos array comes in:
		// 0 is TOP, 1 is MID, and 2 is BOT. when you to the next gid location, your cumulative growth rate is TOPnew + MIDnew + BOTnew. MIDnew is simply MIDnorth + BOTnorth - TOPnew.
		// (where north indicates the position above you). TOPnew can be written TOPwest - TOPwest.leftMost + TOPnew.rightmost. BOTnew can be written BOTwest - BOTwest.leftMost + BOTnew.rightmost.
		// the TOP, MID, and BOT are all recorded.

		for (int i = 0; i < env.getHeight(); i++)
		{
			int envGridIndex = i;
			Random generator = env.getGenerator(i);

			for (int row = 0; row < gridLength; row++)
			{
				for (int col = 0; col < gridLength; col++)
				{
					/*
					 * System.out.println(""); System.out.println(""); System.out.println("");
					 */
					// if it's occupied, pull a random number to see if it dies
					int gridValue = env.getGridValue(row, col, envGridIndex);
					if (gridValue != 0)
					{

						if (generator.nextDouble() < speciesList.get(gridValue - 1).getDeathRate(new Location(row, col)))
						{
							// index it to remove at the end of the time step
							toRemoveLocation.add(new Location3D(row, col, envGridIndex));
						}
						// if it does die, go to the next row,col location
					}
					else
					{
						double[] speciesCompValuesSum = new double[numberOfSpecies];
						for (int s = 0; s < numberOfSpecies; s++)
						{
							speciesCompValuesSum[s] = propaguleRainGrid[envGridIndex][row][col][s];
						}

						Integer winnerIndex = determineEmptySiteWinner(speciesCompValuesSum, generator);
						if (winnerIndex != null)
						{
							ISpecies curSpecies = speciesList.get(winnerIndex);
							Location3D loc = new Location3D(row, col, envGridIndex);
							if (curSpecies.canRecruit(com, new Location(loc.row(), loc.col())))
							{

								toAddCritter.add(curSpecies);
								toAddLocation.add(loc);

							}
						}
					}
				}
			}
		}

		for (int i = 0; i < toRemoveLocation.size(); i++)
		{
			Location3D loc = toRemoveLocation.get(i);

			env.remove(loc);

		}
		// births
		for (int i = 0; i < toAddLocation.size(); i++)
		{
			Location3D loc = toAddLocation.get(i);
			ISpecies tempSpecies = toAddCritter.get(i);

			env.add(loc, tempSpecies.getGridProxy());
		}

		/*UpdateAbundances ua = new UpdateAbundances(com);
		ua.update();*/

		com.updateTimeStepCounter();

		
		//CommunityUtilsStep.stepPrimer(com);
		// CommunityUtilsStep.CMAndDMMovingWindow(com);

	}

	public static void step(Community com) throws Exception
	{
		
		if (com.doesAnySpeciesHaveAnIndividualBasedTrait())
		{
			CommunityUtilsStep.stepWithIndividualBasedTraits(com);
		}
		else
		{
			CommunityUtilsStep.stepWithoutIndividualBasedTraits(com);
		}

		//CommunityUtilsStep.enforceAllTradeOffs(com);
	}

	public static void enforceAllTradeOffs(Community com)
	{

		ArrayList<ISpecies> speciesList = com.getSpeciesList();
		for (int i = 0; i < speciesList.size(); i++)
		{
			TraitList traitList = speciesList.get(i).getTraitList();
			if (traitList != null)
			{
				traitList.enforceAllTradeOffs();
			}
		}
	}

	public static void updateAllOldTraitArchives(Community com)
	{

		ArrayList<ISpecies> speciesList = com.getSpeciesList();
		for (int i = 0; i < speciesList.size(); i++)
		{
			TraitList traitList = speciesList.get(i).getTraitList();
			if (traitList != null)
			{
				traitList.checkForOldTraitUpdate(com);
			}
		}
	}

	public static void step(Community com, int numSteps) throws Exception
	{
		for (int i = 0; i < numSteps; i++)
		{
			com.individualBasedHousekeeping();
			if (com.doesAnySpeciesHaveAnIndividualBasedTrait())
			{
				CommunityUtilsStep.stepWithIndividualBasedTraits(com);
			}
			else
			{
				CommunityUtilsStep.stepWithoutIndividualBasedTraits(com);
			}
			//CommunityUtilsStep.enforceAllTradeOffs(com);
		}
	}
	
	public static void stepThroughTime(Community com, int time) throws Exception
	{
		
		int numSteps = (int) Math.round(time/com.getDt());
		for (int i = 0; i < numSteps; i++)
		{
			
			if (com.doesAnySpeciesHaveAnIndividualBasedTrait())
			{
				CommunityUtilsStep.stepWithIndividualBasedTraits(com);
			}
			else
			{
				CommunityUtilsStep.stepWithoutIndividualBasedTraits(com);
			}
			//CommunityUtilsStep.enforceAllTradeOffs(com);
		}
	}
	
	public static void stepAndScrambleThroughTime(Community com, int time) throws Exception
	{
		
		int numSteps = (int) Math.round(time/com.getDt());
		for (int i = 0; i < numSteps; i++)
		{
			com.individualBasedHousekeeping();
			if (com.doesAnySpeciesHaveAnIndividualBasedTrait())
			{
				CommunityUtilsStep.stepWithIndividualBasedTraits(com);
			}
			else
			{
				CommunityUtilsStep.stepWithoutIndividualBasedTraits(com);
			}
			//CommunityUtilsStep.enforceAllTradeOffs(com);
		}
	}

	public static void stepAndScramble(Community com) throws Exception
	{
		
		if (com.doesAnySpeciesHaveAnIndividualBasedTrait())
		{
			CommunityUtilsStep.stepWithIndividualBasedTraits(com);
			Scramble s = new Scramble(com);
			s.scramble();
		}
		else
		{
			CommunityUtilsStep.stepWithoutIndividualBasedTraits(com);
			Scramble s = new Scramble(com);
			s.scramble();
		}
	}

	public static void stepAndScramble(Community com, int numSteps) throws Exception
	{
		for (int i = 0; i < numSteps; i++)
		{
			
			if (com.doesAnySpeciesHaveAnIndividualBasedTrait())
			{
				CommunityUtilsStep.stepWithIndividualBasedTraits(com);
				Scramble s = new Scramble(com);
				s.scramble();
			}
			else
			{
				CommunityUtilsStep.stepWithoutIndividualBasedTraits(com);
				Scramble s = new Scramble(com);
				s.scramble();
			}
			//CommunityUtilsStep.enforceAllTradeOffs(com);
		}
	}

	public static void stepAndMaybeTerminate(Community com, int numSteps, int checkHowOften, ITerminateCondition condition) throws Exception
	{
		for (int i = 0; i < numSteps; i++)
		{

			CommunityUtilsStep.step(com);

			int timeStep = com.getStepCallCounter();
			if (timeStep / checkHowOften != 0 && timeStep % checkHowOften == 0)
			{
				if (condition.shouldTerminate())
				{
					break;
				}

			}
		}
	}
	
	
	public static void stepAndMaybeTerminateThroughTime(Community com, int time, int checkHowOftenTime, ITerminateCondition condition) throws Exception
	{
		int numSteps = (int) Math.round(time/com.getDt());
		int checkHowOften = (int) Math.round(checkHowOftenTime/com.getDt());
		for (int i = 0; i < numSteps; i++)
		{

			CommunityUtilsStep.step(com);

			int timeStep = com.getStepCallCounter();
			if (timeStep / checkHowOften != 0 && timeStep % checkHowOften == 0)
			{
				if (condition.shouldTerminate())
				{
					break;
				}

			}
		}
	}

	/**
	 * executes time sstep but checks every once in a while to see if a species has died out - if the specified species has died-out, the time-stepping is terminated. Increases efficiency in certain cases.
	 * @param numSteps the number of time steps to possibly execute
	 * @param checkHowOften this is the number of time series calls that are executed between checking to see if a species is extinct.
	 * @param speciesIndex the position of the species which is checked to see if it is extinct. 
	 * @return 
	 * @throws Exception 
	 */
	public static void stepAndTerminateIfAnyoneDies(Community com, int numSteps, int checkHowOften, int max) throws Exception
	{

		for (int i = 0; i < numSteps; i++)
		{

			CommunityUtilsStep.step(com);

			int timeStep = com.getStepCallCounter();
			if (timeStep / checkHowOften != 0 && timeStep % checkHowOften == 0)
			{
				int[] abunds = com.getAbundances();
				boolean shouldBreak = false;
				if (abunds[0] > max)
				{
					shouldBreak = true;
				}
				for (int j = 0; j < abunds.length; j++)
				{
					if (abunds[j] == 0)
					{
						shouldBreak = true;
						break;
					}
				}
				if (shouldBreak)
				{
					break;
				}

			}
		}
	}

}
