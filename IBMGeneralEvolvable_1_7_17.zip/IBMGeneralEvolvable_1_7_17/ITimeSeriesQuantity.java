import java.io.Serializable;

public interface ITimeSeriesQuantity extends Serializable
{
	// BUT, object must be double or double[] or int or int[]
	Object get();
	int getReturnLength();
}
