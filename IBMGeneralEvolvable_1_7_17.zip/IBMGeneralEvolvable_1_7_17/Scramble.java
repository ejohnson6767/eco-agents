import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

public class Scramble implements Serializable
{

	private boolean[] isIB;
	private ArrayList<ArrayList<double[]>> allTraitsAllSpecies;
	private ArrayList<int[]> indexes;
	private int numSpecies;
	private int[] abundanceCounter;
	//private Random shuffleSpeciesOrderGen = new Random();
	private Random generator;

	protected ISpecies curSpecies;

	protected Environment env;
	protected int curSpeciesHomeIndex;
	protected int curSpeciesValue;
	protected int curSpeciesIndex;
	protected int gridLength;
	protected Community com;
	private Random queueGenerator;

	public Scramble(Community com)
	{
		// set up setable instance variables. Other instance variables will be instantiated and changed during the scramble method
		this.com = com;
		this.env = com.getEnvironment();
		this.gridLength = this.env.getGridLength();
		this.numSpecies = this.com.getNumberOfSpecies();
		this.queueGenerator = this.com.env.getGenerator(this.com.getSpeciesList().get(0).getHomeGridIndex());
	}

	// shuffles the order in which species are re-added to the grid. Fisher-Yates
	private int[] shuffleSpeciesOrderArray(int length)
	{
		int[] array = new int[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = i;
		}

		int index;
		for (int i = array.length - 1; i > 0; i--)
		{
			index = this.queueGenerator.nextInt(i + 1);
			if (index != i)
			{
				array[index] ^= array[i];
				array[i] ^= array[index];
				array[index] ^= array[i];
			}
		}
		return array;
	}

	// if there are traits, this shuffles the order in which they are re-added back to the grid. Fisher-Yates
	private int[] shuffleTraitIndexArray(int speciesValue, int length)
	{
		int[] array = new int[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = i;
		}

		int index;
		Random generatorTemp = com.getEnvironment().getGenerator(com.getSpeciesList().get(speciesValue - 1).getHomeGridIndex());
		for (int i = array.length - 1; i > 0; i--)
		{
			index = generatorTemp.nextInt(i + 1);
			if (index != i)
			{
				array[index] ^= array[i];
				array[i] ^= array[index];
				array[index] ^= array[i];
			}
		}
		return array;
	}

	public void scramble()
	{
		this.abundanceCounter = new int[this.numSpecies];
		this.allTraitsAllSpecies = new ArrayList<ArrayList<double[]>>();
		this.indexes = new ArrayList<int[]>();
		this.isIB = new boolean[numSpecies];
		ArrayList<ISpecies> speciesList = this.com.getSpeciesList();
		int[] abundances = this.com.getAbundances();

		for (int i = 0; i < com.getNumberOfSpecies(); i++)
		{
			ISpecies curSpecies = speciesList.get(i);
			if (SpeciesTraitQuestions.isIndividualBased(curSpecies))
			{
				// does the species have any individual based traits? will be used in addCritter method
				isIB[i] = true;
				TraitList tl = curSpecies.getTraitList();
				// get an arraylist of all traits (in a double array) at each location
				allTraitsAllSpecies.add(tl.getTraits());
				// make a random array that defines the order in which traits are added back to the grid
				indexes.add(shuffleTraitIndexArray((i + 1), abundances[i]));
				// make every value 0 in every spatial distribution tracker
				tl.resetAllSpatialDistributionTrackers();
			}
			else
			{
				isIB[i] = false;
				allTraitsAllSpecies.add(null);
				indexes.add(null);
			}
		}

		// get rid of all the critters
		this.env.clearEnvOfCritters();

		// get an array which defines the order in which species are added back to the grid. Should minimalize artifacts of always re-adding species in the same order
		int[] speciesOrder = shuffleSpeciesOrderArray(numSpecies);
		for (int i = 0; i < numSpecies; i++)
		{
			// set up instance variables
			this.curSpeciesIndex = speciesOrder[i];
			this.curSpeciesValue = speciesOrder[i] + 1;
			this.curSpecies = com.getSpeciesList().get(this.curSpeciesIndex);
			this.curSpeciesHomeIndex = this.curSpecies.getHomeGridIndex();
			this.generator = com.getEnvironment().getGenerator(this.curSpeciesHomeIndex);
			addCrittersRandomly(this.isIB[this.curSpeciesIndex], abundances[this.curSpeciesIndex]);
		}
	}

	public void scrambleSomeSpecies(int[] speciesValues)
	{
		int numScrambleSpecies = speciesValues.length;
		this.abundanceCounter = new int[this.numSpecies];
		this.allTraitsAllSpecies = new ArrayList<ArrayList<double[]>>();
		this.indexes = new ArrayList<int[]>();
		this.isIB = new boolean[numScrambleSpecies];
		ArrayList<ISpecies> speciesList = this.com.getSpeciesList();
		int[] abundances = this.com.getAbundances();

		for (int j = 0; j < numScrambleSpecies; j++)
		{
			int speciesValue = speciesValues[j];
			ISpecies curSpecies = speciesList.get(speciesValue-1);
			if (SpeciesTraitQuestions.isIndividualBased(curSpecies))
			{
				// does the species have any individual based traits? will be used in addCritter method
				isIB[j] = true;
				TraitList tl = curSpecies.getTraitList();
				// get an arraylist of all traits (in a double array) at each location
				allTraitsAllSpecies.add(tl.getTraits());
				// make a random array that defines the order in which traits are added back to the grid
				indexes.add(shuffleTraitIndexArray(speciesValue, abundances[speciesValue -1]));
				// make every value 0 in every spatial distribution tracker
				tl.resetAllSpatialDistributionTrackers();
			}
			else
			{
				isIB[j] = false;
				allTraitsAllSpecies.add(null);
				indexes.add(null);
			}

			//System.out.println("about to remove");
			RemoveCritters rc = new RemoveCritters(this.com, speciesValue);
			rc.removeCritters(abundances[speciesValue - 1]);

		}

		// get an array which defines the order in which species are added back to the grid. Should minimalize artifacts
		int[] speciesOrder = shuffleSpeciesOrderArray(numScrambleSpecies);

		for (int i = 0; i < numScrambleSpecies; i++)
		{
			// set up instance variables
			this.curSpeciesIndex = speciesValues[speciesOrder[i]]-1;
			this.curSpeciesValue = this.curSpeciesIndex + 1;
			//System.out.println("scrambling species " + this.curSpeciesValue);
			this.curSpecies = com.getSpeciesList().get(this.curSpeciesIndex);
			this.curSpeciesHomeIndex = this.curSpecies.getHomeGridIndex();
			this.generator = com.getEnvironment().getGenerator(this.curSpeciesHomeIndex);
			boolean ib = this.isIB[speciesOrder[i]];
			addCrittersRandomly(ib, abundances[this.curSpeciesIndex]);
		}
	}


	public void addCrittersRandomly(boolean ib, int invadersToAdd)
	{
		for (int i = 0; i < invadersToAdd; i++)
		{
			addCritterRandomly(ib);
		}
	}


	public void addCritterRandomly(boolean ib)
	{
		int k = 0;
		while (true)
		{
			int randRow = this.generator.nextInt(this.gridLength);
			int randCol = this.generator.nextInt(this.gridLength);

			Location newLoc = new Location(randRow, randCol);
			Location3D newLoc3D = new Location3D(randRow, randCol, this.curSpeciesHomeIndex);
			boolean added = false;

			if (k < 1000)
			{
				added = tryToAddCritter(ib, newLoc3D, newLoc);
			}

			if (added)
			{
				break;
			}

			k++;
		}
	}

	public boolean tryToAddCritter(boolean ib, Location3D newLoc3D, Location newLoc)
	{
		boolean added = false;
		if (this.curSpecies.canRecruit(this.com, newLoc))
		{
			addCritter(ib, newLoc3D, newLoc);
			added = true;
		}
		return added;
	}

	

	public void addCritter(boolean ib, Location3D newLoc3D, Location newLoc)
	{

		// if the species has individual based traits
		if (ib)
		{
			//System.out.println("TRAITS: " + this.curSpeciesIndex);
			// get index for the traits that we're adding back to the trait's spatial distribution trackers
			//System.out.println("curSpeciesIndex: " + this.curSpeciesIndex);
			//System.out.println("this.abundancecounter: " + this.abundanceCounter[this.curSpeciesIndex]);

			int randIndex = this.indexes.get(this.curSpeciesIndex)[this.abundanceCounter[this.curSpeciesIndex]];
			// get those traits!
			double[] traitValues = this.allTraitsAllSpecies.get(this.curSpeciesIndex).get(randIndex);
			// add critter to the grid
			this.env.add(newLoc3D, this.curSpeciesValue);
			// add those traits back
			this.curSpecies.getTraitList().addToAllSpatialDistributionTrackerForScrambling(newLoc, traitValues);

			// increment the abundance counter. Helps us know what traits to add
			this.abundanceCounter[this.curSpeciesIndex]++;

		}
		else
		{
			// if there aren't any traits involved, just add the critter to the grid
			this.env.add(newLoc3D, this.curSpeciesValue);
		}

	}

}
