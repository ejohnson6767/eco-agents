import java.io.Serializable;
import java.util.ArrayList;

public class EmpiricalFitness implements Serializable
{

	private Community com;
	private Environment env;
	private ArrayList<ISpecies> speciesList;
	private int gridLength;
	private int[][][] beforeGrids;
	private int[][][] afterGrids;

	public EmpiricalFitness(Community com)
	{
		this.com = com;
		this.env = com.getEnvironment();
		this.gridLength = this.env.getGridLength();
		this.speciesList = this.com.getSpeciesList();
		giveAllSpeciesDummyTrait();
		communicateWithDummyTrait();
		// initialize aftergrids in the beginning because it is will be reset as beforegrids, see make beforegrids
		this.afterGrids = new int[this.com.getNumberOfSpecies()][this.gridLength][this.gridLength];

	}

	public void giveAllSpeciesDummyTrait()
	{
		for (ISpecies s : this.speciesList)
		{
			s.addDummyTrait(new DummyTrait());
		}
	}

	public void communicateWithDummyTrait()
	{
		for (ISpecies s : this.speciesList)
		{
			s.getDummyTrait().setIBFitness(this);
		}
	}

	public void makeAllSpeciesIB() throws Exception
	{
		for (ISpecies s : this.speciesList)
		{
			s.getDummyTrait().startBeingIndividualBased();
		}
	}

	public void makeAllSpeciesNOTIB() throws Exception
	{
		for (ISpecies s : this.speciesList)
		{
			s.getDummyTrait().stopBeingIndividualBased();
		}
	}

	public void resetBeforeGrid()
	{
		this.beforeGrids = new int[this.com.getNumberOfSpecies()][this.gridLength][this.gridLength];
	}

	public void makeBeforeGrids()
	{
		for (int i = 0; i < env.getHeight(); i++)
		{
			for (int row = 0; row < gridLength; row++)
			{
				for (int col = 0; col < gridLength; col++)
				{
					int gridValue = this.env.getGridValue(row, col, i);
					if (gridValue != 0)
					{
						this.beforeGrids[gridValue - 1][row][col] = 1;
					}
				}
			}
		}
		
		int numSpecies = this.com.getNumberOfSpecies();
		for (int i = 0; i < numSpecies; i++)
		{
			for (int row = 0; row < gridLength; row++)
			{
				for (int col = 0; col < gridLength; col++)
				{
					this.afterGrids[i][row][col] = this.beforeGrids[i][row][col];
				}
			}
		}
		
	}
	
	public void beforeSteppingStuff() throws Exception
	{
		resetBeforeGrid();
		makeBeforeGrids();
		makeAllSpeciesIB();
	}

	public void addToAfterGrid(int speciesValue, Location parentLoc)
	{
		//System.out.println("adding to after grid");
		this.afterGrids[speciesValue - 1][parentLoc.row()][parentLoc.col()] += 1;
	}

	public double[][][] getFitnessGrids()
	{
		double dt = this.com.getDt();

		int numSpecies = this.com.getNumberOfSpecies();
		double[][][] lambdaGrids = new double[numSpecies][this.gridLength][this.gridLength];
		for (int i = 0; i < numSpecies; i++)
		{

			for (int row = 0; row < gridLength; row++)
			{
				for (int col = 0; col < gridLength; col++)
				{
					int before = this.beforeGrids[i][row][col];
					if (before == 1)
					{
						int after = this.afterGrids[i][row][col];
						double lambda = (after / (double) before);
						if (lambda != 0)
						{
							lambdaGrids[i][row][col] = CorrectLambdaWithDt.correct(lambda, dt);
						}
						else
						{
							lambdaGrids[i][row][col] = lambda;
						}
					}
					else
					{
						lambdaGrids[i][row][col] = 0 / (double) 0;
					}
				}
			}
		}
		return lambdaGrids;
	}

	public double[][] getFitnessGrid(int speciesValue)
	{
		double dt = this.com.getDt();
		int i = speciesValue - 1;
		double[][] lambdaGrid = new double[this.gridLength][this.gridLength];

		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				int before = this.beforeGrids[i][row][col];
				if (before != 0)
				{
					int after = this.afterGrids[i][row][col];
					double lambda = (after / (double) before);
					if (lambda != 0)
					{
						//System.out.println("lambda is not zero: " + lambda + ", corrected: " + CorrectLambdaWithDt.correct(lambda, dt));
						lambdaGrid[row][col] = CorrectLambdaWithDt.correct(lambda, dt);
					}
					else
					{
						//System.out.println("lambda is zero: " + lambda);
						lambdaGrid[row][col] = lambda;
					}
				}
				else
				{
					
					lambdaGrid[row][col] = 0 / (double) 0;
				}
			}
		}

		return lambdaGrid;
	}

	public double getFitnessAverage(int speciesValue)
	{
		double[][] fitGrid = getFitnessGrid(speciesValue);
		double total = 0;
		int counter = 0;

		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				if (!Double.isNaN(fitGrid[row][col]))
				{
					total += fitGrid[row][col];
					counter++;
				} 
			}
		}
		return total / (double) counter;
	}

	public double[] getFitnessAverages()
	{
		int numSpecies = this.com.getNumberOfSpecies();
		double[] fitAverages = new double[numSpecies];
		for (int i = 0; i < numSpecies; i++)
		{
			fitAverages[i] = getFitnessAverage((i + 1));
		}
		return fitAverages;
	}

	public void removeFromAfterGrid(int speciesValue, Location loc)
	{
		this.afterGrids[speciesValue - 1][loc.row()][loc.col()] -= 1;
		
	}

}
