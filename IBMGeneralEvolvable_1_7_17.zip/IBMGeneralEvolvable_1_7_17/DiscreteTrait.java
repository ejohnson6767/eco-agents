import java.io.Serializable;

public class DiscreteTrait extends ContinuousTrait implements Serializable
{
	protected int[] discreteHistogram;
	protected int maxDiscreteTraitValues = 5;

	public DiscreteTrait(IMutationFunction mf)
	{
		super(mf);
	}

	public boolean isContinuous()
	{
		return false;
	}

	public boolean isDiscrete()
	{
		return true;
	}

	public void fillDiscreteHistogram()
	{
		this.discreteHistogram = new int[this.maxDiscreteTraitValues];

		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				int gridValue = this.env.getGridValue(row, col, this.envGridIndex);
				if (gridValue == speciesValue)
				{

					int val = (int) this.spatialDistributionTracker[row][col];

					//System.out.println("val is " + val + " max val is " + this.maxDiscreteTraitValues);
					while (val >= this.maxDiscreteTraitValues)
					{
						biggerMaxDiscreteTraitValues((int) Math.round(1.5 * this.maxDiscreteTraitValues));
					}

					this.discreteHistogram[val]++;

				}
			}
		}
		//System.out.println("discrete histogram length is " + this.discreteHistogram.length);
	}

	public void biggerMaxDiscreteTraitValues(int newMaxDALength)
	{
		//System.out.println("old maxdaLength is " + this.maxDiscreteTraitValues);
		//System.out.println("new maxdaLength is " + newMaxDALength);
		int[] temp = new int[newMaxDALength];

		for (int p = 0; p < this.maxDiscreteTraitValues; p++)
		{
			temp[p] = this.discreteHistogram[p];
		}

		this.discreteHistogram = temp;
		this.maxDiscreteTraitValues = newMaxDALength;
	}

	public int[] getDiscreteHistogram()
	{
		return this.discreteHistogram;
	}

	
	public int getMaxTraitValue()
	{
		// fillDiscreteHistogram();
		// System.out.println("get max dispersal value - discrete histogram length is " + this.discreteHistogram.length);

		int toReturn = this.discreteHistogram.length;
		for (int i = this.discreteHistogram.length - 1; i > -1; i--)
		{
			//System.out.println("trying dispersal value " + i + " - " + this.discreteHistogram[i] + " critters");
			if (this.discreteHistogram[i] != 0)
			{
				toReturn = i;
				break;
			}
		}
		return toReturn;
	}
	
	
	public int getMinTraitValue()
	{
		// fillDiscreteHistogram();
		// System.out.println("get max dispersal value - discrete histogram length is " + this.discreteHistogram.length);

		int toReturn = 0;
		for (int i = 0; i < this.discreteHistogram.length ; i++)
		{
			//System.out.println("trying dispersal value " + i + " - " + this.discreteHistogram[i] + " critters");
			if (this.discreteHistogram[i] != 0)
			{
				toReturn = i;
				break;
			}
		}
		return toReturn;
	}
	
}
