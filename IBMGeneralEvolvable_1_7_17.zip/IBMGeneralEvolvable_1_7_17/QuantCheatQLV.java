import java.io.Serializable;

public class QuantCheatQLV implements IQuantCheatQLV, Serializable
{

	protected ISpecies speciesOwner;
	protected Community com;
	protected Environment env;
	protected int gridLength;
	protected double[][] spatialDistributionTracker;
	protected int envGridIndex;
	protected int speciesValue;
	private double q;

	public QuantCheatQLV(double q)
	{
		this.q = q;
	}
	
	public double getQ(Location loc)
	{
		return this.q;
	}
	@Override
	public double getQ()
	{
		return this.q;
	}

	
	public void setQ(double q)
	{
		this.q = q;
	}

	@Override
	public boolean isIndividualBased()
	{
		return false;
	}
	
	public void setSpeciesOwner(ISpecies species)
	{
		this.speciesOwner = species;
		
	}
	public void setupAfterCommunityIsCreated(Community com)
	{
		this.com = com;
		this.env = com.getEnvironment();
		this.gridLength = this.com.getEnvironment().getGridLength();
		this.spatialDistributionTracker = new double[gridLength][gridLength];
		this.envGridIndex = this.speciesOwner.getHomeGridIndex();
		this.speciesValue = this.speciesOwner.getGridProxy();
	}
	

	public double[][] getSpatialDistributionTracker()
	{
		System.out.println("GETTING SPATIAL DISTRIBUTION TRACKER");
		System.out.println("GRIDLENGTH IS " + this.gridLength);
		double[][] sdt = new double[this.gridLength][this.gridLength];
		for (int row = 0; row < gridLength; row++)
		{
			for (int col = 0; col < gridLength; col++)
			{
				if(this.env.getGridValue(row, col, this.envGridIndex) == this.speciesValue)
				{
					System.out.println("effect val is " + this.q);
					sdt[row][col] = this.q;
				}
			}
		}
		
		return sdt;
	}

	
	
}
